export type Band = "Excellent" | "Good" | "Watch" | "At Risk" | "Critical";
export type RiskLevel = "Low" | "Medium" | "High" | "Unknown" | "None";

export interface VendorRow {
  vendor_id: string; name: string; country: string; region: string; tier: string; status: string;
  category_id: string; category: string; overall: number; delivery: number; quality: number; cost: number;
  lead_time: number; band: Band; trend: string | null; change_3m: number | null; slope: number | null;
  is_deteriorating: boolean; rank: number; risk_level: RiskLevel; risk_probability: number | null;
  is_anomaly: boolean; data_sufficient: boolean; external_risk?: RiskLevel;
}

export interface Health {
  status: string; app: string; demo_mode: boolean; data_version: string; latest_period: string; auth_mode: string;
  components: {
    postgres: { ok: boolean; vendors: number };
    neo4j: { ok: boolean; host: string; error: string };
    chromadb: { ok: boolean; chunks: number; policy_version: string };
    llm: { ok: boolean; provider: string; mode: string; detail?: string; last_checked?: string | null };
  };
}

export interface Filters {
  periods: string[]; categories: { id: string; name: string }[]; regions: string[]; statuses: string[]; bands: Band[];
}

export interface TrendPoint {
  period: string; overall?: number; avg?: number; delivery: number; quality: number; cost: number; lead_time: number;
  band?: Band; category_avg?: number; on_time_pct?: number; defect_rate_pct?: number; invoice_variance_pct?: number; lead_time_cv?: number;
  on_time_delivery_pct?: number | null; invoice_accuracy_pct?: number | null; avg_lead_time_days?: number | null; sla_compliance_pct?: number | null;
}

export interface DashboardSummary {
  period: string;
  kpis: { total_vendors: number; avg_score: number; avg_score_change: number; excellent: number; good: number; watch: number;
          at_risk: number; critical: number; deteriorating: number; high_risk: number };
  band_counts: { band: Band; count: number }[];
  distribution: { bucket: string; from: number; to: number; mid: number; count: number; band: Band }[];
  trend: TrendPoint[];
  score_model?: { weights: Record<string, number>; component_avg: Record<string, number | null> };
  top_vendors: VendorRow[]; bottom_vendors: VendorRow[]; deteriorating_vendors: VendorRow[]; spotlight: VendorRow | null;
  operational: Operational | null;
  category_performance: { category_id: string; category: string; vendors: number; avg: number; delivery: number; quality: number;
                          cost: number; lead_time: number; at_risk: number }[];
}

export interface Operational {
  spend: number; spend_at_risk: number; spend_at_risk_pct: number | null; on_time_delivery_pct: number | null; defect_rate_pct: number | null;
  invoice_accuracy_pct: number | null; avg_lead_time_days: number | null; avg_lead_time_variance_days: number | null; avg_overrun_pct: number | null;
  sla_compliance_pct: number | null; sla_breaches: number; sla_vendors_ok?: number; sla_vendors?: number; pos_completed: number; delta: Record<string, number | null>;
  window: { start: string; end: string }; open_po_count: number; open_po_value: number; open_po_value_at_risk: number;
  pending_approvals: number; invoice_tolerance_pct: number;
}

export interface Commercials {
  window: { start: string; end: string }; spend: number; open_po_value: number; max_share_pct: number; concentration_limit_pct: number; policy: string;
  category_share: { category_id: string; category: string; spend: number; share_pct: number; over_limit: boolean }[];
}

export interface Breakdown {
  delivery: number; quality: number; cost: number; lead_time: number; overall: number; band: Band;
  weights: Record<string, number>; contributions: Record<string, number>; points_lost: Record<string, number>;
  data_sufficient: boolean; model_version: string;
}

export interface Driver {
  component: string; label: string; score: number; weighted_points_lost: number; change: number;
  weighted_change: number; direction: "up" | "down" | "flat"; impact: "negative" | "positive" | "neutral";
}

export interface Kpis {
  delivery: { total_pos: number; on_time_pos: number; late_pos: number; on_time_pct: number; avg_delay_days: number;
              max_delay_days: number; critical_pos: number; critical_late_pos: number; avg_lateness_days: number };
  quality: { inspections: number; failed_inspections: number; inspected_qty: number; defect_qty: number; rejected_qty: number;
             defect_rate_pct: number; rejection_rate_pct: number; inspection_failure_rate_pct: number;
             top_rejection_reasons: { reason: string; count: number }[] };
  cost: { invoices: number; po_value: number; invoice_value: number; variance_amount: number; variance_pct: number;
          avg_cost_variance_pct: number; benchmark_variance_pct: number; disputed_invoices: number };
  lead_time: { records: number; avg_promised_days: number; avg_actual_days: number; avg_variance_days: number;
               std_dev_days: number; coefficient_of_variation: number; avg_overrun_pct: number; consistency_score: number };
}

export interface ScoreDetail {
  vendor_id: string; period: string; breakdown: Breakdown; kpis: Kpis; previous_period: string; previous_breakdown: Breakdown;
  drivers: Driver[]; trend: { direction: string; slope_per_month: number; change_3m: number; change_6m: number; peak_score: number;
                              drop_from_peak: number; is_deteriorating: boolean };
  benchmark: { overall: number; delivery: number; quality: number; cost: number; lead_time: number; vendors: number };
  data_sufficient: boolean;
}

export interface Contract {
  contract_id: string; contract_type: string; start_date: string; end_date: string; sla_id: string; sla_otd_target_pct: number;
  sla_max_defect_rate_pct: number; sla_max_invoice_variance_pct: number; payment_terms_days: number; penalty_clause: string; exclusivity: boolean;
}

export interface VendorProfile {
  vendor_id: string; name: string; country: string; region: string; city: string; port: string; tier: string; status: string;
  category_id: string; category: string; onboarded_date: string; annual_capacity_units: number; sustainability_rating: string;
  products: { product_id: string; name: string; category: string; is_critical: boolean; is_primary_source: boolean }[];
  categories: string[]; contract: Contract | null;
}

export interface SlaCheck { metric: string; actual: number; target: number; operator: string; unit: string; status: "met" | "breached"; sla_id: string }

export interface Vendor360 {
  profile: VendorProfile; score: ScoreDetail; sla_compliance: SlaCheck[];
  rank: { overall: number; of: number; in_category: number; category_size: number };
  commercials: Commercials;
  transactions: {
    purchase_orders: { po_id: string; product: string; po_date: string; promised_date: string; delivered_date: string | null;
                       days_late: number | null; value: number; status: string; is_critical: boolean }[];
    quality_issues: { inspection_id: string; po_id: string; date: string; inspected_qty: number; defect_qty: number; rejected_qty: number;
                      defect_rate_pct: number; reason: string }[];
    invoice_variance: { invoice_id: string; po_id: string; date: string; po_value: number; invoice_value: number; variance_amount: number;
                        variance_pct: number; status: string }[];
    open_pos: { count: number; value: number };
  };
}

export interface RiskDriver { type: string; label?: string; feature?: string; value?: number; contribution?: number; method?: string; detail?: string; robust_z?: number }

export interface VendorRisk {
  performance: { score: number; band: Band };
  internal: { risk_level: RiskLevel; risk_probability: number | null; anomaly_score: number; is_anomaly: boolean; drivers: RiskDriver[];
              model_version: string; model: { credible: boolean; label_definition: string; metrics: Record<string, number>; reason: string } };
  external: { external_risk: RiskLevel; events: { event_id: string; title: string; severity: string; event_type: string; expected_delay_days: number }[];
              exposure: { open_pos: number; open_value: number; critical_pos_at_risk: number; pos_at_risk: number } | null };
}

export interface Alternative extends VendorRow {
  fit_score: number; product_overlap_pct: number; shared_products: number; shared_product_names: string[]; graph_hops: number;
  eligible: boolean; eligibility_issues: string[]; score_delta_vs_incumbent: number;
}

export interface Alternatives {
  vendor: VendorRow; alternatives: Alternative[]; candidates_considered: number; graph_source: string; method: string; policy_constraints: string[];
}

export interface EngineDecision {
  stage: number; action: string; title: string; policy_basis: string; triggers: string[]; steps: string[];
  needs_backup_supplier: boolean; critical_dependency: boolean; requires_approval: boolean; approver: string; policy_refs: string[];
  alternatives: Alternative[];
}

export interface RecommendationRecord {
  id: number; vendor_id: string; action: string; title: string; rationale: string[]; alternatives: Partial<Alternative>[];
  evidence: { id: string; title: string; source: string }[]; policy_refs: string[]; confidence: number; requires_approval: boolean;
  status: string; governance: { status: string; checks: GovCheck[]; approval_reason: string | null }; source: string; request_id: string;
  created_by: string; created_at: string; decided_by: string | null; decided_at: string | null; decision_note: string | null;
}

export interface GraphNode { id: string; label: string; type: string; primary?: boolean; critical?: boolean }
export interface Relationships {
  neighbourhood: { source: string; nodes: GraphNode[]; edges: { from: string; to: string; type: string }[] };
  dependency: { source: string; dependency_level: string; products: { product_id: string; product: string; category: string; is_critical: boolean;
                is_primary_source: boolean; alt_sources: number; open_pos: number; open_value: number }[];
                categories: { category: string; products: number; primary_source_for: number; open_pos: number }[] };
}

export interface Evidence { id: string; kind: string; title: string; value: unknown; source: string; priority?: number; ref?: string }
export interface GovCheck { check: string; passed: boolean; detail: string }
export interface TraceStep { agent: string; action: string; tools: string[]; sources: string[]; status: string; duration_ms: number; detail: string }

export interface CopilotResponse {
  request_id: string; session_id: string; question: string; intent: string; intent_method: string; vendor_id: string | null;
  vendor_name: string | null; answer: string; reasoning: string[]; cited_evidence: string[]; mode: string; model: string | null;
  fallback_reason: string | null; jev: { raw_tokens: number; compressed_tokens: number; saved_tokens: number; dropped: string[]; items: number } | null;
  metrics: { label: string; value: number | string | null; unit: string; band?: Band; detail?: string }[];
  evidence: Evidence[];
  sources: { id: string; document_id: string; title: string; section: string; clause: string; policy_version: string; score: number; snippet: string }[];
  graph_evidence: { source: string; relationships: unknown; dependency: Relationships["dependency"] | null } | null;
  recommendation: (EngineDecision & { id: number | null; status: string; vendor_id: string }) | null;
  portfolio: { vendors: VendorRow[]; count: number } | null;
  confidence: number; confidence_label: string;
  governance: { status: string; checks: GovCheck[]; confidence: number; unsupported_claims: string[]; requires_approval: boolean;
                approval_reason: string | null; rejected_llm_claims?: string[] };
  agent_trace: TraceStep[]; llm_calls: { task: string; model: string; tier: string; status: string; reason: string }[];
  guardrails: string[]; suggested_followups: string[]; latency_ms: number;
  cache: { semantic_hit: boolean; similarity: number; matched_question?: string };
  budget?: { llm_calls: number; max_llm_calls: number; tokens_used: number; token_budget: number };
  cost?: { cost_usd: number; cost_gbp: number; tokens: number; model_calls: number };
  ai_written?: boolean;
}

export interface KnowledgeDoc {
  document_id: string; title: string; document_type: string; category: string; policy_version: string; effective_date: string;
  source: string; file: string; sections?: { section: string; clause: string }[];
}
export interface KnowledgeHit { id: string; text: string; metadata: KnowledgeDoc & { section: string; clause: string }; similarity: number; score: number }

export interface ExternalEvent {
  event_id: string; event_type: string; title: string; description: string; affected_countries: string[]; affected_ports: string[];
  severity: string; detected_at: string; expected_duration_days: number; expected_delay_days: number; source: string;
  impact?: { vendors: number; high_risk_vendors: number; open_pos: number; critical_pos_at_risk: number; open_value: number; products: number; categories: number };
}

// ---------------------------------------------------------------- Business value (GET /value/benefits)
export interface ValueLever { key: string; type: string; lever: string; baseline: string; assumption: string; annual_gbp: number; hours?: number; note?: string }
export interface ValueAssumption { key: string; label: string; value: number; applied: number; min: number; max: number; scaled_by_scenario: boolean }
export interface ValueBenefits {
  scenario: string; scenarios: string[]; currency: string; window: { from: string; to: string };
  baseline: { spend_gbp: number; vendors: number; high_risk_vendors: number; [k: string]: number };
  levers: ValueLever[]; risk_mitigation: ValueLever; total_annual_gbp: number; spend_share_pct: number;
  run_cost_annual: { infrastructure_gbp: number; ai_usage_gbp: number; support_gbp: number; total_gbp: number };
  implementation_cost_gbp: number; first_year_roi_pct: number | null; roi_multiple: number | null; payback_months: number | null;
  operational: { key: string; label: string; value: number; unit: string; standard: string; detail: string; improved: number | null }[];
  other_benefits: { benefit: string; detail: string }[]; assumptions: ValueAssumption[]; method: string;
}
