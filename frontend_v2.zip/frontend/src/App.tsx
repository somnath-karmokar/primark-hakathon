import { Route, Routes } from "react-router-dom";
import type * as React from "react";
import { Loader2, Lock } from "lucide-react";
import { useAuth } from "@/lib/auth";
import LoginPage from "@/pages/LoginPage";
import GuardrailsPage from "@/pages/GuardrailsPage";
import TrustCentrePage from "@/pages/TrustCentrePage";
import FinOpsPage from "@/pages/FinOpsPage";
import AppShell from "@/layouts/AppShell";
import DashboardPage from "@/pages/DashboardPage";
import VendorsPage from "@/pages/VendorsPage";
import Vendor360Page from "@/pages/Vendor360Page";
import AnalyticsPage from "@/pages/AnalyticsPage";
import ComparePage from "@/pages/ComparePage";
import CopilotPage from "@/pages/CopilotPage";
import RecommendationsPage from "@/pages/RecommendationsPage";
import KnowledgePage from "@/pages/KnowledgePage";
import GovernancePage from "@/pages/GovernancePage";
import SettingsPage from "@/pages/SettingsPage";
import RiskIntelPage from "@/pages/RiskIntelPage";
import ModelLabPage from "@/pages/ModelLabPage";
import { EmptyState } from "@/components/domain";

function Allowed({ menu, children }: { menu: string; children: React.ReactNode }) {
  const { sees } = useAuth();
  return sees(menu) ? <>{children}</> : (
    <EmptyState icon={Lock} title="This page isn't part of your role"
      hint="Ask a procurement administrator if you need access. Use the menu on the left to see what's available to you." />
  );
}

export default function App() {
  const { user, ready } = useAuth();
  if (!user && !ready) return <div className="flex min-h-screen items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-brand-500" /></div>;
  if (!user) return <LoginPage />;
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route index element={<Allowed menu="dashboard"><DashboardPage /></Allowed>} />
        <Route path="vendors" element={<Allowed menu="vendors"><VendorsPage /></Allowed>} />
        <Route path="vendors/:id" element={<Allowed menu="vendor360"><Vendor360Page /></Allowed>} />
        <Route path="analytics" element={<Allowed menu="insights"><AnalyticsPage /></Allowed>} />
        <Route path="compare" element={<Allowed menu="compare"><ComparePage /></Allowed>} />
        <Route path="copilot" element={<Allowed menu="assistant"><CopilotPage /></Allowed>} />
        <Route path="recommendations" element={<Allowed menu="alternatives"><RecommendationsPage /></Allowed>} />
        <Route path="knowledge" element={<Allowed menu="policies"><KnowledgePage /></Allowed>} />
        <Route path="governance" element={<Allowed menu="approvals"><GovernancePage /></Allowed>} />
        <Route path="settings" element={<Allowed menu="settings"><SettingsPage /></Allowed>} />
        <Route path="risk-intel" element={<Allowed menu="risk_alerts"><RiskIntelPage /></Allowed>} />
        <Route path="model-lab" element={<Allowed menu="models"><ModelLabPage /></Allowed>} />
        <Route path="guardrails" element={<Allowed menu="safety"><GuardrailsPage /></Allowed>} />
        <Route path="trust" element={<Allowed menu="trust"><TrustCentrePage /></Allowed>} />
        <Route path="finops" element={<Allowed menu="finops"><FinOpsPage /></Allowed>} />
        <Route path="*" element={<EmptyState title="Page not found" hint="Use the navigation to continue." />} />
      </Route>
    </Routes>
  );
}
