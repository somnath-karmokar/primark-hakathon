/**
 * AIRA - the AI assistant. One conversation shared by the full page (/copilot) and the floating
 * launcher, so a chat started in one continues in the other. Kept in sessionStorage (per tab).
 */
import * as React from "react";
import { useChat } from "@/hooks/queries";
import type { CopilotResponse } from "@/types/api";

export const AIRA_NAME = "AIRA";
export const AIRA_TAGLINE = "Your AI procurement assistant";

export type Msg = { role: "user"; text: string } | { role: "assistant"; res: CopilotResponse } | { role: "error"; text: string };
const STORE = "vendor360.copilot";

function load(): { session?: string; msgs: Msg[] } {
  try { return JSON.parse(sessionStorage.getItem(STORE) ?? "") as { session?: string; msgs: Msg[] }; } catch { return { msgs: [] }; }
}

interface AiraState {
  msgs: Msg[]; pending: boolean; ask: (q: string) => void; reset: () => void;
  open: boolean; setOpen: (v: boolean) => void;
  /** index of the newest assistant message, bumped on every answer (the full page selects it) */
  lastAnswer: number | null;
}

const Ctx = React.createContext<AiraState | null>(null);

export function AiraProvider({ children }: { children: React.ReactNode }) {
  const init = React.useMemo(load, []);
  const [msgs, setMsgs] = React.useState<Msg[]>(init.msgs ?? []);
  const [session, setSession] = React.useState<string | undefined>(init.session);
  const [open, setOpen] = React.useState(false);
  const [lastAnswer, setLastAnswer] = React.useState<number | null>(null);
  const chat = useChat();

  React.useEffect(() => { try { sessionStorage.setItem(STORE, JSON.stringify({ session, msgs: msgs.slice(-30) })); } catch { /* storage unavailable */ } }, [msgs, session]);

  // Synchronous guards: React state (and chat.isPending) updates asynchronously, so two calls in the same tick -
  // e.g. React StrictMode running a mount effect twice, or a double click - would otherwise both be sent.
  const busy = React.useRef(false);
  const last = React.useRef<{ text: string; at: number }>({ text: "", at: 0 });
  React.useEffect(() => { if (!chat.isPending) busy.current = false; }, [chat.isPending]);   // safety net: never stay stuck

  const ask = React.useCallback((q: string) => {
    const text = q.trim();
    const now = Date.now();
    if (text.length < 3 || busy.current) return;
    if (last.current.text === text && now - last.current.at < 3000) return;   // same question again within 3 s
    busy.current = true;
    last.current = { text, at: now };
    setMsgs((m) => [...m, { role: "user", text }]);
    chat.mutate({ message: text, session_id: session }, {
      onSuccess: (res) => { setSession(res.session_id); setMsgs((m) => { const n: Msg[] = [...m, { role: "assistant", res }]; setLastAnswer(n.length - 1); return n; }); },
      onError: (e) => setMsgs((m) => [...m, { role: "error", text: e instanceof Error ? e.message : "Request failed" }]),
      onSettled: () => { busy.current = false; },
    });
  }, [chat, session]);

  const reset = React.useCallback(() => { setMsgs([]); setSession(undefined); setLastAnswer(null); }, []);
  const value = React.useMemo(() => ({ msgs, pending: chat.isPending, ask, reset, open, setOpen, lastAnswer }), [msgs, chat.isPending, ask, reset, open, lastAnswer]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAira(): AiraState {
  const v = React.useContext(Ctx);
  if (!v) throw new Error("useAira must be used inside <AiraProvider>");
  return v;
}
