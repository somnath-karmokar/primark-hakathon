import * as React from "react";
import { Eye, History, Info, Loader2, PencilLine, Save, X } from "lucide-react";
import { usePolicyHistory, usePolicySource, usePolicyVersion, useSavePolicy, type PolicyInput } from "@/hooks/queries";
import { Markdown } from "@/components/Markdown";
import { LoadingCard } from "@/components/domain";
import { Badge, Button, Card, CardBody, CardHeader, Input, NativeSelect } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";

const TYPES = ["policy", "sla", "standard", "guideline", "contract"];
const TEMPLATE = `# New policy

## XX-1 Purpose
Why this policy exists and who it applies to.

## XX-2 Rule
What must happen, by when, and who approves exceptions.
`;

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="text-[11.5px] font-medium text-ink-600">{label}</span>
      <div className="mt-0.5">{children}</div>
      {hint && <span className="text-[10.5px] text-ink-400">{hint}</span>}
    </label>
  );
}

/** Edit an existing document (id) or create a new one (no id). */
export function PolicyEditor({ id, onDone, onCancel }: { id?: string; onDone: (docId: string, version: string) => void; onCancel: () => void }) {
  const { data: src, isLoading } = usePolicySource(id);
  const save = useSavePolicy();
  const [f, setF] = React.useState<PolicyInput>();
  const [preview, setPreview] = React.useState(false);
  React.useEffect(() => {
    if (id && src && !f) {
      setF({ title: src.meta.title, document_type: src.meta.document_type, category: src.meta.category || "all", effective_date: src.meta.effective_date,
             policy_version: "", markdown: src.markdown, change_note: "" });
    }
    if (!id && !f) setF({ document_id: "", title: "", document_type: "policy", category: "all", effective_date: new Date().toISOString().slice(0, 10),
                          policy_version: "1.0", markdown: TEMPLATE, change_note: "New document" });
  }, [id, src, f]);
  if ((id && isLoading) || !f) return <LoadingCard h="h-[520px]" />;
  const set = (p: Partial<PolicyInput>) => setF({ ...f, ...p });
  const sections = (f.markdown.match(/^##\s+.+$/gm) ?? []).map((h) => h.replace(/^##\s+/, ""));
  const canSave = f.title.trim().length >= 3 && f.change_note.trim().length >= 3 && f.markdown.trim().length >= 50 && sections.length > 0 && (!!id || /^[A-Z][A-Z0-9]{1,7}$/.test(f.document_id ?? ""));

  return (
    <Card>
      <CardHeader title={id ? `Edit ${src?.meta.document_id} · ${src?.meta.title}` : "New policy document"} icon={<PencilLine className="h-4 w-4 text-brand-500" />}
        subtitle={id ? `Current version v${src?.meta.policy_version}${src?.meta.updated_by ? ` · last changed by ${src.meta.updated_by} ${src.meta.updated_at ?? ""}` : ""}` : "Becomes searchable by AIRA as soon as it is saved"}
        action={<Button variant="ghost" size="sm" onClick={onCancel}><X />Cancel</Button>} />
      <CardBody className="space-y-4">
        <div className="grid gap-3 md:grid-cols-12">
          {!id && <div className="md:col-span-2"><Field label="Document ID" hint="e.g. RSP"><Input value={f.document_id} maxLength={8} onChange={(e) => set({ document_id: e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "") })} className="h-8" /></Field></div>}
          <div className={id ? "md:col-span-5" : "md:col-span-3"}><Field label="Title"><Input value={f.title} maxLength={120} onChange={(e) => set({ title: e.target.value })} className="h-8" /></Field></div>
          <div className="md:col-span-2"><Field label="Type"><NativeSelect value={f.document_type} onChange={(e) => set({ document_type: e.target.value })} className="h-8 w-full">{TYPES.map((t) => <option key={t} value={t}>{t}</option>)}</NativeSelect></Field></div>
          <div className="md:col-span-2"><Field label="Category"><Input value={f.category} maxLength={40} onChange={(e) => set({ category: e.target.value })} className="h-8" /></Field></div>
          <div className="md:col-span-3"><Field label="Effective date"><Input type="date" value={f.effective_date} onChange={(e) => set({ effective_date: e.target.value })} className="h-8" /></Field></div>
        </div>

        <div>
          <div className="mb-1 flex items-center justify-between">
            <span className="text-[11.5px] font-medium text-ink-600">Policy text (Markdown) · {sections.length} section{sections.length === 1 ? "" : "s"}</span>
            <div className="inline-flex rounded-lg bg-ink-100/70 p-1">
              {[["Edit", false], ["Preview", true]].map(([l, v]) => (
                <button key={String(l)} onClick={() => setPreview(v as boolean)} className={cn("rounded-md px-2.5 py-0.5 text-[11.5px] font-medium", preview === v ? "bg-white shadow-sm" : "text-ink-600")}>{l as string}</button>))}
            </div>
          </div>
          {preview
            ? <div className="max-h-[48vh] overflow-y-auto rounded-xl border border-ink-100 p-4 scrollbar-thin"><Markdown md={f.markdown} /></div>
            : <textarea value={f.markdown} onChange={(e) => set({ markdown: e.target.value })} spellCheck aria-label="Policy text"
                className="h-[48vh] w-full resize-y rounded-xl border border-ink-200 p-3 font-mono text-[12.5px] leading-relaxed focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-100" />}
          <p className="mt-1 text-[11px] text-ink-500"><Info className="mr-1 inline h-3 w-3 align-[-2px]" />Start each clause with a heading such as <code className="rounded bg-ink-50 px-1">## PP-3.4 Backup suppliers</code> - AIRA quotes and cites clauses by that code. Tables use <code className="rounded bg-ink-50 px-1">| a | b |</code>.</p>
        </div>

        <div className="grid gap-3 md:grid-cols-6">
          <div className="md:col-span-5"><Field label="What changed and why (saved in the audit trail)"><Input value={f.change_note} maxLength={200} onChange={(e) => set({ change_note: e.target.value })} placeholder="e.g. Raised the late-delivery credit cap from 5% to 7% (approved by Head of Buying)" className="h-8" /></Field></div>
          <div className="md:col-span-1"><Field label="New version" hint={id ? `blank = v${bump(src?.meta.policy_version)}` : undefined}><Input value={f.policy_version ?? ""} maxLength={12} onChange={(e) => set({ policy_version: e.target.value })} placeholder={id ? bump(src?.meta.policy_version) : "1.0"} className="h-8" /></Field></div>
        </div>

        {save.isError && <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-[12.5px] text-rose-900">{(save.error as Error).message}</div>}
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-ink-100 pt-3">
          <p className="text-[11.5px] text-ink-500">The old version is kept. AIRA uses the new text immediately.</p>
          <Button variant="brand" disabled={!canSave || save.isPending}
            onClick={() => save.mutate({ id, body: { ...f, policy_version: f.policy_version || undefined } }, { onSuccess: (r) => onDone(r.document_id, r.to_version) })}>
            {save.isPending ? <><Loader2 className="animate-spin" />Saving and re-indexing...</> : <><Save />{id ? "Save new version" : "Create document"}</>}
          </Button>
        </div>
      </CardBody>
    </Card>
  );
}

function bump(v?: string): string {
  const parts = (v ?? "1.0").split(".").map(Number).filter((n) => !Number.isNaN(n));
  if (parts.length === 1) parts.push(0);
  parts[parts.length - 1] += 1;
  return parts.join(".");
}

/** Previous versions of a document, newest first, with a read-only viewer. */
export function PolicyHistory({ id, onClose }: { id: string; onClose: () => void }) {
  const { data, isLoading } = usePolicyHistory(id);
  const [file, setFile] = React.useState<string>();
  const { data: ver, isFetching } = usePolicyVersion(id, file);
  return (
    <Card>
      <CardHeader title={`Version history · ${id}`} subtitle="Every saved change keeps the previous text. Read-only." icon={<History className="h-4 w-4 text-brand-500" />}
        action={<Button variant="ghost" size="sm" onClick={onClose}><X />Close</Button>} />
      <CardBody className="grid gap-4 lg:grid-cols-5">
        <div className="space-y-1.5 lg:col-span-2">
          {isLoading && <LoadingCard h="h-40" />}
          {data && data.versions.length === 0 && <p className="text-[12.5px] text-ink-500">No earlier versions yet - the history starts with the first edit.</p>}
          {data?.versions.map((v) => (
            <button key={v.file} onClick={() => setFile(v.file)} className={cn("w-full rounded-lg border px-3 py-2 text-left text-[12px]", file === v.file ? "border-brand-300 bg-brand-50/50" : "border-ink-100 hover:border-ink-200")}>
              <div className="flex items-center justify-between gap-2"><span className="font-semibold">v{v.version}</span>{v.archived ? <Badge tone="warning">archived</Badge> : <Eye className="h-3.5 w-3.5 text-ink-400" />}</div>
              <div className="text-[11px] text-ink-500">replaced {v.saved_at.replace(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2}).*/, "$1-$2-$3 $4:$5 UTC")}{v.updated_by && ` · edited by ${v.updated_by}`}</div>
              {v.change_note && <div className="mt-0.5 line-clamp-2 text-[11px] text-ink-600">{v.change_note}</div>}
            </button>
          ))}
        </div>
        <div className="lg:col-span-3">
          {!file ? <p className="rounded-xl border border-dashed border-ink-200 p-6 text-center text-[12.5px] text-ink-500">Pick a version to read it.</p>
            : isFetching || !ver ? <LoadingCard h="h-60" />
            : <div className="max-h-[56vh] overflow-y-auto rounded-xl border border-ink-100 p-4 scrollbar-thin"><Markdown md={ver.markdown} /></div>}
        </div>
      </CardBody>
    </Card>
  );
}
