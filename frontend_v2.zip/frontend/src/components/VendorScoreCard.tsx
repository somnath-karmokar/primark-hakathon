import { Link } from "react-router-dom";
import { Clock, Gauge, PoundSterling, ShieldCheck, Truck } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ChartTooltip } from "@/components/domain";
import { Card, CardBody, CardHeader, Tip } from "@/components/ui/primitives";
import { BAND_COLOR, fmt } from "@/lib/utils";
import type { Band, DashboardSummary } from "@/types/api";

/** Bands on the 0-100 scale, lowest first (matches docs/SCORING.md). */
const SCALE: { band: Band; from: number; to: number; action: string }[] = [
  { band: "Critical", from: 0, to: 40, action: "escalate now" },
  { band: "At Risk", from: 40, to: 60, action: "improvement plan" },
  { band: "Watch", from: 60, to: 75, action: "keep an eye on" },
  { band: "Good", from: 75, to: 90, action: "meets expectations" },
  { band: "Excellent", from: 90, to: 100, action: "best in class" },
];

const AREAS = [
  { key: "delivery", label: "Delivery", icon: Truck, what: "On time and in full; late critical orders count extra" },
  { key: "quality", label: "Quality", icon: ShieldCheck, what: "Defects, failed inspections and rejected goods" },
  { key: "cost", label: "Cost", icon: PoundSterling, what: "Invoices matching the order, prices vs benchmark" },
  { key: "lead_time", label: "Lead time", icon: Clock, what: "How reliable and predictable delivery times are" },
] as const;

export function VendorScoreCard({ data }: { data: DashboardSummary }) {
  const k = data.kpis;
  const total = Math.max(1, k.total_vendors);
  const count = (b: Band) => data.band_counts.find((x) => x.band === b)?.count ?? 0;
  const weights = data.score_model?.weights ?? { delivery: 0.3, quality: 0.3, cost: 0.2, lead_time: 0.2 };
  const avg = data.score_model?.component_avg;
  const avgPos = Math.min(100, Math.max(0, k.avg_score));

  return (
    <Card className="mb-5">
      <CardHeader title="Vendor score" icon={<Gauge className="h-4 w-4 text-brand-500" />}
        subtitle={`Out of 100 · recalculated monthly · ${fmt.int(k.total_vendors)} vendors`} />
      <CardBody className="grid gap-6 xl:grid-cols-12">
        {/* ---- how it is calculated */}
        <div className="xl:col-span-5">
          <div className="eyebrow mb-2">How the score is calculated</div>
          <p className="mb-3 text-[12.5px] text-ink-600">Same fixed rules for every vendor - never set by AI.</p>
          <ul className="space-y-2.5">
            {AREAS.map((a) => {
              const w = Math.round((weights[a.key] ?? 0) * 100);
              const v = avg?.[a.key];
              return (
                <li key={a.key} className="flex items-center gap-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-600"><a.icon className="h-4 w-4" /></span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="text-[13px] font-semibold text-ink-900">{a.label} <span className="num font-normal text-ink-500">· {w}% of the score</span></span>
                      {v != null && <Tip content={`Average ${a.label.toLowerCase()} score of the vendors shown`}><span className="num cursor-help text-[12.5px] font-semibold text-ink-800">avg {v.toFixed(1)}</span></Tip>}
                    </div>
                    <div className="mt-1 h-1.5 rounded-full bg-ink-100"><div className="h-1.5 rounded-full bg-brand-500" style={{ width: `${v ?? 0}%` }} /></div>
                    <div className="mt-0.5 truncate text-[11px] text-ink-500" title={a.what}>{a.what}</div>
                  </div>
                </li>
              );
            })}
          </ul>
          <div className="mt-3 rounded-lg bg-ink-50 px-3 py-2 text-[12px] text-ink-700">
            <span className="font-semibold">Score</span> = {AREAS.map((a, i) => <span key={a.key}>{i > 0 && " + "}{a.label} × {Math.round((weights[a.key] ?? 0) * 100)}%</span>)}
          </div>
        </div>

        {/* ---- where vendors stand */}
        <div className="xl:col-span-7">
          <div className="eyebrow mb-2">Where our vendors stand</div>
          <div className="relative pt-9">
            <div className="absolute top-0 -translate-x-1/2 text-center" style={{ left: `${avgPos}%` }}>
              <div className="whitespace-nowrap rounded-md bg-ink-900 px-2 py-0.5 text-[11px] font-semibold text-white">Average {fmt.score(k.avg_score)}</div>
              <div className="mx-auto h-3 w-0.5 bg-ink-900" />
            </div>
            <div className="flex h-4 overflow-hidden rounded-full" role="img" aria-label={`Score scale 0 to 100, average ${fmt.score(k.avg_score)}`}>
              {SCALE.map((s) => <div key={s.band} style={{ width: `${s.to - s.from}%`, backgroundColor: BAND_COLOR[s.band] }} className="border-r-2 border-white last:border-r-0" />)}
            </div>
            <div className="relative mt-1 h-4 text-[10.5px] text-ink-400">
              {[0, 40, 60, 75, 90, 100].map((t) => <span key={t} className="num absolute -translate-x-1/2" style={{ left: `${t}%` }}>{t}</span>)}
            </div>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-5">
            {[...SCALE].reverse().map((s) => {
              const n = count(s.band);
              return (
                <Link key={s.band} to={`/vendors?band=${encodeURIComponent(s.band)}`}
                  className="group rounded-xl border border-ink-100 p-2.5 transition-colors hover:border-brand-300 hover:bg-brand-50/30">
                  <div className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: BAND_COLOR[s.band] }} /><span className="text-[12px] font-semibold text-ink-900">{s.band}</span></div>
                  <div className="num mt-1 font-display text-[22px] font-bold leading-none text-ink-950">{n}</div>
                  <div className="mt-1 text-[11px] text-ink-500"><span className="num">{Math.round((n / total) * 100)}%</span> · {s.from === 90 ? "90-100" : s.from === 0 ? "0-39" : `${s.from}-${s.to - 1}`}</div>
                  <div className="text-[11px] text-ink-500">{s.action}</div>
                </Link>
              );
            })}
          </div>
          <div className="mt-4 flex items-baseline justify-between text-[12px]"><span className="font-medium text-ink-700">How many vendors have each score</span></div>
          <div className="h-[170px]">
            <ResponsiveContainer>
              <BarChart data={data.distribution} margin={{ top: 6, right: 4, left: -22, bottom: 0 }} barCategoryGap={2}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="from" tickLine={false} axisLine={false} tickFormatter={(v) => `${v}`} />
                <YAxis tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip cursor={{ fill: "rgba(0,159,214,0.06)" }} content={<ChartTooltip labelFormatter={(v: number) => `Score ${v}-${v + 4.9}`} valueFormatter={(v: number) => `${v} vendors`} />} />
                <Bar dataKey="count" name="Vendors" radius={[3, 3, 0, 0]}>
                  {data.distribution.map((d) => <Cell key={d.bucket} fill={BAND_COLOR[d.band]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardBody>
    </Card>
  );
}
