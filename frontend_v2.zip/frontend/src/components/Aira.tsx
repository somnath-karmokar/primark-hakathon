import * as React from "react";
import { Link, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUp, CheckCircle2, CircleAlert, Maximize2, RotateCcw, Sparkles, X } from "lucide-react";
import { useHealth, useSuggestions } from "@/hooks/queries";
import { AIRA_NAME, AIRA_TAGLINE, useAira } from "@/lib/aira";
import { useAuth } from "@/lib/auth";
import { cn, fmt, mdSegments } from "@/lib/utils";
import type { CopilotResponse } from "@/types/api";

/** AIRA's face: a friendly robot head with glowing eyes, drawn in SVG so it stays crisp at any size. */
export function AiraFace({ className }: { className?: string }) {
  const id = React.useId().replace(/:/g, "");
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden>
      <defs>
        <radialGradient id={`eye${id}`} cx="50%" cy="50%" r="50%"><stop offset="0%" stopColor="#e6f8ff" /><stop offset="55%" stopColor="#5fd3ff" /><stop offset="100%" stopColor="#009fd6" /></radialGradient>
        <linearGradient id={`head${id}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#ffffff" /><stop offset="100%" stopColor="#dbe7f2" /></linearGradient>
      </defs>
      <line x1="20" y1="11.5" x2="20" y2="6.5" stroke="#ffffff" strokeWidth="1.6" strokeLinecap="round" />
      <circle cx="20" cy="5.2" r="2.1" fill="#7fdcff" className="aira-spark" />
      <rect x="4.2" y="18" width="3.2" height="7" rx="1.6" fill="#ffffff" opacity="0.85" />
      <rect x="32.6" y="18" width="3.2" height="7" rx="1.6" fill="#ffffff" opacity="0.85" />
      <rect x="7" y="11.5" width="26" height="21" rx="9" fill={`url(#head${id})`} />
      <rect x="10.2" y="15.6" width="19.6" height="11.6" rx="5.8" fill="#0f1d30" />
      <circle cx="15.9" cy="21.4" r="2.5" fill={`url(#eye${id})`} className="aira-eye" />
      <circle cx="24.1" cy="21.4" r="2.5" fill={`url(#eye${id})`} className="aira-eye" />
      <path d="M17 29.4 Q20 31 23 29.4" stroke="#0f1d30" strokeWidth="1.3" fill="none" strokeLinecap="round" opacity="0.55" />
    </svg>
  );
}

/** Round gradient avatar used in the launcher, the panel header and next to messages. */
export function AiraAvatar({ size = 36, className }: { size?: number; className?: string }) {
  return (
    <span className={cn("relative inline-flex shrink-0 items-center justify-center rounded-full bg-[radial-gradient(circle_at_30%_25%,#3fc6f5_0%,#009fd6_38%,#0b3a5c_78%,#0f1d30_100%)] shadow-[inset_0_1px_1px_rgba(255,255,255,0.45),0_2px_8px_rgba(0,119,168,0.35)]", className)}
      style={{ width: size, height: size }}>
      <AiraFace className="h-[72%] w-[72%]" />
    </span>
  );
}

function Answer({ text }: { text: string }) {
  return (
    <p className="text-[13px] leading-relaxed text-ink-800">
      {mdSegments(text).map((s, i) => s.kind === "bold" ? <strong key={i}>{s.t}</strong> : s.kind === "em" ? <em key={i}>{s.t}</em>
        : s.kind === "cite" ? <span key={i} className="num mx-0.5 rounded bg-brand-50 px-1 text-[10.5px] font-semibold text-brand-700 ring-1 ring-inset ring-brand-200">{s.t}</span>
        : <React.Fragment key={i}>{s.t}</React.Fragment>)}
    </p>
  );
}

function CompactAnswer({ res, onAsk }: { res: CopilotResponse; onAsk: (q: string) => void }) {
  const conf = Math.round(res.confidence * 100);
  return (
    <div className="rounded-2xl rounded-tl-md border border-ink-100 bg-white p-3 shadow-card">
      {res.mode === "llm" && <span className="mb-1.5 inline-flex items-center gap-1 rounded-md bg-amber-50 px-1.5 py-0.5 text-[10.5px] font-semibold text-amber-800 ring-1 ring-inset ring-amber-200"><Sparkles className="h-3 w-3" />AI-written from checked facts</span>}
      <Answer text={res.answer} />
      {res.metrics.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">{res.metrics.slice(0, 4).map((m) => (
          <span key={m.label} className="inline-flex items-center gap-1 rounded-md bg-ink-50 px-1.5 py-0.5 text-[11px]"><span className="text-ink-500">{m.label}</span>
            <span className="num font-semibold">{typeof m.value === "number" ? (m.unit === "pts" ? fmt.delta(m.value) : Number.isInteger(m.value) ? fmt.int(m.value) : m.value.toFixed(1)) : m.value}</span></span>))}</div>
      )}
      {res.intent.startsWith("portfolio") && res.reasoning.length > 0 && (
        <ol className="mt-2 space-y-1 rounded-lg bg-ink-50/70 p-2 text-[12px] text-ink-800">
          {res.reasoning.slice(0, 10).map((r, i) => <li key={i} className="leading-snug">{r.replace(/\s*\[[A-Z]\d+\]/g, "")}</li>)}
          {res.reasoning.length > 10 && <li className="text-ink-500">+{res.reasoning.length - 10} more - open the full view</li>}
        </ol>
      )}
      {res.recommendation && (
        <div className="mt-2 rounded-lg bg-ink-950 px-2.5 py-2 text-white">
          <div className="text-[9.5px] font-semibold uppercase tracking-wider text-brand-300">Recommended action · step {res.recommendation.stage} of 4</div>
          <div className="text-[12.5px] font-semibold">{res.recommendation.title}</div>
          {res.recommendation.status === "pending_approval" && <div className="mt-0.5 text-[10.5px] text-amber-300">Needs approval before acting</div>}
        </div>
      )}
      <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-ink-100 pt-2 text-[11px] text-ink-500">
        <span>How sure <span className="num font-semibold text-ink-800">{conf}%</span></span>
        <span className="inline-flex items-center gap-1">{res.governance.status === "passed" ? <CheckCircle2 className="h-3 w-3 text-emerald-600" /> : <CircleAlert className="h-3 w-3 text-amber-600" />}{res.governance.status === "passed" ? "Checks passed" : "Check needed"}</span>
        <Link to="/copilot" className="ml-auto font-medium text-brand-600 hover:text-brand-700">See the facts →</Link>
      </div>
      {res.suggested_followups.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">{res.suggested_followups.slice(0, 2).map((q) => (
          <button key={q} onClick={() => onAsk(q)} className="rounded-full border border-ink-200 px-2 py-0.5 text-[11px] text-ink-700 hover:border-brand-300 hover:text-brand-700">{q}</button>))}</div>
      )}
    </div>
  );
}

function Thinking() {
  const steps = ["Understanding your question", "Checking scores and trends", "Reading policies", "Checking every figure"];
  const [i, setI] = React.useState(0);
  React.useEffect(() => { const t = setInterval(() => setI((x) => (x + 1) % steps.length), 900); return () => clearInterval(t); }, [steps.length]);
  return (
    <div className="flex items-center gap-2 rounded-2xl rounded-tl-md border border-brand-100 bg-brand-50/50 px-3 py-2.5 text-[12px] text-brand-800">
      <span className="flex gap-1">{[0, 1, 2].map((d) => <span key={d} className="h-1.5 w-1.5 animate-bounce rounded-full bg-brand-500" style={{ animationDelay: `${d * 140}ms` }} />)}</span>
      {steps[i]}...
    </div>
  );
}

function Panel() {
  const { msgs, pending, ask, reset, setOpen } = useAira();
  const { user } = useAuth();
  const { data: sugg } = useSuggestions();
  const { data: health } = useHealth();
  const aiLive = health?.components.llm.ok ?? true;
  const [input, setInput] = React.useState("");
  const endRef = React.useRef<HTMLDivElement>(null);
  const inputRef = React.useRef<HTMLTextAreaElement>(null);
  React.useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs.length, pending]);
  React.useEffect(() => { inputRef.current?.focus(); }, []);
  const send = (q: string) => { if (q.trim().length >= 3 && !pending) { ask(q); setInput(""); } };
  const first = (user?.display_name ?? "").split(" ")[0];

  return (
    <motion.div role="dialog" aria-label={`${AIRA_NAME} chat`} initial={{ opacity: 0, y: 16, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 16, scale: 0.97 }}
      transition={{ type: "spring", stiffness: 380, damping: 32 }}
      className="fixed inset-x-2 bottom-[88px] z-50 flex h-[min(640px,calc(100vh-120px))] origin-bottom-right flex-col overflow-hidden rounded-3xl border border-white/60 bg-ink-50 shadow-[0_24px_60px_-12px_rgba(15,29,48,0.45)] sm:inset-x-auto sm:right-6 sm:w-[410px]">
      <div className="relative overflow-hidden bg-[linear-gradient(135deg,#0f1d30_0%,#0b3a5c_55%,#0077a8_100%)] px-4 pb-4 pt-3.5 text-white">
        <div className="pointer-events-none absolute -right-10 -top-12 h-36 w-36 rounded-full bg-brand-400/25 blur-2xl" />
        <div className="relative flex items-center gap-3">
          <AiraAvatar size={42} className="ring-2 ring-white/25" />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2"><span className="font-display text-[17px] font-bold tracking-wide">{AIRA_NAME}</span>
              {aiLive
                ? <span className="inline-flex items-center gap-1 rounded-full bg-emerald-400/15 px-1.5 py-0.5 text-[10px] font-medium text-emerald-200"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />Online</span>
                : <span title={health?.components.llm.detail} className="inline-flex items-center gap-1 rounded-full bg-amber-400/15 px-1.5 py-0.5 text-[10px] font-medium text-amber-200"><span className="h-1.5 w-1.5 rounded-full bg-amber-400" />Fact-based mode</span>}</div>
            <div className="text-[11.5px] text-white/70">{AIRA_TAGLINE}</div>
          </div>
          <div className="flex items-center gap-0.5">
            {msgs.length > 0 && <button onClick={reset} className="rounded-lg p-1.5 text-white/70 hover:bg-white/10 hover:text-white" aria-label="New chat" title="New chat"><RotateCcw className="h-4 w-4" /></button>}
            <Link to="/copilot" onClick={() => setOpen(false)} className="rounded-lg p-1.5 text-white/70 hover:bg-white/10 hover:text-white" aria-label="Open full view" title="Open full view with facts and checks"><Maximize2 className="h-4 w-4" /></Link>
            <button onClick={() => setOpen(false)} className="rounded-lg p-1.5 text-white/70 hover:bg-white/10 hover:text-white" aria-label="Close"><X className="h-4 w-4" /></button>
          </div>
        </div>
      </div>

      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-3 scrollbar-thin">
        {msgs.length === 0 && (
          <div className="space-y-3">
            <div className="flex gap-2"><AiraAvatar size={28} />
              <div className="rounded-2xl rounded-tl-md border border-ink-100 bg-white px-3 py-2.5 text-[13px] text-ink-800 shadow-card">
                Hi{first ? ` ${first}` : ""}, I'm <strong>{AIRA_NAME}</strong>. Ask me about any vendor, policy or backup supplier.
              </div></div>
            <div className="pl-9"><div className="eyebrow mb-1.5">Try asking</div>
              <div className="flex flex-col gap-1.5">{(sugg?.suggestions ?? []).slice(0, 4).map((q) => (
                <button key={q} onClick={() => send(q)} className="rounded-xl border border-ink-200 bg-white px-3 py-2 text-left text-[12.5px] text-ink-800 transition-colors hover:border-brand-300 hover:bg-brand-50/50">{q}</button>))}</div></div>
          </div>
        )}
        {msgs.map((m, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className={cn("flex gap-2", m.role === "user" && "justify-end")}>
            {m.role !== "user" && <AiraAvatar size={28} className="mt-0.5" />}
            {m.role === "user" ? <div className="max-w-[82%] rounded-2xl rounded-tr-md bg-ink-900 px-3 py-2 text-[13px] text-white">{m.text}</div>
              : m.role === "error" ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-[12.5px] text-rose-800">{m.text}</div>
              : <div className="min-w-0 flex-1"><CompactAnswer res={m.res} onAsk={send} /></div>}
          </motion.div>
        ))}
        {pending && <div className="flex gap-2"><AiraAvatar size={28} /><Thinking /></div>}
        <div ref={endRef} />
      </div>

      <form className="border-t border-ink-100 bg-white p-2.5" onSubmit={(e) => { e.preventDefault(); send(input); }}>
        <div className="flex items-end gap-2 rounded-2xl border border-ink-200 bg-white px-1.5 py-1 focus-within:border-brand-400 focus-within:ring-2 focus-within:ring-brand-100">
          <textarea ref={inputRef} value={input} onChange={(e) => setInput(e.target.value)} maxLength={600} rows={1}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }}
            placeholder={`Message ${AIRA_NAME}...`} aria-label={`Message ${AIRA_NAME}`}
            className="max-h-28 min-h-[36px] flex-1 resize-none bg-transparent px-2 py-2 text-[13px] focus:outline-none focus-visible:ring-0 focus-visible:ring-offset-0" />
          <button type="submit" disabled={input.trim().length < 3 || pending} aria-label="Send"
            className="mb-0.5 flex h-8 w-8 items-center justify-center rounded-full bg-[linear-gradient(135deg,#009fd6,#0077a8)] text-white shadow-sm transition-opacity disabled:opacity-40"><ArrowUp className="h-4 w-4" /></button>
        </div>
        <p className="mt-1 px-1 text-center text-[10.5px] text-ink-400">Scores use fixed rules · {AIRA_NAME} explains them · actions need approval</p>
      </form>
    </motion.div>
  );
}

/** Floating launcher, bottom-right on every page except the full AIRA page. */
export function AiraLauncher() {
  const { open, setOpen, msgs, lastAnswer, pending } = useAira();
  const { pathname } = useLocation();
  const [seen, setSeen] = React.useState(lastAnswer);
  const [hint, setHint] = React.useState(true);
  React.useEffect(() => { const t = setTimeout(() => setHint(false), 7000); return () => clearTimeout(t); }, []);
  React.useEffect(() => { if (open) setSeen(lastAnswer); }, [open, lastAnswer]);
  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setOpen]);
  if (pathname.startsWith("/copilot")) return null;
  const unread = !open && lastAnswer != null && lastAnswer !== seen;

  return (
    <>
      <AnimatePresence>{open && <Panel />}</AnimatePresence>
      <div className="fixed bottom-5 right-5 z-50 flex items-center gap-3 sm:bottom-6 sm:right-6">
        <AnimatePresence>
          {!open && hint && msgs.length === 0 && (
            <motion.span initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 8 }} transition={{ delay: 0.6 }}
              className="hidden rounded-full border border-ink-100 bg-white px-3 py-1.5 text-[12.5px] font-medium text-ink-800 shadow-lift sm:inline-block">
              Ask <span className="font-semibold text-brand-700">{AIRA_NAME}</span>
            </motion.span>
          )}
        </AnimatePresence>
        <motion.button onClick={() => setOpen(!open)} whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.95 }}
          aria-label={open ? `Close ${AIRA_NAME}` : `Open ${AIRA_NAME}, the AI assistant`} aria-expanded={open}
          className="group relative flex h-[62px] w-[62px] items-center justify-center rounded-full bg-[radial-gradient(circle_at_30%_25%,#3fc6f5_0%,#009fd6_38%,#0b3a5c_80%,#0f1d30_100%)] shadow-[0_10px_30px_-6px_rgba(0,119,168,0.65),inset_0_1px_1px_rgba(255,255,255,0.5)] ring-4 ring-white">
          {!open && <span className="absolute inset-0 animate-aira-ping rounded-full bg-brand-400/40" />}
          <AnimatePresence mode="wait" initial={false}>
            {open ? <motion.span key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}><X className="h-6 w-6 text-white" /></motion.span>
              : <motion.span key="face" initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.6, opacity: 0 }}><AiraFace className="h-10 w-10" /></motion.span>}
          </AnimatePresence>
          {(unread || pending) && !open && <span className={cn("absolute right-0.5 top-0.5 h-3.5 w-3.5 rounded-full ring-2 ring-white", pending ? "animate-pulse bg-amber-400" : "bg-emerald-500")} />}
        </motion.button>
      </div>
    </>
  );
}
