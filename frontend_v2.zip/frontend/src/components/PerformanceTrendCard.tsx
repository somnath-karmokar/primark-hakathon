import * as React from "react";
import { LineChart as LineIcon } from "lucide-react";
import { CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ChartTooltip } from "@/components/domain";
import { Card, CardBody, CardHeader, NativeSelect } from "@/components/ui/primitives";
import { cn, fmt } from "@/lib/utils";
import type { TrendPoint } from "@/types/api";

type Key = keyof TrendPoint;
interface Area { key: string; label: string; measure?: { key: Key; label: string; unit: "%" | "days"; better: "higher" | "lower"; digits: number }; score?: Key }

const AREAS: Area[] = [
  { key: "delivery", label: "Delivery", score: "delivery", measure: { key: "on_time_delivery_pct", label: "On-time delivery", unit: "%", better: "higher", digits: 1 } },
  { key: "quality", label: "Quality", score: "quality", measure: { key: "defect_rate_pct", label: "Defect rate", unit: "%", better: "lower", digits: 2 } },
  { key: "cost", label: "Cost", score: "cost", measure: { key: "invoice_accuracy_pct", label: "Invoice accuracy", unit: "%", better: "higher", digits: 1 } },
  { key: "lead_time", label: "Lead time", score: "lead_time", measure: { key: "avg_lead_time_days", label: "Average lead time", unit: "days", better: "lower", digits: 1 } },
  { key: "sla", label: "Contract targets", measure: { key: "sla_compliance_pct", label: "Vendors meeting all contract targets", unit: "%", better: "higher", digits: 1 } },
  { key: "overall", label: "Overall score", score: "avg" },
];

const fmtVal = (v: number, unit: string, digits: number) => (unit === "%" ? `${v.toFixed(digits)}%` : unit === "days" ? `${v.toFixed(digits)} days` : v.toFixed(1));

export function PerformanceTrendCard({ trend }: { trend: TrendPoint[] }) {
  const [areaKey, setAreaKey] = React.useState("delivery");
  const [view, setView] = React.useState<"measure" | "score">("measure");
  const area = AREAS.find((a) => a.key === areaKey) ?? AREAS[0];
  const mode = area.measure && area.score ? view : area.measure ? "measure" : "score";
  const key = (mode === "measure" ? area.measure!.key : area.score!) as Key;
  const unit = mode === "measure" ? area.measure!.unit : "pts";
  const digits = mode === "measure" ? area.measure!.digits : 1;
  const better = mode === "measure" ? area.measure!.better : "higher";
  const title = mode === "measure" ? area.measure!.label : `${area.label} score`;

  const points = trend.map((t) => ({ period: t.period, value: t[key] as number | null | undefined })).filter((p) => p.value != null) as { period: string; value: number }[];
  const last = points.at(-1)?.value;
  const back3 = points.length > 3 ? points[points.length - 4].value : undefined;
  const change = last != null && back3 != null ? last - back3 : undefined;
  const good = change == null || Math.abs(change) < 0.05 ? null : (better === "higher") === change > 0;
  const vals = points.map((p) => p.value);
  const pad = Math.max(0.5, (Math.max(...vals) - Math.min(...vals)) * 0.4);
  const domain: [number, number] = vals.length ? [Math.max(0, Math.floor(Math.min(...vals) - pad)), Math.ceil(Math.max(...vals) + pad)] : [0, 100];
  const show = (v: number) => (unit === "pts" ? v.toFixed(1) : fmtVal(v, unit, digits));

  return (
    <Card>
      <CardHeader title="Performance over time" icon={<LineIcon className="h-4 w-4 text-brand-500" />} subtitle="Each month covers the previous 3 months"
        action={
          <div className="flex flex-wrap items-center gap-2">
            <NativeSelect value={areaKey} onChange={(e) => setAreaKey(e.target.value)} aria-label="Choose what to show" className="h-8 w-44">
              {AREAS.map((a) => <option key={a.key} value={a.key}>{a.label}</option>)}
            </NativeSelect>
            {area.measure && area.score && (
              <div className="inline-flex rounded-lg bg-ink-100/70 p-1" role="tablist" aria-label="Measure or score">
                {([["measure", "Actual"], ["score", "Score"]] as const).map(([v, l]) => (
                  <button key={v} role="tab" aria-selected={view === v} onClick={() => setView(v)} className={cn("rounded-md px-2.5 py-0.5 text-[12px] font-medium", view === v ? "bg-white shadow-sm" : "text-ink-600")}>{l}</button>))}
              </div>
            )}
          </div>
        } />
      <CardBody>
        <div className="mb-2 flex flex-wrap items-baseline gap-x-3 gap-y-1">
          <span className="text-[12.5px] font-medium text-ink-600">{title}</span>
          {last != null && <span className="num font-display text-[24px] font-bold text-ink-950">{show(last)}</span>}
          {change != null && (
            <span className={cn("num text-[12.5px] font-semibold", good == null ? "text-ink-500" : good ? "text-emerald-700" : "text-rose-700")}>
              {change > 0 ? "▲" : change < 0 ? "▼" : "■"} {Math.abs(change).toFixed(unit === "%" && digits === 2 ? 2 : 1)}{unit === "%" ? " pts" : unit === "days" ? " days" : " pts"} vs 3 months ago
            </span>
          )}
          <span className="text-[11.5px] text-ink-500">{better === "lower" ? "lower is better" : "higher is better"}</span>
        </div>
        <div className="h-[270px]">
          <ResponsiveContainer>
            <LineChart data={points} margin={{ top: 8, right: 16, left: -6, bottom: 0 }}>
              <CartesianGrid vertical={false} />
              <XAxis dataKey="period" tickFormatter={fmt.month} tickLine={false} axisLine={false} />
              <YAxis domain={domain} tickLine={false} axisLine={false} width={48} tickFormatter={(v) => (unit === "%" ? `${v}%` : `${v}`)} />
              {mode === "score" && domain[0] < 74 && domain[1] > 76 && <ReferenceLine y={75} stroke="#8496ab" strokeDasharray="4 4" label={{ value: "Good (75)", position: "insideTopRight", fontSize: 10.5, fill: "#5f738b" }} />}
              <Tooltip content={<ChartTooltip labelFormatter={fmt.month} valueFormatter={(v: number) => show(v)} />} />
              <Line dataKey="value" name={title} stroke="#0a8fc4" strokeWidth={2.5} dot={{ r: 3.5, strokeWidth: 0, fill: "#0a8fc4" }} activeDot={{ r: 5 }} isAnimationActive={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardBody>
    </Card>
  );
}
