import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Boxes, Columns3, Link2, PackageOpen, Star, Users } from "lucide-react";
import { BandBadge, SourcePill } from "@/components/domain";
import { useAlternatives } from "@/hooks/queries";
import { Badge, Button, Tip } from "@/components/ui/primitives";
import { BAND_COLOR, cn, fmt } from "@/lib/utils";
import type { Alternatives, GraphNode, Relationships } from "@/types/api";

/** How easy a product is to source elsewhere, from the number of other vendors who make it. */
function switchability(n: number) {
  if (n <= 2) return { label: "Hard to replace", cls: "bg-rose-50 text-rose-800 ring-rose-200" };
  if (n <= 4) return { label: "Few options", cls: "bg-amber-50 text-amber-800 ring-amber-200" };
  return { label: "Easy to switch", cls: "bg-emerald-50 text-emerald-800 ring-emerald-200" };
}

const DEPENDENCY_TEXT: Record<string, string> = {
  High: "We rely on this vendor: it is the main source for a product that two or fewer other vendors make.",
  Medium: "It is our main source for some products, but other vendors already make them - a switch is possible.",
  Low: "Not the main source for any product - other vendors already cover everything it supplies.",
};

function Stat({ icon: Icon, label, value, sub, tone }: { icon: React.ElementType; label: string; value: React.ReactNode; sub: string; tone?: string }) {
  return (
    <div className={cn("rounded-xl border p-3", tone ?? "border-ink-100 bg-white")}>
      <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-ink-500"><Icon className="h-3.5 w-3.5" />{label}</div>
      <div className="num mt-1 font-display text-[20px] font-bold leading-tight text-ink-950">{value}</div>
      <div className="mt-0.5 text-[11.5px] text-ink-600">{sub}</div>
    </div>
  );
}

/** Column layout: category -> products -> vendor -> backup suppliers, with SLA / region above. Readable at card width. */
function NetworkMap({ rel, alts, vendorId }: { rel: Relationships; alts?: Alternatives; vendorId: string }) {
  const nav = useNavigate();
  const nodes = rel.neighbourhood.nodes;
  const altInfo = new Map((alts?.alternatives ?? []).map((a) => [a.vendor_id, a]));
  const products = nodes.filter((n) => n.type === "Product");
  const cats = nodes.filter((n) => n.type === "Category");
  const others = nodes.filter((n) => n.type === "SLA" || n.type === "Region");
  const altNodes = nodes.filter((n) => n.type === "Vendor" && !n.primary);
  const rows = Math.max(products.length, altNodes.length, cats.length, 3);
  const W = 1120, top = 78, gap = 48, H = top + rows * gap + 12;
  const colY = (i: number, n: number) => top + ((rows - n) * gap) / 2 + i * gap + gap / 2;
  const X = { cat: 110, prod: 370, vendor: 620, alt: 790 };
  const pos: Record<string, { x: number; y: number }> = {};
  cats.forEach((n, i) => (pos[n.id] = { x: X.cat, y: colY(i, cats.length) }));
  products.forEach((n, i) => (pos[n.id] = { x: X.prod, y: colY(i, products.length) }));
  altNodes.forEach((n, i) => (pos[n.id] = { x: X.alt, y: colY(i, altNodes.length) }));
  const vy = top + (rows * gap) / 2;
  const center = nodes.find((n) => n.primary);
  if (center) pos[center.id] = { x: X.vendor, y: vy };
  others.forEach((n, i) => (pos[n.id] = { x: X.vendor - 95 + i * 190, y: 28 }));
  const TIER: Record<string, string> = { STR: "Strategic", PRE: "Preferred", APP: "Approved" };
  const label = (n: GraphNode) => (n.type === "SLA" ? `Contract tier: ${TIER[n.label.replace("SLA-", "")] ?? n.label}` : n.type === "Region" ? `Region: ${n.label}` : n.label);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label={`Supplier network for ${vendorId}`}>
      <g fontSize={11} fontWeight={600} fill="#8496ab" letterSpacing={0.6}>
        <text x={X.cat} y={top - 6} textAnchor="middle">CATEGORY</text>
        <text x={X.prod} y={top - 6} textAnchor="middle">PRODUCTS SUPPLIED</text>
        <text x={X.alt + 150} y={top - 6} textAnchor="middle">BACKUP SUPPLIERS (SAME PRODUCTS)</text>
      </g>
      {rel.neighbourhood.edges.map((e, i) => {
        const a = pos[e.from], b = pos[e.to];
        if (!a || !b) return null;
        const alt = e.type === "ALTERNATIVE_TO";
        const mx = (a.x + b.x) / 2;
        return <path key={i} d={`M${a.x},${a.y} C${mx},${a.y} ${mx},${b.y} ${b.x},${b.y}`} fill="none"
          stroke={alt ? "#26b0df" : e.type === "HAS_SLA" || e.type === "OPERATES_IN" ? "#c9d3df" : "#b3bfce"} strokeWidth={alt ? 1.6 : 1.3} strokeDasharray={alt ? "5 4" : undefined} />;
      })}
      {nodes.map((n) => {
        const p = pos[n.id];
        if (!p) return null;
        if (n.primary) return (
          <g key={n.id}><title>{`${n.label} - this vendor`}</title>
            <rect x={p.x - 52} y={p.y - 22} width={104} height={44} rx={22} fill="#0f1d30" />
            <text x={p.x} y={p.y + 5} textAnchor="middle" fontSize={15} fontWeight={700} fill="#fff">{n.label}</text></g>
        );
        if (n.type === "Vendor") {
          const a = altInfo.get(n.id);
          return (
            <g key={n.id} className="cursor-pointer" onClick={() => nav(`/vendors/${n.id}`)}>
              <title>{a ? `${a.name} - score ${a.overall.toFixed(1)}, ${a.product_overlap_pct.toFixed(0)}% product overlap. Click to open.` : `${n.label} - click to open`}</title>
              <rect x={p.x - 4} y={p.y - 15} width={300} height={30} rx={15} fill="#eaf7fc" stroke="#26b0df" />
              <circle cx={p.x + 12} cy={p.y} r={5} fill={a ? BAND_COLOR[a.band] : "#26b0df"} />
              <text x={p.x + 24} y={p.y + 4.5} fontSize={13} fontWeight={700} fill="#006a93">{n.label}</text>
              <text x={p.x + 72} y={p.y + 4.5} fontSize={12} fill={a ? "#33445a" : "#8496ab"}>{a ? `score ${a.overall.toFixed(1)} · ${a.product_overlap_pct.toFixed(0)}% match` : "lower fit - outside the top 15"}</text>
            </g>
          );
        }
        const isProd = n.type === "Product";
        const w = Math.min(220, 18 + label(n).length * 6.6);
        const fill = isProd ? "#ffffff" : n.type === "Category" ? "#fff7e6" : "#f5f7fa";
        const stroke = n.critical ? "#a8223d" : isProd ? "#b3bfce" : n.type === "Category" ? "#eaa400" : "#c9d3df";
        return (
          <g key={n.id}><title>{`${n.type === "SLA" ? "Contract tier" : n.type}: ${n.label}${n.critical ? " (critical product)" : ""}`}</title>
            <rect x={p.x - w / 2} y={p.y - 14} width={w} height={28} rx={8} fill={fill} stroke={stroke} strokeWidth={n.critical ? 2 : 1.2} />
            <text x={p.x} y={p.y + 4.5} textAnchor="middle" fontSize={12.5} fontWeight={isProd ? 500 : 600} fill={n.type === "Category" ? "#8a6100" : "#33445a"}>
              {label(n).length > 32 ? label(n).slice(0, 31) + "…" : label(n)}</text>
          </g>
        );
      })}
    </svg>
  );
}

export function VendorLinks({ rel, vendorId }: { rel: Relationships; vendorId: string }) {
  const { data: alts } = useAlternatives(vendorId, 15);
  const d = rel.dependency;
  const products = [...d.products].sort((a, b) => Number(b.is_primary_source) - Number(a.is_primary_source) || a.alt_sources - b.alt_sources);
  const openPos = products.reduce((s, p) => s + (p.open_pos || 0), 0);
  const openValue = products.reduce((s, p) => s + (p.open_value || 0), 0);
  const mainFor = products.filter((p) => p.is_primary_source);
  const cats = [...new Set(products.map((p) => p.category))];
  const level = d.dependency_level;
  const top = (alts?.alternatives ?? []).slice(0, 5);
  const levelTone = level === "High" ? "border-rose-200 bg-rose-50/60" : level === "Medium" ? "border-amber-200 bg-amber-50/60" : "border-emerald-200 bg-emerald-50/60";

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat icon={Boxes} label="Products supplied" value={products.length} sub={`in ${cats.join(", ")}`} />
        <Stat icon={Star} label="Main source for" value={`${mainFor.length} product${mainFor.length === 1 ? "" : "s"}`} sub={mainFor.length ? mainFor.map((p) => p.product).join(", ") : "none - others are the main source"} />
        <Stat icon={PackageOpen} label="Orders on the way" value={fmt.gbp(openValue)} sub={`${openPos} open orders across these products`} />
        <Stat icon={Link2} label="Our dependency" value={`${level}`} sub={DEPENDENCY_TEXT[level] ?? ""} tone={levelTone} />
      </div>

      <div className="grid gap-4 xl:grid-cols-12">
        <div className="min-w-0 xl:col-span-7">
          <div className="mb-2 flex items-center justify-between"><span className="text-[13px] font-semibold text-ink-900">Products this vendor supplies</span><SourcePill source={d.source} /></div>
          <div className="overflow-x-auto rounded-xl border border-ink-100">
            <table className="w-full text-[12.5px]">
              <thead><tr className="bg-ink-50/70">
                <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-ink-500">Product</th>
                <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-ink-500"><Tip content="Number of other vendors (not under review) who already supply this exact product"><span className="cursor-help border-b border-dotted border-ink-300">Other vendors who make it</span></Tip></th>
                <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-ink-500">Orders on the way</th>
              </tr></thead>
              <tbody>{products.map((p) => {
                const sw = switchability(p.alt_sources);
                return (
                  <tr key={p.product_id} className="border-t border-ink-100">
                    <td className="px-3 py-2.5">
                      <div className="font-semibold text-ink-900">{p.product}</div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1 text-[11px] text-ink-500">{p.category} · {p.product_id}
                        {p.is_primary_source && <Badge tone="brand">main source</Badge>}{p.is_critical && <Badge tone="critical">critical</Badge>}</div>
                    </td>
                    <td className="px-3 py-2.5"><span className="num mr-2 text-[14px] font-bold text-ink-900">{p.alt_sources}</span><span className={cn("rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset", sw.cls)}>{sw.label}</span></td>
                    <td className="px-3 py-2.5 text-right"><div className="num font-semibold text-ink-900">{fmt.gbp(p.open_value)}</div><div className="num text-[11px] text-ink-500">{p.open_pos} order{p.open_pos === 1 ? "" : "s"}</div></td>
                  </tr>
                );
              })}</tbody>
            </table>
          </div>
          <p className="mt-2 text-[11.5px] text-ink-500"><b>Main source</b> = we buy most of it here.</p>
        </div>

        <div className="min-w-0 xl:col-span-5">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[13px] font-semibold text-ink-900">Best backup suppliers</span>
            {top.length > 0 && <Button asChild size="sm" variant="outline"><Link to={`/compare?ids=${[vendorId, ...top.slice(0, 3).map((a) => a.vendor_id)].join(",")}`}><Columns3 />Compare top 3</Link></Button>}
          </div>
          {top.length === 0 ? <p className="rounded-xl border border-dashed border-ink-200 p-4 text-[12.5px] text-ink-500">No other vendor currently makes these products.</p> : (
            <ul className="space-y-2">{top.map((a, i) => (
              <li key={a.vendor_id}>
                <Link to={`/vendors/${a.vendor_id}`} className={cn("group flex items-center gap-3 rounded-xl border p-2.5 transition-colors hover:border-brand-300 hover:bg-brand-50/30", i === 0 ? "border-emerald-200 bg-emerald-50/40" : "border-ink-100")}>
                  <span className="num flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-ink-100 text-[12px] font-bold text-ink-700">{i + 1}</span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12.5px]"><span className="num font-bold text-ink-900">{a.vendor_id}</span> <span className="text-ink-700">{a.name}</span></div>
                    <div className="text-[11px] text-ink-500">{a.country} · makes {a.shared_products} of the same products ({a.product_overlap_pct.toFixed(0)}%) · fit {a.fit_score.toFixed(0)}</div>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-0.5"><span className="num text-[14px] font-bold">{a.overall.toFixed(1)}</span><BandBadge band={a.band} /></div>
                  <ArrowRight className="h-3.5 w-3.5 shrink-0 text-ink-300 group-hover:text-brand-500" />
                </Link>
              </li>))}</ul>
          )}
          {alts && <p className="mt-2 text-[11.5px] text-ink-500"><Users className="mr-1 inline h-3 w-3 align-[-2px]" />{alts.candidates_considered} vendors make some of the same products · best fit first</p>}
        </div>
      </div>

      <div>
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <span className="text-[13px] font-semibold text-ink-900">Supplier network map</span>
          <div className="flex flex-wrap items-center gap-3 text-[11.5px] text-ink-600">
            <span className="inline-flex items-center gap-1.5"><span className="h-3 w-5 rounded border border-[#eaa400] bg-[#fff7e6]" />Category</span>
            <span className="inline-flex items-center gap-1.5"><span className="h-3 w-5 rounded border border-ink-300 bg-white" />Product supplied</span>
            <span className="inline-flex items-center gap-1.5"><span className="h-3 w-5 rounded-full border border-[#26b0df] bg-[#eaf7fc]" />Backup supplier (click to open)</span>
            <span className="inline-flex items-center gap-1.5"><span className="w-5 border-t-2 border-dashed border-[#26b0df]" />makes the same products</span>
            <SourcePill source={rel.neighbourhood.source} />
          </div>
        </div>
        <div className="rounded-xl border border-ink-100 bg-gradient-to-b from-ink-50/40 to-white p-2"><NetworkMap rel={rel} alts={alts} vendorId={vendorId} /></div>
      </div>
    </div>
  );
}
