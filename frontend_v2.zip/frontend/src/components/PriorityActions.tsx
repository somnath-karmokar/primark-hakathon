import { Link } from "react-router-dom";
import { AlertOctagon, ArrowRight, ClipboardList, Globe2, Receipt, ShieldAlert, Sparkles, Wrench } from "lucide-react";
import { useEvents, useValue } from "@/hooks/queries";
import { Card, CardBody, CardHeader } from "@/components/ui/primitives";
import { cn, fmt } from "@/lib/utils";
import type { DashboardSummary } from "@/types/api";

interface Action { key: string; icon: React.ElementType; tone: string; title: React.ReactNode; why: string; owner: string; to: string; cta: string }

const TONE: Record<string, string> = {
  critical: "bg-rose-50 text-rose-700 ring-rose-200", serious: "bg-orange-50 text-orange-700 ring-orange-200",
  warning: "bg-amber-50 text-amber-700 ring-amber-200", brand: "bg-brand-50 text-brand-700 ring-brand-200", good: "bg-emerald-50 text-emerald-700 ring-emerald-200",
};

/** Turns the dashboard numbers into a short, ordered to-do list for the buying team. */
export function PriorityActions({ data }: { data: DashboardSummary }) {
  const { data: events } = useEvents();
  const { data: value } = useValue("expected");
  const k = data.kpis;
  const s = data.spotlight;
  const ev = events?.find((e) => (e.impact?.vendors ?? 0) > 0);
  const over = value?.baseline?.overbilled_paid_gbp;
  const pending = data.operational?.pending_approvals ?? 0;

  const actions: Action[] = [
    s && { key: "spotlight", icon: Sparkles, tone: "critical", title: <>Review <b>{s.vendor_id} {s.name}</b></>,
      why: `Key ${s.category.toLowerCase()} supplier down ${Math.abs(s.change_3m ?? 0).toFixed(1)} pts in 3 months (now ${fmt.score(s.overall)}, ${s.band})`, owner: "Category Manager", to: `/vendors/${s.vendor_id}`, cta: "Open profile" },
    k.critical > 0 && { key: "critical", icon: AlertOctagon, tone: "critical", title: <>Escalate <b>{k.critical} Critical</b> vendors</>,
      why: "Score below 40 - escalation step 4 of the supplier policy", owner: "Head of Buying", to: "/vendors?band=Critical", cta: "See vendors" },
    k.at_risk > 0 && { key: "atrisk", icon: Wrench, tone: "serious", title: <>Agree improvement plans with <b>{k.at_risk} At Risk</b> vendors</>,
      why: "Score 40-59 - corrective action request and monthly review", owner: "Category Managers", to: "/vendors?band=At%20Risk", cta: "See vendors" },
    k.high_risk > 0 && { key: "early", icon: ShieldAlert, tone: "warning", title: <>Act early on <b>{k.high_risk} vendors</b> likely to decline</>,
      why: "Predicted to drop in the next 3 months - check capacity and line up backups", owner: "Sourcing Analysts", to: "/vendors?risk=High&sort=overall&order=asc", cta: "See vendors" },
    ev && { key: "event", icon: Globe2, tone: ev.severity === "high" ? "critical" : "warning", title: <>Prepare for <b>{ev.title}</b></>,
      why: `${fmt.int(ev.impact?.vendors ?? 0)} vendors · ${fmt.gbp(ev.impact?.open_value ?? 0)} of orders on the way · ${fmt.int(ev.impact?.critical_pos_at_risk ?? 0)} key orders at risk`,
      owner: "Supply Planning", to: "/risk-intel", cta: "See impact" },
    over && over > 0 && { key: "invoice", icon: Receipt, tone: "brand", title: <>Recover invoice overcharges</>,
      why: `${fmt.gbp(over)} billed above the order value and paid in the last 12 months`, owner: "Finance", to: "/vendors?sort=cost&order=asc", cta: "Worst cost scores" },
  ].filter(Boolean) as Action[];

  return (
    <Card className="mb-5">
      <CardHeader title="Priority actions" icon={<ClipboardList className="h-4 w-4 text-brand-500" />} subtitle="What to do this month, most urgent first"
        action={pending > 0 && <span className="rounded-full bg-amber-50 px-2.5 py-1 text-[11.5px] font-semibold text-amber-800 ring-1 ring-inset ring-amber-200">{pending} recommended actions awaiting approval</span>} />
      <CardBody className="pt-0">
        <ol className="divide-y divide-ink-100">
          {actions.map((a, i) => (
            <li key={a.key} className="flex flex-wrap items-center gap-3 py-2.5 sm:flex-nowrap">
              <span className="num w-5 shrink-0 text-center text-[12px] font-bold text-ink-400">{i + 1}</span>
              <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ring-1 ring-inset", TONE[a.tone])}><a.icon className="h-4 w-4" /></span>
              <div className="min-w-0 flex-1">
                <div className="text-[13px] text-ink-900">{a.title}</div>
                <div className="text-[11.5px] text-ink-500">{a.why}</div>
              </div>
              <span className="hidden shrink-0 rounded-md bg-ink-50 px-2 py-0.5 text-[11px] font-medium text-ink-600 lg:inline">{a.owner}</span>
              <Link to={a.to} className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-ink-200 px-2.5 py-1 text-[12px] font-medium text-ink-800 hover:border-brand-300 hover:text-brand-700">
                {a.cta}<ArrowRight className="h-3.5 w-3.5" /></Link>
            </li>
          ))}
        </ol>
      </CardBody>
    </Card>
  );
}
