import * as React from "react";
import { ArrowRight, BadgeCheck, CalendarClock, Calculator, ChevronDown, Clock, Coins, Info, Loader2, Radar, Receipt, ShieldCheck, TrendingUp, Truck, Users } from "lucide-react";
import { useSaveValueAssumptions, useValue } from "@/hooks/queries";
import { useAuth } from "@/lib/auth";
import { ErrorState, KpiTile, LoadingCard } from "@/components/domain";
import { Badge, Button, Card, CardBody, CardHeader, Input, Td, Th, Tip } from "@/components/ui/primitives";
import { cn, fmt } from "@/lib/utils";
import type { ValueAssumption, ValueLever } from "@/types/api";

const gbp = (v: number) => (Math.abs(v) >= 1e9 ? `£${(v / 1e9).toFixed(2)}bn` : Math.abs(v) >= 1e6 ? `£${(v / 1e6).toFixed(2)}m` : Math.abs(v) >= 1e3 ? `£${Math.round(v / 1e3).toLocaleString("en-GB")}k` : `£${Math.round(v)}`);

const TYPE_TONE: Record<string, "good" | "brand" | "neutral" | "warning"> = {
  "Hard saving": "good", "Cost avoidance": "brand", Productivity: "neutral", "Risk mitigation": "warning",
};
const SCENARIO_LABEL: Record<string, string> = { conservative: "Conservative", expected: "Expected", stretch: "Stretch" };

function LeverRow({ l, max }: { l: ValueLever; max: number }) {
  return (
    <li className="py-2.5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="flex items-center gap-2"><span className="text-[13px] font-semibold text-ink-900">{l.lever}</span><Tip content={`Measured: ${l.baseline}. Assumed: ${l.assumption}.`}><Info className="h-3.5 w-3.5 cursor-help text-ink-400" /></Tip><Badge tone={TYPE_TONE[l.type]}>{l.type}</Badge></span>
        <span className="num font-display text-[16px] font-bold text-ink-950">{gbp(l.annual_gbp)}<span className="ml-1 text-[11px] font-medium text-ink-500">/ year</span></span>
      </div>
      <div className="mt-1.5 h-2 rounded-full bg-ink-100"><div className="h-2 rounded-full bg-brand-500" style={{ width: `${Math.max(2, (l.annual_gbp / max) * 100)}%` }} /></div>
      
    </li>
  );
}

function Assumptions({ rows, admin }: { rows: ValueAssumption[]; admin: boolean }) {
  const save = useSaveValueAssumptions();
  const [draft, setDraft] = React.useState<Record<string, number>>({});
  const changed = Object.keys(draft).length > 0;
  return (
    <div className="mt-3 overflow-x-auto rounded-xl border border-ink-100">
      <table className="w-full text-[12px]">
        <thead><tr><Th>Assumption</Th><Th className="text-right">Value</Th><Th className="text-right">Used in this scenario</Th><Th className="text-right">Allowed range</Th></tr></thead>
        <tbody>{rows.map((a) => (
          <tr key={a.key}>
            <Td>{a.label}{a.scaled_by_scenario && <Tip content="Scaled by the scenario: x0.5 conservative, x1 expected, x1.5 stretch"><span className="ml-1 cursor-help text-ink-400">*</span></Tip>}</Td>
            <Td className="text-right">{admin
              ? <Input type="number" min={a.min} max={a.max} value={draft[a.key] ?? a.value} onChange={(e) => setDraft({ ...draft, [a.key]: Number(e.target.value) })} className="ml-auto h-7 w-28 text-right" aria-label={a.label} />
              : <span className="num">{a.value.toLocaleString("en-GB")}</span>}</Td>
            <Td className="num text-right text-ink-600">{a.applied.toLocaleString("en-GB")}</Td>
            <Td className="num text-right text-ink-400">{a.min.toLocaleString("en-GB")} - {a.max.toLocaleString("en-GB")}</Td>
          </tr>))}</tbody>
      </table>
      {admin && (
        <div className="flex items-center gap-3 border-t border-ink-100 px-3 py-2">
          <Button size="sm" disabled={!changed || save.isPending} onClick={() => save.mutate(draft, { onSuccess: () => setDraft({}) })}>{save.isPending && <Loader2 className="animate-spin" />}Save assumptions</Button>
          {changed && <button className="text-[12px] text-ink-500 hover:text-ink-800" onClick={() => setDraft({})}>Undo changes</button>}
          {save.isSuccess && !changed && <span className="text-[12px] text-emerald-700">Saved and recorded in the audit log.</span>}
          {save.isError && <span className="text-[12px] text-rose-700">{(save.error as Error).message}</span>}
        </div>
      )}
    </div>
  );
}

export function BusinessValue() {
  const [scenario, setScenario] = React.useState("expected");
  const [open, setOpen] = React.useState(false);
  const { data, isLoading, error } = useValue(scenario);
  const { can } = useAuth();
  if (error) return <ErrorState error={error} />;
  if (isLoading || !data) return <LoadingCard h="h-72" />;
  const max = Math.max(...data.levers.map((l) => l.annual_gbp), 1);
  const lever = (k: string) => data.levers.find((l) => l.key === k);
  const op = (k: string) => data.operational.find((o) => o.key === k);
  const pct = (v?: number | null) => (v == null ? "-" : `${v.toFixed(1)}%`);
  const otd = op("otd"), fpq = op("fpq"), inv = op("invoice"), warn = op("warning"), prod = lever("productivity");
  const teams = [
    { team: "Buying & merchandising", icon: Truck, outcome: "More stock arrives on time for launches",
      proof: `On-time shipments ${pct(otd?.value)} → ${pct(otd?.improved)}`, value: lever("late")?.annual_gbp },
    { team: "Quality & compliance", icon: ShieldCheck, outcome: "Fewer faulty products reach stores",
      proof: `Inspections passed ${pct(fpq?.value)} → ${pct(fpq?.improved)}`, value: lever("quality")?.annual_gbp },
    { team: "Finance", icon: Receipt, outcome: "Overcharges spotted and recovered",
      proof: `Invoice accuracy today ${pct(inv?.value)}`, value: lever("overcharges")?.annual_gbp },
    { team: "Leadership & risk", icon: Radar, outcome: "Early warning before suppliers slip",
      proof: `${warn?.value ?? "-"} vendors flagged before their score drops`, value: data.risk_mitigation.annual_gbp, protected: true },
    { team: "Sourcing analysts", icon: Clock, outcome: "Scorecards built automatically",
      proof: `${fmt.int(prod?.hours ?? 0)} hours a year freed`, value: prod?.annual_gbp },
  ];
  const run = data.run_cost_annual;
  return (
    <section className="mb-5" aria-labelledby="value-heading">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <div><h2 id="value-heading" className="text-[14px] font-semibold">Business value for Primark</h2>
          <p className="text-[11.5px] text-ink-500">How the business benefits · estimated yearly impact · all vendors · 12 months to {new Date(data.window.to).toLocaleDateString("en-GB", { month: "short", year: "numeric" })}</p></div>
        <div className="inline-flex rounded-lg bg-ink-100/70 p-1" role="tablist" aria-label="Scenario">{data.scenarios.map((s) => (
          <button key={s} role="tab" aria-selected={scenario === s} onClick={() => setScenario(s)} className={cn("rounded-md px-3 py-1 text-[12px] font-medium", scenario === s ? "bg-white shadow-sm" : "text-ink-600")}>{SCENARIO_LABEL[s] ?? s}</button>))}</div>
      </div>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <KpiTile label="Yearly benefit" value={gbp(data.total_annual_gbp)} icon={Coins} accent="#1f8a4c" sub={`${data.spend_share_pct.toFixed(2)}% of ${gbp(data.baseline.spend_gbp)} spend`}
          tip="Hard savings + cost avoidance + productivity. Risk mitigation is shown separately." />
        <KpiTile label="Return on cost" value={data.roi_multiple != null ? `${data.roi_multiple}x` : "-"} icon={TrendingUp}
          sub={`year 1, after ${gbp(data.implementation_cost_gbp)} build + ${gbp(run.total_gbp)} a year to run`}
          tip="Yearly benefit divided by first-year cost (one-off build plus a year of hosting, AI usage and support)." />
        <KpiTile label="Pays back in" value={data.payback_months != null ? `${data.payback_months} months` : "-"} icon={CalendarClock}
          sub="build cost recovered from net monthly benefit" />
        <KpiTile label="Spend protected" value={gbp(data.risk_mitigation.annual_gbp)} icon={ShieldCheck} accent="#eaa400"
          sub="risk mitigation - not in the total" tip={`${data.risk_mitigation.baseline}. ${data.risk_mitigation.assumption}.`} />
      </div>

      <Card>
        <CardHeader title="How each team benefits" icon={<Users className="h-4 w-4 text-brand-500" />} subtitle="Measured today · estimated yearly value" />
        <CardBody className="pt-0">
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">{teams.map((t) => (
            <div key={t.team} className="flex flex-col rounded-xl border border-ink-100 p-3">
              <div className="flex items-center gap-2"><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-50 text-brand-600"><t.icon className="h-4 w-4" /></span>
                <span className="text-[12px] font-semibold uppercase tracking-wide text-ink-500">{t.team}</span></div>
              <div className="mt-2 flex-1 text-[13px] font-semibold leading-snug text-ink-900">{t.outcome}</div>
              <div className="mt-1 text-[11.5px] text-ink-600">{t.proof}</div>
              {t.value != null && <div className="mt-2 border-t border-ink-100 pt-2 text-[12px]"><span className="num font-display text-[16px] font-bold text-ink-950">{gbp(t.value)}</span>
                <span className="text-ink-500"> {t.protected ? "spend protected / year" : "a year"}</span></div>}
            </div>))}</div>
          <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5 text-[12px]"><span className="text-ink-500">Also:</span>{data.other_benefits.map((b) => (
            <div key={b.benefit} className="flex gap-1.5"><BadgeCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" /><Tip content={b.detail}><span className="cursor-help text-ink-700">{b.benefit}</span></Tip></div>))}</div>
          <button onClick={() => setOpen(!open)} aria-expanded={open} className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-medium text-brand-600 hover:text-brand-700">
            <Calculator className="h-3.5 w-3.5" />{open ? "Hide the detail" : "Show the detail: where the money comes from, measures and assumptions"}<ChevronDown className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} />
          </button>
          {open && (
            <>
              <div className="mt-3">
      <div className="grid gap-4 xl:grid-cols-12">
            <Card className="xl:col-span-7">
              <CardHeader title="Where the money comes from" subtitle="Hover ⓘ to see how each is calculated" icon={<Coins className="h-4 w-4 text-brand-500" />} />
              <CardBody className="pt-0">
                <ul className="divide-y divide-ink-100">{data.levers.map((l) => <LeverRow key={l.key} l={l} max={max} />)}</ul>
                
              </CardBody>
            </Card>
            <Card className="xl:col-span-5">
              <CardHeader title="Operational benefits" subtitle="Today → with improvement · industry-standard measures" icon={<BadgeCheck className="h-4 w-4 text-brand-500" />} />
              <CardBody className="pt-0">
                <ul className="divide-y divide-ink-100">{data.operational.map((o) => (
                  <li key={o.key} className="flex items-center justify-between gap-3 py-2">
                    <div className="min-w-0"><div className="text-[12.5px] font-semibold text-ink-900">{o.label}</div>
                      <div className="truncate text-[11px] text-ink-500" title={`${o.detail} (${o.standard})`}>{o.detail}</div></div>
                    <div className="flex shrink-0 items-center gap-1.5 text-[13px]">
                      <span className="num font-semibold">{o.unit === "%" ? `${o.value.toFixed(1)}%` : `${o.value} ${o.unit}`}</span>
                      {o.improved != null && <><ArrowRight className="h-3.5 w-3.5 text-ink-400" /><span className="num font-semibold text-emerald-700">{o.improved.toFixed(1)}%</span></>}
                    </div>
                  </li>))}</ul>
              </CardBody>
            </Card>
          </div>
    
    
              </div>
              <p className="mt-3 flex gap-1.5 text-[11.5px] text-ink-600"><Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />{data.method}</p>
              <Assumptions rows={data.assumptions} admin={can("configure")} />
            </>
          )}
        </CardBody>
      </Card>
    </section>
  );
}
