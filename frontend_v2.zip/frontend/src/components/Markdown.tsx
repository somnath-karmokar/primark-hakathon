import { cn } from "@/lib/utils";

/** Minimal, safe markdown renderer for the policy documents (headings, lists, tables, paragraphs). */
export function Markdown({ md, highlight }: { md: string; highlight?: string }) {
  const blocks = md.split(/\n\s*\n/);
  return (
    <div className="space-y-3 text-[13px] leading-relaxed text-ink-800">
      {blocks.map((b, i) => {
        const t = b.trim();
        if (t.startsWith("## ") || t.startsWith("### ")) {
          const [h, ...rest] = t.split("\n");
          const title = h.replace(/^#+\s*/, "");
          const hit = highlight && title.toLowerCase().includes(highlight.toLowerCase());
          return (
            <div key={i} id={title} className={cn(hit && "-mx-3 rounded-lg bg-brand-50 px-3 py-2 ring-1 ring-brand-200")}>
              <h3 className="mt-2 text-[14px] font-semibold text-ink-950">{title}</h3>
              {rest.length > 0 && <Markdown md={rest.join("\n")} />}
            </div>
          );
        }
        if (t.startsWith("# ")) return <h2 key={i} className="text-[18px] font-bold">{t.slice(2)}</h2>;
        if (t.startsWith("|")) {
          const rows = t.split("\n").filter((r) => !/^\|\s*-/.test(r)).map((r) => r.split("|").slice(1, -1).map((c) => c.trim()));
          return (
            <div key={i} className="overflow-x-auto"><table className="w-full text-[12.5px]">
              <thead><tr>{rows[0].map((c) => <th key={c} className="border-b border-ink-200 bg-ink-50 px-2.5 py-1.5 text-left font-semibold">{c}</th>)}</tr></thead>
              <tbody>{rows.slice(1).map((r, j) => <tr key={j}>{r.map((c, k) => <td key={k} className="border-b border-ink-100 px-2.5 py-1.5">{c}</td>)}</tr>)}</tbody>
            </table></div>
          );
        }
        if (/^(\d+\.|-)\s/.test(t)) return <ul key={i} className="ml-4 list-disc space-y-1">{t.split("\n").map((l, j) => <li key={j}>{l.replace(/^(\d+\.|-)\s/, "")}</li>)}</ul>;
        return <p key={i}>{t}</p>;
      })}
    </div>
  );
}
