import * as React from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Download, Search, TrendingDown } from "lucide-react";
import { useVendors } from "@/hooks/queries";
import { FilterBar } from "@/components/FilterBar";
import { BandBadge, Delta, EmptyState, ErrorState, PageHeader, RiskBadge } from "@/components/domain";
import { Button, Card, Input, NativeSelect, Skeleton, Switch, Td, Th } from "@/components/ui/primitives";
import { BAND_COLOR, BAND_ORDER, bandOf, cn, fmt } from "@/lib/utils";
import type { VendorRow } from "@/types/api";

const COLS: { key: string; label: string; align?: "right" }[] = [
  { key: "rank", label: "#" }, { key: "vendor_id", label: "Vendor" }, { key: "category", label: "Category" },
  { key: "overall", label: "Score", align: "right" }, { key: "delivery", label: "Delivery", align: "right" },
  { key: "quality", label: "Quality", align: "right" }, { key: "cost", label: "Cost", align: "right" },
  { key: "lead_time", label: "Lead-time", align: "right" }, { key: "change_3m", label: "3m change", align: "right" },
  { key: "risk_probability", label: "Risk of decline" },
];

function Cell({ v }: { v: number }) {
  return (
    <span className="num inline-flex items-center gap-1.5">
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: BAND_COLOR[bandOf(v)] }} aria-hidden />{v.toFixed(1)}
    </span>
  );
}

function toCsv(rows: VendorRow[]) {
  const keys: (keyof VendorRow)[] = ["rank", "vendor_id", "name", "category", "region", "tier", "status", "overall", "band", "delivery", "quality", "cost", "lead_time", "change_3m", "trend", "risk_level"];
  return [keys.join(","), ...rows.map((r) => keys.map((k) => JSON.stringify(r[k] ?? "")).join(","))].join("\n");
}

export default function VendorsPage() {
  const [sp, setSp] = useSearchParams();
  const nav = useNavigate();
  const set = (k: string, v: string | null) => { const n = new URLSearchParams(sp); if (v) n.set(k, v); else n.delete(k); if (k !== "page") n.delete("page"); setSp(n, { replace: true }); };
  const [search, setSearch] = React.useState(sp.get("search") ?? "");
  React.useEffect(() => { const t = setTimeout(() => set("search", search || null), 250); return () => clearTimeout(t); }, [search]); // eslint-disable-line react-hooks/exhaustive-deps

  const q = {
    period: sp.get("period") ?? undefined, category: sp.get("category") ?? undefined, region: sp.get("region") ?? undefined,
    status: sp.get("status") ?? undefined, band: sp.get("band") ?? undefined, search: sp.get("search") ?? undefined,
    sort: sp.get("sort") ?? "overall", order: sp.get("order") ?? "desc", page: Number(sp.get("page") ?? 1), page_size: 25,
    deteriorating: sp.get("deteriorating") === "true", risk: sp.get("risk") ?? undefined,
  };
  const { data, isLoading, isFetching, error, refetch } = useVendors(q);
  const pages = data ? Math.max(1, Math.ceil(data.total / data.page_size)) : 1;
  const sortBy = (k: string) => {
    const n = new URLSearchParams(sp);
    n.set("sort", k);
    n.set("order", q.sort === k && q.order === "desc" ? "asc" : "desc");
    n.delete("page");
    setSp(n, { replace: true });
  };
  const exportCsv = () => {
    if (!data) return;
    const url = URL.createObjectURL(new Blob([toCsv(data.items)], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = "vendor-ranking.csv"; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <>
      <PageHeader eyebrow="Vendor scorecards" title="Vendor scorecards, ranked by score" description="All vendors ranked by score. Click one to open its profile." actions={<FilterBar />} />
      <Card>
        <div className="flex flex-wrap items-center gap-3 border-b border-ink-100 px-4 py-3">
          <div className="relative w-full max-w-xs">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Filter by ID or name" className="pl-9" aria-label="Filter vendors" />
          </div>
          <NativeSelect value={q.band ?? ""} onChange={(e) => set("band", e.target.value || null)} aria-label="Band">
            <option value="">All bands</option>
            {BAND_ORDER.map((b) => <option key={b} value={b}>{b}</option>)}
          </NativeSelect>
          <NativeSelect value={q.risk ?? ""} onChange={(e) => set("risk", e.target.value || null)} aria-label="Risk of decline">
            <option value="">Any risk of decline</option>
            {["High", "Medium", "Low"].map((r) => <option key={r} value={r}>{r} risk of decline</option>)}
          </NativeSelect>
          <label className="flex items-center gap-2 text-[12.5px] font-medium text-ink-700">
            <Switch checked={q.deteriorating} onCheckedChange={(c) => set("deteriorating", c ? "true" : null)} aria-label="Only vendors getting worse" />
            <TrendingDown className="h-4 w-4 text-ink-400" />Getting worse only
          </label>
          <div className="ml-auto flex items-center gap-3 text-[12px] text-ink-500">
            {data && <span><span className="num font-semibold text-ink-900">{data.total}</span> vendors{isFetching && " · updating..."}</span>}
            <Button variant="outline" size="sm" onClick={exportCsv} disabled={!data}><Download />Export page</Button>
          </div>
        </div>
        {error ? <div className="p-4"><ErrorState error={error} onRetry={() => refetch()} /></div> : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12.5px]">
              <thead>
                <tr>
                  {COLS.map((c) => (
                    <Th key={c.key} className={cn(c.align === "right" && "text-right")}>
                      <button onClick={() => sortBy(c.key === "category" ? "name" : c.key)} className={cn("inline-flex items-center gap-1 uppercase hover:text-ink-900", q.sort === c.key && "text-ink-900")}>
                        {c.label}{q.sort === c.key && (q.order === "desc" ? <ArrowDown className="h-3 w-3" /> : <ArrowUp className="h-3 w-3" />)}
                      </button>
                    </Th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {isLoading && Array.from({ length: 10 }).map((_, i) => <tr key={i}><td colSpan={COLS.length} className="px-3 py-2"><Skeleton className="h-6 w-full" /></td></tr>)}
                {data?.items.map((v) => (
                  <tr key={v.vendor_id} onClick={() => nav(`/vendors/${v.vendor_id}`)} className="cursor-pointer transition-colors hover:bg-brand-50/40">
                    <Td className="num w-10 text-ink-500">{v.rank}</Td>
                    <Td>
                      <div className="font-semibold text-ink-950"><span className="num">{v.vendor_id}</span> <span className="font-normal text-ink-600">{v.name}</span></div>
                      <div className="text-[11px] text-ink-500">{v.country} · {v.tier} · {v.status}</div>
                    </Td>
                    <Td className="text-ink-700">{v.category}</Td>
                    <Td className="text-right"><div className="flex items-center justify-end gap-2"><span className="num text-[13.5px] font-bold">{fmt.score(v.overall)}</span><BandBadge band={v.band} /></div></Td>
                    <Td className="text-right"><Cell v={v.delivery} /></Td>
                    <Td className="text-right"><Cell v={v.quality} /></Td>
                    <Td className="text-right"><Cell v={v.cost} /></Td>
                    <Td className="text-right"><Cell v={v.lead_time} /></Td>
                    <Td className="text-right"><Delta value={v.change_3m} className="text-[12px]" /></Td>
                    <Td><RiskBadge level={v.risk_level} label="" /></Td>
                  </tr>
                ))}
              </tbody>
            </table>
            {data && data.items.length === 0 && <EmptyState title="No vendors match these filters" hint="Try clearing the band or search filter." />}
          </div>
        )}
        {data && data.total > 0 && (
          <div className="flex items-center justify-between border-t border-ink-100 px-4 py-2.5 text-[12px] text-ink-500">
            <span>Page {q.page} of {pages}</span>
            <div className="flex gap-1.5">
              <Button variant="outline" size="sm" disabled={q.page <= 1} onClick={() => set("page", String(q.page - 1))}><ChevronLeft />Prev</Button>
              <Button variant="outline" size="sm" disabled={q.page >= pages} onClick={() => set("page", String(q.page + 1))}>Next<ChevronRight /></Button>
            </div>
          </div>
        )}
      </Card>
    </>
  );
}
