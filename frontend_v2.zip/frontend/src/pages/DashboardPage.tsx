import * as React from "react";
import { motion } from "framer-motion";
import {
  Activity, AlertOctagon, ShieldAlert, Sparkles, TrendingDown,
  PoundSterling, Truck, PackageOpen,
} from "lucide-react";
import { useDashboard, useValue } from "@/hooks/queries";
import { BusinessValue } from "@/components/BusinessValue";
import { VendorScoreCard } from "@/components/VendorScoreCard";
import { PriorityActions } from "@/components/PriorityActions";
import { PerformanceTrendCard } from "@/components/PerformanceTrendCard";
import { FilterBar, useUrlFilters } from "@/components/FilterBar";
import {
  BandBadge, Delta, ErrorState, KpiTile, LoadingCard, PageHeader, RiskBadge, SectionLink, VendorLink,
} from "@/components/domain";
import { Card, CardBody, CardHeader, Tabs, TabsContent, TabsList, TabsTrigger, Td, Th } from "@/components/ui/primitives";
import { BAND_COLOR, fmt } from "@/lib/utils";

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } };

export default function DashboardPage() {
  const [f] = useUrlFilters();
  const { data, isLoading, error, refetch } = useDashboard(f);
  const { data: value } = useValue("expected");

  const header = (
    <PageHeader eyebrow="Executive dashboard" title="How our vendors are performing"
      description={data ? <>{data.kpis.total_vendors} vendors · score out of 100 · 3 months to {fmt.month(data.period)} · fixed rules, not AI</> : "Loading..."}
      actions={<FilterBar />} />
  );
  if (error) return <>{header}<ErrorState error={error} onRetry={() => refetch()} /></>;
  if (isLoading || !data) return <>{header}<div className="grid gap-4 md:grid-cols-2"><LoadingCard /><LoadingCard /><LoadingCard /><LoadingCard /></div></>;

  const k = data.kpis;

  return (
    <>
      {header}
      {(() => {
        const o = data.operational;
        const needAction = k.at_risk + k.critical;
        const tiles = [
          { label: "Average score", value: fmt.score(k.avg_score), icon: Activity, delta: k.avg_score_change, sub: "out of 100 · change vs last month",
            tip: "Average of all vendor scores shown. Scores use fixed rules: delivery 30%, quality 30%, cost 20%, lead time 20%." },
          { label: "Need urgent action", value: needAction, icon: AlertOctagon, accent: BAND_COLOR.Critical, sub: `${k.at_risk} At Risk · ${k.critical} Critical (score below 60)`,
            to: "/vendors?sort=overall&order=asc", tip: "Vendors scoring below 60: At Risk (40-59) need an improvement plan; Critical (below 40) need escalation." },
          { label: "Getting worse", value: k.deteriorating, icon: TrendingDown, accent: "#dd5a24", sub: "score falling steadily, 8+ points off its best",
            to: "/vendors?deteriorating=true&sort=change_3m&order=asc", tip: "Vendors whose score has fallen steadily over the last 6 months and is at least 8 points below its recent best." },
          { label: "High risk of decline", value: k.high_risk, icon: ShieldAlert, accent: "#a8223d", sub: "likely to drop further in the next 3 months",
            to: "/vendors?risk=High&sort=overall&order=asc", tip: "From the XGBoost prediction model plus current warning signs (a weak, falling score always counts as High). A forecast, kept separate from the score." },
          o && { label: "Spend at risk", value: fmt.pct(o.spend_at_risk_pct), icon: PoundSterling, accent: "#dd5a24", delta: o.delta.spend_at_risk_pct, invertDelta: true, deltaSuffix: " pts",
            sub: `${fmt.gbp(o.spend_at_risk)} of 3-month spend with vendors below 75`, tip: "Share of the last 3 months of invoiced spend placed with vendors in the Watch, At Risk or Critical bands (score below 75). Lower is better." },
          o && { label: "Open orders at risk", value: fmt.gbp(o.open_po_value_at_risk), icon: PackageOpen, sub: `of ${fmt.gbp(o.open_po_value)} not yet delivered`,
            tip: "Value of orders placed but not yet delivered with vendors scoring below 75." },
          o && { label: "On-time delivery", value: fmt.pct(o.on_time_delivery_pct), icon: Truck, delta: o.delta.on_time_delivery_pct, deltaSuffix: " pts", sub: `of ${fmt.int(o.pos_completed)} orders in the last 3 months`,
            tip: "Orders fully delivered on or before the promised date, last 3 months." },
          value && { label: "Estimated yearly benefit", value: fmt.gbp(value.total_annual_gbp), icon: Sparkles, accent: "#1f8a4c", sub: `${value.roi_multiple ?? "-"}x return on cost · details below`,
            tip: "Expected scenario: invoice overcharges recovered, fewer late deliveries and quality failures, analyst time saved. Indicative - see Value for Primark below." },
        ].filter(Boolean) as React.ComponentProps<typeof KpiTile>[];
        return (
          <section aria-labelledby="key-heading" className="mb-5">
            <div className="mb-2 flex items-baseline justify-between"><h2 id="key-heading" className="text-[14px] font-semibold">Key metrics</h2><span className="text-[11.5px] text-ink-500">Hover a title for its definition</span></div>
            <motion.div variants={stagger} initial="hidden" animate="show" className="grid grid-cols-2 gap-3 md:grid-cols-4 2xl:grid-cols-8">
              {tiles.map((t) => <motion.div key={t.label} variants={item}><KpiTile {...t} /></motion.div>)}
            </motion.div>
          </section>
        );
      })()}

      <PriorityActions data={data} />

      <div className="mb-5 grid gap-4 xl:grid-cols-12">
        <div className="xl:col-span-8"><PerformanceTrendCard trend={data.trend} /></div>
        <Card className="xl:col-span-4">
          <Tabs defaultValue="worse">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-100 px-4 py-3">
              <span className="whitespace-nowrap text-[14px] font-semibold">Needs attention</span>
              <TabsList><TabsTrigger value="worse">Getting worse</TabsTrigger><TabsTrigger value="lowest">Lowest scores</TabsTrigger></TabsList>
            </div>
            <TabsContent value="worse" className="px-4 pb-2">
              <ul className="divide-y divide-ink-100">
                {data.deteriorating_vendors.slice(0, 5).map((v) => (
                  <li key={v.vendor_id} className="flex items-center justify-between gap-3 py-2.5">
                    <VendorLink id={v.vendor_id} name={v.name} className="max-w-[170px]" />
                    <div className="flex items-center gap-2">
                      <RiskBadge level={v.risk_level} label="" />
                      <span className="num w-10 text-right font-semibold">{fmt.score(v.overall)}</span>
                      <Delta value={v.change_3m} className="w-14 justify-end text-[12px]" />
                    </div>
                  </li>
                ))}
              </ul>
              <div className="py-2"><SectionLink to="/vendors?deteriorating=true&sort=change_3m&order=asc">All vendors getting worse</SectionLink></div>
            </TabsContent>
            <TabsContent value="lowest" className="px-4 pb-2">
              <ul className="divide-y divide-ink-100">
                {data.bottom_vendors.slice(0, 5).map((v) => (
                  <li key={v.vendor_id} className="flex items-center justify-between gap-3 py-2.5">
                    <VendorLink id={v.vendor_id} name={v.name} className="max-w-[170px]" />
                    <div className="flex items-center gap-2">
                      <BandBadge band={v.band} />
                      <span className="num w-10 text-right font-semibold">{fmt.score(v.overall)}</span>
                    </div>
                  </li>
                ))}
              </ul>
              <div className="py-2"><SectionLink to="/vendors?sort=overall&order=asc">All scorecards, lowest first</SectionLink></div>
            </TabsContent>
          </Tabs>
        </Card>
      </div>

      <BusinessValue />

      <VendorScoreCard data={data} />

      <Card>
        <CardHeader title="Performance by category" subtitle="Average scores for each product category" />
        <CardBody className="px-2 pt-2">
          <div className="overflow-x-auto">
            <table className="w-full text-[12.5px]">
              <thead><tr><Th>Category</Th><Th className="text-right">Vendors</Th><Th className="w-[220px]">Average score</Th><Th className="text-right">Delivery</Th><Th className="text-right">Quality</Th><Th className="text-right">Cost</Th><Th className="text-right">Lead-time</Th><Th className="text-right">At risk / critical</Th></tr></thead>
              <tbody>
                {data.category_performance.map((c) => (
                  <tr key={c.category_id} className="hover:bg-ink-50/50">
                    <Td className="font-medium text-ink-900">{c.category}</Td>
                    <Td className="num text-right">{c.vendors}</Td>
                    <Td><div className="flex items-center gap-2"><div className="h-1.5 flex-1 rounded-full bg-ink-100"><div className="h-1.5 rounded-full bg-brand-500" style={{ width: `${c.avg}%` }} /></div><span className="num w-9 text-right font-semibold">{c.avg.toFixed(1)}</span></div></Td>
                    {(["delivery", "quality", "cost", "lead_time"] as const).map((k2) => <Td key={k2} className="num text-right text-ink-700">{c[k2].toFixed(1)}</Td>)}
                    <Td className="num text-right">{c.at_risk > 0 ? <span className="font-semibold text-rose-700">{c.at_risk}</span> : <span className="text-ink-400">0</span>}</Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </>
  );
}
