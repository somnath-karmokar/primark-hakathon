import * as React from "react";
import {
  AlertTriangle, Calculator, CheckCircle2, CircleDollarSign, Coins, Gauge, HandCoins, Layers, Lock, PiggyBank, Receipt, Scissors, Timer, TrendingUp, Users, Zap,
} from "lucide-react";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useFinops, useSaveBudget } from "@/hooks/queries";
import { ChartTooltip, EmptyState, ErrorState, KpiTile, LoadingCard, PageHeader } from "@/components/domain";
import { Badge, Button, Card, CardBody, CardHeader, Input, Slider, Switch, Td, Th } from "@/components/ui/primitives";
import { useAuth } from "@/lib/auth";
import { SERIES, cn, fmt } from "@/lib/utils";

const KEY_LABEL: Record<string, string> = {
  "-": "No AI call needed", semantic_cache: "Answer reused (cache)", performance_explanation: "Explain performance", recommendation: "Recommend action",
  summary: "Summarise", policy_explanation: "Explain policy", executive_synthesis: "Executive summary", classify: "Understand question",
};
const keyLabel = (k: string) => KEY_LABEL[k] ?? k.replace(/^(openai|azure):/, "").replace(/_/g, " ");
const money = (v: number | null | undefined, d = 2) => (v == null ? "-" : v < 0.01 && v > 0 ? `£${v.toFixed(4)}` : `£${v.toLocaleString("en-GB", { minimumFractionDigits: d, maximumFractionDigits: d })}`);

interface Group { key: string; requests: number; calls: number; tokens: number; cost_gbp: number }
interface TopRequest { request_id: string; ts: string; user: string; role: string; tasks: string[]; calls: number; prompt_tokens: number; completion_tokens: number; cost_gbp: number; model: string }

export default function FinOpsPage() {
  const { data, isLoading, error } = useFinops();
  const save = useSaveBudget();
  const { can } = useAuth();
  const admin = can("configure");
  const [budget, setBudget] = React.useState<{ monthly_budget_gbp: number; alert_pct: number; hard_stop: boolean }>();
  const [users, setUsers] = React.useState(50);
  const [qpd, setQpd] = React.useState(10);
  const [days, setDays] = React.useState(21);
  React.useEffect(() => { if (data && !budget) setBudget({ monthly_budget_gbp: data.budget.monthly_budget_gbp, alert_pct: data.budget.alert_pct, hard_stop: data.budget.hard_stop }); }, [data, budget]);

  const header = <PageHeader eyebrow="AI cost management" title="AI cost and token usage"
    description="What AIRA costs to run, and who and what is spending." />;
  if (error) return <>{header}<ErrorState error={error} /></>;
  if (isLoading || !data || !budget) return <>{header}<LoadingCard h="h-96" /></>;

  const b = data.budget;
  const e = data.efficiency;
  const fx = data.usd_to_gbp;
  const req = Math.max(1, data.requests);
  const avgPrompt = data.requests ? data.tokens.prompt / req : 1800;
  const avgCompletion = data.requests ? data.tokens.completion / req : 250;
  const cacheShare = data.share_answered_without_new_model_call / 100;
  const questions = users * qpd * days;
  const perQ = (model: string) => {
    const [pin, pout] = data.prices_usd_per_million[model] ?? [0, 0];
    return ((avgPrompt / 1e6) * pin + (avgCompletion / 1e6) * pout) * fx;
  };
  const scenario = (model: string) => questions * (1 - cacheShare) * perQ(model);
  const active = data.active_model as string;
  const fixedLow = data.infrastructure.filter((i: { low: number | null }) => i.low != null).reduce((a: number, i: { low: number }) => a + i.low, 0);
  const fixedHigh = data.infrastructure.filter((i: { high: number | null }) => i.high != null).reduce((a: number, i: { high: number }) => a + i.high, 0);
  const totalTokens = data.tokens.prompt + data.tokens.completion;

  return (
    <>
      {header}
      <div className="space-y-4">
        {b.alert && <div className={cn("flex items-center gap-2 rounded-lg border px-4 py-2.5 text-[12.5px]", b.exhausted ? "border-rose-200 bg-rose-50 text-rose-900" : "border-amber-200 bg-amber-50 text-amber-900")}>
          <AlertTriangle className="h-4 w-4" />{b.exhausted ? (b.hard_stop ? "Monthly AI budget used up - the assistant now answers from facts only until next month." : "Monthly AI budget used up - spending continues (hard stop is off).") : `AI spend has passed ${b.alert_pct}% of the monthly budget.`}</div>}

        <div><h2 className="mb-2 text-[14px] font-semibold">Spend - {data.month}</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            <KpiTile label="AI spend so far" value={money(data.month_to_date_gbp, 4)} icon={CircleDollarSign} sub={`${fmt.int(data.model_calls)} AI model calls`} />
            <KpiTile label="Month-end forecast" value={money(data.forecast_month_gbp, 2)} icon={TrendingUp} sub="at the current daily rate" />
            <KpiTile label="Budget used" value={fmt.pct(b.used_pct, 1)} icon={HandCoins} accent={b.exhausted ? "#a8223d" : b.alert ? "#eaa400" : "#1f8a4c"} sub={`${money(b.spent_gbp, 4)} of ${money(b.monthly_budget_gbp, 0)} / month`} />
            <KpiTile label="Cost per question" value={money(data.avg_cost_per_question_gbp, 4)} icon={Calculator} sub={`${fmt.int(data.requests)} questions this month`} />
            <KpiTile label="Answered without a new AI call" value={fmt.pct(data.share_answered_without_new_model_call, 0)} icon={PiggyBank} accent="#1f8a4c" sub="cache or fact-based answers" />
            <KpiTile label="Saved by optimisation" value={money(data.savings.total_saving_gbp, 4)} icon={PiggyBank} sub={`${data.savings.cache_hits} cached · ${fmt.int(data.savings.jev_tokens_saved)} tokens trimmed`} />
          </div>
        </div>

        <div><h2 className="mb-2 text-[14px] font-semibold">Tokens</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            <KpiTile label="Tokens used" value={fmt.int(totalTokens)} icon={Coins} sub={`${fmt.int(data.tokens.prompt)} sent · ${fmt.int(data.tokens.completion)} received`}
              tip="Tokens are the units AI models are billed by - roughly 3/4 of a word each. 'Sent' is the question plus the facts we give the model; 'received' is its answer." />
            <KpiTile label="Tokens per question" value={fmt.int(e.avg_tokens_per_question)} icon={Layers} sub={`${fmt.int(e.avg_prompt_tokens_per_call)} sent · ${fmt.int(e.avg_completion_tokens_per_call)} received per AI call`} />
            <KpiTile label="Context trimmed" value={fmt.pct(e.context_reduction_pct, 0)} icon={Scissors} accent="#1f8a4c" sub="of the facts removed before sending (JEV)"
              tip="Share of tokens removed by compressing and de-duplicating the evidence before it is sent to the model." />
            <KpiTile label="Cost per 1,000 tokens" value={money(e.cost_per_1k_tokens_gbp, 5)} icon={Receipt} sub={`received tokens = ${fmt.pct(e.output_share_of_cost_pct, 0)} of cost`}
              tip="Answer (output) tokens cost about 4x more than input tokens, so short answers matter." />
            <KpiTile label="Cache hit rate" value={fmt.pct(e.cache_hit_rate_pct, 0)} icon={Zap} sub="questions answered from a saved answer" />
            <KpiTile label="AI response time" value={e.avg_latency_ms ? `${(e.avg_latency_ms / 1000).toFixed(1)} s` : "-"} icon={Timer} sub="average per AI call" />
          </div>
        </div>

        <div className="grid gap-4 xl:grid-cols-2">
          <Card>
            <CardHeader title="Tokens per day (last 30 days)" subtitle="Sent, received and trimmed" icon={<Coins className="h-4 w-4 text-brand-500" />} />
            <CardBody><div className="h-[240px]"><ResponsiveContainer>
              <BarChart data={data.daily} margin={{ top: 6, right: 8, left: -2, bottom: 0 }}>
                <CartesianGrid vertical={false} /><XAxis dataKey="date" tickFormatter={(d) => d.slice(5)} tickLine={false} axisLine={false} interval={4} />
                <YAxis tickLine={false} axisLine={false} tickFormatter={(v) => fmt.int(v)} width={56} />
                <Tooltip content={<ChartTooltip valueFormatter={(v: number) => `${fmt.int(v)} tokens`} />} />
                <Legend iconType="square" wrapperStyle={{ fontSize: 11.5, paddingTop: 6 }} />
                <Bar dataKey="prompt_tokens" name="Sent" stackId="t" fill={SERIES[0]} />
                <Bar dataKey="completion_tokens" name="Received" stackId="t" fill={SERIES[1]} radius={[3, 3, 0, 0]} />
                <Bar dataKey="saved_tokens" name="Trimmed (not sent)" fill="#b3bfce" radius={[3, 3, 0, 0]} />
              </BarChart></ResponsiveContainer></div></CardBody>
          </Card>
          <Card>
            <CardHeader title="AI spend per day (last 30 days)" subtitle={`Model: ${active} · GBP at ${fx} per USD`} icon={<CircleDollarSign className="h-4 w-4 text-brand-500" />} />
            <CardBody><div className="h-[240px]"><ResponsiveContainer>
              <BarChart data={data.daily} margin={{ top: 6, right: 8, left: -6, bottom: 0 }}>
                <CartesianGrid vertical={false} /><XAxis dataKey="date" tickFormatter={(d) => d.slice(5)} tickLine={false} axisLine={false} interval={4} />
                <YAxis tickLine={false} axisLine={false} tickFormatter={(v) => `£${Number(v).toFixed(4)}`} width={66} />
                <Tooltip content={<ChartTooltip valueFormatter={(v: number) => `£${v.toFixed(5)}`} />} />
                <Bar dataKey="cost_gbp" name="AI spend" fill="#0a8fc4" radius={[3, 3, 0, 0]} />
              </BarChart></ResponsiveContainer></div></CardBody>
          </Card>
        </div>

        <div className="grid gap-4 xl:grid-cols-12">
          <Card className="xl:col-span-8">
            <CardHeader title="Who and what is spending" subtitle="Cost attribution for showback / chargeback (this month)" icon={<Users className="h-4 w-4 text-brand-500" />} />
            <CardBody className="grid gap-4 px-2 pt-2 md:grid-cols-2">
              {([["By role", data.by_role], ["By person", data.by_user], ["By AI task", data.by_task], ["By model", data.by_model]] as [string, Group[]][]).map(([title, rows]) => (
                <div key={title}>
                  <div className="eyebrow mb-1 px-3">{title}</div>
                  <table className="w-full text-[12px]"><thead><tr><Th></Th><Th className="text-right">Questions</Th><Th className="text-right">Tokens</Th><Th className="text-right">Cost</Th></tr></thead>
                    <tbody>{rows.slice(0, 6).map((r) => (
                      <tr key={r.key}><Td>{keyLabel(r.key)}</Td><Td className="num text-right">{r.requests}</Td><Td className="num text-right">{fmt.int(r.tokens)}</Td><Td className="num text-right font-medium">{money(r.cost_gbp, 4)}</Td></tr>))}</tbody></table>
                </div>
              ))}
            </CardBody>
          </Card>
          <Card className="xl:col-span-4">
            <CardHeader title="Monthly AI budget" subtitle={admin ? "Admins can change the budget; changes are audited" : "Set by the administrator"} icon={<Lock className="h-4 w-4 text-brand-500" />} />
            <CardBody className="space-y-4">
              <div className="h-2.5 overflow-hidden rounded-full bg-ink-100"><div className={cn("h-2.5 rounded-full", b.exhausted ? "bg-band-critical" : b.alert ? "bg-band-watch" : "bg-band-excellent")} style={{ width: `${Math.min(100, b.used_pct)}%` }} /></div>
              <label className="block"><span className="text-[12px] font-medium text-ink-600">Budget per month (£)</span>
                <Input type="number" min={0} value={budget.monthly_budget_gbp} disabled={!admin} onChange={(ev) => setBudget({ ...budget, monthly_budget_gbp: Number(ev.target.value) })} className="mt-1 h-9" /></label>
              <div><div className="mb-1.5 flex justify-between text-[12px]"><span className="font-medium text-ink-600">Warn at</span><span className="num font-semibold">{budget.alert_pct}%</span></div>
                <Slider value={[budget.alert_pct]} min={10} max={100} step={5} disabled={!admin} onValueChange={([v]) => setBudget({ ...budget, alert_pct: v })} aria-label="Alert threshold" /></div>
              <label className="flex items-start justify-between gap-3"><span><span className="block text-[12.5px] font-medium">Hard stop at 100%</span><span className="block text-[11px] text-ink-500">Assistant keeps working from facts only - no surprise bills</span></span>
                <Switch checked={budget.hard_stop} disabled={!admin} onCheckedChange={(v) => setBudget({ ...budget, hard_stop: v })} /></label>
              {admin && <Button className="w-full" onClick={() => save.mutate(budget)} disabled={save.isPending}>Save budget</Button>}
              {save.isSuccess && <p className="text-[12px] text-emerald-700">Budget saved.</p>}
            </CardBody>
          </Card>
        </div>

        <Card>
          <CardHeader title="Most expensive questions this month" subtitle="Use this to spot long prompts or answers worth trimming" icon={<Gauge className="h-4 w-4 text-brand-500" />} />
          <CardBody className="overflow-x-auto px-2 pt-2">
            {data.top_requests.length === 0 ? <EmptyState icon={Gauge} title="No paid AI calls yet this month" hint="Ask AIRA a question; its token usage and cost appear here." /> : (
              <table className="w-full text-[12px]">
                <thead><tr><Th>When</Th><Th>Who</Th><Th>AI tasks</Th><Th>Model</Th><Th className="text-right">AI calls</Th><Th className="text-right">Tokens sent</Th><Th className="text-right">Tokens received</Th><Th className="text-right">Cost</Th></tr></thead>
                <tbody>{(data.top_requests as TopRequest[]).map((r) => (
                  <tr key={r.request_id}><Td className="whitespace-nowrap text-ink-600">{fmt.datetime(r.ts)}</Td><Td>{r.user} <span className="text-ink-400">({r.role})</span></Td>
                    <Td className="text-ink-600">{r.tasks.map(keyLabel).join(", ")}</Td><Td className="text-ink-600">{keyLabel(r.model)}</Td>
                    <Td className="num text-right">{r.calls}</Td><Td className="num text-right">{fmt.int(r.prompt_tokens)}</Td><Td className="num text-right">{fmt.int(r.completion_tokens)}</Td>
                    <Td className="num text-right font-semibold">{money(r.cost_gbp, 5)}</Td></tr>))}</tbody>
              </table>
            )}
          </CardBody>
        </Card>

        <div className="grid gap-4 xl:grid-cols-12">
          <Card className="xl:col-span-7">
            <CardHeader title="What would it cost at scale?" subtitle="Based on today's usage" icon={<Calculator className="h-4 w-4 text-brand-500" />} />
            <CardBody>
              <div className="grid gap-4 md:grid-cols-3">
                {([["People using it", users, setUsers, 5, 500, 5], ["Questions per person per day", qpd, setQpd, 1, 50, 1], ["Working days per month", days, setDays, 5, 23, 1]] as [string, number, (n: number) => void, number, number, number][]).map(([l, v, set, mn, mx, st]) => (
                  <div key={l}><div className="mb-1.5 flex justify-between text-[12px]"><span className="font-medium text-ink-600">{l}</span><span className="num font-semibold">{v}</span></div>
                    <Slider value={[v]} min={mn} max={mx} step={st} onValueChange={([x]) => set(x)} aria-label={l} /></div>
                ))}
              </div>
              <div className="mt-4 rounded-xl bg-ink-50 p-3 text-[12.5px] text-ink-700">{fmt.int(questions)} questions a month · {Math.round(cacheShare * 100)}% answered without a new AI call · ~{fmt.int(avgPrompt)} tokens sent / {fmt.int(avgCompletion)} received per question</div>
              <table className="mt-3 w-full text-[12.5px]">
                <thead><tr><Th>AI model</Th><Th className="text-right">Price per 1M tokens (sent / received)</Th><Th className="text-right">Cost per AI answer</Th><Th className="text-right">Monthly AI cost</Th><Th className="text-right">Per person / month</Th></tr></thead>
                <tbody>{Object.keys(data.prices_usd_per_million).filter((k) => !k.startsWith("text-embedding")).map((k) => (
                  <tr key={k} className={cn(k === active && "bg-brand-50/50")}><Td className="font-medium">{k}{k === active && <Badge tone="brand" className="ml-2">in use</Badge>}</Td>
                    <Td className="num text-right text-ink-600">${data.prices_usd_per_million[k][0]} / ${data.prices_usd_per_million[k][1]}</Td>
                    <Td className="num text-right">{money(perQ(k), 5)}</Td><Td className="num text-right font-semibold">{money(scenario(k), 2)}</Td><Td className="num text-right">{money(scenario(k) / users, 3)}</Td></tr>))}</tbody>
              </table>
              <p className="mt-2 text-[11px] text-ink-500">List prices in USD per million tokens.</p>
            </CardBody>
          </Card>
          <Card className="xl:col-span-5">
            <CardHeader title="Expected monthly running cost (pilot)" subtitle="Planning estimate" icon={<CircleDollarSign className="h-4 w-4 text-brand-500" />} />
            <CardBody className="px-2 pt-2">
              <table className="w-full text-[12.5px]">
                <thead><tr><Th>Item</Th><Th className="text-right">£ / month</Th></tr></thead>
                <tbody>{data.infrastructure.map((i: { item: string; low: number | null; high: number | null; basis: string }) => (
                  <tr key={i.item}><Td><div className="font-medium">{i.item}</div><div className="text-[11px] text-ink-500">{i.basis}</div></Td>
                    <Td className="num whitespace-nowrap text-right">{i.low == null ? money(scenario(active), 2) : i.low === i.high ? money(i.low, 0) : `${money(i.low, 0)} - ${money(i.high, 0)}`}</Td></tr>))}
                  <tr className="bg-ink-50/70"><Td className="font-semibold">Total (with the scenario above)</Td><Td className="num whitespace-nowrap text-right font-semibold">{money(fixedLow + scenario(active), 0)} - {money(fixedHigh + scenario(active), 0)}</Td></tr></tbody>
              </table>
            </CardBody>
          </Card>
        </div>

        <Card>
          <CardHeader title="How the solution keeps AI costs down" icon={<PiggyBank className="h-4 w-4 text-brand-500" />} />
          <CardBody><ul className="grid gap-2.5 md:grid-cols-2">{data.levers.map((l: { lever: string; effect: string }) => (
            <li key={l.lever} className="flex gap-2.5 text-[12.5px]"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /><span><span className="font-semibold text-ink-900">{l.lever}.</span> <span className="text-ink-600">{l.effect}</span></span></li>))}</ul>
          </CardBody>
        </Card>
      </div>
    </>
  );
}
