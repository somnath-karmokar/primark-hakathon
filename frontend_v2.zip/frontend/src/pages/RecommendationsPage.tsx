import * as React from "react";
import { Link, useSearchParams } from "react-router-dom";
import { CheckCircle2, FileSignature, Scale, ShieldCheck, Sparkles, XCircle } from "lucide-react";
import { useAlternatives, useChat, useVendorRecs, useVendors } from "@/hooks/queries";
import { BandBadge, Delta, EmptyState, ErrorState, LoadingCard, PageHeader, RiskBadge, ScoreRing, SourcePill, VendorLink } from "@/components/domain";
import { Badge, Button, Card, CardBody, CardHeader, NativeSelect, Td, Th } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";
import type { Alternative } from "@/types/api";

function FitBar({ a }: { a: Alternative }) {
  const parts = [
    { label: "Score", v: 0.55 * a.overall, c: "#0a8fc4" },
    { label: "Overlap", v: 0.2 * a.product_overlap_pct, c: "#1baf7a" },
    { label: "Risk headroom", v: 0.15 * ({ Low: 100, Medium: 60, High: 20 } as Record<string, number>)[a.risk_level] || 0.15 * 60, c: "#eda100" },
    { label: "Trend", v: 0.1 * (({ improving: 100, stable: 85, declining: 50, deteriorating: 20 } as Record<string, number>)[a.trend ?? "stable"] ?? 70), c: "#e87ba4" },
  ];
  return (
    <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-ink-100" title={parts.map((p) => `${p.label} ${p.v.toFixed(1)}`).join(" · ")}>
      {parts.map((p) => <div key={p.label} style={{ width: `${p.v}%`, backgroundColor: p.c }} className="border-r-2 border-white last:border-0" />)}
    </div>
  );
}

export default function RecommendationsPage() {
  const [sp, setSp] = useSearchParams();
  const vid = (sp.get("vendor") ?? "V1024").toUpperCase();
  const { data: under } = useVendors({ sort: "change_3m", order: "asc", page_size: 25, deteriorating: true });
  const { data: low } = useVendors({ sort: "overall", order: "asc", page_size: 15 });
  const { data: alts, isLoading, error } = useAlternatives(vid, 6);
  const { data: recs } = useVendorRecs(vid);
  const chat = useChat();
  const [governed, setGoverned] = React.useState<{ confidence: number; label: string; status: string; id: number | null } | null>(null);
  React.useEffect(() => setGoverned(null), [vid]);

  const options = React.useMemo(() => {
    const m = new Map<string, string>();
    [...(under?.items ?? []), ...(low?.items ?? [])].forEach((v) => m.set(v.vendor_id, `${v.vendor_id} · ${v.name} (${v.overall.toFixed(1)})`));
    if (!m.has(vid)) m.set(vid, alts?.vendor ? `${vid} · ${alts.vendor.name} (${alts.vendor.overall.toFixed(1)})` : vid);
    return [...m.entries()];
  }, [under, low, vid, alts]);

  const engine = recs?.engine;
  const generate = () => chat.mutate({ message: `What procurement action do you recommend for ${vid}?` }, {
    onSuccess: (r) => setGoverned({ confidence: r.confidence, label: r.confidence_label, status: r.recommendation?.status ?? "-", id: r.recommendation?.id ?? null }),
  });

  return (
    <>
      <PageHeader eyebrow="Alternative suppliers" title="Who could replace or back up this vendor?"
        description="Vendors that already make the same products - best match first."
        actions={<NativeSelect label="Vendor to replace or back up" value={vid} onChange={(e) => setSp({ vendor: e.target.value })} className="min-w-[320px]">
          {options.map(([id, label]) => <option key={id} value={id}>{label}</option>)}
        </NativeSelect>} />
      {error ? <ErrorState error={error} /> : isLoading || !alts ? <div className="grid gap-4 md:grid-cols-3"><LoadingCard /><LoadingCard /><LoadingCard /></div> : (
        <>
          <div className="mb-4 grid gap-4 xl:grid-cols-12">
            <Card className="xl:col-span-4">
              <CardHeader title="Current vendor" subtitle="The vendor under review" />
              <CardBody className="flex items-center gap-4">
                <ScoreRing score={alts.vendor.overall} size={104} />
                <div className="min-w-0">
                  <VendorLink id={alts.vendor.vendor_id} name={alts.vendor.name} />
                  <div className="mt-1.5 flex flex-wrap gap-1.5"><BandBadge band={alts.vendor.band} /><RiskBadge level={alts.vendor.risk_level} /></div>
                  <div className="mt-1.5 text-[12px] text-ink-500">{alts.vendor.category} · {alts.vendor.region} · trend <Delta value={alts.vendor.change_3m} /></div>
                </div>
              </CardBody>
            </Card>
            <Card className="xl:col-span-8">
              <CardHeader title={engine?.title ?? "Recommendation"} subtitle={engine?.policy_basis} icon={<FileSignature className="h-4 w-4 text-brand-500" />}
                action={<Button variant="brand" size="sm" onClick={generate} disabled={chat.isPending}><Sparkles />{chat.isPending ? "Working..." : "Create a recommendation for approval"}</Button>} />
              <CardBody>
                {engine && (
                  <div className="grid gap-4 md:grid-cols-2">
                    <div><div className="eyebrow mb-1">Why we recommend it</div><ul className="space-y-1 text-[12.5px]">{engine.triggers.length ? engine.triggers.map((t) => <li key={t}>• {t}</li>) : <li className="text-ink-500">No escalation triggers.</li>}</ul></div>
                    <div><div className="eyebrow mb-1">What to do</div><ol className="space-y-1 text-[12.5px]">{engine.steps.map((s, i) => <li key={s}><span className="num font-semibold text-brand-600">{i + 1}.</span> {s}</li>)}</ol></div>
                  </div>
                )}
                <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-ink-100 pt-3 text-[12px]">
                  {engine?.policy_refs.map((r) => <Badge key={r} tone="brand">{r}</Badge>)}
                  <span className="text-ink-500">Approved by: <span className="font-semibold text-ink-800">{engine?.approver}</span></span>
                  {governed ? (
                    <span className="ml-auto flex items-center gap-2 rounded-lg bg-emerald-50 px-2.5 py-1 text-emerald-900">
                      <ShieldCheck className="h-4 w-4" />Recorded · how sure <span className="num font-semibold">{Math.round(governed.confidence * 100)}%</span> ({governed.label}) · {governed.status.replace("_", " ")}
                      <Link to="/governance" className="font-semibold underline">review</Link>
                    </span>
                  ) : <span className="ml-auto text-ink-400">Creates a recommendation with its evidence, for approval.</span>}
                </div>
              </CardBody>
            </Card>
          </div>

          <Card className="mb-4">
            <CardHeader title="Possible alternatives" subtitle={`${alts.candidates_considered} suppliers found · best ${alts.alternatives.length} shown`}
              action={<div className="flex items-center gap-2"><SourcePill source={alts.graph_source} /><Link to={`/compare?ids=${[alts.vendor.vendor_id, ...alts.alternatives.slice(0, 3).map((a) => a.vendor_id)].join(",")}`} className="text-[12px] font-medium text-brand-600">Open in comparison →</Link></div>} />
            <CardBody className="overflow-x-auto px-2 pt-2">
              {alts.alternatives.length === 0 ? <EmptyState title="No alternative suppliers found" hint="No vendor makes these products." /> : (
                <table className="w-full text-[12.5px]">
                  <thead><tr><Th>Rank</Th><Th>Supplier</Th><Th className="text-right">Score</Th><Th className="text-right">vs current</Th><Th className="text-right">Delivery</Th><Th className="text-right">Quality</Th><Th className="text-right">Cost</Th><Th className="text-right">Lead-time</Th><Th>Same products</Th><Th>Risk</Th><Th className="w-40">Match score</Th><Th>Allowed?</Th></tr></thead>
                  <tbody>
                    <tr className="bg-ink-50/70"><Td className="text-ink-500">Current</Td><Td><VendorLink id={alts.vendor.vendor_id} name={alts.vendor.name} className="max-w-[200px]" /></Td>
                      <Td className="num text-right font-semibold">{alts.vendor.overall.toFixed(1)}</Td><Td /><Td className="num text-right">{alts.vendor.delivery.toFixed(1)}</Td><Td className="num text-right">{alts.vendor.quality.toFixed(1)}</Td>
                      <Td className="num text-right">{alts.vendor.cost.toFixed(1)}</Td><Td className="num text-right">{alts.vendor.lead_time.toFixed(1)}</Td><Td>-</Td><Td><RiskBadge level={alts.vendor.risk_level} label="" /></Td><Td /><Td /></tr>
                    {alts.alternatives.map((a, i) => (
                      <tr key={a.vendor_id} className={cn(i === 0 && a.eligible && "bg-emerald-50/40")}>
                        <Td className="num font-semibold">{i + 1}</Td>
                        <Td><VendorLink id={a.vendor_id} name={a.name} className="max-w-[200px]" /><div className="text-[11px] text-ink-500">{a.region} · {a.tier}</div></Td>
                        <Td className="text-right"><div className="flex items-center justify-end gap-1.5"><span className="num font-semibold">{a.overall.toFixed(1)}</span><BandBadge band={a.band} /></div></Td>
                        <Td className="text-right"><Delta value={a.score_delta_vs_incumbent} /></Td>
                        {(["delivery", "quality", "cost", "lead_time"] as const).map((k) => <Td key={k} className={cn("num text-right", a[k] > alts.vendor[k] ? "text-emerald-700" : "text-ink-700")}>{a[k].toFixed(1)}</Td>)}
                        <Td><div className="num font-medium">{a.product_overlap_pct.toFixed(0)}%</div><div className="max-w-[160px] truncate text-[11px] text-ink-500">{a.shared_product_names.join(", ")}</div></Td>
                        <Td><RiskBadge level={a.risk_level} label="" /></Td>
                        <Td><div className="num mb-1 text-right font-semibold">{a.fit_score.toFixed(1)}</div><FitBar a={a} /></Td>
                        <Td>{a.eligible ? <span className="inline-flex items-center gap-1 text-emerald-700"><CheckCircle2 className="h-4 w-4" />Yes</span>
                          : <span className="inline-flex items-start gap-1 text-amber-800" title={a.eligibility_issues.join("; ")}><XCircle className="mt-0.5 h-4 w-4 shrink-0" /><span className="text-[11.5px]">{a.eligibility_issues[0]}</span></span>}</Td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </CardBody>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader title="How the ranking works" icon={<Scale className="h-4 w-4 text-brand-500" />} subtitle="Fixed, repeatable rules - no AI decides the order" />
              <CardBody className="space-y-2 text-[12.5px]">
                <code className="block rounded-lg bg-ink-50 p-3 text-[12px] text-ink-800">{alts.method}</code>
                <div className="flex flex-wrap gap-3 text-[11.5px] text-ink-600">
                  {[["Performance score (55%)", "#0a8fc4"], ["Makes the same products (20%)", "#1baf7a"], ["Low risk (15%)", "#eda100"], ["Improving trend (10%)", "#e87ba4"]].map(([l, c]) => <span key={l} className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: c }} />{l}</span>)}
                </div>
              </CardBody>
            </Card>
            <Card>
              <CardHeader title="Policy rules applied" icon={<ShieldCheck className="h-4 w-4 text-brand-500" />} subtitle="Checked before any supplier is suggested" />
              <CardBody><ul className="space-y-1.5 text-[12.5px]">{alts.policy_constraints.map((p) => <li key={p} className="flex gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand-500" />{p}</li>)}</ul></CardBody>
            </Card>
          </div>
        </>
      )}
    </>
  );
}
