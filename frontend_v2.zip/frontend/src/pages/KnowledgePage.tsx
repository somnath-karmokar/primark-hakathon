import * as React from "react";
import { useSearchParams } from "react-router-dom";
import { Archive, BookOpen, CheckCircle2, FilePlus2, FileText, History, Lock, PencilLine, Search } from "lucide-react";
import { useArchivePolicy, useDocument, useDocuments, useKnowledgeSearch } from "@/hooks/queries";
import { useAuth } from "@/lib/auth";
import { PolicyEditor, PolicyHistory } from "@/components/PolicyEditor";
import { EmptyState, ErrorState, LoadingCard, PageHeader } from "@/components/domain";
import { Badge, Button, Card, CardBody, CardHeader, Input, NativeSelect, Skeleton } from "@/components/ui/primitives";
import { cn, fmt } from "@/lib/utils";
import { Markdown } from "@/components/Markdown";

const TYPE_TONE: Record<string, "brand" | "good" | "warning" | "neutral" | "serious"> = { policy: "brand", sla: "good", standard: "warning", guideline: "neutral", contract: "serious" };

export default function KnowledgePage() {
  const [sp, setSp] = useSearchParams();
  const docId = sp.get("doc") ?? undefined;
  const [q, setQ] = React.useState("");
  const [dq, setDq] = React.useState("");
  const [type, setType] = React.useState("");
  React.useEffect(() => { const t = setTimeout(() => setDq(q), 300); return () => clearTimeout(t); }, [q]);
  const { data: docs, isLoading, error } = useDocuments();
  const { data: doc, isLoading: docLoading } = useDocument(docId ?? docs?.[0]?.document_id);
  const { data: hits, isFetching } = useKnowledgeSearch(dq, type || undefined);
  const [highlight, setHighlight] = React.useState<string>();
  const { can } = useAuth();
  const admin = can("configure");
  const [mode, setMode] = React.useState<"view" | "edit" | "new" | "history">("view");
  const [notice, setNotice] = React.useState<string>();
  const [confirmArchive, setConfirmArchive] = React.useState(false);
  const archive = useArchivePolicy();
  const currentId = docId ?? docs?.[0]?.document_id;

  const open = (id: string, section?: string) => { setMode("view"); setConfirmArchive(false); setSp({ doc: id }); setHighlight(section); setTimeout(() => section && document.getElementById(section)?.scrollIntoView({ behavior: "smooth", block: "center" }), 250); };

  return (
    <>
      <PageHeader eyebrow="Policies & contracts" title="Procurement policies, contracts and standards"
        description={admin ? "Search and maintain the rules AIRA uses. Every change is versioned and audited." : "The policies, SLAs, standards and contracts AIRA uses."}
        actions={admin ? <Button variant="brand" onClick={() => { setMode("new"); setNotice(undefined); }}><FilePlus2 />New document</Button>
          : <Badge tone="neutral" className="px-2.5 py-1 text-[12px]"><Lock className="h-3.5 w-3.5" />View only - admins can edit</Badge>} />
      {notice && <div className="mb-4 flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-[12.5px] text-emerald-900"><CheckCircle2 className="h-4 w-4" />{notice}</div>}
      {error ? <ErrorState error={error} /> : (
        <div className="grid gap-4 xl:grid-cols-12">
          <div className="space-y-4 xl:col-span-4">
            <Card>
              <CardHeader title="Search" subtitle="Searches by meaning" icon={<Search className="h-4 w-4 text-brand-500" />} />
              <CardBody className="space-y-2">
                <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="e.g. late delivery penalty, quality checks, backup supplier rules" aria-label="Search knowledge" />
                <NativeSelect value={type} onChange={(e) => setType(e.target.value)} aria-label="Document type" className="w-full">
                  <option value="">All document types</option>{["policy", "sla", "standard", "guideline", "contract"].map((t) => <option key={t} value={t}>{t}</option>)}
                </NativeSelect>
                {dq.length >= 3 && (
                  <div className="space-y-2 pt-1">
                    <div className="flex justify-between text-[11px] text-ink-400"><span>{isFetching ? "Searching..." : `${hits?.results.length ?? 0} passages`}</span><span>{hits?.embedding_model}{hits?.cache_hit && " · cached"}</span></div>
                    {hits?.results.map((h) => (
                      <button key={h.id} onClick={() => open(h.metadata.document_id, h.metadata.section)} className="w-full rounded-lg border border-ink-100 p-2.5 text-left hover:border-brand-300 hover:bg-brand-50/30">
                        <div className="flex items-center justify-between gap-2"><span className="truncate text-[12px] font-semibold">{h.metadata.section}</span><span className="num text-[11px] text-ink-400">{h.score.toFixed(2)}</span></div>
                        <div className="text-[11px] text-ink-500">{h.metadata.title} · v{h.metadata.policy_version}</div>
                        <p className="mt-1 line-clamp-3 text-[12px] text-ink-700">{h.text.split("\n").slice(1).join(" ")}</p>
                      </button>
                    ))}
                  </div>
                )}
              </CardBody>
            </Card>
            <Card>
              <CardHeader title="Documents" subtitle={docs ? `${docs.length} documents indexed` : ""} icon={<BookOpen className="h-4 w-4 text-brand-500" />} />
              <CardBody className="space-y-1.5">
                {isLoading && <Skeleton className="h-40 w-full" />}
                {docs?.map((d) => (
                  <button key={d.document_id} onClick={() => open(d.document_id)} className={cn("w-full rounded-lg border px-3 py-2 text-left transition-colors", (docId ?? docs[0].document_id) === d.document_id ? "border-brand-300 bg-brand-50/50" : "border-ink-100 hover:bg-ink-50")}>
                    <div className="flex items-center justify-between gap-2"><span className="flex items-center gap-2 text-[12.5px] font-semibold"><FileText className="h-3.5 w-3.5 text-ink-400" />{d.title}</span><Badge tone={TYPE_TONE[d.document_type] ?? "neutral"}>{d.document_type}</Badge></div>
                    <div className="mt-0.5 text-[11px] text-ink-500">{d.document_id} · v{d.policy_version} · effective {fmt.date(d.effective_date)} · {d.sections?.length} sections</div>
                  </button>
                ))}
              </CardBody>
            </Card>
          </div>
          <div className="xl:col-span-8">
            {mode === "new" ? <PolicyEditor onCancel={() => setMode("view")} onDone={(id, v) => { setMode("view"); setSp({ doc: id }); setNotice(`${id} v${v} created and indexed - AIRA can now quote it.`); }} />
            : mode === "edit" && currentId ? <PolicyEditor id={currentId} onCancel={() => setMode("view")} onDone={(id, v) => { setMode("view"); setNotice(`${id} saved as v${v} and re-indexed - AIRA now uses the new wording. The previous version is in the history.`); }} />
            : mode === "history" && currentId ? <PolicyHistory id={currentId} onClose={() => setMode("view")} />
            : docLoading || !doc ? <LoadingCard h="h-[520px]" /> : (
              <Card>
                <div className="border-b border-ink-100 px-6 py-4">
                  <div className="flex flex-wrap items-center gap-2"><Badge tone={TYPE_TONE[doc.document_type] ?? "neutral"}>{doc.document_type}</Badge><Badge>{doc.document_id}</Badge><Badge>v{doc.policy_version}</Badge><Badge>effective {fmt.date(doc.effective_date)}</Badge><Badge>{doc.chunks.length} chunks</Badge></div>
                  <div className="mt-2 flex flex-wrap items-start justify-between gap-2">
                    <h2 className="text-[20px] font-bold">{doc.title}</h2>
                    {admin && (
                      <div className="flex flex-wrap gap-1.5">
                        <Button size="sm" variant="outline" onClick={() => { setMode("edit"); setNotice(undefined); }}><PencilLine />Edit</Button>
                        <Button size="sm" variant="outline" onClick={() => setMode("history")}><History />Version history</Button>
                        {confirmArchive
                          ? <><Button size="sm" variant="outline" className="border-rose-300 text-rose-700" disabled={archive.isPending}
                                onClick={() => archive.mutate(doc.document_id, { onSuccess: () => { setConfirmArchive(false); setSp({}); setNotice(`${doc.document_id} archived - AIRA no longer uses it. It can still be read in its version history.`); } })}>
                                <Archive />Confirm archive</Button>
                              <Button size="sm" variant="ghost" onClick={() => setConfirmArchive(false)}>Keep</Button></>
                          : <Button size="sm" variant="ghost" className="text-ink-500" onClick={() => setConfirmArchive(true)}><Archive />Archive</Button>}
                      </div>
                    )}
                  </div>
                  {archive.isError && <p className="mt-1 text-[12px] text-rose-700">{(archive.error as Error).message}</p>}
                  <p className="text-[11.5px] text-ink-500">Source: {doc.source} · {doc.file}</p>
                </div>
                <CardBody className="max-h-[70vh] overflow-y-auto px-6 py-5 scrollbar-thin">
                  {doc.markdown ? <Markdown md={doc.markdown} highlight={highlight} /> : <EmptyState title="Empty document" />}
                </CardBody>
              </Card>
            )}
          </div>
        </div>
      )}
    </>
  );
}
