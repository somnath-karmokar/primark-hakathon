import * as React from "react";
import {
  AlertTriangle, BadgeCheck, Ban, CheckCircle2, Eye, Fingerprint, Gauge, Lock, MessageSquareHeart,
  Scale, ShieldCheck, ThumbsDown, UserCheck, XCircle,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useTrustRAI, useTrustSecurity } from "@/hooks/queries";
import { ErrorState, KpiTile, LoadingCard, PageHeader } from "@/components/domain";
import { Badge, Card, CardBody, CardHeader, Tabs, TabsContent, TabsList, TabsTrigger, Td, Th, Tip } from "@/components/ui/primitives";
import { cn, fmt } from "@/lib/utils";

const PRINCIPLE_ICON: Record<string, React.ElementType> = {
  "Human in control": UserCheck, "Accuracy & grounding": BadgeCheck, Transparency: Eye, Fairness: Scale, Privacy: Fingerprint,
  "Safety & security": ShieldCheck, "Honest ML": Gauge, "Feedback & accountability": MessageSquareHeart,
};

/* ================================================================ Responsible AI */
function ResponsibleAI() {
  const { data, isLoading, error } = useTrustRAI();
  if (error) return <ErrorState error={error} />;
  if (isLoading || !data) return <LoadingCard h="h-96" />;
  const m = data.metrics;
  const f = data.fairness;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 2xl:grid-cols-7">
        <KpiTile label="AI answers given" value={fmt.int(m.answers)} icon={MessageSquareHeart} sub={`${m.ai_written} written by AI · ${m.fact_based_fallback} fact-based`} />
        <KpiTile label="Passed every check" value={fmt.pct(m.fully_checked_pct)} icon={BadgeCheck} accent="#1f8a4c" sub="figures, citations, policy" />
        <KpiTile label="AI drafts rejected" value={m.drafts_rejected} icon={XCircle} accent="#dd5a24" sub="replaced by checked answer" />
        <KpiTile label="Questions blocked" value={m.blocked_questions} icon={Ban} accent="#a8223d" sub={`${m.injection_attempts} manipulation attempts`} />
        <KpiTile label="Personal data removed" value={m.personal_data_redactions} icon={Fingerprint} sub="before reaching the AI" />
        <KpiTile label="Waiting for approval" value={m.approvals_pending} icon={UserCheck} accent="#eaa400" sub={`${m.approvals_approved} approved · ${m.approvals_rejected} rejected`} />
        <KpiTile label="Rated helpful" value={m.feedback_positive_pct != null ? fmt.pct(m.feedback_positive_pct, 0) : "-"} icon={MessageSquareHeart} sub={`${m.feedback_up} helpful · ${m.feedback_down} not helpful`} />
      </div>

      <Card>
        <CardHeader title="How we use AI responsibly" subtitle="Principles, controls and live evidence" icon={<ShieldCheck className="h-4 w-4 text-brand-500" />} />
        <CardBody className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {data.principles.map((p: { principle: string; what: string; controls: string[]; evidence: string }) => {
            const Icon = PRINCIPLE_ICON[p.principle] ?? ShieldCheck;
            return (
              <div key={p.principle} className="flex flex-col rounded-xl border border-ink-100 p-3.5">
                <div className="flex items-center gap-2"><span className="rounded-lg bg-brand-50 p-1.5"><Icon className="h-4 w-4 text-brand-600" /></span><span className="text-[13.5px] font-semibold">{p.principle}</span></div>
                <p className="mt-2 text-[12.5px] text-ink-700">{p.what}</p>
                <ul className="mt-2 flex-1 space-y-1 text-[12px] text-ink-600">{p.controls.map((c) => <li key={c} className="flex gap-1.5"><CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />{c}</li>)}</ul>
                <div className="mt-3 rounded-lg bg-ink-50 px-2.5 py-1.5 text-[11.5px] text-ink-700"><span className="font-semibold">Live: </span>{p.evidence}</div>
              </div>
            );
          })}
        </CardBody>
      </Card>

      <div className="grid gap-4 xl:grid-cols-12">
        <Card className="xl:col-span-12">
          <CardHeader title="Fairness check - are all sourcing regions treated the same way?" icon={<Scale className="h-4 w-4 text-brand-500" />}
            subtitle={`Average score by region (portfolio average ${f.portfolio_avg}). Largest gap: ${f.max_gap} points.`} />
          <CardBody className="overflow-x-auto px-2 pt-2">
            <table className="w-full text-[12.5px]">
              <thead><tr><Th>Region</Th><Th className="text-right">Vendors</Th><Th className="w-44">Average score</Th><Th className="text-right">Delivery</Th><Th className="text-right">Quality</Th><Th className="text-right">Cost</Th><Th className="text-right">Lead time</Th><Th className="text-right">Below 75</Th><Th>Main reason for difference</Th></tr></thead>
              <tbody>{f.by_region.map((r: { region: string; vendors: number; overall: number; delivery: number; quality: number; cost: number; lead_time: number; weak: number; explained_by: string }) => (
                <tr key={r.region}>
                  <Td className="font-medium">{r.region}</Td><Td className="num text-right">{r.vendors}</Td>
                  <Td><div className="flex items-center gap-2"><div className="h-1.5 flex-1 rounded-full bg-ink-100"><div className="h-1.5 rounded-full bg-brand-500" style={{ width: `${r.overall}%` }} /></div><span className="num w-9 text-right font-semibold">{r.overall}</span></div></Td>
                  {(["delivery", "quality", "cost", "lead_time"] as const).map((k) => <Td key={k} className="num text-right text-ink-700">{r[k]}</Td>)}
                  <Td className="num text-right">{r.weak}%</Td><Td className="text-ink-600">{r.explained_by}</Td>
                </tr>))}</tbody>
            </table>
            <p className="px-3 pt-3 text-[12px] text-ink-700">{f.verdict}</p>
            <p className="px-3 pt-1 text-[11.5px] text-ink-500">{f.threshold_note}</p>
          </CardBody>
        </Card>
        <Card className="xl:col-span-12">
          <CardHeader title="Answers people marked 'not helpful'" subtitle="Reviewed by the Procurement Excellence team" icon={<ThumbsDown className="h-4 w-4 text-brand-500" />} />
          <CardBody>
            {data.recent_negative_feedback.length === 0 ? <p className="text-[12.5px] text-ink-500">No negative feedback yet. Users can rate any answer with a thumbs up or down in the AI assistant.</p> : (
              <ul className="space-y-2">{data.recent_negative_feedback.map((n: { ts: string; user: string; question: string; comment: string | null; request_id: string }) => (
                <li key={n.request_id + n.ts} className="rounded-lg border border-ink-100 p-2.5 text-[12px]">
                  <div className="font-medium text-ink-900">{n.question || "(question not captured)"}</div>
                  {n.comment && <div className="mt-0.5 text-ink-600">"{n.comment}"</div>}
                  <div className="mt-1 text-[11px] text-ink-400">{n.user} · {fmt.datetime(n.ts)} · {n.request_id}</div>
                </li>))}</ul>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

/* ================================================================ Security */
const STATUS = {
  pass: { icon: CheckCircle2, cls: "text-emerald-600", label: "In place", tone: "good" as const },
  warn: { icon: AlertTriangle, cls: "text-amber-600", label: "Pilot setting", tone: "warning" as const },
  fail: { icon: XCircle, cls: "text-rose-600", label: "Fix needed", tone: "critical" as const },
};

function Security() {
  const { data, isLoading, error } = useTrustSecurity();
  if (error) return <ErrorState error={error} />;
  if (isLoading || !data) return <LoadingCard h="h-96" />;
  const areas = [...new Set(data.checks.map((c: { area: string }) => c.area))] as string[];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <KpiTile label="Controls in place" value={data.summary.pass} icon={CheckCircle2} accent="#1f8a4c" sub="checked live on this system" />
        <KpiTile label="Pilot-only settings" value={data.summary.warn} icon={AlertTriangle} accent="#eaa400" sub="acceptable locally; changed for production" />
        <KpiTile label="Fix needed" value={data.summary.fail} icon={XCircle} accent="#a8223d" sub="should be zero" />
      </div>
      <Card>
        <CardHeader title="Security checks - today and in an enterprise rollout" subtitle="Checked automatically each time this page loads" icon={<ShieldCheck className="h-4 w-4 text-brand-500" />} />
        <CardBody className="overflow-x-auto px-2 pt-2">
          <table className="w-full text-[12.5px]">
            <thead><tr><Th>Area</Th><Th>Check</Th><Th>Status</Th><Th>In this build</Th><Th>Enterprise implementation</Th></tr></thead>
            <tbody>{areas.map((a) => data.checks.filter((c: { area: string }) => c.area === a).map((c: { area: string; check: string; status: "pass" | "warn" | "fail"; detail: string; enterprise: string }, i: number) => {
              const st = STATUS[c.status];
              return (
                <tr key={c.check} className="align-top">
                  <Td className="font-semibold text-ink-700">{i === 0 ? a : ""}</Td>
                  <Td className="font-medium">{c.check}</Td>
                  <Td><span className="inline-flex items-center gap-1 whitespace-nowrap"><st.icon className={cn("h-4 w-4", st.cls)} /><Badge tone={st.tone}>{st.label}</Badge></span></Td>
                  <Td className="text-ink-600">{c.detail}</Td>
                  <Td className="text-ink-600">{c.enterprise}</Td>
                </tr>
              );
            }))}</tbody>
          </table>
        </CardBody>
      </Card>
      <Card>
        <CardHeader title="Enterprise security plan" subtitle="For a production rollout on Azure" icon={<Lock className="h-4 w-4 text-brand-500" />} />
        <CardBody className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {data.enterprise_plan.map((p: { area: string; items: string[] }) => (
            <div key={p.area} className="rounded-xl border border-ink-100 p-3">
              <div className="mb-1.5 text-[13px] font-semibold">{p.area}</div>
              <ul className="space-y-1 text-[12px] text-ink-600">{p.items.map((i) => <li key={i} className="flex gap-1.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-ink-400" />{i}</li>)}</ul>
            </div>
          ))}
        </CardBody>
      </Card>
    </div>
  );
}

export default function TrustCentrePage() {
  return (
    <>
      <PageHeader eyebrow="Trust Centre" title="Responsible AI and security"
        description={<>Responsible AI and security, with live evidence. AI costs are on the <Link to="/finops" className="font-medium text-brand-600 hover:underline">AI Cost &amp; Tokens</Link> page.</>} />
      <Tabs defaultValue="rai">
        <TabsList className="mb-4">
          <TabsTrigger value="rai"><span className="inline-flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" />Responsible AI</span></TabsTrigger>
          <TabsTrigger value="security"><span className="inline-flex items-center gap-1.5"><Lock className="h-3.5 w-3.5" />Security</span></TabsTrigger>
        </TabsList>
        <TabsContent value="rai"><ResponsibleAI /></TabsContent>
        <TabsContent value="security"><Security /></TabsContent>
      </Tabs>
      <p className="mt-4 text-[11.5px] text-ink-400"><Tip content="Figures come from the audit log and live configuration."><span className="cursor-help underline decoration-dotted">Where do these numbers come from?</span></Tip></p>
    </>
  );
}
