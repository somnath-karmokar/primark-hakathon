import * as React from "react";
import { Link } from "react-router-dom";
import { CheckCircle2, ChevronDown, Cpu, Database, Gauge, Layers, ShieldCheck, Timer, XCircle } from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useAudit, useDecision, useModelInfo, useRecommendations } from "@/hooks/queries";
import { useAuth } from "@/lib/auth";
import { ChartTooltip, EmptyState, ErrorState, KpiTile, LoadingCard, PageHeader } from "@/components/domain";
import { Badge, Button, Card, CardBody, CardHeader, Input, NativeSelect, Tabs, TabsContent, TabsList, TabsTrigger, Td, Th } from "@/components/ui/primitives";
import { cn, fmt } from "@/lib/utils";
import type { RecommendationRecord } from "@/types/api";

const STATUS_TONE: Record<string, "warning" | "good" | "critical" | "neutral"> = { pending_approval: "warning", approved: "good", rejected: "critical", auto_approved: "neutral" };

function RecRow({ r }: { r: RecommendationRecord }) {
  const { can } = useAuth();
  const [open, setOpen] = React.useState(false);
  const [note, setNote] = React.useState("");
  const decide = useDecision();
  return (
    <>
      <tr className="cursor-pointer hover:bg-ink-50/50" onClick={() => setOpen(!open)}>
        <Td className="num text-ink-500">#{r.id}</Td>
        <Td><Link to={`/vendors/${r.vendor_id}`} onClick={(e) => e.stopPropagation()} className="num font-semibold hover:text-brand-600">{r.vendor_id}</Link></Td>
        <Td className="font-medium">{r.title}</Td>
        <Td><div className="flex items-center gap-2"><div className="h-1.5 w-14 rounded-full bg-ink-100"><div className={cn("h-1.5 rounded-full", r.confidence >= 0.8 ? "bg-emerald-500" : r.confidence >= 0.6 ? "bg-amber-500" : "bg-rose-500")} style={{ width: `${r.confidence * 100}%` }} /></div><span className="num">{Math.round(r.confidence * 100)}%</span></div></Td>
        <Td><span className="inline-flex items-center gap-1">{r.governance.checks.every((c) => c.passed) ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" /> : <XCircle className="h-3.5 w-3.5 text-amber-600" />}{r.governance.checks.filter((c) => c.passed).length}/{r.governance.checks.length}</span></Td>
        <Td><Badge tone={STATUS_TONE[r.status]}>{r.status.replace("_", " ")}</Badge></Td>
        <Td className="text-ink-500">{fmt.datetime(r.created_at)}</Td>
        <Td><ChevronDown className={cn("h-4 w-4 text-ink-400 transition-transform", open && "rotate-180")} /></Td>
      </tr>
      {open && (
        <tr><td colSpan={8} className="border-b border-ink-100 bg-ink-50/40 px-4 py-4">
          <div className="grid gap-4 lg:grid-cols-3 text-[12.5px]">
            <div><div className="eyebrow mb-1">Rationale</div><ul className="space-y-1">{r.rationale.map((x) => <li key={x}>• {x}</li>)}</ul>
              <div className="mt-2 flex flex-wrap gap-1">{r.policy_refs.map((p) => <Badge key={p} tone="brand">{p}</Badge>)}</div></div>
            <div><div className="eyebrow mb-1">Governance checks</div>
              <ul className="space-y-1">{r.governance.checks.map((c) => <li key={c.check} className="flex gap-1.5">{c.passed ? <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 text-emerald-600" /> : <XCircle className="mt-0.5 h-3.5 w-3.5 text-rose-600" />}<span><span className="font-medium">{c.check.replace(/_/g, " ")}</span> <span className="text-ink-500">{c.detail}</span></span></li>)}</ul>
              <div className="mt-2 text-ink-500">Evidence: {r.evidence.map((e) => e.id).join(", ")}</div>
              <div className="text-ink-500">Request {r.request_id} · by {r.created_by}</div></div>
            <div>
              <div className="eyebrow mb-1">Alternatives proposed</div>
              <ul className="mb-3 space-y-0.5">{r.alternatives.map((a) => <li key={a.vendor_id}><span className="num font-semibold">{a.vendor_id}</span> {a.name} · {a.overall?.toFixed(1)} · {a.eligible ? "eligible" : "not eligible"}</li>)}</ul>
              {r.status === "pending_approval" && !can("approve") ? (
                <div className="rounded-lg bg-amber-50 p-2.5 text-amber-900">Awaiting approval by an Admin ({r.governance.approval_reason ?? "policy PP-5"}). Your role can view but not decide.</div>
              ) : r.status === "pending_approval" ? (
                <div className="space-y-2">
                  {r.governance.approval_reason && <div className="text-amber-800">{r.governance.approval_reason}</div>}
                  <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Decision note (optional)" maxLength={500} />
                  <div className="flex gap-2">
                    <Button variant="success" size="sm" disabled={decide.isPending} onClick={() => decide.mutate({ id: r.id, decision: "approved", note })}><CheckCircle2 />Approve</Button>
                    <Button variant="outline" size="sm" disabled={decide.isPending} onClick={() => decide.mutate({ id: r.id, decision: "rejected", note })}><XCircle />Reject</Button>
                  </div>
                </div>
              ) : r.decided_by ? <div className="text-ink-600">{r.status} by {r.decided_by} · {r.decided_at && fmt.datetime(r.decided_at)}{r.decision_note && <> · “{r.decision_note}”</>}</div> : <div className="text-ink-500">No approval required (advisory / monitor action).</div>}
            </div>
          </div>
        </td></tr>
      )}
    </>
  );
}

function AuditRow({ e }: { e: { id: number; ts: string; request_id: string; actor: string; event_type: string; entity_id: string; summary: string; details: Record<string, unknown> } }) {
  const [open, setOpen] = React.useState(false);
  const trace = (e.details.agent_trace as { agent: string; action: string; duration_ms: number }[] | undefined) ?? [];
  return (
    <>
      <tr className="cursor-pointer hover:bg-ink-50/50" onClick={() => setOpen(!open)}>
        <Td className="num whitespace-nowrap text-ink-500">{fmt.datetime(e.ts)}</Td>
        <Td><Badge tone={e.event_type.includes("approved") ? "good" : e.event_type.includes("rejected") ? "critical" : e.event_type === "copilot_answer" ? "brand" : "neutral"}>{e.event_type.replace(/_/g, " ")}</Badge></Td>
        <Td className="num">{e.entity_id}</Td><Td>{e.summary}</Td><Td className="text-ink-500">{e.actor}</Td>
        <Td className="num text-ink-500">{e.details.confidence != null ? `${Math.round(Number(e.details.confidence) * 100)}%` : "-"}</Td>
      </tr>
      {open && (
        <tr><td colSpan={6} className="border-b border-ink-100 bg-ink-50/40 px-4 py-3 text-[12px]">
          {trace.length > 0 && <div className="mb-2 flex flex-wrap items-center gap-1.5">{trace.map((t, i) => <span key={i} className="rounded-md bg-white px-2 py-1 ring-1 ring-ink-100"><span className="font-semibold capitalize">{t.agent}</span> <span className="text-ink-500">{t.duration_ms}ms</span></span>)}</div>}
          <pre className="max-h-60 overflow-auto rounded-lg bg-white p-3 text-[11px] text-ink-700 ring-1 ring-ink-100">{JSON.stringify({ request_id: e.request_id, ...e.details }, null, 2)}</pre>
        </td></tr>
      )}
    </>
  );
}

export default function GovernancePage() {
  const [status, setStatus] = React.useState("");
  const [etype, setEtype] = React.useState("");
  const { data: recs, error } = useRecommendations(status || undefined);
  const { data: audit } = useAudit(etype || undefined);
  const { data: model } = useModelInfo();
  const t = model?.llm_telemetry;
  const risk = model?.risk_model;
  return (
    <>
      <PageHeader eyebrow="Approvals & audit trail" title="Approvals and audit trail"
        description="Approve recommended actions and see every AI answer and decision." />
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
        <KpiTile label="Awaiting approval" value={recs?.counts.pending_approval ?? 0} icon={ShieldCheck} accent="#eaa400" />
        <KpiTile label="Approved" value={recs?.counts.approved ?? 0} icon={CheckCircle2} accent="#1f8a4c" />
        <KpiTile label="Rejected" value={recs?.counts.rejected ?? 0} icon={XCircle} accent="#a8223d" />
        <KpiTile label="LLM calls" value={t?.llm_calls ?? 0} icon={Cpu} sub={`${t?.fallbacks ?? 0} deterministic fallbacks`} />
        <KpiTile label="JEV tokens saved" value={fmt.int(t?.jev_tokens_saved ?? 0)} icon={Layers} sub={t?.jev_compression_ratio ? `context at ${Math.round(t.jev_compression_ratio * 100)}% of raw` : "no synthesis yet"} />
        <KpiTile label="Cache hit rate" value={model ? `${Math.round((model.cache.analytics.hit_rate ?? 0) * 100)}%` : "-"} icon={Database} sub={model ? `semantic ${model.cache.semantic.hits} hits` : ""} />
      </div>
      <Tabs defaultValue="recs">
        <TabsList className="mb-3"><TabsTrigger value="recs">Recommendations to approve</TabsTrigger><TabsTrigger value="audit">Audit log</TabsTrigger><TabsTrigger value="models">How the AI is set up</TabsTrigger></TabsList>
        <TabsContent value="recs">
          {error ? <ErrorState error={error} /> : (
            <Card>
              <div className="flex items-center justify-between border-b border-ink-100 px-4 py-3">
                <span className="text-[13px] font-semibold">Recommendation register</span>
                <NativeSelect value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status filter">
                  <option value="">All statuses</option>{["pending_approval", "approved", "rejected", "auto_approved"].map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
                </NativeSelect>
              </div>
              <div className="overflow-x-auto p-2">
                {!recs ? <LoadingCard h="h-40" /> : recs.items.length === 0 ? <EmptyState icon={ShieldCheck} title="No recommendations yet" hint="Ask AIRA what to do about a vendor to create one." /> : (
                  <table className="w-full text-[12.5px]">
                    <thead><tr><Th>ID</Th><Th>Vendor</Th><Th>Action</Th><Th>Confidence</Th><Th>Checks</Th><Th>Status</Th><Th>Created</Th><Th /></tr></thead>
                    <tbody>{recs.items.map((r) => <RecRow key={r.id} r={r} />)}</tbody>
                  </table>
                )}
              </div>
            </Card>
          )}
        </TabsContent>
        <TabsContent value="audit">
          <Card>
            <div className="flex items-center justify-between border-b border-ink-100 px-4 py-3">
              <span className="text-[13px] font-semibold">Audit trail <span className="font-normal text-ink-500">· click a row for agent trace & details</span></span>
              <NativeSelect value={etype} onChange={(e) => setEtype(e.target.value)} aria-label="Event type">
                <option value="">All events</option>{["copilot_answer", "scoring_run", "settings_changed", "recommendation_approved", "recommendation_rejected", "knowledge_ingest", "graph_ingest"].map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
              </NativeSelect>
            </div>
            <div className="overflow-x-auto p-2">
              <table className="w-full text-[12.5px]">
                <thead><tr><Th>Time</Th><Th>Event</Th><Th>Entity</Th><Th>Summary</Th><Th>Actor</Th><Th>Confidence</Th></tr></thead>
                <tbody>{audit?.map((e) => <AuditRow key={e.id} e={e} />)}</tbody>
              </table>
            </div>
          </Card>
        </TabsContent>
        <TabsContent value="models">
          {!model ? <LoadingCard /> : (
            <div className="grid gap-4 xl:grid-cols-2">
              <Card>
                <CardHeader title="Vendor Performance Score" icon={<Gauge className="h-4 w-4 text-brand-500" />} subtitle={model.scoring.method} action={<Badge tone="brand">{model.scoring.model_version}</Badge>} />
                <CardBody>
                  <div className="grid grid-cols-4 gap-2">{Object.entries(model.scoring.weights as Record<string, number>).map(([k, v]) => (
                    <div key={k} className="rounded-lg bg-ink-50 p-2.5 text-center"><div className="eyebrow">{k.replace("_", "-")}</div><div className="num font-display text-[20px] font-bold">{Math.round(v * 100)}%</div></div>))}</div>
                  <p className="mt-3 text-[12px] text-ink-500">Scores use fixed formulas - no AI.</p>
                </CardBody>
              </Card>
              <Card>
                <CardHeader title="Internal risk model" icon={<Timer className="h-4 w-4 text-brand-500" />} subtitle={risk?.label_definition}
                  action={<Badge tone={risk?.credible ? "good" : "warning"}>{risk?.credible ? "Credible - in use" : "Not credible - statistical fallback"}</Badge>} />
                <CardBody>
                  {risk ? (
                    <>
                      <div className="mb-2 text-[12px] text-ink-500">{risk.algorithm} · temporal split: train {risk.train_periods?.length} periods ({risk.n_train} rows), test {risk.test_periods?.join(", ")} ({risk.n_test} rows) · positive rate {Math.round(risk.positive_rate_test * 100)}%</div>
                      <table className="w-full text-[12.5px]"><thead><tr><Th>Metric (held-out)</Th><Th className="text-right">XGBoost</Th><Th className="text-right">Random guess</Th></tr></thead>
                        <tbody>{["roc_auc", "pr_auc", "accuracy", "precision", "recall", "f1"].map((m) => <tr key={m}><Td className="uppercase text-ink-600">{m.replace("_", "-")}</Td><Td className="num text-right font-semibold">{risk.metrics[m]}</Td><Td className="num text-right text-ink-500">{risk.baseline_metrics[m] ?? "–"}</Td></tr>)}</tbody></table>
                      {risk.reason && <p className="mt-2 text-[12px] text-amber-800">{risk.reason}</p>}
                      <div className="mt-3 h-[190px]"><ResponsiveContainer>
                        <BarChart layout="vertical" data={risk.feature_importance.slice(0, 7)} margin={{ left: 40, right: 12 }}>
                          <CartesianGrid horizontal={false} /><XAxis type="number" tickLine={false} axisLine={false} /><YAxis type="category" dataKey="label" width={170} tickLine={false} axisLine={false} />
                          <Tooltip content={<ChartTooltip valueFormatter={(v: number) => v.toFixed(3)} />} /><Bar dataKey="importance" name="Importance" fill="#0a8fc4" radius={[0, 4, 4, 0]} barSize={12} />
                        </BarChart></ResponsiveContainer></div>
                      <p className="text-[11.5px] text-ink-500">Per-vendor explanations use SHAP ({risk.shap_available ? "available" : "unavailable - tree importances used"}).</p>
                    </>
                  ) : <EmptyState title="Risk model not trained yet" />}
                </CardBody>
              </Card>
              <Card>
                <CardHeader title="LLM layer & model routing" icon={<Cpu className="h-4 w-4 text-brand-500" />} subtitle={`Provider: ${model.llm.provider} · prompt ${model.llm.prompt_version}`} />
                <CardBody>
                  <table className="w-full text-[12.5px]"><thead><tr><Th>Task</Th><Th>Tier</Th><Th>Model</Th></tr></thead>
                    <tbody>{model.llm.routing.map((r: { task: string; tier: string; model: string }) => <tr key={r.task}><Td>{r.task.replace(/_/g, " ")}</Td><Td><Badge>{r.tier}</Badge></Td><Td className="num text-ink-600">{r.model}</Td></tr>)}</tbody></table>
                  {!model.llm.configured && <p className="mt-2 rounded-lg bg-amber-50 p-2.5 text-[12px] text-amber-900">AI is not connected - AIRA gives fact-based answers. Scores are unaffected.</p>}
                  <div className="mt-3 grid grid-cols-3 gap-2 text-[12px]">
                    {[["Prompt tokens", fmt.int(t.prompt_tokens)], ["Completion tokens", fmt.int(t.completion_tokens)], ["Response cache hits", t.cache_hits], ["JEV raw → sent", `${fmt.int(t.jev_raw_tokens)} → ${fmt.int(t.jev_compressed_tokens)}`], ["Errors", t.errors], ["Fallbacks", t.fallbacks]].map(([a, b]) => (
                      <div key={a as string} className="rounded-lg bg-ink-50 p-2"><div className="text-ink-500">{a}</div><div className="num font-semibold">{b}</div></div>))}
                  </div>
                </CardBody>
              </Card>
              <Card>
                <CardHeader title="Guardrails, caches & data planes" icon={<ShieldCheck className="h-4 w-4 text-brand-500" />} />
                <CardBody className="space-y-3 text-[12.5px]">
                  <div className="grid grid-cols-3 gap-2">{Object.entries(model.guardrails as Record<string, number>).map(([k, v]) => <div key={k} className="rounded-lg bg-ink-50 p-2"><div className="text-[11px] text-ink-500">{k.replace(/_/g, " ")}</div><div className="num font-semibold">{v}</div></div>)}</div>
                  <table className="w-full"><thead><tr><Th>Cache</Th><Th className="text-right">Hits</Th><Th className="text-right">Misses</Th><Th className="text-right">Hit rate</Th><Th className="text-right">Size</Th></tr></thead>
                    <tbody>{Object.entries(model.cache as Record<string, { hits: number; misses: number; hit_rate: number; size: number }>).map(([k, c]) => <tr key={k}><Td className="capitalize">{k}</Td><Td className="num text-right">{c.hits}</Td><Td className="num text-right">{c.misses}</Td><Td className="num text-right">{Math.round(c.hit_rate * 100)}%</Td><Td className="num text-right">{c.size}</Td></tr>)}</tbody></table>
                  <div className="flex flex-wrap gap-2"><Badge tone={model.graph.available ? "good" : "warning"}>Neo4j {model.graph.available ? "connected" : "fallback"} · {model.graph.host}</Badge><Badge tone="brand">ChromaDB {model.knowledge.chunks} chunks · {model.knowledge.policy_version}</Badge></div>
                  <details className="rounded-lg bg-ink-50 p-2.5"><summary className="cursor-pointer font-medium">LangGraph workflow (Mermaid)</summary><pre className="mt-2 overflow-auto text-[10.5px] text-ink-700">{model.agent_graph_mermaid}</pre></details>
                </CardBody>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
}
