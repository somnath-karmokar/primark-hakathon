import { Link, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import {
  AlertTriangle, ArrowRight, Bot, CheckCircle2, Clock3, Columns3, Globe2, MapPin, Package, PoundSterling,
  ShieldCheck, Sparkles, Timer, Truck, XCircle,
} from "lucide-react";
import { Area, CartesianGrid, ComposedChart, Legend, Line, ReferenceArea, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useAuth } from "@/lib/auth";
import { useRelationships, useVendor360, useVendorRecs, useVendorRisk, useVendorTrend } from "@/hooks/queries";
import {
  BandBadge, ChartTooltip, ComponentBar, Delta, EmptyState, ErrorState, LoadingCard, RiskBadge, ScoreRing,
} from "@/components/domain";
import { VendorLinks } from "@/components/VendorLinks";
import { Badge, Button, Card, CardBody, CardHeader, Skeleton, Tabs, TabsContent, TabsList, TabsTrigger, Td, Th, Tip } from "@/components/ui/primitives";
import { BAND_COLOR, COMPONENTS, cn, fmt } from "@/lib/utils";
import type { Driver, Vendor360 } from "@/types/api";

function ComponentCard({ icon: Icon, label, score, prev, bench, lines }: {
  icon: React.ElementType; label: string; score: number; prev: number; bench: number; lines: [string, string][];
}) {
  const band = score >= 90 ? "Excellent" : score >= 75 ? "Good" : score >= 60 ? "Watch" : score >= 40 ? "At Risk" : "Critical";
  return (
    <Card className="relative overflow-hidden p-4">
      <span className="absolute inset-y-0 left-0 w-[3px]" style={{ backgroundColor: BAND_COLOR[band] }} />
      <div className="flex items-center justify-between">
        <span className="eyebrow flex min-w-0 items-center gap-1.5 truncate"><Icon className="h-3.5 w-3.5 shrink-0" />{label}</span>
        <BandBadge band={band} />
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        <span className="num font-display text-[28px] font-bold leading-none">{score.toFixed(1)}</span>
        <Delta value={score - prev} className="text-[12px]" />
        <span className="ml-auto text-[11px] text-ink-500">cat. avg <span className="num font-semibold text-ink-700">{bench.toFixed(1)}</span></span>
      </div>
      <dl className="mt-3 space-y-1 border-t border-ink-100 pt-2.5 text-[12px]">
        {lines.map(([k, v]) => <div key={k} className="flex justify-between gap-2"><dt className="text-ink-500">{k}</dt><dd className="num font-medium text-ink-800">{v}</dd></div>)}
      </dl>
    </Card>
  );
}

function DriverList({ drivers }: { drivers: Driver[] }) {
  return (
    <ul className="space-y-2">
      {drivers.map((d) => (
        <li key={d.component} className={cn("flex items-start gap-3 rounded-lg border px-3 py-2.5",
          d.impact === "negative" ? "border-rose-100 bg-rose-50/40" : d.impact === "positive" ? "border-emerald-100 bg-emerald-50/30" : "border-ink-100 bg-ink-50/30")}>
          {d.impact === "negative" ? <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" /> : d.impact === "positive" ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /> : <Clock3 className="mt-0.5 h-4 w-4 shrink-0 text-ink-400" />}
          <div className="min-w-0 flex-1 text-[12.5px]">
            <div className="font-semibold text-ink-900">{d.label} <span className="num">{d.score.toFixed(1)}</span>
              {Math.abs(d.change) >= 1 && <span className={cn("num ml-1.5 font-medium", d.change < 0 ? "text-rose-700" : "text-emerald-700")}>({fmt.delta(d.change)} vs 3 months ago)</span>}
            </div>
            <div className="text-ink-500">Costs <span className="num font-medium text-ink-700">{d.weighted_points_lost.toFixed(1)}</span> points off the overall score{d.weighted_change < -0.5 && <> · caused <span className="num font-medium text-rose-700">{d.weighted_change.toFixed(1)}</span> pts of the recent drop</>}</div>
          </div>
        </li>
      ))}
    </ul>
  );
}

function Header({ v }: { v: Vendor360 }) {
  const { profile: p, score: s, rank } = v;
  const { data: risk } = useVendorRisk(p.vendor_id);
  return (
    <Card className="mb-4 overflow-hidden">
      <div className="h-1 bg-gradient-to-r from-brand-500 via-brand-400 to-brand-200" />
      <div className="flex flex-col items-start gap-5 px-5 py-5 sm:flex-row sm:flex-wrap sm:items-center sm:gap-6 sm:px-6">
        <ScoreRing score={s.breakdown.overall} size={124} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="num rounded-md bg-ink-900 px-2 py-0.5 text-[12px] font-bold text-white">{p.vendor_id}</span>
            <BandBadge band={s.breakdown.band} size="lg" />
            {s.trend.is_deteriorating && <Badge tone="critical"><AlertTriangle className="h-3 w-3" />Getting worse</Badge>}
            {!s.data_sufficient && <Badge tone="warning">Limited data - treat as provisional</Badge>}
          </div>
          <h1 className="mt-1.5 text-[20px] font-bold sm:truncate sm:text-[22px]">{p.name}</h1>
          <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12.5px] text-ink-500">
            <span className="flex items-center gap-1"><Package className="h-3.5 w-3.5" />{p.category}</span>
            <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{p.city}, {p.country} · {p.region}</span>
            <span>{p.tier} supplier · {p.status}</span>
            <span>Ships via {p.port}</span>
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-1 text-[12.5px]">
            <span>Change in 3 months <Delta value={s.trend.change_3m} suffix=" pts" /></span>
            <span>Best in 6 months <span className="num font-semibold">{s.trend.peak_score.toFixed(1)}</span></span>
            <span>Spend (3m) <span className="num font-semibold">{fmt.gbp(v.commercials.spend)}</span></span>
            <Tip content={`Share of category spend - Procurement Policy ${v.commercials.policy} limit ${v.commercials.concentration_limit_pct}%`}>
              <span className={cn("cursor-help", v.commercials.max_share_pct > v.commercials.concentration_limit_pct && "font-semibold text-rose-700")}>Category share <span className="num font-semibold">{v.commercials.max_share_pct.toFixed(1)}%</span>{v.commercials.max_share_pct > v.commercials.concentration_limit_pct ? " - above PP-3.3 limit" : ""}</span>
            </Tip>
            <span>Open POs <span className="num font-semibold">{fmt.gbp(v.commercials.open_po_value)}</span></span>
            <span>Rank <span className="num font-semibold">#{rank.overall}</span> of {rank.of} · <span className="num font-semibold">#{rank.in_category}</span> of {rank.category_size} in {p.category}</span>
          </div>
        </div>
        <div className="grid w-full grid-cols-3 gap-2 sm:w-auto sm:min-w-[360px]">
          {[
            { label: "Performance score", value: <span className="num">{s.breakdown.overall.toFixed(1)}</span>, sub: s.breakdown.band, tip: "Score out of 100, calculated by fixed rules from deliveries, quality checks and invoices" },
            { label: "Risk of decline", value: risk?.internal.risk_level ?? <Skeleton className="h-5 w-12" />, sub: risk?.internal.risk_probability != null ? `${Math.round(risk.internal.risk_probability * 100)}% chance (model)` : "based on trend", tip: "How likely the score is to keep falling over the next 3 months. Shown separately - it does not change the score." },
            { label: "Outside-event risk", value: risk?.external.external_risk ?? <Skeleton className="h-5 w-12" />, sub: risk ? `${risk.external.events.length} active alert(s)` : "", tip: "Risk from outside events such as port delays or storms. Shown separately - it does not change the score." },
          ].map((x) => (
            <Tip key={x.label} content={x.tip}>
              <div className="rounded-lg border border-ink-100 bg-ink-50/40 px-3 py-2">
                <div className="text-[10px] font-semibold uppercase tracking-wide text-ink-500">{x.label}</div>
                <div className={cn("mt-0.5 font-display text-[16px] font-bold",
                  x.value === "High" ? "text-band-critical" : x.value === "Medium" ? "text-band-atrisk" : "text-ink-950")}>{x.value}</div>
                <div className="text-[11px] text-ink-500">{x.sub}</div>
              </div>
            </Tip>
          ))}
          <div className="col-span-3 flex gap-2">
            <Button asChild variant="brand" size="sm" className="flex-1"><Link to={`/copilot?q=${encodeURIComponent(`Why is Vendor ${p.vendor_id} underperforming?`)}`}><Bot />Ask AIRA why</Link></Button>
            <Button asChild variant="outline" size="sm"><Link to={`/compare?ids=${p.vendor_id}`}><Columns3 />Compare</Link></Button>
          </div>
        </div>
      </div>
    </Card>
  );
}

export default function Vendor360Page() {
  const { sees } = useAuth();
  const { id = "" } = useParams();
  const vid = id.toUpperCase();
  const { data: v, isLoading, error, refetch } = useVendor360(vid);
  const { data: trend } = useVendorTrend(vid);
  const { data: recs } = useVendorRecs(vid);
  const { data: rel, isLoading: relLoading } = useRelationships(vid);
  const { data: risk } = useVendorRisk(vid);

  if (error) return <ErrorState error={error} onRetry={() => refetch()} />;
  if (isLoading || !v) return <div className="space-y-4"><LoadingCard h="h-28" /><div className="grid gap-4 md:grid-cols-4"><LoadingCard h="h-24" /><LoadingCard h="h-24" /><LoadingCard h="h-24" /><LoadingCard h="h-24" /></div><LoadingCard /></div>;

  const s = v.score;
  const b = s.breakdown, pb = s.previous_breakdown, k = s.kpis, bench = s.benchmark;
  const engine = recs?.engine;

  return (
    <>
      <div className="mb-3 flex items-center gap-1.5 text-[12px] text-ink-500">
        <Link to="/vendors" className="hover:text-ink-800">All vendors</Link><span>/</span><span className="font-medium text-ink-800">{v.profile.vendor_id}</span>
        <span className="ml-auto hidden sm:inline">Based on the 3 months to {fmt.month(s.period)}</span>
      </div>
      <Header v={v} />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <ComponentCard icon={Truck} label="Delivery" score={b.delivery} prev={pb.delivery} bench={bench.delivery} lines={[
          ["Delivered on time", fmt.pct(k.delivery.on_time_pct)], ["Late orders", `${k.delivery.late_pos} of ${k.delivery.total_pos}`],
          ["Average delay when late", `${k.delivery.avg_delay_days.toFixed(1)} days`], ["Key orders late", `${k.delivery.critical_late_pos} of ${k.delivery.critical_pos}`]]} />
        <ComponentCard icon={ShieldCheck} label="Quality" score={b.quality} prev={pb.quality} bench={bench.quality} lines={[
          ["Faulty items", fmt.pct(k.quality.defect_rate_pct, 2)], ["Failed quality checks", fmt.pct(k.quality.inspection_failure_rate_pct)],
          ["Items rejected", fmt.pct(k.quality.rejection_rate_pct, 2)], ["Quality checks", fmt.int(k.quality.inspections)]]} />
        <ComponentCard icon={PoundSterling} label="Cost" score={b.cost} prev={pb.cost} bench={bench.cost} lines={[
          ["Over-invoicing", fmt.pct(k.cost.variance_pct, 2)], ["Price vs typical price", `${fmt.delta(k.cost.benchmark_variance_pct)}%`],
          ["Extra invoiced", fmt.gbp(k.cost.variance_amount)], ["Disputed invoices", String(k.cost.disputed_invoices)]]} />
        <ComponentCard icon={Timer} label="Lead time" score={b.lead_time} prev={pb.lead_time} bench={bench.lead_time} lines={[
          ["Promised vs actual", `${k.lead_time.avg_promised_days.toFixed(0)} / ${k.lead_time.avg_actual_days.toFixed(0)} days`],
          ["How much it varies", `${Math.round(k.lead_time.coefficient_of_variation * 100)}%`], ["Typical gap vs promise", `${k.lead_time.std_dev_days.toFixed(1)} days`],
          ["Reliability rating", k.lead_time.consistency_score.toFixed(1)]]} />
      </div>

      <div className="mb-4 grid gap-4 xl:grid-cols-12">
        <Card className="xl:col-span-8">
          <CardHeader title="Score over time" subtitle="Monthly score vs category average" />
          <CardBody>
            {!trend ? <Skeleton className="h-[280px] w-full" /> : (
              <div className="h-[280px]">
                <ResponsiveContainer>
                  <ComposedChart data={trend} margin={{ top: 8, right: 16, left: -16, bottom: 0 }}>
                    <defs><linearGradient id="ovr" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#009fd6" stopOpacity={0.18} /><stop offset="100%" stopColor="#009fd6" stopOpacity={0} /></linearGradient></defs>
                    <ReferenceArea y1={90} y2={100} fill={BAND_COLOR.Excellent} fillOpacity={0.05} />
                    <ReferenceArea y1={60} y2={75} fill={BAND_COLOR.Watch} fillOpacity={0.06} />
                    <ReferenceArea y1={40} y2={60} fill={BAND_COLOR["At Risk"]} fillOpacity={0.06} />
                    <CartesianGrid vertical={false} />
                    <XAxis dataKey="period" tickFormatter={fmt.month} tickLine={false} axisLine={false} />
                    <YAxis domain={[40, 100]} tickLine={false} axisLine={false} />
                    <Tooltip content={<ChartTooltip labelFormatter={fmt.month} />} />
                    <Legend iconType="plainline" wrapperStyle={{ fontSize: 11.5, paddingTop: 6 }} />
                    <Area dataKey="overall" name={`${v.profile.vendor_id} score`} stroke="#009fd6" strokeWidth={2.5} fill="url(#ovr)" dot={{ r: 3.5, strokeWidth: 2, fill: "#fff" }} activeDot={{ r: 5 }} />
                    <Line dataKey="category_avg" name={`${v.profile.category} average`} stroke="#8496ab" strokeDasharray="5 4" strokeWidth={1.5} dot={false} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            )}
            {trend && trend.length > 1 && (
              <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
                {COMPONENTS.map((c) => {
                  const first = trend[0][c.key], last = trend[trend.length - 1][c.key];
                  return (
                    <div key={c.key} className="rounded-lg bg-ink-50/70 px-3 py-2 text-[12px]">
                      <div className="text-ink-500">{c.label}</div>
                      <div className="num font-semibold text-ink-900">{first.toFixed(0)} → {last.toFixed(0)} <Delta value={last - first} className="text-[11px]" /></div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardBody>
        </Card>
        <Card className="xl:col-span-4">
          <CardHeader title="What makes up the score" subtitle="Black tick = category average" />
          <CardBody className="space-y-4">
            {COMPONENTS.map((c) => <ComponentBar key={c.key} label={c.label} score={b[c.key]} benchmark={bench[c.key]} weight={b.weights[c.key]} change={b[c.key] - pb[c.key]} />)}
            <div className="rounded-lg border border-ink-100 bg-ink-50/50 p-3 text-[12px]">
              <div className="mb-1.5 font-semibold text-ink-800">How {b.overall.toFixed(1)} is calculated</div>
              <div className="num leading-6 text-ink-600">
                {COMPONENTS.map((c, i) => <span key={c.key}>{i > 0 && " + "}{b[c.key].toFixed(1)}×{b.weights[c.key]}</span>)} = <span className="font-bold text-ink-950">{b.overall.toFixed(1)}</span>
              </div>
            </div>
          </CardBody>
        </Card>
      </div>

      <div className="mb-4 grid gap-4 xl:grid-cols-12">
        <Card className="xl:col-span-6">
          <CardHeader title="Why is the score at this level?" subtitle={`What changed since ${fmt.month(s.previous_period)} - biggest impact first`} icon={<Sparkles className="h-4 w-4 text-brand-500" />} />
          <CardBody>
            <DriverList drivers={s.drivers} />
            <div className="mt-4">
              <div className="eyebrow mb-2">Contract targets (SLA)</div>
              <div className="grid gap-2 sm:grid-cols-3">
                {v.sla_compliance.map((c) => (
                  <div key={c.metric} className={cn("rounded-lg border px-3 py-2", c.status === "breached" ? "border-rose-200 bg-rose-50/50" : "border-emerald-200 bg-emerald-50/40")}>
                    <div className="flex items-center justify-between text-[11.5px] text-ink-600">{c.metric}{c.status === "breached" ? <XCircle className="h-3.5 w-3.5 text-rose-600" /> : <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />}</div>
                    <div className="num text-[15px] font-bold text-ink-950">{c.actual.toFixed(1)}{c.unit}</div>
                    <div className="text-[11px] text-ink-500">target {c.operator} {c.target}{c.unit} · <span className={c.status === "breached" ? "font-semibold text-rose-700" : "text-emerald-700"}>{c.status}</span></div>
                  </div>
                ))}
              </div>
            </div>
          </CardBody>
        </Card>
        <Card className={cn("relative overflow-hidden xl:col-span-6 ring-2", !engine ? "ring-transparent" : engine.stage >= 2 ? "ring-rose-300" : engine.stage === 1 ? "ring-amber-300" : "ring-emerald-300")}>
          <div className={cn("absolute inset-x-0 top-0 h-1.5", !engine ? "bg-ink-100" : engine.stage >= 2 ? "bg-gradient-to-r from-rose-500 to-orange-400" : engine.stage === 1 ? "bg-gradient-to-r from-amber-400 to-yellow-300" : "bg-gradient-to-r from-emerald-500 to-teal-400")} />
          <CardHeader title="Recommended action" icon={<Sparkles className="h-4 w-4 text-brand-500" />}
            action={engine && <Badge tone={engine.stage >= 2 ? "critical" : engine.stage === 1 ? "warning" : "good"}>Step {engine.stage} of 4</Badge>} />
          <CardBody>
            {!engine ? <Skeleton className="h-40 w-full" /> : (
              <>
                <div className={cn("rounded-xl px-4 py-3.5", engine.stage >= 2 ? "bg-rose-50 ring-1 ring-rose-200" : engine.stage === 1 ? "bg-amber-50 ring-1 ring-amber-200" : "bg-emerald-50 ring-1 ring-emerald-200")}>
                  <div className="font-display text-[18px] font-bold leading-snug text-ink-950">{engine.title.replace(/^Stage \d+\s*[-–]\s*/, "")}</div>
                  {engine.triggers.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      <span className="text-[11.5px] font-semibold text-ink-500">Why:</span>
                      {engine.triggers.slice(0, 3).map((t) => <span key={t} className="rounded-full bg-white px-2 py-0.5 text-[11.5px] font-medium text-ink-700 ring-1 ring-inset ring-ink-200">{t}</span>)}
                    </div>
                  )}
                </div>
                <ol className="mt-3 space-y-1.5 text-[13px]">{engine.steps.slice(0, 3).map((st, i) => <li key={st} className="flex gap-2"><span className="num flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-600 text-[11px] font-bold text-white">{i + 1}</span><span className="text-ink-800">{st.replace(/\s*\([A-Z]{2,}-[^)]*\)/g, "")}</span></li>)}</ol>
                {engine.alternatives.length > 0 && (
                  <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[12px]">
                    <span className="font-semibold text-ink-500">Backup:</span>
                    {engine.alternatives.filter((a) => a.eligible).concat(engine.alternatives.filter((a) => !a.eligible)).slice(0, 2).map((a) => (
                      <Link key={a.vendor_id} to={`/vendors/${a.vendor_id}`} title={`${a.region} · ${a.product_overlap_pct.toFixed(0)}% product overlap`}
                        className="rounded-full border border-ink-200 px-2.5 py-0.5 hover:border-brand-300 hover:bg-brand-50">
                        <span className="font-semibold">{a.name}</span> <span className="num text-ink-500">{a.overall.toFixed(0)}</span>
                      </Link>
                    ))}
                  </div>
                )}
                <div className="mt-3 text-[11.5px] text-ink-500">
                  {engine.requires_approval ? <>Needs approval from <span className="font-semibold text-ink-700">{engine.approver}</span></> : "No approval needed"} · set by policy, not AI
                </div>
                <Button asChild variant="outline" size="sm" className="mt-3 w-full"><Link to={`/copilot?q=${encodeURIComponent(`What procurement action do you recommend for ${v.profile.vendor_id}?`)}`}><Bot />Ask AIRA why<ArrowRight /></Link></Button>
              </>
            )}
          </CardBody>
        </Card>
      </div>

      <Card>
        <Tabs defaultValue="pos">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-100 px-4 py-3">
            <TabsList className="max-w-full overflow-x-auto scrollbar-thin">
              <TabsTrigger value="pos">Recent deliveries</TabsTrigger>
              <TabsTrigger value="quality">Quality issues</TabsTrigger>
              <TabsTrigger value="invoices">Invoice differences</TabsTrigger>
              <TabsTrigger value="graph">Products & backup suppliers</TabsTrigger>
              <TabsTrigger value="risk">Risk</TabsTrigger>
              <TabsTrigger value="contract">Contract & targets</TabsTrigger>
            </TabsList>
            <span className="text-[12px] text-ink-500">{v.transactions.open_pos.count} open POs · {fmt.gbp(v.transactions.open_pos.value)}</span>
          </div>
          <TabsContent value="pos" className="overflow-x-auto p-2">
            <table className="w-full text-[12.5px]">
              <thead><tr><Th>PO</Th><Th>Product</Th><Th>Ordered</Th><Th>Promised</Th><Th>Delivered</Th><Th className="text-right">Days late</Th><Th className="text-right">Value</Th><Th>Status</Th></tr></thead>
              <tbody>{v.transactions.purchase_orders.map((po) => (
                <tr key={po.po_id}>
                  <Td className="num font-medium">{po.po_id}{po.is_critical && <Badge tone="critical" className="ml-1.5">critical</Badge>}</Td>
                  <Td>{po.product}</Td><Td className="num">{fmt.date(po.po_date)}</Td><Td className="num">{fmt.date(po.promised_date)}</Td>
                  <Td className="num">{po.delivered_date ? fmt.date(po.delivered_date) : "-"}</Td>
                  <Td className={cn("num text-right", (po.days_late ?? 0) > 0 && "font-semibold text-rose-700")}>{po.days_late ?? "-"}</Td>
                  <Td className="num text-right">{fmt.gbp(po.value)}</Td>
                  <Td><Badge tone={po.status === "Open" ? "brand" : (po.days_late ?? 0) > 0 ? "warning" : "good"}>{po.status === "Open" ? "Open" : (po.days_late ?? 0) > 0 ? "Late" : "On time"}</Badge></Td>
                </tr>))}</tbody>
            </table>
          </TabsContent>
          <TabsContent value="quality" className="overflow-x-auto p-2">
            {v.transactions.quality_issues.length === 0 ? <EmptyState icon={ShieldCheck} title="No failed inspections" hint="All recent batches passed their quality checks." /> : (
              <table className="w-full text-[12.5px]">
                <thead><tr><Th>Inspection</Th><Th>PO</Th><Th>Date</Th><Th>Reason</Th><Th className="text-right">Inspected</Th><Th className="text-right">Defects</Th><Th className="text-right">Defect rate</Th></tr></thead>
                <tbody>{v.transactions.quality_issues.map((q) => (
                  <tr key={q.inspection_id}><Td className="num">{q.inspection_id}</Td><Td className="num">{q.po_id}</Td><Td className="num">{fmt.date(q.date)}</Td><Td>{q.reason}</Td>
                    <Td className="num text-right">{q.inspected_qty}</Td><Td className="num text-right">{q.defect_qty}</Td><Td className="num text-right font-semibold text-rose-700">{fmt.pct(q.defect_rate_pct, 2)}</Td></tr>))}</tbody>
              </table>
            )}
            {k.quality.top_rejection_reasons.length > 0 && <div className="flex flex-wrap gap-2 px-3 py-3 text-[12px] text-ink-600">Most common rejection reasons (last 3 months): {k.quality.top_rejection_reasons.map((r) => <Badge key={r.reason}>{r.reason} · {r.count}</Badge>)}</div>}
          </TabsContent>
          <TabsContent value="invoices" className="overflow-x-auto p-2">
            <table className="w-full text-[12.5px]">
              <thead><tr><Th>Invoice</Th><Th>PO</Th><Th>Date</Th><Th className="text-right">PO value</Th><Th className="text-right">Invoiced</Th><Th className="text-right">Variance</Th><Th className="text-right">Variance %</Th><Th>Status</Th></tr></thead>
              <tbody>{v.transactions.invoice_variance.map((i) => (
                <tr key={i.invoice_id}><Td className="num">{i.invoice_id}</Td><Td className="num">{i.po_id}</Td><Td className="num">{fmt.date(i.date)}</Td>
                  <Td className="num text-right">{fmt.gbp(i.po_value)}</Td><Td className="num text-right">{fmt.gbp(i.invoice_value)}</Td><Td className="num text-right">{fmt.gbp(i.variance_amount)}</Td>
                  <Td className={cn("num text-right font-semibold", i.variance_pct > 1 ? "text-rose-700" : "text-ink-700")}>{fmt.pct(i.variance_pct, 2)}</Td>
                  <Td><Badge tone={i.status === "Disputed" ? "critical" : "neutral"}>{i.status}</Badge></Td></tr>))}</tbody>
            </table>
          </TabsContent>
          <TabsContent value="graph" className="p-4">
            {relLoading || !rel ? <Skeleton className="h-72 w-full" /> : <VendorLinks rel={rel} vendorId={vid} />}
          </TabsContent>
          <TabsContent value="risk" className="p-4">
            {!risk ? <Skeleton className="h-40 w-full" /> : (
              <div className="grid gap-4 lg:grid-cols-2">
                <div>
                  <div className="mb-2 flex items-center gap-2"><span className="eyebrow">Risk of further decline</span><RiskBadge level={risk.internal.risk_level} prob={risk.internal.risk_probability} /></div>
                  <p className="mb-3 text-[12px] text-ink-500">{risk.internal.model.credible ? <>Model: {risk.internal.model_version} · predicts “{risk.internal.model.label_definition}” · held-out ROC-AUC {risk.internal.model.metrics.roc_auc}</> : <>ML model not credible on this data ({risk.internal.model.reason}) - statistical trend + anomaly signals used.</>}</p>
                  <ul className="space-y-1.5 text-[12.5px]">{risk.internal.drivers.map((d, i) => (
                    <li key={i} className="flex items-center justify-between gap-2 rounded-md bg-ink-50/70 px-3 py-1.5">
                      <span>{d.label ?? d.feature}{d.detail && <span className="text-ink-500"> · {d.detail}</span>}</span>
                      <span className="flex items-center gap-2 text-[11px] text-ink-500">{d.value != null && <span className="num">{Number(d.value).toFixed(2)}</span>}<Badge>{d.method ?? d.type}</Badge></span>
                    </li>))}</ul>
                </div>
                <div>
                  <div className="mb-2 flex items-center gap-2"><span className="eyebrow">Outside-event risk</span><RiskBadge level={risk.external.external_risk} /></div>
                  {risk.external.events.length === 0 ? <EmptyState icon={Globe2} title="No active external events" hint="No current events affect this vendor's country or port." /> : (
                    <ul className="space-y-2">{risk.external.events.map((e) => (
                      <li key={e.event_id} className="rounded-lg border border-ink-100 px-3 py-2 text-[12.5px]"><div className="font-medium">{e.title}</div><div className="text-[11.5px] text-ink-500">{e.event_type} · severity {e.severity} · ~{e.expected_delay_days} days delay</div></li>))}
                      {risk.external.exposure && <li className="text-[12px] text-ink-600">Exposure: {risk.external.exposure.open_pos} open POs ({fmt.gbp(risk.external.exposure.open_value)}), {risk.external.exposure.critical_pos_at_risk} critical POs at risk.</li>}
                      <li><Link to="/risk-intel" className="text-[12px] font-medium text-brand-600">Open Supplier Risk Alerts →</Link></li>
                    </ul>
                  )}
                </div>
              </div>
            )}
          </TabsContent>
          <TabsContent value="contract" className="p-4">
            {v.profile.contract ? (
              <div className="grid gap-4 md:grid-cols-3">
                {[["Contract", `${v.profile.contract.contract_id} · ${v.profile.contract.contract_type}`], ["Term", `${fmt.date(v.profile.contract.start_date)} → ${fmt.date(v.profile.contract.end_date)}`],
                  ["SLA tier", v.profile.contract.sla_id], ["On-time target", `${v.profile.contract.sla_otd_target_pct}%`], ["Max defect rate", `${v.profile.contract.sla_max_defect_rate_pct}%`],
                  ["Max invoice variance", `${v.profile.contract.sla_max_invoice_variance_pct}%`], ["Payment terms", `${v.profile.contract.payment_terms_days} days`],
                  ["Penalty clause", v.profile.contract.penalty_clause], ["Exclusivity", v.profile.contract.exclusivity ? "Yes - review before re-allocation (CTG-5)" : "No"]].map(([a, b2]) => (
                  <div key={a} className="rounded-lg bg-ink-50/60 px-3 py-2"><div className="eyebrow">{a}</div><div className="mt-0.5 text-[13px] font-medium text-ink-900">{b2}</div></div>
                ))}
              </div>
            ) : <EmptyState title="No contract on file" />}
          </TabsContent>
        </Tabs>
      </Card>
      {recs && recs.history.length > 0 && (
        <Card className="mt-4">
          <CardHeader title="Past recommendations" subtitle="Recommended actions recorded for this vendor" action={sees("approvals") && <Link to="/governance" className="text-[12px] font-medium text-brand-600">Approvals →</Link>} />
          <CardBody className="pt-2">
            <ul className="divide-y divide-ink-100 text-[12.5px]">{recs.history.map((r) => (
              <motion.li key={r.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-wrap items-center justify-between gap-2 py-2">
                <span><span className="font-medium">{r.title}</span> <span className="text-ink-500">· {fmt.datetime(r.created_at)} · confidence {Math.round(r.confidence * 100)}%</span></span>
                <Badge tone={r.status === "approved" ? "good" : r.status === "rejected" ? "critical" : r.status === "pending_approval" ? "warning" : "neutral"}>{r.status.replace("_", " ")}</Badge>
              </motion.li>))}</ul>
          </CardBody>
        </Card>
      )}
    </>
  );
}
