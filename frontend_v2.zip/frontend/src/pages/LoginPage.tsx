import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, BarChart3, Bot, Briefcase, Eye, EyeOff, Loader2, LockKeyhole, ShieldCheck, UserCog, UserRound } from "lucide-react";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { Button, Input } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";

const schema = z.object({
  username: z.string().trim().min(2, "Enter your username"),
  password: z.string().min(1, "Enter your password"),
});
type Form = z.infer<typeof schema>;

interface Roles {
  roles: { role: string; label: string; permissions: string[] }[];
  permissions: Record<string, string>;
  personas: { username: string; display_name: string; title: string; role: string }[];
}

const PERSONA_ICON: Record<string, React.ElementType> = { business: Briefcase, staff: UserRound, admin: UserCog };
const PERSONA_ROLE: Record<string, string> = { business: "Business user", staff: "Staff", admin: "Admin" };

export default function LoginPage() {
  const { login } = useAuth();
  const { data: roles } = useQuery({ queryKey: ["roles"], queryFn: () => api.get<Roles>("/auth/roles"), staleTime: Infinity });
  const [show, setShow] = React.useState(false);
  const [error, setError] = React.useState<string>();
  const { register, handleSubmit, setValue, watch, setFocus, formState } = useForm<Form>({ resolver: zodResolver(schema), defaultValues: { username: "", password: "" } });
  const username = watch("username");

  const onSubmit = async (f: Form) => {
    setError(undefined);
    try { await login(f.username, f.password); } catch (e) { setError(e instanceof Error ? e.message : "Sign-in failed"); }
  };
  const pick = (u: string) => { setValue("username", u, { shouldValidate: true }); setValue("password", ""); setFocus("password"); };

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <div className="relative hidden overflow-hidden bg-ink-950 px-14 py-12 text-white lg:flex lg:flex-col">
        <div className="absolute -right-32 -top-32 h-[420px] w-[420px] rounded-full bg-brand-500/20 blur-3xl" />
        <div className="absolute -bottom-40 left-10 h-[360px] w-[360px] rounded-full bg-brand-400/10 blur-3xl" />
        <img src="/brand/primark-logo-white.png" alt="Primark" className="relative h-6 w-auto self-start" />
        <div className="relative mt-auto max-w-lg">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-[11.5px] font-semibold uppercase tracking-wider text-brand-200">Vendor360 AI</div>
          <h1 className="font-display text-[38px] font-bold leading-[1.1] text-white">Vendor performance,<br />measured and explained.</h1>
          <p className="mt-4 text-[14px] leading-relaxed text-ink-300">See how every supplier performs, why, and what to do next.</p>
          <ul className="mt-8 space-y-3 text-[13px] text-ink-200">
            {[[BarChart3, "Every supplier scored out of 100 on delivery, quality, cost and lead-time reliability"],
              [Bot, "Ask questions in plain English and get answers backed by facts and policy"],
              [ShieldCheck, "Safety checks, approvals for important actions and a full audit trail"]].map(([I, t]) => {
              const Icon = I as React.ElementType;
              return <li key={t as string} className="flex items-start gap-3"><span className="mt-0.5 rounded-md bg-white/10 p-1.5"><Icon className="h-4 w-4 text-brand-300" /></span>{t as string}</li>;
            })}
          </ul>
        </div>
        <p className="relative mt-auto pt-10 text-[11.5px] text-ink-500">Powered by TCS for Primark</p>
      </div>

      <div className="flex items-center justify-center bg-canvas px-5 py-10">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-[420px]">
          <img src="/brand/primark-logo-blue.png" alt="Primark" className="mb-8 h-5 lg:hidden" />
          <h2 className="text-[24px] font-bold">Sign in</h2>
          <p className="mt-1 text-[13px] text-ink-500">Pick who you are, then enter your password.</p>

          {roles && roles.personas.length > 0 && (
            <div className="mt-6 grid grid-cols-3 gap-2.5">
              {roles.personas.map((p) => {
                const Icon = PERSONA_ICON[p.role] ?? UserRound;
                const role = roles.roles.find((r) => r.role === p.role);
                return (
                  <button key={p.username} type="button" onClick={() => pick(p.username)}
                    className={cn("rounded-xl border bg-white p-3.5 text-left shadow-card transition-all hover:border-brand-300",
                      username === p.username ? "border-brand-400 ring-2 ring-brand-100" : "border-ink-100")}>
                    <div className="flex items-center gap-2">
                      <span className={cn("rounded-lg p-1.5", p.role === "admin" ? "bg-ink-900 text-white" : "bg-brand-50 text-brand-700")}><Icon className="h-4 w-4" /></span>
                      <span className="text-[10.5px] font-semibold uppercase tracking-wide text-ink-500">{PERSONA_ROLE[p.role] ?? p.role}</span>
                    </div>
                    <div className="mt-2 text-[13.5px] font-semibold text-ink-950">{p.display_name}</div>
                    <div className="text-[11.5px] leading-snug text-ink-500">{p.title}</div>
                    <div className="mt-2 text-[10.5px] leading-snug text-ink-500">{role?.permissions.length ?? 0} of 6 permissions</div>
                  </button>
                );
              })}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4" noValidate>
            <label className="block">
              <span className="eyebrow">Username</span>
              <Input {...register("username")} autoComplete="username" className="mt-1 h-10" placeholder="business, staff or admin" />
              {formState.errors.username && <span className="mt-1 block text-[12px] text-rose-700">{formState.errors.username.message}</span>}
            </label>
            <label className="block">
              <span className="eyebrow">Password</span>
              <div className="relative mt-1">
                <Input {...register("password")} type={show ? "text" : "password"} autoComplete="current-password" className="h-10 pr-10" />
                <button type="button" onClick={() => setShow(!show)} className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-ink-400 hover:text-ink-700" aria-label={show ? "Hide password" : "Show password"}>
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {formState.errors.password && <span className="mt-1 block text-[12px] text-rose-700">{formState.errors.password.message}</span>}
            </label>
            {error && <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-[12.5px] text-rose-800"><LockKeyhole className="mt-0.5 h-4 w-4 shrink-0" />{error}</div>}
            <Button type="submit" variant="brand" size="lg" className="w-full" disabled={formState.isSubmitting}>
              {formState.isSubmitting ? <Loader2 className="animate-spin" /> : <>Sign in<ArrowRight /></>}
            </Button>
          </form>
          <p className="mt-5 text-[11.5px] leading-relaxed text-ink-400">
            Passwords are set by your administrator (server <code className="rounded bg-ink-100 px-1">.env</code>).
            Five failed attempts lock an account for five minutes.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
