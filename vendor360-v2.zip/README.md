# Vendor360 AI - Agentic Vendor Performance Scoring & Supplier Intelligence

A hackathon prototype for **Primark sourcing & procurement**. It measures, scores, explains and
governs supplier performance:

**Measure → Score → Detect → Explain → Recommend → Govern → Act**

* **Primary capability: Vendor Performance Scoring.** A deterministic, auditable score built
  from delivery (30%), quality (30%), cost (20%) and lead-time consistency (20%). See
  [docs/SCORING.md](docs/SCORING.md).
* **LangGraph agents** (Supervisor, Performance, Risk/Trend, Knowledge, Recommendation,
  Governance) explain *why* a score is what it is and recommend the next procurement action.
  Their sources are PostgreSQL analytics, **ChromaDB** policies and the **Neo4j** supplier
  graph, and every figure they state is checked against the evidence.
* **Azure OpenAI / OpenAI** run behind an LLM optimisation layer (JEV context compression,
  caching, model routing, token budgets). Everything except the copilot's prose works with
  no LLM at all.
* **Secondary extension: Proactive Supplier-Risk Intelligence.** External events are traced
  through the supplier graph and kept separate from the score.

Architecture: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

> All data and policy documents are **synthetic** and generated for this demo. The Primark
> logo is used at the client's request for the hackathon presentation.

---

## Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript, Vite, Tailwind CSS, shadcn/ui-style Radix components, Recharts, TanStack Query, React Router, Lucide, Framer Motion, React Hook Form + Zod |
| Backend | Python 3.12, FastAPI, Pydantic v2, SQLAlchemy 2, Alembic, LangChain (`langchain-openai`, `langchain-core`), LangGraph, scikit-learn, XGBoost, SHAP, pandas |
| Data | PostgreSQL 17 (transactions), Neo4j Aura (relationships), ChromaDB (policy knowledge) |
| LLM | Azure OpenAI or OpenAI (configurable); deterministic labelled fallback when none is set |

Ports: API **8040**, UI **5200**, PostgreSQL **5433**. They were chosen so they don't collide
with other local projects.

---

## Run it locally (Windows, no Docker)

Prerequisites: Python 3.11+, Node 20+, PostgreSQL 17 binaries (the installer is enough; the
script runs its own user-owned cluster, so no admin rights or Windows service are needed).

```powershell
cd vendor360-ai

# 1. Python virtual environment + backend packages
python -m venv backend\.venv
backend\.venv\Scripts\python -m pip install -r backend\requirements.txt

# 2. Frontend packages
cd frontend; npm install; cd ..

# 3. Configure: copy .env.example to .env and fill in Neo4j (and optionally LLM) settings
copy .env.example .env

# 4. Start PostgreSQL (first run creates .local\pgdata, user/password/db = vendor360)
powershell -ExecutionPolicy Bypass -File scripts\start-postgres.ps1

# 5-9. Migrate DB, generate + seed synthetic data, score, train the risk model,
#      ingest the Neo4j graph and the ChromaDB knowledge base (about 3-4 minutes)
backend\.venv\Scripts\python scripts\bootstrap.py

# 10. Start the API  (OpenAPI docs: http://127.0.0.1:8040/docs)
cd backend; ..\backend\.venv\Scripts\python -m uvicorn app.main:app --port 8040

# 11. Start React (new terminal)  ->  http://localhost:5200
cd frontend; npm run dev
```

Or start everything at once with `scripts\start-dev.ps1` (add `-Bootstrap` on first run).
`make` targets exist for Git Bash, macOS and Linux.

Useful bootstrap flags: `--regenerate` (new synthetic data), `--no-graph`, `--graph-only`,
`--knowledge-only`. The same pipeline is available from the API at `POST /api/v1/data/seed`
(runs in the background; poll `GET /api/v1/data/seed/status`).

### Enabling a live LLM

In `.env`:

```env
LLM_PROVIDER=azure                       # or openai
AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_DEPLOYMENT=gpt-4o-mini      # standard tier
AZURE_OPENAI_DEPLOYMENT_LIGHT=           # optional cheaper tier
AZURE_OPENAI_DEPLOYMENT_STRONG=          # optional stronger tier
# OpenAI instead:  LLM_PROVIDER=openai, OPENAI_API_KEY=..., OPENAI_MODEL=gpt-4o-mini
# Optional embeddings: EMBEDDING_PROVIDER=azure|openai (+ deployment/model), then re-run --knowledge-only
```

Restart the API. With no provider configured, the copilot runs the same agents and evidence
and returns **clearly labelled deterministic answers**. It never pretends a model answered.

---

## Sign-in & personas

| Persona | Username | Default password (`.env`) | Menu they see |
|---|---|---|---|
| **Business user** - Alex Morgan, Head of Buying | `business` | `DEMO_BUSINESS_PASSWORD` (Business@2026) | Dashboard, Vendor Scorecards, Vendor 360 Profile, Performance Analytics, Vendor Comparison, Ask AIRA (the AI assistant), Alternative Suppliers, Policies & Contracts, Supplier Risk Monitor |
| **Staff** - Sam Patel, Sourcing Analyst | `staff` | `DEMO_STAFF_PASSWORD` (Staff@2026) | the above + **Approvals & Audit** (view only) + **Trust Centre** + **AI Cost Management** |
| **Admin** - Jordan Lee, Procurement Administrator | `admin` | `DEMO_ADMIN_PASSWORD` (Admin@2026) | everything + approve actions, **AI Safety Rules**, **Risk Prediction Models**, **Platform Settings** |

Menus per role are defined once in `backend/app/security.py` (`ROLE_MENUS`), returned by `/auth/me`
and used by the frontend menu and page guard. Pages outside a role are also blocked by the API.
The UI uses plain business language (e.g. "Getting worse", "Risk of decline", "Meeting contract targets").

Permissions are enforced by the API (`app/security.py`); the UI only mirrors them. Sessions are
HMAC-signed bearer tokens (`AUTH_SECRET`, 8 h). Five failed sign-ins lock an account for 5 minutes.
`AUTH_MODE=demo` disables sign-in (everyone is admin); `AUTH_MODE=api_key` is for service clients.
**Change the demo passwords and `AUTH_SECRET` before sharing the app beyond a local demo.**

## Value for Primark (dashboard, every role)

The dashboard opens with the estimated yearly benefit, using the usual procurement savings categories:
**hard savings** (invoice overcharges recovered), **cost avoidance** (fewer late deliveries and quality
failures), **productivity** (scorecard hours freed), plus **spend protected** from disruption (risk
mitigation, shown separately and not added to the total). Each figure is a measured 12-month baseline
from the data x a stated assumption (admins can edit them; changes are audited), with Conservative /
Expected / Stretch scenarios, return on cost, payback, SCOR-style operational measures (on-time delivery,
first-pass quality, invoice accuracy, lead-time reliability) and non-financial benefits. Indicative only.

## Admin editing: policies and AI safety rules

**Policies & Contracts** - admins can create, edit and archive policy documents in the app. Every save needs a change
note, creates a new version (the old one is kept and readable in *Version history*), re-indexes the policy search so
AIRA uses the new wording straight away, and is written to the audit trail. Other roles see the library read-only.

**AI Safety Rules** - admins can change thresholds and blocked terms, switch individual manipulation checks and
personal-data types on or off, add custom rules (phrases to flag or block, with a message for the user), test any prompt
before saving, and reset everything to the defaults. All changes are audited.

## Trust Centre and AI Cost Management (`/trust`, `/finops`, staff & admin)

**Responsible AI** - eight principles, each with its controls and *live evidence*:
human in control (approval queue, the action is decided by policy rules not AI), accuracy & grounding
(every figure checked, bad drafts replaced), transparency ("AI-written" label, facts behind every
answer, published formulas), fairness (score inputs listed; no location / size / ownership / personal
data used; a live **region parity check** explains score gaps by measured KPIs), privacy (personal data
redacted before the model; only KPI summaries sent), safety (injection detection, blocked terms, rate
limits, audit), honest ML (time-based testing, 0.65 bar), feedback (thumbs up/down on every answer,
negative feedback queue).

**AI Cost Management (FinOps, its own menu at `/finops`)** - every model call is stored in `llm_usage` with tokens and cost (list prices
per 1M tokens, `LLM_PRICE_TABLE`, converted at `USD_TO_GBP`). The page shows spend this month,
the month-end forecast, cost per question, the share answered without a new AI call, savings from
caching and context compression, attribution by role / person / task / model, 30-day cost and token trends (sent / received / trimmed), token efficiency (tokens per question,
context trimmed, cost per 1,000 tokens, cache hit rate, response time), the 10 most expensive questions, a
**monthly budget with alert and hard stop** (when reached, AIRA answers from facts only), a
**scale calculator** (people × questions × days, compared across models), indicative pilot running
costs for the whole stack, and the cost-saving levers built in. Each AI answer also shows its own cost
to staff and admins.

**Security** - an automatic self-check of 20 controls (sign-in, RBAC, lockout, session lifetime,
secret strength, secrets out of git, TLS to the graph, browser security headers, CORS, input
validation, AI input protection, audit, log masking...). Each control shows its status in this build
**and** how it is delivered in an enterprise rollout (Entra ID SSO/MFA, Key Vault, private
endpoints, Front Door + WAF, Sentinel, Content Safety, CI scanning, pen test), plus a 7-area
enterprise security plan. Demo-only settings are flagged honestly ("Demo setting").

## Guardrails (`/guardrails`)

One page for every rule around the AI layer (`app/governance/guardrails.py`):

* **Input**: length limits; prompt-injection detection (5 pattern families, *flag* or *block*);
  redaction of personal data (email, phone, card number with Luhn check, NI number) before anything
  reaches an agent or LLM; blocked terms; per-user rate limit; vendor-id and date validation.
* **Agent**: max steps, tool calls, LLM calls, token and context budgets, tool allow-lists, graph
  depth, timeouts. These are live, so edits apply to the next request.
* **Output**: numeric grounding (an LLM draft with too many unsupported figures is replaced by the
  grounded answer), required citations, protection of the deterministic ranking, a minimum
  confidence below which the answer carries a warning, and human approval for Stage 2+ actions.
* **Access**: the staff vs admin permission matrix. Denied actions and failed sign-ins are logged.

Admins edit the rules on the page (audited); everyone can dry-run a prompt and see every guardrail event.

---

## Hackathon demo script (about 5 minutes)

1. **Executive Dashboard**: 500 vendors evaluated, plus spend at risk, on-time delivery, defect rate, invoice accuracy and SLA compliance; the score distribution, band mix, trend,
   deteriorating vendors and category performance. The spotlight banner shows **V1024**.
2. **Vendor 360 · V1024** (Ningbo Bluewave Denim): score **86 → 64**, Watch band,
   deteriorating. Delivery 55, quality 82, cost 63, lead-time consistency 51; the score
   breakdown with the formula; the drivers; SLA breaches; the Stage 2 recommendation with
   backup suppliers; the graph relationships.
3. **Ask AIRA** (the AI assistant - click the floating AIRA button on any page, or open the full page for the facts and checks): *"Why is Vendor V1024 underperforming?"* Watch the agents run, then inspect
   the evidence, sources, graph, agent trace and governance tabs.
4. *"What procurement action do you recommend?"* The session remembers V1024. The answer uses
   score, trend, SLA, policy (SEP-2, SEP-4.1), graph dependency and alternatives, and the
   recommendation is logged as **awaiting approval**.
5. *"Find the best alternative supplier."* Then open **Alternative Sourcing** for the
   comparison matrix, ranking rationale and policy constraints, and **Vendor Comparison** for
   radar and trend.
6. **Governance & Audit**: approve or reject the recommendation, then view the audit trail with
   agent traces, the risk-model card (temporal held-out metrics vs baseline, SHAP), routing,
   JEV token savings and cache hit rates.
7. **Risk Model Lab**: train the XGBoost risk model on a
   temporal hold-out; review ROC/PR/calibration curves, confusion matrices, rolling validation and feature
   importance; tune hyper-parameters; **promote** a credible model to drive production risk scores; run the
   IsolationForest anomaly detector.
8. **External Risk (add-on)**: *Chittagong port congestion*. The path runs Event →
   Port → Vendor → POs → Product → Category → Impact, and a strong performer (score 90+) can
   still carry **High external risk**. The three indicators stay separate.

Other demo vendors: **V1001** excellent · **V1035** quality concern (kidswear) · **V1050**
cost concern (premium pricing) · **V1088** lead-time variability.

---

## Repository layout

```
vendor360-ai/
├── backend/
│   ├── app/
│   │   ├── analytics/     scoring.py (deterministic VPS), metrics.py (KPI extraction)
│   │   ├── agents/        LangGraph state, intent, nodes, rules (SEP-2), compose, graph, copilot service
│   │   ├── api/           REST v1 routes
│   │   ├── database/      engine/session
│   │   ├── governance/    grounding checks, audit
│   │   ├── graph/         Neo4j client, idempotent ingestion, queries (+ relational fallback)
│   │   ├── knowledge/     Chroma ingestion pipeline, embeddings, hybrid retrieval
│   │   ├── llm/           provider factory + routing, JEV optimiser, gateway (cache/budget/timeout)
│   │   ├── ml/            risk model (temporal validation, SHAP), anomaly detection
│   │   ├── models/        SQLAlchemy entities
│   │   ├── risk_intel/    SECONDARY: external event impact propagation
│   │   ├── schemas/       request validation
│   │   ├── services/      snapshots, analytics read models, alternatives ranking, caches, settings, pipeline
│   │   ├── tools/         typed agent tools + per-agent allow-lists (MCP-ready catalogue)
│   │   ├── security.py    auth abstraction + RBAC
│   │   └── main.py
│   ├── alembic/           migrations
│   └── tests/             unit + integration tests
├── frontend/src/          pages/ (10 screens), components/, layouts/, hooks/, lib/, types/
├── data/                  synthetic CSVs (vendors, purchase_orders, deliveries, quality_inspections, invoices, lead_times, ...)
├── knowledge/             8 synthetic policy / SLA / standards / guideline / contract documents
├── scripts/               generate_data.py, bootstrap.py, start-*.ps1
├── docs/                  SCORING.md, ARCHITECTURE.md
├── .env.example
└── Makefile
```

## Tests

```powershell
cd backend;  .venv\Scripts\python -m pytest -q -p no:cacheprovider              # unit + integration (about 2 min)
             .venv\Scripts\python -m pytest -q -p no:cacheprovider -m "not integration"
cd frontend; npx vitest run; npx tsc -b --force; npm run build
```

Integration tests run against the seeded local stack and **skip** (not fail) if PostgreSQL or
Neo4j is unavailable.

## Synthetic data

`scripts/generate_data.py` (seeded and reproducible) creates 500 vendors across 11 sourcing
countries and 10 categories, with about 35k POs, 44k deliveries, 32k inspections, 30k invoices
and lead-time records, plus contracts/SLAs and 5 external events. Each vendor has a latent
archetype: excellent, good, average, poor, deteriorating, quality-deteriorating,
expensive-but-high-quality, cheap-but-poor-quality, lead-time-variable or delivery-problem.
These drive realistic distributions and time drift. `data/_archetypes.csv` is ground truth for
validation only; the app never reads it.

## Honest limitations

* The data, policies and external events are synthetic. The risk model's metrics are real
  measurements *on synthetic data*.
* The local ChromaDB uses the on-device MiniLM embedding model. Switching to Azure or OpenAI
  embeddings needs a re-ingest.
* Session memory for the copilot is in-process. A production deployment would use Redis or
  the database and a LangGraph checkpointer.
* Authentication is a demo/API-key abstraction. Enterprise SSO (e.g. Entra ID) plugs into
  `app/security.py::authenticate`.
