# Vendor360 AI - Handover for coding agents

> Read this first. It tells you what the system is, how to run it, where everything lives, which
> rules you must not break, and how to make the common kinds of change safely. Deeper detail:
> [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) (design), [docs/SCORING.md](docs/SCORING.md) (score
> formulas), [README.md](README.md) (user-facing setup and demo script).

---

## 1. What this is

**Vendor360 AI** is a hackathon prototype for **Primark sourcing & procurement** (built by TCS).
Primary capability: **Vendor Performance Scoring**. It is a *deterministic* 0-100 score per vendor
from Delivery 30% / Quality 30% / Cost 20% / Lead-time consistency 20%, computed monthly over
rolling 3-month windows. Around the score sit:

| Layer | What it does |
|---|---|
| Analytics | KPIs, trends, deterioration detection, operational and commercial KPIs (spend, OTD %, invoice accuracy, SLA compliance) |
| AI copilot | LangGraph agents (Supervisor, Performance, Risk, Knowledge, Recommendation, Synthesis, Governance) explain scores and recommend actions |
| Knowledge | ChromaDB holds 8 synthetic policy/SLA documents (`knowledge/*.md`) |
| Graph | Neo4j Aura holds supplier relationships (supplies, alternatives, contracts, ports, external events) |
| ML | Risk model (XGBoost only, Model Lab to tune/train/promote) + IsolationForest anomalies |
| Governance | Numeric grounding, guardrails (input/agent/output/access), human approval, audit trail |
| AI assistant | **AIRA** - named in the system prompt (`agents/compose.py`), floating launcher on every page + full page `/copilot` |
| Auth | Three personas: **business** (read + AIRA), **staff** (+ approvals/audit view), **admin** (everything) |
| Add-on | External risk intelligence: synthetic events traced through the graph. Kept separate from the score |

All data is **synthetic** (`scripts/generate_data.py`, seed 42). The Primark logo is used at the
client's request.

---

## 2. Run it (Windows, no Docker)

| Service | Port | How |
|---|---|---|
| PostgreSQL 17 (user-owned cluster in `.local/pgdata`) | **5433** | `powershell -File scripts\start-postgres.ps1` (stops on reboot - start it first) |
| FastAPI backend | **8040** | `cd backend; .venv\Scripts\python -m uvicorn app.main:app --port 8040` (no auto-reload: **restart after every backend edit**) |
| React frontend (Vite) | **5200** | `cd frontend; npm run dev` (hot reloads; proxies `/api` to 8040) |
| Neo4j | Aura cloud | credentials in `.env` |
| ChromaDB | embedded | `.local/chroma` |

- One command for everything: `scripts\start-dev.ps1` (add `-Bootstrap` on first run).
- First-time data: `backend\.venv\Scripts\python scripts\bootstrap.py` (about 3-4 min) runs
  migrate → generate CSVs → load Postgres → score → train risk → ingest Neo4j → ingest Chroma.
  Flags: `--regenerate`, `--no-graph`, `--no-knowledge`, `--graph-only`, `--knowledge-only`.
- **Ports 5173, 5183, 5190, 5195, 8000, 8010, 8020, 8030 and 8100 belong to the user's other
  projects. Never use or kill them.** Other uvicorn processes on this machine are not ours; only
  stop the one listening on 8040.
- Sign in at http://localhost:5200 as `business` / `Business@2026`, `staff` / `Staff@2026` or
  `admin` / `Admin@2026` (set in `.env`). Health check: `GET /api/v1/health` (public). OpenAPI: http://127.0.0.1:8040/docs.

### `.env` (repo root, git-ignored; template `.env.example`)
Key settings: `DATABASE_URL`, `NEO4J_*`, `LLM_PROVIDER=openai` (`OPENAI_API_KEY` set,
`OPENAI_MODEL=gpt-4o-mini`; the key only works for gpt-4o-mini), `EMBEDDING_PROVIDER=local`,
`AUTH_MODE=login`, `AUTH_SECRET` (random), `DEMO_BUSINESS_PASSWORD`, `DEMO_STAFF_PASSWORD`, `DEMO_ADMIN_PASSWORD`,
`PROMPT_VERSION=v1.4`. **Never print or commit secrets.** When you need to edit a key, do it with
a script that does not echo the value.

---

## 3. Non-negotiable rules (the brief and the design depend on them)

1. **Scores are deterministic.** Never compute or adjust scores, KPIs or rankings with an LLM.
   Formulas live only in `backend/app/analytics/scoring.py`. Changing one means updating
   `docs/SCORING.md` and `tests/test_scoring.py`, and bumping `SCORING_MODEL_VERSION`.
2. **The LLM only phrases answers from evidence.** Agents pass structured evidence items (ids
   P1, K2, A3...). Governance rejects LLM drafts with unsupported figures, missing citations, or a
   re-ordered supplier ranking, and serves the deterministic answer instead.
3. **The recommended action comes from rules** (`agents/rules.py`, mapped to escalation policy
   SEP-2 stages), never from the model. Stage 2+ actions require admin approval.
4. **External risk is never blended into the score or internal risk.** There are three separate
   indicators: performance score, internal risk and external risk.
5. **Never fabricate data.** If Neo4j is down, graph queries answer from Postgres and label the
   result `postgres-fallback`. If no LLM is available, answers are labelled `deterministic-fallback`.
6. **ML must stay honest.** Temporal split only (train on earlier months, test on later ones). A
   model below 0.65 ROC-AUC is "not credible" and cannot be promoted. Report metrics as measured.
7. **Permissions are enforced in the API** (`security.require("<perm>")`); the UI only mirrors
   them. Every new mutating route needs a permission. Roles and permissions:
   `business` = read, copilot. `staff` = + audit. `admin` = + approve, configure, seed.
   **Menus per role** come from `ROLE_MENUS` in `security.py` (keys match `NAV[].key` in
   `AppShell.tsx` and the `<Allowed menu=...>` guards in `App.tsx`). Admin-only pages (AI Safety
   Rules, Risk Prediction Models, Settings) need `configure` even for GET. Approvals & Audit
   needs `audit`.
8. **The UI speaks plain business language.** No jargon on screen (no "deterministic", "PR-AUC",
   "LangGraph", "SEV-2"...). Technical detail belongs in tooltips, admin pages or docs.
9. **Transactions are never embedded into ChromaDB.** Only `knowledge/*.md` policy documents.

---

**Presentation material (docs/):** `Vendor360_AI_KPI_Guide.pptx` (22 slides: every KPI explained + solution
architecture + full-size appendix, with speaker notes; the live editable deck is the Claude Slides artifact),
`architecture/vendor360_solution_architecture_L2.{png,svg}` + `generate_architecture.py` (re-run to redraw),
`GEMINI_VIDEO_PROMPT.md` (3-minute cartoon explainer prompt and shot list).

## 4. Repository map

```
vendor360-ai/
├── .env / .env.example        config (root)
├── HANDOVER.md                this file
├── data/                      generated CSVs (+ _archetypes.csv = ground truth, never read by the app)
├── knowledge/                 8 policy docs with YAML front-matter (document_id, version, type...)
├── scripts/                   generate_data.py, bootstrap.py, start-*.ps1
├── docs/                      ARCHITECTURE.md, SCORING.md
├── backend/
│   ├── alembic/versions/      0001 initial schema, 0002 ml_model_runs, 0003 llm_usage
│   ├── tests/                 test_scoring.py, test_ai_components.py (unit), test_integration.py (live stack)
│   └── app/
│       ├── main.py            FastAPI app, CORS, request-id middleware, startup warm-up
│       ├── config.py          pydantic-settings (all env vars + defaults)
│       ├── security.py        personas, PBKDF2, HMAC tokens, lockout, authenticate/require
│       ├── observability.py   JSON logs + request id
│       ├── api/v1.py          ALL REST routes (one file, grouped by tag)
│       ├── schemas/requests.py  validated request bodies (Pydantic v2)
│       ├── models/entities.py   SQLAlchemy models
│       ├── database/session.py  engine, SessionLocal, get_db, session_scope
│       ├── analytics/         scoring.py (pure formulas), metrics.py (KPI extraction with pandas)
│       ├── services/
│       │   ├── scoring_service.py   monthly snapshots, frames() cache, reweight()
│       │   ├── analytics_service.py dashboard, vendor 360, lists, compare, operational KPIs, commercials
│       │   ├── alternatives.py      deterministic alternative ranking (fit score + SEP-4.2 eligibility)
│       │   ├── risk_service.py      trains the production risk model, writes vendor_risk_snapshots
│       │   ├── model_lab.py         experiments, promote/reset, anomaly lab
│       │   ├── runtime_settings.py  app_settings table (weights, risk, cache, agent, guardrails, data_version)
│       │   ├── cache.py             analytics / retrieval / response / semantic caches
│       │   ├── pipeline.py          run_all(), rescore()
│       │   ├── seed.py              CSV → Postgres
│       │   ├── finops.py            AI usage/cost records, prices, budget + hard stop, forecast, savings, token efficiency
│       │   ├── value.py             business value: measured baseline x editable assumptions -> savings, ROI, payback
│       │   └── trust.py             responsible-AI evidence, fairness by region, security self-check
│       ├── agents/            LangGraph: state.py, intent.py, nodes.py, rules.py, compose.py, graph.py, copilot.py
│       ├── tools/registry.py  typed agent tools + per-agent allow-lists (MCP-ready catalogue)
│       ├── llm/               provider.py (routing), gateway.py (cache/budget/timeout), jev.py (context compression)
│       ├── knowledge/         store.py (Chroma ingest + hybrid search), embeddings.py
│       ├── graph/             client.py, ingest.py (idempotent MERGE), queries.py (+ Postgres fallback)
│       ├── ml/                algorithms.py (registry), risk_model.py (dataset, RiskModel, anomalies), lab.py (evaluation)
│       ├── governance/        checks.py (grounding/confidence), guardrails.py (rules + events), audit.py
│       └── risk_intel/service.py  external events → impact propagation (add-on)
└── frontend/src/
    ├── main.tsx / App.tsx     providers, auth gate, routes
    ├── layouts/AppShell.tsx   sidebar NAV (groups/labels), header, search, user menu
    ├── pages/                 one file per screen (see table below)
    ├── components/            ui/primitives.tsx (shadcn-style), domain.tsx (BandBadge, KpiTile, ScoreRing...), FilterBar, VendorLinks (Products & backup suppliers tab: dependency summary, products table, ranked backups, Neo4j network map), VendorScoreCard, BusinessValue, Aira, PolicyEditor
    ├── hooks/queries.ts       ALL TanStack Query hooks
    ├── lib/                   api.ts (fetch + bearer token), auth.tsx (AuthProvider/useAuth), utils.ts (colours, fmt, bands)
    └── types/                 api.ts, ml.ts
```

### Screens (route → file → main API)

| Menu label | Menu key | Roles | Route | File | API |
|---|---|---|---|---|---|
| Executive Dashboard | dashboard | all | `/` | DashboardPage (+ `components/BusinessValue.tsx`) | `GET /dashboard/summary`, `GET /value/benefits?scenario=`; `PUT /value/assumptions` (configure) |
| Vendor Scorecards | vendors | all | `/vendors` | VendorsPage | `GET /vendors` |
| Vendor 360 Profile | vendor360 | all | `/vendors/:id` | Vendor360Page | `/vendors/{id}` (+ `/trend`, `/risk`, `/recommendations`, `/alternatives`, `/relationships`) |
| Performance Analytics | insights | all | `/analytics` | AnalyticsPage | `GET /analytics/performance` |
| Vendor Comparison | compare | all | `/compare` | ComparePage (category filter `?category=`, quick picks top 3 / bottom 3 / best vs worst) | `POST /analytics/compare`, `GET /vendors?category=` |
| Ask AIRA | assistant | all | `/copilot` (+ floating `components/Aira.tsx` on every other page) | CopilotPage | `POST /copilot/chat` |
| Alternative Suppliers | alternatives | all | `/recommendations` | RecommendationsPage | `/vendors/{id}/alternatives` |
| Policies & Contracts | policies | all (edit: admin) | `/knowledge` | KnowledgePage + `components/PolicyEditor.tsx` | `/knowledge/*`; admin: `GET .../{id}/source`, `POST /knowledge/documents`, `PUT/DELETE /knowledge/documents/{id}`, `GET .../{id}/history[/{file}]` |
| Supplier Risk Monitor (add-on) | risk_alerts | all | `/risk-intel` | RiskIntelPage | `/risk-intel/*` |
| Approvals & Audit | approvals | staff, admin | `/governance` | GovernancePage | `/governance/*` (audit) |
| Trust Centre | trust | staff, admin | `/trust` | TrustCentrePage | `/trust/responsible-ai`, `/trust/security` (audit) |
| AI Cost Management | finops | staff, admin | `/finops` | FinOpsPage | `GET /finops/summary` (audit; `/trust/finops` is the same data); `PUT /trust/finops/budget` (configure) |
| AI Safety Rules | safety | admin | `/guardrails` | GuardrailsPage | `GET/PUT /guardrails`, `POST /guardrails/test`, `POST /guardrails/reset` (configure) |
| Risk Prediction Models | models | admin | `/model-lab` | ModelLabPage | `/ml/*` (configure) |
| Settings | settings | admin | `/settings` | SettingsPage | `/settings` (configure) |
| (sign-in) | - | - | any route when signed out | LoginPage | `/auth/login`, `/auth/roles` |

All routes are under `/api/v1`. Only `/health`, `/auth/login` and `/auth/roles` are public.

---

## 5. How the main flows work

**Scoring:** `scoring_service.recompute_all()` loads transaction frames (`metrics.load_frames`).
For each month-end it computes KPIs over the 3-month window, scores them with `scoring.score_from_kpis`,
and writes `vendor_score_snapshots` with weights, KPIs, `model_version` and `data_version`. Changing
weights uses `reweight()`, which re-derives scores from the stored component scores in under a second.
Every rescore bumps `data_version`, and that invalidates the caches.

**Read models:** `analytics_service` reads snapshots into cached DataFrames (`snapshots_df`,
`current_table`) keyed by `data_version`. Use those helpers rather than querying snapshots yourself.

**Copilot request** (`agents/copilot.ask`):
1. Input guardrails run first (block, flag, or redact personal data).
2. The vendor is resolved from the question, by name, or from session context. Context only
   carries over for follow-ups.
3. The semantic cache is checked; it is only valid while data, policy, prompt and model versions all match.
4. The LangGraph supervisor classifies the intent with rules first (light LLM only as a fallback) and builds a plan.
5. The specialist agents call typed tools.
6. Synthesis compresses the evidence with JEV and calls the routed model through the gateway.
7. Governance verifies the answer, applies the output guardrails, persists the recommendation
   and writes the audit event.

The response contains the answer, reasoning, evidence, sources, graph data, recommendation,
confidence, governance result, agent trace and guardrail flags.

**Risk model (XGBoost binary classifier):** the "risk of decline" indicator. It never touches the
performance score.

| | |
|---|---|
| Type | **Classification**, not regression: `XGBClassifier`, objective `binary:logistic` |
| Question | "Will the next-3-month average score be ≥ 6 points below the trailing 3-month average?" (1 = yes) |
| Inputs | 16 features per vendor-month from `build_feature_frame` (`FEATURES` in `ml/risk_model.py`): score levels, 1- and 3-month changes, 3-month slope, late POs, failed inspections, lead-time CV, invoice variance |
| Output | `predict_proba` → probability 0-1 → level High ≥ 0.60, Medium ≥ 0.35 (`risk_high_threshold` / `risk_medium_threshold`, editable in Settings) |
| Explanations | SHAP `TreeExplainer` → top 4 drivers per vendor (`drivers` with `method: "shap"`) |
| Default settings | depth 2, 200 rounds, eta 0.05, min_child_weight 5, subsample/colsample 0.8, `balance_classes` 0 |
| Validation | temporal hold-out (train on earlier months, test on the latest) + rolling-origin folds; card compares with a random guess (ROC-AUC 0.5, PR-AUC = base rate) |
| Current result | ROC-AUC 0.735, PR-AUC 0.403, Brier 0.0996, lift@10% 3.7x, precision 0.75 / recall 0.13 at 0.5 |
| Credibility gate | ROC-AUC < 0.65, < 15 train / < 5 test positives or single-class labels → model not used; the statistical trend fallback is shown instead (`model_version = "statistical-fallback"`) |

Why XGBoost: fixed rules only show a decline once it has happened; the classifier learns combinations of
early signs. It was picked in a bake-off against Logistic Regression, Random Forest and scikit-learn
Gradient Boosting, where (tuned) it matched or beat all three, so the others were removed. Be honest
about it: the gain over Logistic Regression is small (0.735 vs 0.723 ROC-AUC); the bigger benefit is exact
per-vendor SHAP reasons. Why not regression: the decision is yes/no ("should I worry?"), and a probability is
easier to explain than a forecast score.

Production uses the **promoted** `ml_model_runs` row, or the defaults above. Old runs of removed algorithms
stay in `ml_model_runs` but are hidden from `/ml/runs` and ignored by `active_config`.

Final level = model level, which current signals can *raise* but never lower (`risk_service.classify`):
At Risk / Critical band, or Watch band + deteriorating → High. Example: V1024 gets 10% from the model
(its drop already happened) and is raised to High by its falling Watch score.

---

## 6. Recipes - how to change things

**Add an API endpoint:**
1. Add the route in `api/v1.py` with `Depends(authenticate)` for reads or `require("configure"|"approve"|"seed"|"copilot")` for mutations.
2. Put the request body in `schemas/requests.py`.
3. Put the logic in a `services/` module; keep routes thin.
4. Add an integration test using the `client` (admin), `staff` or `anon` fixture.

**Add a page:**
1. Create `pages/XPage.tsx` using `PageHeader`, `Card`/`CardHeader`/`CardBody` and `KpiTile`.
2. Add a hook in `hooks/queries.ts` and types in `types/`.
3. Add the route in `App.tsx` wrapped in `<Allowed menu="key">`, the menu item (with the same
   `key`) in `NAV` in `layouts/AppShell.tsx`, and the key in each role's list in `ROLE_MENUS`
   (`backend/app/security.py`).
4. Gate admin-only controls with `useAuth().can("configure")`.

**Add a KPI:** compute it in `analytics_service` (operational KPIs go in `_operational_for`, which
returns the prior-period delta automatically). Add the field to `types/api.ts` and a tile in
`DashboardPage` (`invertDelta` when lower is better).

**Change a score formula or weight default:** edit `scoring.py` and `docs/SCORING.md`, update
`test_scoring.py`, bump `SCORING_MODEL_VERSION`, then run `scripts/bootstrap.py --no-graph --no-knowledge`
to rescore. Weights can also be changed at runtime on Platform Settings.

**Change the demo data story:** `scripts/generate_data.py` (archetypes, `DEMO_VENDORS`,
`DEMO_PROFILES`). V1024 is tuned to go 86 → 64. Any RNG-affecting change reshuffles every other
vendor, so re-check the demo vendors (V1001, V1024, V1035, V1050, V1088) after
`bootstrap.py --regenerate`.

**Add an agent tool:** add a `ToolSpec` to `REGISTRY` in `tools/registry.py`, add it to the right
agent in `AGENT_TOOLS`, and return a `ToolResult`. Call it from the agent node in `agents/nodes.py`
and emit evidence items with `_ev(...)`. If the composer should use the evidence, match the evidence
title in `compose.deterministic_answer`.

**Add an intent:** add the regex in `agents/intent.classify`, a plan in `PLANS`, a template branch in
`compose.deterministic_answer`, `TASK_FOR_INTENT` in `nodes.py`, and a test in `test_ai_components.py`.

**Change the LLM prompt:** edit `SYSTEM_PROMPT` in `agents/compose.py`, then **bump
`PROMPT_VERSION` in `.env`** (it is part of the response/semantic cache key). Restart the API.

**Add a guardrail:** edit `governance/guardrails.py` (`DEFAULTS`, `INJECTION_PATTERNS`,
`PII_PATTERNS`, `check_input`, `catalogue`). Configurable fields also need adding to
`InputGuardrails`/`OutputGuardrails` in `schemas/requests.py` and to `GuardrailsPage.tsx`.

**Add an ML algorithm back:** add an `Algorithm` entry in `ml/algorithms.py` (bounded params + build
function), extend the `Candidate.algorithm` Literal in `schemas/requests.py`, and add a colour to
`ALGO_COLOR` in `ModelLabPage.tsx`.

**DB schema change:** edit `models/entities.py`, add `backend/alembic/versions/000N_*.py` (create
with `alembic revision --autogenerate --rev-id 000N -m "..."` from `backend/`), then run
`alembic upgrade head`. `create_all` is not used.

**Re-ingest knowledge or graph:** `bootstrap.py --knowledge-only` / `--graph-only`, or from the API
`POST /knowledge/ingest` / `POST /graph/ingest` (admin). Both are idempotent.

---

## 7. Testing & verification

```powershell
cd backend;  .venv\Scripts\python -m pytest -q -p no:cacheprovider          # 92 tests, ~2-4 min (needs PG + seeded data; Neo4j optional)
             .venv\Scripts\python -m pytest -q -p no:cacheprovider -m "not integration"   # unit only, fast
cd frontend; npx tsc -b --force        # typecheck (tsc --noEmit checks NOTHING here - project references)
             npx vitest run            # 15 tests, slow on this disk (~4 min)
             npm run build
```

- Integration tests log in as admin (`client` fixture). They create audit rows and `ml_model_runs`
  in the real DB; that's expected.
- Visual checks: Playwright scripts live in the session scratchpad (not in the repo) and use the
  pre-installed browser at `%LOCALAPPDATA%\ms-playwright\chromium_headless_shell-1234\...`.
  Full-page screenshots restart Recharts animations, so charts look empty; judge charts with
  viewport screenshots.
- Definition of done for any change: backend tests pass, `tsc -b --force` passes, the API has been
  restarted, and the affected page has been checked in a browser as both staff and admin when
  permissions are involved.

---

## 8. Environment gotchas (learned the hard way)

- **Bash heredocs on this machine mangle backslashes** (`\b` became a backspace character, three
  times) and fail to parse with `'''` plus apostrophes. Use the file-editing tool, or write a patch
  script to a file and run it. After any scripted edit, scan for `chr(8)`.
- Python's `open(...,'w')` on Windows writes CRLF; pass `newline="\n"` (or `newline=""` on
  read-modify-write).
- The bare `python` on PATH has no project packages. Use `backend\.venv\Scripts\python.exe`, and
  set `PYTHONPATH=.` when running scripts from outside `backend/`.
- Cold imports are slow (the first import of `openai`, `xgboost` or `shap` can take 30 s or more).
  The API pre-loads them in `main._warm_up`. Allow about 30-60 s for API startup after a restart.
- Don't name scratch files after stdlib modules (`inspect.py` once broke imports).
- pandas is 3.x (copy-on-write, `str` dtype); LangGraph and LangChain are 1.x.
- The system Postgres service needs admin rights. That's why we run our own cluster on 5433.

---

**Menu (professional names, grouped):** Overview - Executive Dashboard; Vendor Performance - Vendor Scorecards,
Vendor 360 Profile, Performance Analytics, Vendor Comparison; Sourcing & Risk - Supplier Risk Monitor, Alternative
Suppliers, Policies & Contracts; AI Assistant - Ask AIRA; Governance - Approvals & Audit, Trust Centre, AI Cost
Management; Administration - AI Safety Rules, Risk Prediction Models, Platform Settings. Labels and order live in
`NAV` (`layouts/AppShell.tsx`); page eyebrows match. No 'demo' / 'add-on' labels in the UI (the runtime flag is shown as
'Sample data mode' in Platform Settings; security self-check uses 'Pilot setting').

**Dashboard order (business-first):** Key metrics -> **Priority actions** (`components/PriorityActions.tsx`: ordered to-do list
built from the summary, the top outside event (`/risk-intel/events`) and the value baseline - spotlight vendor, escalate
Critical, improvement plans for At Risk, early action on High risk, prepare for the event, recover overcharges; owner +
link each) -> Performance over time (dropdown) + Needs attention (tabs) -> **Business value for Primark** (headline tiles,
"How each team benefits" cards for Buying, Quality, Finance, Leadership, Analysts with a measured proof point and £ value;
money breakdown, measures and assumptions behind "Show the detail") -> Vendor score explainer -> Performance by category.
Removed: one-off spotlight banner (now action 1), static tile rows, top-performers table.

**Admin editing - policy library:** `app/knowledge/editor.py`. Policies are Markdown files with front matter in
`knowledge/`. Save = validate (ID, type, date, 50-60k chars, at least one `## ` clause heading) -> copy the old file to
`knowledge/_history/<ID>/v<old>__<UTC>.md` -> bump `policy_version` (1.4 -> 1.5 unless a higher one is given) -> atomic
write -> `store.ingest()` (rolls the file back if indexing fails). The policy-version hash changes, so cached AIRA answers
on the old wording are not reused; the semantic cache is cleared too. Archive moves the file to history. Audit events:
`policy_created`, `policy_changed`, `policy_archived` (with a required change note). Only text changes what AIRA quotes;
escalation thresholds and rules live in code / Platform Settings.

**Admin editing - AI safety rules:** besides thresholds and blocked terms, admins can switch each built-in manipulation
check (`disabled_injection_rules`) and personal-data type (`disabled_pii_types`) off, and add up to 20 custom rules
(`custom_rules`: name, plain phrases matched as whole words - no regex, so no ReDoS - flag/block, user message). Labels
come from `INJECTION_LABELS` / `PII_LABELS` in `governance/guardrails.py`; `POST /guardrails/reset` restores defaults.

**AIRA (the AI assistant):** one conversation shared by the full page and the floating launcher via
`AiraProvider` / `useAira()` in `lib/aira.tsx` (mounted in `AppShell`, kept in sessionStorage
`vendor360.copilot`). The launcher (`AiraLauncher`) shows for roles with the `assistant` menu, hides on
`/copilot`, closes on Esc, and shows a dot for an unread answer. The avatar is an inline SVG (`AiraFace`,
blink/glow animations in `index.css`, disabled under reduced motion). Renaming the assistant: change
`AIRA_NAME` in `lib/aira.tsx` and the system prompt + out-of-scope text in `agents/compose.py`, then bump
`PROMPT_VERSION` (answer-cache key; now v1.5).

**AIRA ranking questions:** intent `portfolio_ranking` ("top 10 vendors", "5 worst suppliers in denim", "rank vendors by
delivery", "bottom 3 by quality in Menswear"). `intent.parse_ranking` reads count (default 10, max 25), direction, score area
and an optional category / region (matched against `filter_options`); the performance agent calls `list_vendors` (ties broken
by overall score, then vendor id) and `compose` returns a numbered list. Vendor-specific questions are never routed here.

**AI connection status:** `gateway.llm_health()` reports `live`, `key-rejected` (the provider returned 401 on the last call) or
`deterministic-fallback`; shown in `/health`, the header status pill and the AIRA panel ("Fact-based mode"). When the key is
rejected, AIRA keeps answering from facts. Fix: put a new `OPENAI_API_KEY` in `.env` and restart the API.

**AI Cost Management (FinOps) page:** `finops.summary()` returns spend, forecast, budget, savings, cost attribution
(role / person / task / model), `daily` (cost + tokens sent / received / trimmed), `efficiency` (tokens per
question, context trimmed %, cost per 1k tokens, output share of cost, cache hit rate, latency) and
`top_requests` (10 most expensive questions). Prices: `DEFAULT_PRICES` or the `LLM_PRICE_TABLE` env JSON.

**Value for Primark (dashboard):** `services/value.py`. Each lever = measured 12-month baseline (POs,
deliveries, inspections, invoices, risk snapshots) x an editable assumption (`DEFAULT_ASSUMPTIONS`,
stored in `app_settings["value"]`, bounded by `BOUNDS`). Levers follow the usual procurement savings
categories: hard saving (invoice overcharges recovered), cost avoidance (late deliveries, quality failures),
productivity (scorecard hours). Risk mitigation (open orders at High-risk vendors) is shown but **not** added
to the total. Scenarios scale the improvement assumptions x0.5 / x1 / x1.5. ROI = yearly benefit / (build
+ one year of hosting, AI usage and support); payback = build / net monthly benefit. Operational measures
are SCOR-style (on-time delivery, first-pass quality, invoice accuracy, lead-time reliability). The panel
covers the whole portfolio (dashboard filters do not apply); the baseline is memoised for 60 s.
Current demo result (expected): ~£3.1m a year, 6.8x first-year return, 1.4-month payback - all
assumption-driven and labelled indicative. To add a lever: add the assumption + bound + label, compute it
in `benefits()`, and it appears automatically.

## 9. Current state & known gaps

**Working and verified:** every screen above; OpenAI gpt-4o-mini live; Neo4j Aura (~21k nodes);
Chroma (50 chunks, local MiniLM); risk model credible (held-out AUC ~0.72); auth with two personas;
guardrails; Model Lab (XGBoost); AI Cost Management page; Value for Primark panel. **104 backend tests and 15 frontend tests passing.**

**Responsible AI and security** live on the Trust Centre page; **AI cost and tokens** on its own page (`/finops`). Every AI call is recorded in
`llm_usage` (`finops.record`, called from `copilot.ask`); the monthly budget hard stop sets
`RequestBudget.blocked_reason`; security headers come from `observability.SECURITY_HEADERS`; the security
self-check is `trust.security()` - add a row there when you add a control. Users rate answers via
`POST /copilot/feedback` (audit event `ai_feedback`).

**Known gaps / sensible next steps:**
- Copilot session memory and the rate limiter are in-process. Use Redis or the DB plus a LangGraph
  checkpointer for multi-instance deployments.
- The user directory is just the two demo personas in code (`security.users()`). The next step is
  SSO/OIDC (Entra ID) inside `authenticate`.
- XGBoost with `balance_classes = 1` gives inflated probabilities (~87 vendors over the 0.6 High
  threshold vs ~9 without), so it is off by default. Add calibration (Platt/isotonic) before turning it on.
- External events are synthetic (`data/external_events.csv`); there's no live feed.
- No CI pipeline and no Docker (the user prefers no Docker). No git repository has been initialised.
- `SettingsPage` and `GuardrailsPage` both edit agent limits (same `app_settings.agent` row). If you
  touch either, keep them consistent.

---

## 10. Conventions

- **Backend:** type hints everywhere, Pydantic v2 bodies, services hold logic, routes stay thin.
  Docstrings explain *why*. No secrets in logs (the JSON formatter masks keys containing
  key/password/secret/token).
- **Frontend:**
  - Tailwind design tokens live in `tailwind.config.ts`: `brand` = Primark blue #009FD6, `ink` = navy, `band.*` = validated band colours.
  - Band colour always comes with a text label (Watch is below 3:1 contrast).
  - Categorical chart colours: `SERIES` in `lib/utils.ts`, fixed per entity, never per rank.
  - Numbers use the `num` class (tabular figures). Money uses `fmt.gbp`, percentages `fmt.pct`.
- **Copy:** British English, professional procurement terms ("vendor" for scoring, "supplier" in
  policy text), policy clause ids (SEP-4.2, DSLA-4, PP-3.3...) cited wherever a rule applies.
- **Copy:** write for a non-technical buyer. Prefer "getting worse" over "deteriorating", "risk of
  decline" over "internal risk", "meeting contract targets" over "SLA compliance".
- **Label changes:** the menu lives only in `AppShell.tsx` `NAV`. Page titles are in each page's
  `PageHeader`. Keep README section 7 (demo script) in sync.
