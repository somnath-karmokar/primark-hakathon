---
document_id: SOG
title: Supplier Onboarding Guidelines
document_type: guideline
category: all
policy_version: "1.8"
effective_date: 2025-09-01
source: "Vendor360 policy library (illustrative - not an official Primark document)"
---
# Supplier Onboarding Guidelines

## SOG-1 Pre-qualification
New suppliers must complete an ethical trade audit, a technical capability assessment and financial due diligence before receiving a trial purchase order.

## SOG-2 Trial period
Onboarding suppliers receive up to three trial purchase orders over a 90-day period. Their Vendor Performance Score is flagged as provisional until at least three purchase orders are complete.

## SOG-3 Promotion to Active
An Onboarding supplier is promoted to Active when its provisional score is 75 or above, it passes two consecutive inspections and the ethical trade audit has no open critical findings.

## SOG-4 Data requirements
Suppliers must provide promised lead times on every confirmation, use the standard invoice template and share capacity plans quarterly.
