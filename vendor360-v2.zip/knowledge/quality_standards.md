---
document_id: QS
title: Product Quality Standards
document_type: standard
category: all
policy_version: "5.2"
effective_date: 2025-11-01
source: "Vendor360 policy library (illustrative - not an official Primark document)"
---
# Product Quality Standards

## QS-1 Inspection regime
All finished goods are subject to pre-shipment inspection under ISO 2859-1 (AQL) sampling. General inspection level II applies, with AQL 2.5 for major defects and AQL 4.0 for minor defects.

## QS-2 Defect classification
Critical defects (safety, contamination, sharp objects) result in automatic lot rejection. Major defects include stitching failures, measurement out of tolerance, colour shade variation beyond the approved band, fabric flaws and incorrect care labels. Minor defects include loose threads and minor packaging damage.

## QS-3 Quality thresholds
A supplier with a defect rate above 2.5% over a rolling three-month window, or an inspection failure rate above 15%, must submit a root-cause analysis and corrective action plan within 10 working days.

## QS-4 Repeat failures
Three failed inspections on the same product within 90 days requires a factory quality audit before further shipments are accepted for that product.

## QS-5 Children's products
Kidswear and baby products are subject to additional safety testing (small parts, cord and drawstring rules, flammability). Any critical defect on a children's product must be escalated immediately to the Head of Quality.
