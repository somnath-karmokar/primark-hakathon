---
document_id: DSLA
title: Delivery Service Level Agreement Standard
document_type: sla
category: all
policy_version: "4.0"
effective_date: 2026-02-01
source: "Vendor360 policy library (illustrative - not an official Primark document)"
---
# Delivery Service Level Agreement Standard

## DSLA-1 SLA tiers
Each supplier contract references one of three SLA tiers, aligned to supplier tier.

| SLA | Supplier tier | On-time delivery target | Max defect rate | Max invoice variance |
|---|---|---|---|---|
| SLA-STR | Strategic | 95% | 2.5% | 1.0% |
| SLA-PRE | Preferred | 92% | 2.5% | 1.0% |
| SLA-APP | Approved | 90% | 3.0% | 1.0% |

## DSLA-2 On-time definition
A purchase order is on time when the final shipment is received at the UK distribution centre on or before the promised date. Partial shipments do not count as on time until the order is complete.

## DSLA-3 Late delivery remedies
Late delivery attracts a credit of 1% of PO value for every seven days late, capped at 5%. Late delivery of a critical purchase order must be reported to the Category Manager within 24 hours.

## DSLA-4 Breach and escalation
Two consecutive months below the on-time target constitutes an SLA breach. An SLA breach triggers a corrective action request (CAR) to the supplier within five working days. Three consecutive months of breach triggers the Supplier Escalation Policy.

## DSLA-5 Lead-time commitments
Suppliers must confirm a promised lead time on every purchase order. Lead-time variability above 20% (coefficient of variation) for two consecutive months must be addressed in the supplier's capacity plan.
