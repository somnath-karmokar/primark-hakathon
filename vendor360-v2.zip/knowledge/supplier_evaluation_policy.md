---
document_id: SEV
title: Supplier Evaluation Policy
document_type: policy
category: all
policy_version: "2.4"
effective_date: 2026-01-15
source: "Vendor360 policy library (illustrative - not an official Primark document)"
---
# Supplier Evaluation Policy

## SEV-1 Vendor Performance Score (VPS)
The VPS is calculated monthly over a rolling three-month window. The default weighting is Delivery 30%, Quality 30%, Cost 20% and Lead-Time Consistency 20%. Weights may only be changed by the Procurement Excellence team and every change is recorded in the audit log.

## SEV-2 Score bands
| Band | Score | Expected action |
|---|---|---|
| Excellent | 90-100 | Eligible for volume growth and strategic partnership |
| Good | 75-89 | Business as usual |
| Watch | 60-74 | Category Manager monitors monthly; agree corrective actions |
| At Risk | 40-59 | Formal Performance Improvement Plan (PIP) within 14 days |
| Critical | 0-39 | Escalate to Head of Sourcing; stop new POs pending review |

## SEV-3.1 Delivery component
Delivery performance reflects on-time delivery against the promised date, the severity of lateness and late critical purchase orders.

## SEV-3.2 Quality component
Quality performance reflects defect rate on inspected samples, inspection pass rate against AQL 2.5 and rejection rate.

## SEV-3.3 Cost component
Cost performance reflects invoice discipline (invoice value versus PO value) and unit price competitiveness against the category benchmark.

## SEV-3.4 Lead-time consistency component
Lead-time consistency measures the predictability of lead times, using the coefficient of variation of actual versus promised lead time, together with average overrun. Two suppliers with the same average lead time can receive very different consistency scores.

## SEV-4 Deterioration
A supplier is considered deteriorating when its VPS falls by eight points or more over three months, or from its six-month peak, while the trend remains negative. Deteriorating suppliers must be discussed in the next monthly category review even if they remain in the Good band.

## SEV-5 Data sufficiency
A score based on fewer than three completed purchase orders in the window is flagged as low-confidence and must not be used on its own to justify volume changes.
