"""Vendor360 AI - Level 2 solution architecture (container view). Writes SVG; rendered to PNG separately."""
from html import escape

W, H = 2400, 1420
NAVY, BLUE, LBLUE, INK, MUTED, LINE = "#0F1D30", "#009FD6", "#E6F6FC", "#33445A", "#5F738B", "#8496AB"
out = []


def text(x, y, s, size=15, weight=400, fill=INK, anchor="start", italic=False):
    out.append(f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}"'
               f'{" font-style=\"italic\"" if italic else ""}>{escape(s)}</text>')


def box(x, y, w, h, title, lines=(), tech="", fill="#FFFFFF", stroke=BLUE, title_fill=NAVY, icon=None, dashed=False, r=14, sw=2):
    out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"'
               f'{" stroke-dasharray=\"7 5\"" if dashed else ""} filter="url(#sh)"/>')
    ty = y + 30
    if icon:
        out.append(f'<circle cx="{x + 26}" cy="{y + 25}" r="13" fill="{stroke}"/>')
        text(x + 26, y + 30, icon, 13, 700, "#FFFFFF", "middle")
        text(x + 48, ty, title, 17, 700, title_fill)
    else:
        text(x + 16, ty, title, 17, 700, title_fill)
    if tech:
        text(x + (48 if icon else 16), ty + 20, tech, 12.5, 500, BLUE)
    yy = ty + (44 if tech else 26)
    for ln in lines:
        text(x + 18, yy, "• " + ln, 13.5, 400, INK)
        yy += 19


def zone(x, y, w, h, label, sub="", fill="#F5F7FA", stroke="#C9D3DF", dashed=True):
    out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="20" fill="{fill}" stroke="{stroke}" stroke-width="1.6"'
               f'{" stroke-dasharray=\"10 6\"" if dashed else ""}/>')
    text(x + 20, y + 30, label, 15, 800, MUTED)
    if sub:
        text(x + 20, y + 50, sub, 12.5, 500, MUTED)


def arrow(pts, label=None, num=None, color=NAVY, dashed=False, lx=None, ly=None, both=False, width=2.2):
    d = "M" + " L".join(f"{x},{y}" for x, y in pts)
    out.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}" marker-end="url(#ah{color[1:]})"'
               f'{" marker-start=\"url(#as" + color[1:] + ")\"" if both else ""}{" stroke-dasharray=\"7 5\"" if dashed else ""}/>')
    if label or num:
        (x1, y1), (x2, y2) = pts[len(pts) // 2 - 1], pts[len(pts) // 2]
        cx, cy = (lx if lx is not None else (x1 + x2) / 2), (ly if ly is not None else (y1 + y2) / 2)
        wlab = (len(label) * 6.9 if label else 0) + (30 if num else 0) + 16
        out.append(f'<rect x="{cx - wlab / 2}" y="{cy - 13}" width="{wlab}" height="24" rx="12" fill="#FFFFFF" stroke="{color}" stroke-width="1.2"/>')
        tx = cx - wlab / 2 + 10
        if num:
            out.append(f'<circle cx="{tx + 9}" cy="{cy - 1}" r="10" fill="{color}"/>')
            text(tx + 9, cy + 4, str(num), 12, 800, "#FFFFFF", "middle")
            tx += 26
        if label:
            text(tx, cy + 4, label, 12.5, 600, color)


def person(cx, cy, label, sub):
    out.append(f'<circle cx="{cx}" cy="{cy - 30}" r="17" fill="{NAVY}"/>')
    out.append(f'<path d="M{cx - 30},{cy + 18} Q{cx - 30},{cy - 8} {cx},{cy - 8} Q{cx + 30},{cy - 8} {cx + 30},{cy + 18} Z" fill="{NAVY}"/>')
    text(cx, cy + 40, label, 14.5, 700, NAVY, "middle")
    text(cx, cy + 58, sub, 12, 500, MUTED, "middle")


def cylinder(x, y, w, h, title, tech, lines, color=NAVY):
    ry = 14
    out.append(f'<path d="M{x},{y + ry} L{x},{y + h - ry} A{w / 2},{ry} 0 0 0 {x + w},{y + h - ry} L{x + w},{y + ry}" fill="#FFFFFF" stroke="{color}" stroke-width="2" filter="url(#sh)"/>')
    out.append(f'<ellipse cx="{x + w / 2}" cy="{y + ry}" rx="{w / 2}" ry="{ry}" fill="{LBLUE}" stroke="{color}" stroke-width="2"/>')
    text(x + w / 2, y + ry + 34, title, 16.5, 700, NAVY, "middle")
    text(x + w / 2, y + ry + 53, tech, 12.5, 600, BLUE, "middle")
    yy = y + ry + 76
    for ln in lines:
        text(x + w / 2, yy, ln, 12.8, 400, INK, "middle")
        yy += 18


# ------------------------------------------------------------------ canvas
out.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="Inter, Segoe UI, Arial, sans-serif">')
out.append("<defs>")
for c in (NAVY, BLUE, "#1F8A4C", "#DD5A24", LINE, "#7C3AED"):
    out.append(f'<marker id="ah{c[1:]}" markerWidth="12" markerHeight="12" refX="10" refY="6" orient="auto"><path d="M0,0 L12,6 L0,12 z" fill="{c}"/></marker>')
    out.append(f'<marker id="as{c[1:]}" markerWidth="12" markerHeight="12" refX="2" refY="6" orient="auto"><path d="M12,0 L0,6 L12,12 z" fill="{c}"/></marker>')
out.append('<filter id="sh" x="-5%" y="-5%" width="110%" height="120%"><feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#0F1D30" flood-opacity="0.10"/></filter>')
out.append("</defs>")
out.append(f'<rect width="{W}" height="{H}" fill="#FFFFFF"/>')

# ------------------------------------------------------------------ header
out.append(f'<rect x="0" y="0" width="{W}" height="92" fill="{NAVY}"/>')
out.append(f'<rect x="0" y="92" width="{W}" height="6" fill="{BLUE}"/>')
text(40, 52, "Vendor360 AI  -  Level 2 Solution Architecture", 32, 800, "#FFFFFF")
text(40, 78, "Supplier performance scoring, risk prediction and the AIRA AI assistant for Primark buying teams  ·  container view", 15, 500, "#9FD9F0")
text(W - 40, 52, "Primark  ·  TCS", 20, 700, "#FFFFFF", "end")
text(W - 40, 78, "v1.0  ·  Oct 2026", 14, 500, "#9FD9F0", "end")

# ------------------------------------------------------------------ actors (left)
zone(30, 130, 250, 560, "USERS", "Role-based access", fill="#FFFFFF")
person(155, 235, "Business user", "Head of Buying")
person(155, 395, "Staff", "Sourcing Analyst")
person(155, 555, "Admin", "Procurement Admin")

zone(30, 720, 250, 550, "SOURCE SYSTEMS", "Enterprise data feeds", fill="#FFFFFF")
for i, (t, s) in enumerate([("ERP", "Purchase orders, deliveries"), ("QMS", "Quality inspections"), ("Accounts payable", "Invoices"),
                             ("Contract system", "SLAs, terms, tiers"), ("Supplier master", "Vendors, products")]):
    box(50, 790 + i * 94, 210, 82, t, [s], fill="#FFFFFF", stroke=LINE, title_fill=INK, r=10, sw=1.5)

# ------------------------------------------------------------------ platform boundary
zone(320, 130, 1690, 1140, "VENDOR360 AI PLATFORM",
     "Pilot: local containers  ·  Target: Azure UK South (Container Apps, Front Door + WAF, Entra ID, Key Vault, private endpoints)",
     fill="#FBFDFF", stroke=BLUE)

# row A: experience + API + AIRA
box(360, 190, 470, 220, "Web application (SPA)", [
    "Executive dashboard · priority actions · value",
    "Vendor scorecards · Vendor 360 · comparison",
    "Supplier risk monitor · alternative suppliers",
    "Policies & contracts library (admin editing)",
    "AIRA floating assistant + full chat with evidence",
    "Admin: AI safety rules, models, AI cost, settings",
], tech="React 18 · TypeScript · Vite · Tailwind · Recharts", icon="W")
box(900, 190, 520, 220, "Vendor360 API", [
    "REST /api/v1 · OpenAPI · Pydantic validation",
    "Sign-in, signed session tokens, role-based menus",
    "RBAC: business / staff / admin permissions",
    "Rate limiting · security headers · CORS",
    "Request IDs · structured logs · health checks",
    "Analytics cache keyed by data version",
], tech="Python 3.12 · FastAPI · Uvicorn · SQLAlchemy 2", icon="A")
box(1490, 190, 480, 250, "AIRA agent orchestrator", [
    "Supervisor: intent (rules first, LLM fallback)",
    "Performance agent: scores, KPIs, rankings",
    "Risk agent: ML risk, anomalies, trends",
    "Knowledge agent: policy RAG + supplier graph",
    "Recommendation agent: escalation rules",
    "Synthesiser: grounded answer from evidence",
    "Tool allow-list · step / tool / token limits",
], tech="LangGraph · LangChain · typed state · tool registry", icon="AI", stroke="#7C3AED")

# row B: domain services
SB = 500
box(360, SB, 250, 185, "Scoring & analytics", [
    "Deterministic score 0-100", "Delivery 30 · Quality 30", "Cost 20 · Lead time 20", "Bands, trends, rankings", "Monthly 3-month snapshots",
], tech="pandas · pure functions", icon="S", stroke="#1F8A4C")
box(625, SB, 250, 185, "Risk prediction & ML", [
    "XGBoost risk of decline", "IsolationForest anomalies", "SHAP explanations", "0.65 AUC credibility gate", "Model Lab: train, promote",
], tech="XGBoost · scikit-learn · SHAP", icon="ML", stroke="#DD5A24")
box(890, SB, 250, 185, "Value & alternatives", [
    "Yearly benefit, ROI, payback", "Backup supplier ranking", "Fit, overlap, risk, policy", "Policy editor + versions", "Priority actions",
], tech="Domain services", icon="V", stroke="#1F8A4C")
box(1155, SB, 250, 185, "Supplier risk intelligence", [
    "Outside events: port, weather", "Event → port → vendor", "→ order → product", "Exposure, key orders at risk", "Early-warning signals",
], tech="Graph traversal · rules", icon="R", stroke="#DD5A24")

# right column under AIRA
box(1490, 490, 480, 145, "LLM gateway & FinOps", [
    "Model routing · timeouts · budget hard stop",
    "JEV context compression · exact + semantic cache",
    "Token and cost metering per user, role, task",
], tech="LangChain OpenAI client · cost ledger", icon="$", stroke="#7C3AED")
box(1490, 675, 480, 165, "AI safety & governance", [
    "Input: injection, personal data, blocked terms, custom rules",
    "Output: every figure and citation checked",
    "Ranking protection · confidence threshold",
    "Human approval queue · audit trail",
], tech="Guardrails engine · audit events", icon="G", stroke="#A8223D")

# data platform
zone(690, 905, 1300, 345, "DATA PLATFORM", "", fill="#F5F7FA", stroke="#C9D3DF", dashed=False)
CY, CH = 950, 240
cylinder(715, CY, 330, CH, "Operational database", "PostgreSQL 17", ["Vendors, POs, deliveries,", "inspections, invoices, contracts,", "score & risk snapshots,", "audit log, approvals, AI usage"])
cylinder(1065, CY, 270, CH, "Supplier graph", "Neo4j AuraDB", ["Vendor · product · category,", "SLA tier, region, port,", "alternatives, dependency,", "event impact paths"])
cylinder(1355, CY, 270, CH, "Policy vector index", "ChromaDB · MiniLM (ONNX)", ["Policies, SLAs, standards,", "contract clauses + metadata,", "policy-version hash"])
cylinder(1645, CY, 155, CH, "Model store", "Files / Blob", ["XGBoost model,", "model card,", "run history"])
cylinder(1815, CY, 155, CH, "Policy library", "Markdown", ["Versioned", "documents +", "history"])

# pipeline (next to the sources)
box(360, 960, 300, 290, "Ingestion & scoring pipeline", [
    "Load & validate extracts",
    "Score every vendor-month",
    "Write score snapshots",
    "Retrain & validate model",
    "Sync supplier graph",
    "Re-index policies",
    "Bump data / policy version",
], tech="Batch: bootstrap + monthly · Alembic", icon="P", stroke=LINE)

# ------------------------------------------------------------------ external services (right)
zone(2050, 130, 320, 1140, "EXTERNAL SERVICES", "Outside the platform", fill="#FFFFFF")
box(2075, 190, 270, 165, "Identity provider", ["Entra ID single sign-on", "MFA, joiner / leaver", "Pilot: built-in sign-in"], tech="OIDC · target state", icon="ID", stroke=LINE, dashed=True)
box(2075, 490, 270, 145, "OpenAI / Azure OpenAI", ["gpt-4o-mini (light & strong)", "Writes from supplied facts"], tech="HTTPS · key in Key Vault", icon="O", stroke="#7C3AED")
box(2075, 675, 270, 145, "External event feeds", ["Port, weather, geopolitical,", "regulatory (pilot: sample)"], tech="Scheduled import", icon="E", stroke="#DD5A24", dashed=True)
box(2075, 905, 270, 175, "Operations & security", ["Azure Monitor / App Insights", "Key Vault · Defender · Sentinel", "CI/CD + dependency scanning"], tech="Target platform services", icon="⚙", stroke=LINE, dashed=True)

# ------------------------------------------------------------------ flows
arrow([(232, 300), (358, 300)], "HTTPS", 1, BLUE, lx=295, ly=278)
arrow([(830, 300), (898, 300)], None, 2, BLUE, lx=864, ly=300)
text(864, 335, "REST", 12, 600, BLUE, "middle")
text(864, 351, "+ token", 12, 500, MUTED, "middle")
arrow([(1420, 300), (1488, 300)], None, 3, "#7C3AED", lx=1454, ly=300)
text(1454, 335, "ask AIRA", 12, 600, "#7C3AED", "middle")
# 4: API -> domain services (trunk)
arrow([(1160, 410), (1160, 455), (485, 455), (485, 498)], "queries", 4, NAVY, lx=820, ly=455)
out.append(f'<path d="M1160,455 L1280,455" fill="none" stroke="{NAVY}" stroke-width="2.2"/>')
for x in (750, 1015, 1280):
    arrow([(x, 455), (x, 498)], color=NAVY)
# 5: AIRA -> gateway, 6: gateway -> OpenAI
arrow([(1730, 440), (1730, 488)], None, 5, "#7C3AED", lx=1730, ly=464)
arrow([(1970, 562), (2073, 562)], None, 6, "#7C3AED", lx=2021, ly=562)
text(2021, 600, "facts only", 11.5, 600, "#7C3AED", "middle")
# AIRA -> governance (answer checks)
arrow([(1940, 440), (1940, 465), (1988, 465), (1988, 700), (1972, 700)], "checks", None, "#A8223D", lx=1988, ly=655)
# 7: AIRA tools -> data
arrow([(1490, 425), (1450, 425), (1450, 903)], "tools", 7, "#7C3AED", lx=1450, ly=780)
# 8: services read / write
arrow([(485, 685), (485, 930), (688, 930)], color=NAVY)
for x in (750, 1015, 1250):
    arrow([(x, 685), (x, 903)], color=NAVY)
out.append(f'<rect x="700" y="755" width="160" height="26" rx="13" fill="#FFFFFF" stroke="{NAVY}" stroke-width="1.2"/>')
out.append(f'<circle cx="719" cy="767" r="10" fill="{NAVY}"/>')
text(719, 772, "8", 12, 800, "#FFFFFF", "middle")
text(736, 772, "read / write (SQL)", 12.5, 600, NAVY)
# 9: governance -> audit log
arrow([(1640, 840), (1640, 903)], "audit", 9, "#A8223D", lx=1640, ly=860)
# 10: sources -> pipeline, 11: pipeline -> data platform
arrow([(280, 1100), (358, 1100)], None, 10, LINE, lx=318, ly=1100)
text(318, 1135, "extracts", 12, 600, MUTED, "middle")
arrow([(660, 1100), (713, 1100)], None, 11, LINE, dashed=True, lx=686, ly=1080)
# 12: event feed -> risk intelligence
arrow([(2075, 748), (2030, 748), (2030, 888), (1310, 888), (1310, 687)], "events", 12, "#DD5A24", dashed=True, lx=1830, ly=888)

# ------------------------------------------------------------------ legend + key flows
lx, ly = 30, 1295
out.append(f'<rect x="{lx}" y="{ly}" width="{W - 60}" height="110" rx="14" fill="#F5F7FA" stroke="#C9D3DF"/>')
text(lx + 20, ly + 30, "KEY FLOWS", 13, 800, MUTED)
flows = ["1-2  Users sign in; every API call carries a signed token checked against their role",
         "3, 5-7  AIRA plans, calls allowed tools (SQL, graph, policy search); the LLM writes from those facts only",
         "4, 8  Scores, rankings and risk come from fixed rules and the XGBoost model - never from the LLM",
         "9  Every answer is checked; approvals, answers and changes go to the audit log",
         "10-11  Monthly pipeline loads source data, re-scores vendors, retrains the model, refreshes graph and index",
         "12  Outside events are mapped to vendors, orders and products for early warning"]
for i, f in enumerate(flows):
    text(lx + 20 + (i % 3) * 775, ly + 58 + (i // 3) * 26, f, 13, 500, INK)
text(W - 50, ly + 30, "Solid = runtime call   ·   Dashed = batch / target state   ·   Purple = AI path   ·   Red = governance   ·   Orange = risk", 12.5, 600, MUTED, "end")
out.append("</svg>")

import pathlib, sys
dest = pathlib.Path(sys.argv[1])
dest.write_text("\n".join(out), encoding="utf-8")
print("wrote", dest)
