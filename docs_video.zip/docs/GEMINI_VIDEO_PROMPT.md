# Gemini prompt: Vendor360 AI cartoon explainer video (under 3 minutes)

Paste the **Master prompt** into Gemini (Google Vids, or the Gemini app with Veo). If your tool makes short clips
(for example 8-second Veo clips), use the **Shot list** at the end: generate each shot, then add the narration as one
voice-over track so the voice stays the same throughout.

---

## Master prompt

Create a **2 minute 50 second animated explainer video** (hard limit: 3:00) in a friendly, premium **3D cartoon style**,
with a **clear British English voice-over**, background music and on-screen captions. The video presents
**Vendor360 AI**, a supplier-performance platform built for **Primark's** buying team, and its AI assistant **AIRA**.
Follow the style guide, characters, script and timings below exactly. Speak the narration word for word.

### Audience and goal
- Audience: retail business leaders and a hackathon judging panel. They are not technical.
- Goal: in under 3 minutes, show the problem, how Vendor360 AI solves it, and the business benefit.
- Tone: confident, warm, clear, a little playful. No jargon.

### Visual style
- Flat 2D cartoon with soft shadows and rounded shapes. Clean, modern, corporate-friendly, like a premium SaaS explainer.
- Colour palette: Primark blue `#009FD6`, deep navy `#0F1D30`, white `#FFFFFF`, light grey `#F5F7FA`.
  Status colours: green `#1F8A4C` (good), amber `#EAA400` (watch), orange `#DD5A24` (at risk), red `#A8223D` (critical).
- Typography on screen: bold rounded sans-serif (like Manrope or Inter). Large, short labels, no more than 6 words each.
- Screens shown in the video are **simplified cartoon versions** of a web dashboard (tiles, a line chart, a list, a chat
  window), not real screenshots.
- Camera: gentle push-ins, smooth slides between scenes, light motion graphics (numbers counting up, bars growing).
- 16:9, 1080p, 24-30 fps.

### Characters (keep consistent in every scene)
- **Alex**: Head of Buying at Primark. Early 40s, friendly, smart-casual navy blazer, lanyard, short dark hair, holds a
  tablet. Expressive but professional.
- **AIRA**: the AI assistant. A small, cute floating robot: round white head, navy visor with two glowing cyan eyes,
  a short antenna with a glowing cyan tip, sitting in a blue circular glow. Blinks and nods when it "speaks". AIRA never
  speaks in the narration voice. It is shown answering in a chat bubble.
- **Background team** (optional extras): a Finance colleague, a Quality inspector in a hi-vis vest, a Supply planner.
  Diverse and friendly.

### Voice-over
- One narrator for the whole video: **clear, warm British English, mid-pace (about 130 words a minute)**, friendly and
  confident, perfectly intelligible. No accents that reduce clarity, no robotic tone.
- Short pause (about 0.5 s) between scenes. Numbers spoken naturally ("eighty-two", "three point one million pounds").
- Captions: burn in subtitles that match the narration exactly, white text on a semi-transparent navy bar.

### Music and sound
- Light, upbeat corporate background music at low volume (about -20 dB under the voice), with a soft lift at the end.
- Subtle sound effects only: soft "pop" when tiles appear, gentle "whoosh" on transitions, a friendly chime when AIRA
  answers. Never louder than the voice.

### Accuracy rules
- Use only the figures in the script. Do not invent numbers, company names or claims.
- Show the end-card note: "Figures from illustrative sample data."
- Do not show a real Primark logo unless the team has permission. Otherwise show the wordmark "Vendor360 AI" in
  Primark blue.

### Script and timing (narration word for word)

| # | Time | Scene (what we see) | Narration | On-screen text |
|---|---|---|---|---|
| 1 | 0:00-0:12 | A bright cartoon Primark store aisle. One shelf is empty. Camera pulls back to a world map with 500 tiny supplier pins pulsing. | "Primark works with five hundred suppliers. When one starts to slip, the first sign is often an empty shelf." | **500 suppliers** |
| 2 | 0:12-0:26 | Alex at a desk buried under paper and spreadsheets. Icons pop up: a delayed truck, a faulty T-shirt with a red cross, an invoice with a red "£" mismatch. Alex looks worried. | "Late deliveries, faulty batches and invoices that don't match the order hide in spreadsheets until it's too late to act." | **Found too late** |
| 3 | 0:26-0:38 | The paper swirls away. A clean laptop opens showing "Vendor360 AI". AIRA pops out of the screen and waves. Alex smiles. | "Vendor360 AI changes that. It scores every supplier, every month, and comes with AIRA, an AI assistant that explains the numbers." | **Vendor360 AI** · **Meet AIRA** |
| 4 | 0:38-0:58 | A big score gauge fills to 82. Four coloured blocks slide in and stack into it: Delivery 30%, Quality 30%, Cost 20%, Lead time 20%. Then a colour bar from red to green with labels Critical, At Risk, Watch, Good, Excellent. A stamp reads "Same rules for every supplier". | "The score is out of one hundred, built from four areas: delivery, quality, cost and lead time. The same published rules apply to every supplier, and the score is never set by AI. Ninety and above is Excellent. Below forty is Critical." | **Delivery 30% · Quality 30% · Cost 20% · Lead time 20%** · **Never set by AI** |
| 5 | 0:58-1:18 | A cartoon dashboard builds tile by tile: "Average score 82.1", "Need urgent action 36", "Getting worse 69", "Spend at risk 19.1%". A checklist titled "Priority actions" slides in with ticks being added. Alex taps the first item. | "The dashboard shows what matters first. Today the average score is eighty-two, thirty-six suppliers need urgent action, and a priority list tells each team exactly what to do this month." | **Priority actions** |
| 6 | 1:18-1:42 | Zoom into a supplier card "Ningbo Bluewave Denim". A line chart drops from 84 to 64 and turns amber. A small brain icon with a warning bell lights up: "Early warning". Three reason chips appear: "Late deliveries", "Unreliable lead times", "Over-billing". | "Take Ningbo Bluewave Denim. Its score has fallen from eighty-four to sixty-four. A machine-learning model flagged the risk early, and the profile shows exactly why: late deliveries and unreliable lead times." | **84 → 64** · **Early warning** |
| 7 | 1:42-2:06 | Alex types into a chat window: "Why is this supplier underperforming?" AIRA blinks, a chime plays, and a chat bubble appears with short bullet points and small citation tags [P1] [P2]. A card "Recommended action: corrective action plan" appears with a padlock and "Manager approval needed". A green card slides in: "Best backup supplier: Kandy Heritage Knitwear, score 91.5". | "Ask AIRA, 'Why is this supplier underperforming?' In seconds it answers in plain English, shows the facts behind every point, and recommends a corrective action plan, which a manager must approve. It even names the best backup supplier." | **Ask AIRA** · **Facts behind every answer** · **People approve actions** |
| 8 | 2:06-2:20 | A world map zooms to a busy cartoon port in Chittagong with stacked containers and a "Delay" sign. Lines connect the port to many supplier pins and then to boxes heading for UK stores. A counter reads "128 suppliers". The Supply planner reroutes a ship icon. | "Vendor360 also watches the outside world. A port delay in Chittagong could affect a hundred and twenty-eight suppliers, so planners can act before orders arrive late." | **Outside-event alerts** · **128 suppliers** |
| 9 | 2:20-2:36 | A shield appears around AIRA. Three ticks animate: "Every answer checked against the facts", "Personal data removed", "Every decision logged". A tiny coin labelled "under 1p per answer" drops into a piggy bank. | "Every AI answer is checked against the facts, personal data is removed before the AI sees it, and every decision is logged. Each answer costs a fraction of a penny." | **Checked · Private · Audited** |
| 10 | 2:36-2:54 | The team gathers around Alex: Finance, Quality, Supply. Three big numbers count up: "£3.1m a year", "6.8× return", "Pays back in 1.4 months". Small team badges pop: Buying, Quality, Finance, Leadership. Confetti in brand colours. | "The result: an estimated three point one million pounds a year in savings and avoided costs, a six point eight times return, and payback in under two months." | **£3.1m a year** · **6.8× return** · **1.4-month payback** |
| 11 | 2:54-3:00 | End card on navy: "Vendor360 AI" wordmark in Primark blue with AIRA waving beside it. Small grey note at the bottom. | "Vendor360 AI. Know every supplier. Act before it hurts." | **Vendor360 AI** · *Know every supplier. Act before it hurts.* · small: *Figures from illustrative sample data* |

Total narration: about 315 words, roughly 2 minutes 30 seconds of speech plus pauses and music. **Final length must
be between 2:45 and 3:00.** If it runs long, shorten the scene transitions and keep the narration unchanged.

### Quality checklist (check before finishing)
- [ ] Total length is 3:00 or less.
- [ ] One consistent narrator voice, clear British English, every word intelligible.
- [ ] Captions match the narration exactly.
- [ ] Alex and AIRA look the same in every scene.
- [ ] Only the figures in the script appear: 500, 82 / 82.1, 36, 69, 19.1%, 84 → 64, 91.5, 128, £3.1m, 6.8×, 1.4 months.
- [ ] End card shows "Figures from illustrative sample data".
- [ ] Music never drowns out the voice.

---

## Shot list (for tools that create short clips, e.g. 8-second Veo clips)

Generate each shot **without speech** (music and sound effects off or very low), then add the full narration above as
one voice-over track in your editor or in Google Vids, so the voice is consistent. Start every shot prompt with this
style line:

> *Flat 2D cartoon explainer style, soft shadows, rounded shapes, colour palette Primark blue #009FD6, navy #0F1D30,
> white and light grey, clean premium corporate look, 16:9, smooth gentle camera motion, no on-screen speech.*

| Shot | Length | Prompt (after the style line) |
|---|---|---|
| 1a | 6 s | A bright cartoon fashion store aisle with neat clothing shelves; one shelf is empty with a small "Out of stock" tag; slow push-in on the empty shelf. |
| 1b | 6 s | Camera pulls back from the store to a stylised world map with 500 small glowing blue supplier pins pulsing across Asia, Europe and Africa; a label "500 suppliers" fades in. |
| 2a | 7 s | A friendly woman in her early 40s (Alex, Head of Buying, navy blazer, lanyard, short dark hair) at a desk buried in paper and spreadsheets, looking worried. |
| 2b | 7 s | Three icons pop up around Alex one after another: a delivery truck with a clock, a T-shirt with a red cross, an invoice with a red pound-sign mismatch; label "Found too late". |
| 3a | 6 s | Papers swirl away; a clean laptop opens on Alex's desk showing the words "Vendor360 AI" in blue; Alex smiles with relief. |
| 3b | 6 s | A cute small floating robot (AIRA: round white head, navy visor, two glowing cyan eyes, short antenna with glowing cyan tip, blue circular glow) pops out of the laptop screen and waves; label "Meet AIRA". |
| 4a | 7 s | A large circular score gauge fills smoothly to 82; four coloured blocks labelled Delivery 30%, Quality 30%, Cost 20%, Lead time 20% slide in and stack into the gauge. |
| 4b | 7 s | A horizontal colour bar from red to green with five labels: Critical, At Risk, Watch, Good, Excellent; a rubber stamp lands: "Same rules for every supplier - never set by AI". |
| 4c | 6 s | The gauge needle settles in the green "Good" zone; subtle sparkle. |
| 5a | 7 s | A simplified cartoon web dashboard builds tile by tile: "Average score 82.1", "Need urgent action 36", "Getting worse 69", "Spend at risk 19.1%". |
| 5b | 7 s | A checklist card titled "Priority actions" slides in; three items get green ticks one by one. |
| 5c | 6 s | Alex taps the first checklist item on her tablet; the screen zooms in. |
| 6a | 8 s | A supplier card titled "Ningbo Bluewave Denim" with a line chart that drops from 84 to 64, the line turning amber; labels "84" and "64". |
| 6b | 8 s | A small brain icon with a ringing bell lights up with the label "Early warning"; three chips appear: "Late deliveries", "Unreliable lead times", "Over-billing". |
| 6c | 7 s | Alex nods thoughtfully looking at the supplier card on her tablet. |
| 7a | 8 s | Alex types into a chat window; the typed question reads "Why is this supplier underperforming?"; AIRA (the cute robot) blinks attentively. |
| 7b | 8 s | AIRA nods; a chat bubble appears with three short bullet points and small tags [P1] [P2]; a card "Recommended action: corrective action plan" with a padlock and "Manager approval needed". |
| 7c | 8 s | A green card slides in: "Best backup supplier: Kandy Heritage Knitwear - score 91.5"; Alex gives a thumbs-up. |
| 8a | 7 s | A world map zooms to a busy cartoon container port labelled "Chittagong" with a big "Delay" sign and stacked containers. |
| 8b | 7 s | Glowing lines connect the port to many supplier pins, then to boxes heading towards UK stores; a counter reads "128 suppliers"; a planner reroutes a ship icon. |
| 9a | 8 s | A protective blue shield forms around AIRA; three ticks animate: "Checked against the facts", "Personal data removed", "Every decision logged". |
| 9b | 6 s | A tiny coin labelled "under 1p per answer" drops into a piggy bank with a sparkle. |
| 10a | 8 s | Alex and three colleagues (Finance, Quality inspector in hi-vis vest, Supply planner) gather happily; big numbers count up: "£3.1m a year", "6.8× return". |
| 10b | 8 s | A third number counts up "Pays back in 1.4 months"; team badges pop: Buying, Quality, Finance, Leadership; brand-colour confetti. |
| 11 | 6 s | End card on deep navy: the wordmark "Vendor360 AI" in blue, the cute robot AIRA waving beside it, tagline "Know every supplier. Act before it hurts.", small grey text "Figures from illustrative sample data". |

Shot total: 2 minutes 55 seconds. Trim shots 4c, 5c or 6c first if the cut runs over 3:00.
