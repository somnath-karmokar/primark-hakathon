# Vendor360 AI - Speaker Notes

Script for presenting [Vendor360_AI_Showcase.html](Vendor360_AI_Showcase.html) to the Primark CIO.

- **Total time:** about 9-10 minutes, plus questions.
- **Format:** each slide gives a target time, the words to say, the point to land, and likely questions.
- **Delivery:** speak to the CIO, not the screen. **Bold** marks the words to stress. `[pause]` means stop for a second and let the point land.

---

## Slide 1 - Vendor360 AI (cover) · ~45 s

**Say:**

> Thank you for the time today.
>
> Primark works with hundreds of suppliers. When one of them starts to slip - late shipments, faulty batches, invoices that don't match - we usually find out **after** it has already hit the shelf or the margin.
>
> Vendor360 AI changes that. It lets us **see supplier problems before they reach the shelf.** `[pause]`
>
> It does four things - you can see them here: it **scores** every supplier on fixed rules, **predicts** who is likely to decline, **explains** why in plain English, and helps the team **act**, with a human always approving.
>
> The picture on the right is the idea in one image: every supplier signal - delivery, quality, cost and lead time - flowing into one place, with AIRA, our AI assistant, at the centre.

**Land this:** one platform that turns supplier data into early warnings and clear actions.

---

## Slide 2 - Why Vendor360 · ~1 min 30 s

**Say:**

> Let's start with the problem. On the left are four things every buying team will recognise.
>
> - **Late deliveries** - in our sample data, about 12% of shipments arrive late.
> - **Faulty batches** - goods rejected at inspection.
> - **Overcharges** - invoices above the agreed order price, which get paid anyway.
> - And most importantly, these issues are **found too late** - manual scorecards, quarterly reviews.
>
> `[pause]` The information exists - it's just scattered across spreadsheets and systems.
>
> On the right is how Vendor360 responds, in four steps.
>
> 1. **Score.** Every supplier gets a 0-to-100 score every month, from orders, inspections and invoices. Delivery and quality count most. The rules are the same for every supplier, and **the score is never set by AI** - that matters for fairness and for supplier conversations.
> 2. **Predict.** A machine-learning model looks three months ahead and flags who is likely to decline, and shows the reasons.
> 3. **Ask.** AIRA answers questions in plain English, and every figure is cited back to the data.
> 4. **Act.** Each team gets a priority to-do list, alerts on outside events like port delays or weather, and a live view of the money saved.

**Land this:** the data is already there; Vendor360 turns it into early, trusted action.

**If asked "Are these real Primark numbers?"**
> No - the figures come from realistic sample data. The pilot would run on Primark's own ERP, quality and accounts payable feeds.

---

## Slide 3 - Solution architecture · ~2 min

**Say:**

> This is how it fits together. Follow the numbers.
>
> - **Top row** - the journey of a question. A buyer, analyst or admin (**1**) uses the web app (**2**), goes through a secure API with sign-in and role-based access (**3**), and reaches AIRA (**4**). AIRA is a team of AI agents: a supervisor plans the work, and specialists for performance, risk, policies and recommendations gather the facts.
> - **Middle row** - the decision engine. This is the deterministic heart of the platform: the vendor score, the machine-learning early warning, risk intelligence and business value. AIRA reads its facts from here (**5**) - **it does not invent them.**
> - **The LLM gateway** (**6, 7**) is where we control cost and quality. It picks the right-sized model, compresses the evidence so we use about 44% fewer tokens, reuses answers to repeat questions, and meters every penny.
> - **Trust and control** (**8, 9**) - every answer is checked: guardrails remove personal data and block manipulation, every figure and citation is verified, supplier actions need human approval, and everything is audited.
> - **Left and bottom** - the data. Sources like ERP, quality, accounts payable and contracts are refreshed monthly into four stores: a relational database for transactions, a graph for supplier relationships, a search index for policies and contracts, and a versioned library of models and policies.
>
> `[pause]` One important detail - the green **A**. The dashboards read the decision engine directly, with **no LLM involved.** So the core numbers are fast and fully reproducible, and if the AI service is ever unavailable, the platform still works.

**Land this:** the AI explains; rules and data decide. That makes it safe to put in front of the business.

**If asked "Where would it run?"**
> The pilot runs on containers. The target is Azure UK South with Entra ID single sign-on, private networking and Azure OpenAI, so data stays in Primark's tenancy.

**If asked "Are we locked in to OpenAI?"**
> No. The model sits behind our own gateway, so it can be swapped - for example to Azure OpenAI - without changing the application.

---

## Slide 4 - Inside AIRA · ~1 min 30 s

**Say:**

> Here's what happens in the few seconds after someone asks AIRA a question - for example, *"Why is vendor V1024 underperforming?"*
>
> 1. **Safety check** - manipulation attempts are blocked and personal data is removed before anything else sees the question.
> 2. **Understand and plan** - fast rules work out what the user wants; a small AI model is only used if the rules are unsure.
> 3. **Gather facts** - each agent can only use the tools it's allowed, with a hard limit on calls.
> 4. **Decide by rules** - the recommended action comes from Primark's supplier escalation policy, **not from the AI.**
> 5. **Pack the evidence** - facts are compressed into a short, numbered list so the AI reads less and costs less.
> 6. **Reuse or route** - if someone asked nearly the same question recently, we reuse the answer at zero cost.
> 7. **Write the answer** - the AI writes plain English in a fixed format and cites the evidence behind every claim.
> 8. **Verify and record** - every number is checked against the facts. If anything doesn't match, the AI draft is replaced with a fact-based answer. Everything is logged, including the cost.
>
> `[pause]` The result: an answer with cited facts, policy quotes and a recommended action - for well under a penny.

**Land this:** every step has a control; the AI is never unchecked.

---

## Slide 5 - Advanced LLM techniques · ~1 min 30 s

Don't read all twelve cards. Pick three or four based on the room.

**Say:**

> This slide is for the technical audience - the modern AI techniques behind the platform. The theme is in the title: **smart where it helps, strict where it matters.** I'll highlight a few.
>
> - **Multi-agent orchestration** - specialist agents, coordinated by a supervisor, with step and time limits.
> - **Hybrid RAG and GraphRAG** - policy answers come from searching our own documents by meaning and by exact clause number, and supplier relationships come from a knowledge graph - not from guesswork.
> - **Context compression and semantic caching** - this is our FinOps story: about 44% fewer tokens and zero cost for repeat questions.
> - **Grounding and self-verification** - the AI's numbers and citations are checked automatically; failures fall back to facts.
> - **Human in the loop** - anything that affects a supplier waits for a named approver.
>
> `[pause]` In short: rules and machine learning make the decisions, the LLM explains them, and people approve them.

**Land this:** this is current, enterprise-grade practice, with cost and risk controls built in, not bolted on.

**If asked "How do you stop hallucinations?"**
> Three layers. AIRA only sees verified facts. It must cite them. And every number it writes is checked against those facts before the user sees it.

---

## Slide 6 - What it delivers · ~1 min 30 s

**Say:**

> Finally, what it delivers.
>
> **Business value.** On our sample data, the model estimates about **£3.1 million a year** in benefit: mostly overcharges recovered, fewer late deliveries and fewer quality failures. That is a **6.8 times return** in year one, with a **payback of under two months**, and around 4,200 analyst hours freed for higher-value work.
>
> **Trust by design.** Scores are never set by AI. Every figure is checked. Personal data is removed. Supplier actions need approval. And there is a full audit trail.
>
> **Proof points.** Along the bottom: the early-warning model has been tested on months it had never seen, answers take a few seconds, compression cuts token use by about 44%, and a typical AI answer costs a fraction of a penny.
>
> `[pause]` **Our ask is simple: a pilot.**
>
> - Start with **one buying category**.
> - Connect the live **ERP, quality and accounts payable** feeds.
> - Deploy on **Azure UK South** with Entra ID single sign-on and Azure OpenAI on private endpoints.
> - Then **track the realised savings** against these estimates.
>
> `[pause]` **Know every supplier. Act before it hurts.** Thank you - happy to take questions.

**Land this:** strong value case, low risk, clear next step - approve a one-category pilot.

**If asked "How confident are you in £3.1m?"**
> It's an estimate from sample data, built from industry-standard levers, and every assumption can be edited in the app. The pilot exists to replace these estimates with measured savings.

---

## Quick answers for Q&A

| Question | Short answer |
|---|---|
| What data do we need? | ERP orders and deliveries, quality inspections, accounts payable invoices, contracts/SLAs, supplier master. |
| How long to pilot? | One category, connected to live feeds; a scope and timeline would be agreed with Primark IT. |
| Is supplier data safe? | Role-based access, personal data redacted before the AI, full audit, and an Azure UK South target with private networking. |
| What if the AI is down? | Dashboards, scores, predictions and actions all work without the LLM; AIRA switches to fact-based answers. |
| How is AI cost controlled? | Every call is metered per user and task, with a monthly budget and a hard stop; a typical answer costs ~£0.0004. |
| Can buyers override the AI? | The AI never makes the decision. Actions follow Primark's escalation policy and need a named human approver. |
