"""Admin editing of the policy library (Policies & Contracts).

Each document is a Markdown file with front matter in ``KNOWLEDGE_DIR``. Saving a document:

1. validates it (id, type, date, size, at least one ``##`` section so it can be chunked and cited);
2. copies the current file to ``_history/<ID>/`` (nothing is ever lost; old versions can be viewed);
3. bumps ``policy_version`` (1.4 -> 1.5) unless the editor sets a higher one;
4. writes the new file atomically and re-indexes ChromaDB, which changes the policy version hash, so
   cached AI answers built on the old wording are no longer reused.

The caller writes the audit event. Archiving moves the file to history and re-indexes.
"""
from __future__ import annotations

import os
import re
import threading
from datetime import date, datetime, timezone
from pathlib import Path

from app.config import get_settings
from app.knowledge import store

DOC_TYPES = ("policy", "sla", "standard", "guideline", "contract")
ID_RE = re.compile(r"^[A-Z][A-Z0-9]{1,7}$")
VERSION_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){0,2}$")
MAX_CHARS = 60_000
_lock = threading.Lock()


class PolicyError(ValueError):
    """Validation problem shown to the admin (HTTP 422)."""


def _dir() -> Path:
    return Path(get_settings().knowledge_dir)


def _history_dir(doc_id: str) -> Path:
    return _dir() / "_history" / doc_id


def _file_for(doc_id: str) -> Path | None:
    for f in _dir().glob("*.md"):
        meta, _ = store.parse_document(f)
        if meta["document_id"].upper() == doc_id.upper():
            return f
    return None


def _bump(version: str) -> str:
    parts = [int(p) for p in str(version or "1.0").split(".") if p.isdigit()] or [1, 0]
    if len(parts) == 1:
        parts.append(0)
    parts[-1] += 1
    return ".".join(str(p) for p in parts)


def _vtuple(v: str) -> tuple:
    return tuple(int(p) for p in v.split("."))


def _front_matter(meta: dict) -> str:
    order = ("document_id", "title", "document_type", "category", "policy_version", "effective_date", "source", "updated_by", "updated_at", "change_note")
    lines = ["---"]
    for k in order:
        v = meta.get(k)
        if v in (None, ""):
            continue
        v = str(v).replace("\n", " ").strip()
        lines.append(f'{k}: "{v}"' if k in ("policy_version", "title", "change_note", "source") else f"{k}: {v}")
    lines.append("---")
    return "\n".join(lines)


def read_source(doc_id: str) -> dict:
    f = _file_for(doc_id)
    if not f:
        raise LookupError(doc_id)
    meta, body = store.parse_document(f)
    return {"meta": {k: meta.get(k, "") for k in ("document_id", "title", "document_type", "category", "policy_version",
                                                  "effective_date", "source", "updated_by", "updated_at", "change_note")},
            "markdown": body, "file": f.name, "doc_types": list(DOC_TYPES)}


def _validate(meta: dict, body: str) -> None:
    if not ID_RE.match(meta["document_id"]):
        raise PolicyError("Document ID must be 2-8 capital letters or digits, starting with a letter (e.g. PP, DSLA).")
    if not 3 <= len(meta["title"].strip()) <= 120:
        raise PolicyError("Title must be 3-120 characters.")
    if meta["document_type"] not in DOC_TYPES:
        raise PolicyError(f"Type must be one of: {', '.join(DOC_TYPES)}.")
    try:
        date.fromisoformat(str(meta["effective_date"]))
    except ValueError as exc:
        raise PolicyError("Effective date must be YYYY-MM-DD.") from exc
    if not VERSION_RE.match(str(meta["policy_version"])):
        raise PolicyError("Version must look like 1.4 or 2.0.1.")
    if not 50 <= len(body) <= MAX_CHARS:
        raise PolicyError(f"Text must be 50-{MAX_CHARS:,} characters.")
    if not re.search(r"(?m)^##\s+\S", body):
        raise PolicyError("Add at least one section heading starting with '## ' (e.g. '## PP-9 New rule'), so AIRA can cite it.")
    if "---" in body.splitlines()[0:1]:
        raise PolicyError("The text must not start with '---'.")


def _atomic_write(path: Path, text: str) -> None:
    tmp = path.with_suffix(".md.tmp")
    tmp.write_text(text, encoding="utf-8", newline="\n")
    os.replace(tmp, path)


def _archive_copy(f: Path, doc_id: str, version: str, label: str = "") -> str:
    h = _history_dir(doc_id)
    h.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    name = f"v{version}__{stamp}{label}.md"
    (h / name).write_text(f.read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
    return name


def save(doc_id: str | None, data: dict, actor: str) -> dict:
    """Create (doc_id None) or update a document. Returns the change summary for the audit log."""
    with _lock:
        body = store.clean(data["markdown"])
        if doc_id:
            f = _file_for(doc_id)
            if not f:
                raise LookupError(doc_id)
            old_meta, old_body = store.parse_document(f)
            old_version = str(old_meta.get("policy_version") or "1.0")
            requested = str(data.get("policy_version") or "").strip()
            version = requested if requested and VERSION_RE.match(requested) and _vtuple(requested) > _vtuple(old_version) else _bump(old_version)
            meta = {**old_meta, "document_id": old_meta["document_id"]}
        else:
            new_id = str(data.get("document_id") or "").strip().upper()
            if _file_for(new_id):
                raise PolicyError(f"A document with ID {new_id} already exists.")
            f, old_body, old_version = None, "", None
            version = str(data.get("policy_version") or "1.0")
            meta = {"document_id": new_id, "source": "Vendor360 policy library"}
        meta.update({
            "title": data["title"].strip(), "document_type": data["document_type"], "category": (data.get("category") or "all").strip()[:40],
            "effective_date": str(data["effective_date"]), "policy_version": version,
            "updated_by": actor, "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "change_note": (data.get("change_note") or "").strip()[:200],
        })
        _validate(meta, body)
        if not body.lstrip().startswith("# "):
            body = f"# {meta['title']}\n\n{body}"
        archived = _archive_copy(f, meta["document_id"], old_version) if f else None
        target = f or (_dir() / f"{meta['document_id'].lower()}.md")
        _atomic_write(target, _front_matter(meta) + "\n" + body + "\n")
        try:
            res = store.ingest()
        except Exception:
            if f and archived:  # roll back the file so the index and disk never disagree
                _atomic_write(f, (_history_dir(meta["document_id"]) / archived).read_text(encoding="utf-8"))
            elif not f:
                target.unlink(missing_ok=True)
            raise
        sections = len(re.findall(r"(?m)^##+\s", body))
        return {"document_id": meta["document_id"], "title": meta["title"], "from_version": old_version, "to_version": version,
                "created": f is None, "archived_previous": archived, "sections": sections,
                "chars_before": len(old_body), "chars_after": len(body), "change_note": meta["change_note"],
                "policy_version": res["policy_version"], "chunks": res["chunks"]}


def archive(doc_id: str) -> dict:
    with _lock:
        f = _file_for(doc_id)
        if not f:
            raise LookupError(doc_id)
        if len(list(_dir().glob("*.md"))) <= 1:
            raise PolicyError("The library must keep at least one document.")
        meta, _ = store.parse_document(f)
        name = _archive_copy(f, meta["document_id"], str(meta.get("policy_version") or "1.0"), "__archived")
        f.unlink()
        res = store.ingest()
        return {"document_id": meta["document_id"], "title": meta["title"], "archived_as": name, "policy_version": res["policy_version"]}


def history(doc_id: str) -> list[dict]:
    h = _history_dir(doc_id.upper())
    out = []
    for p in sorted(h.glob("*.md"), reverse=True) if h.exists() else []:
        meta, body = store.parse_document(p)
        out.append({"file": p.name, "version": str(meta.get("policy_version") or ""), "updated_by": meta.get("updated_by", ""),
                    "updated_at": meta.get("updated_at", ""), "change_note": meta.get("change_note", ""),
                    "archived": p.stem.endswith("__archived"), "saved_at": p.stem.split("__")[1] if "__" in p.stem else "", "chars": len(body)})
    return out


def history_version(doc_id: str, file: str) -> dict:
    if not re.match(r"^v[\d.]+__\d{8}T\d{6}Z(__archived)?\.md$", file):
        raise LookupError(file)
    p = _history_dir(doc_id.upper()) / file
    if not p.exists():
        raise LookupError(file)
    meta, body = store.parse_document(p)
    return {"meta": meta, "markdown": body, "file": file}
