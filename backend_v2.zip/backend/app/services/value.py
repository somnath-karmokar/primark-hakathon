"""Business value for Primark - financial and operational benefits of Vendor360.

Follows the usual procurement value taxonomy (as used in procurement savings reporting):

* **Hard savings** - cash that comes back (invoice overcharges recovered);
* **Cost avoidance** - costs that stop happening (late-delivery and poor-quality costs);
* **Productivity** - people time freed (manual scorecards no longer built by hand);
* **Risk mitigation** - spend protected from disruption. Reported separately and *not* added to the
  savings total, the conservative convention, because it is avoided loss rather than realised saving.

Every number = a **measured baseline** from the last 12 months of data x **an assumption** an admin
can see and change. Assumptions are planning values, not benchmarks; the page says so. Operational
benefits use SCOR-style supply-chain measures (on-time delivery, first-pass quality, invoice
accuracy, lead-time reliability).
"""
from __future__ import annotations

from datetime import date, timedelta

from sqlalchemy import case, func, select
from sqlalchemy.orm import Session

from app.models.entities import (
    Delivery, Invoice, LeadTimeRecord, PurchaseOrder, QualityInspection, Vendor, VendorRiskSnapshot, VendorScoreSnapshot,
)

# Planning assumptions (editable by an admin). Keep them conservative and explainable.
DEFAULT_ASSUMPTIONS: dict[str, float] = {
    "late_cost_pct": 3.0,             # % of late order value lost to expediting, markdowns and missed sales
    "late_reduction_pct": 20.0,       # % fewer late orders once poor performers are managed early
    "quality_cost_multiplier": 1.3,   # rejected goods value x handling, re-inspection and replacement freight
    "quality_reduction_pct": 20.0,    # % fewer rejected goods
    "overcharge_recovery_pct": 30.0,  # % of overbilled amounts (on approved invoices) recovered or prevented
    "hours_per_vendor_month": 1.0,    # analyst hours to build one vendor scorecard by hand
    "automation_pct": 70.0,           # share of that time the platform removes
    "hourly_rate_gbp": 45.0,          # loaded cost of a buyer / analyst hour
    "disruption_protect_pct": 2.0,    # % of open orders at High-risk vendors protected by acting early
    "implementation_cost_gbp": 350000.0,  # one-off build, integration (ERP / QMS feeds) and rollout
    "annual_support_gbp": 100000.0,       # team to run, support and improve it each year
}
BOUNDS: dict[str, tuple[float, float]] = {
    "late_cost_pct": (0, 20), "late_reduction_pct": (0, 80), "quality_cost_multiplier": (1, 5), "quality_reduction_pct": (0, 80),
    "overcharge_recovery_pct": (0, 100), "hours_per_vendor_month": (0, 10), "automation_pct": (0, 100), "hourly_rate_gbp": (10, 200),
    "disruption_protect_pct": (0, 20), "implementation_cost_gbp": (0, 5_000_000), "annual_support_gbp": (0, 2_000_000),
}
LABELS = {
    "late_cost_pct": "Cost of a late order (% of its value)", "late_reduction_pct": "Fewer late orders",
    "quality_cost_multiplier": "Full cost of a rejected item (x its price)", "quality_reduction_pct": "Fewer rejected goods",
    "overcharge_recovery_pct": "Overcharges recovered or prevented", "hours_per_vendor_month": "Hours to build one scorecard by hand",
    "automation_pct": "Scorecard time saved", "hourly_rate_gbp": "Cost of an analyst hour (£)",
    "disruption_protect_pct": "At-risk open orders protected", "implementation_cost_gbp": "One-off implementation cost (£)",
    "annual_support_gbp": "Yearly support team cost (£)",
}
# Scenario multipliers apply to the improvement assumptions only (never to the measured baselines).
SCENARIOS = {"conservative": 0.5, "expected": 1.0, "stretch": 1.5}
IMPROVEMENT_KEYS = ("late_reduction_pct", "quality_reduction_pct", "overcharge_recovery_pct", "automation_pct", "disruption_protect_pct")


def assumptions(db: Session) -> dict[str, float]:
    from app.services import runtime_settings
    stored = runtime_settings.get_runtime(db).get("value") or {}
    return {k: float(stored.get(k, v)) for k, v in DEFAULT_ASSUMPTIONS.items()}


def save_assumptions(db: Session, values: dict) -> dict[str, float]:
    from app.services import runtime_settings
    cur = assumptions(db)
    for k, v in values.items():
        if k in BOUNDS and v is not None:
            lo, hi = BOUNDS[k]
            cur[k] = min(max(float(v), lo), hi)
    runtime_settings.set_section(db, "value", cur)
    return cur


_memo: dict = {}


def _baseline(db: Session) -> dict:
    """Measured 12-month baseline, memoised for 60 s (the queries scan every PO, delivery and invoice)."""
    import time
    hit = _memo.get("b")
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    out = _compute_baseline(db)
    _memo["b"] = (time.time(), out)
    return out


def _compute_baseline(db: Session) -> dict:
    end = db.execute(select(func.max(VendorScoreSnapshot.period))).scalar_one() or date.today()
    start = end - timedelta(days=365)
    in_window = lambda col: (col > start) & (col <= end)  # noqa: E731

    spend = db.execute(select(func.coalesce(func.sum(PurchaseOrder.expected_value), 0.0)).where(in_window(PurchaseOrder.po_date))).scalar_one()
    ship_total, ship_late = db.execute(select(func.count(), func.coalesce(func.sum(case((Delivery.days_late > 0, 1), else_=0)), 0))
                                       .where(in_window(Delivery.delivered_date))).one()
    avg_days_late = db.execute(select(func.avg(Delivery.days_late)).where(in_window(Delivery.delivered_date), Delivery.days_late > 0)).scalar_one() or 0
    late_po_ids = select(Delivery.po_id).where(in_window(Delivery.delivered_date), Delivery.days_late > 0).distinct()
    late_value = db.execute(select(func.coalesce(func.sum(PurchaseOrder.expected_value), 0.0)).where(PurchaseOrder.po_id.in_(late_po_ids))).scalar_one()

    lots, lots_failed, inspected, rejected = db.execute(select(
        func.count(), func.coalesce(func.sum(case((QualityInspection.result == "FAIL", 1), else_=0)), 0),
        func.coalesce(func.sum(QualityInspection.inspected_qty), 0), func.coalesce(func.sum(QualityInspection.rejected_qty), 0),
    ).where(in_window(QualityInspection.inspection_date))).one()
    rejected_value = db.execute(select(func.coalesce(func.sum(QualityInspection.rejected_qty * PurchaseOrder.unit_price), 0.0))
                                .join(PurchaseOrder, PurchaseOrder.po_id == QualityInspection.po_id)
                                .where(in_window(QualityInspection.inspection_date))).scalar_one()

    inv_total, inv_accurate, overbilled_paid, overbilled_disputed = db.execute(select(
        func.count(),
        func.coalesce(func.sum(case((func.abs(Invoice.variance_amount) <= 0.01 * Invoice.po_value, 1), else_=0)), 0),
        func.coalesce(func.sum(case(((Invoice.variance_amount > 0) & (Invoice.status != "Disputed"), Invoice.variance_amount), else_=0.0)), 0.0),
        func.coalesce(func.sum(case(((Invoice.variance_amount > 0) & (Invoice.status == "Disputed"), Invoice.variance_amount), else_=0.0)), 0.0),
    ).where(in_window(Invoice.invoice_date))).one()

    lt_total, lt_on_time = db.execute(select(func.count(), func.coalesce(func.sum(case((LeadTimeRecord.variance_days <= 2, 1), else_=0)), 0))
                                      .join(PurchaseOrder, PurchaseOrder.po_id == LeadTimeRecord.po_id)
                                      .where(in_window(PurchaseOrder.po_date))).one()

    vendors = db.execute(select(func.count()).select_from(Vendor)).scalar_one()
    high_ids = select(VendorRiskSnapshot.vendor_id).where(VendorRiskSnapshot.risk_level == "High")
    high_vendors = db.execute(select(func.count()).select_from(VendorRiskSnapshot).where(VendorRiskSnapshot.risk_level == "High")).scalar_one()
    open_at_risk = db.execute(select(func.coalesce(func.sum(PurchaseOrder.expected_value), 0.0))
                              .where(PurchaseOrder.status == "Open", PurchaseOrder.vendor_id.in_(high_ids))).scalar_one()
    return {
        "window": {"from": (start + timedelta(days=1)).isoformat(), "to": end.isoformat()},
        "spend_gbp": float(spend), "shipments": int(ship_total), "late_shipments": int(ship_late), "avg_days_late": round(float(avg_days_late), 1),
        "late_order_value_gbp": float(late_value), "inspection_lots": int(lots), "failed_lots": int(lots_failed),
        "inspected_units": int(inspected), "rejected_units": int(rejected), "rejected_value_gbp": float(rejected_value),
        "invoices": int(inv_total), "accurate_invoices": int(inv_accurate), "overbilled_paid_gbp": float(overbilled_paid),
        "overbilled_disputed_gbp": float(overbilled_disputed), "lead_time_orders": int(lt_total), "lead_time_reliable": int(lt_on_time),
        "vendors": int(vendors), "high_risk_vendors": int(high_vendors), "open_value_at_high_risk_gbp": float(open_at_risk),
    }


def _run_cost_annual(db: Session, support_gbp: float) -> dict:
    """Yearly running cost: cloud hosting (mid-point of the FinOps planning ranges), AI usage at the current
    month-end forecast, and the support team."""
    from app.services import finops
    fixed = [i for i in finops.INFRA_ESTIMATES if i["low"] is not None]
    infra_mid = sum((i["low"] + i["high"]) / 2 for i in fixed) * 12
    month = finops.summary(db)
    ai = month["forecast_month_gbp"] * 12
    return {"infrastructure_gbp": round(infra_mid), "ai_usage_gbp": round(ai, 2), "support_gbp": round(support_gbp),
            "total_gbp": round(infra_mid + ai + support_gbp)}


def benefits(db: Session, scenario: str = "expected") -> dict:
    scenario = scenario if scenario in SCENARIOS else "expected"
    a = assumptions(db)
    m = SCENARIOS[scenario]
    eff = {k: (min(v * m, BOUNDS[k][1]) if k in IMPROVEMENT_KEYS else v) for k, v in a.items()}
    b = _baseline(db)

    late_cost = b["late_order_value_gbp"] * eff["late_cost_pct"] / 100
    quality_cost = b["rejected_value_gbp"] * eff["quality_cost_multiplier"]
    hours = b["vendors"] * 12 * eff["hours_per_vendor_month"] * eff["automation_pct"] / 100
    levers = [
        {"key": "overcharges", "type": "Hard saving", "lever": "Invoice overcharges recovered",
         "baseline": f"£{b['overbilled_paid_gbp']:,.0f} billed above PO value and paid in 12 months",
         "assumption": f"{eff['overcharge_recovery_pct']:.0f}% recovered or prevented by flagging vendors with invoice variance",
         "annual_gbp": b["overbilled_paid_gbp"] * eff["overcharge_recovery_pct"] / 100},
        {"key": "late", "type": "Cost avoidance", "lever": "Fewer late deliveries",
         "baseline": f"£{b['late_order_value_gbp'] / 1e6:,.1f}m of orders arrived late ({b['late_shipments']:,} shipments, {b['avg_days_late']} days on average)",
         "assumption": f"Lateness costs {eff['late_cost_pct']:.1f}% of order value (expediting, markdowns, missed sales); {eff['late_reduction_pct']:.0f}% fewer late orders",
         "annual_gbp": late_cost * eff["late_reduction_pct"] / 100},
        {"key": "quality", "type": "Cost avoidance", "lever": "Fewer quality failures",
         "baseline": f"£{b['rejected_value_gbp'] / 1e6:,.2f}m of goods rejected at inspection ({b['rejected_units']:,} units)",
         "assumption": f"Full cost {eff['quality_cost_multiplier']:.1f}x the goods value; {eff['quality_reduction_pct']:.0f}% fewer rejections",
         "annual_gbp": quality_cost * eff["quality_reduction_pct"] / 100},
        {"key": "productivity", "type": "Productivity", "lever": "Analyst time freed",
         "baseline": f"{b['vendors']} vendors x {eff['hours_per_vendor_month']:g} h a month to build scorecards by hand",
         "assumption": f"{eff['automation_pct']:.0f}% of that time saved ({hours:,.0f} hours a year) at £{eff['hourly_rate_gbp']:.0f} an hour",
         "annual_gbp": hours * eff["hourly_rate_gbp"], "hours": round(hours)},
    ]
    for lv in levers:
        lv["annual_gbp"] = round(lv["annual_gbp"])
    risk = {"key": "risk", "type": "Risk mitigation", "lever": "Spend protected from disruption",
            "baseline": f"£{b['open_value_at_high_risk_gbp'] / 1e6:,.1f}m of open orders with {b['high_risk_vendors']} High-risk vendors",
            "assumption": f"{eff['disruption_protect_pct']:.1f}% protected by acting early (re-sourcing, expediting, buffer stock)",
            "annual_gbp": round(b["open_value_at_high_risk_gbp"] * eff["disruption_protect_pct"] / 100),
            "note": "Reported separately - avoided loss, not counted in the savings total."}

    total = sum(lv["annual_gbp"] for lv in levers)
    run = _run_cost_annual(db, eff["annual_support_gbp"])
    impl = eff["implementation_cost_gbp"]
    first_year_cost = impl + run["total_gbp"]
    net_monthly = (total - run["total_gbp"]) / 12
    pct = lambda n, d: round(n / d * 100, 1) if d else 0.0  # noqa: E731
    operational = [
        {"key": "otd", "label": "On-time shipments (12 months)", "value": pct(b["shipments"] - b["late_shipments"], b["shipments"]), "unit": "%",
         "standard": "SCOR - delivery reliability", "detail": f"{b['late_shipments']:,} of {b['shipments']:,} shipments late",
         "improved": pct(b["shipments"] - b["late_shipments"] * (1 - eff["late_reduction_pct"] / 100), b["shipments"])},
        {"key": "fpq", "label": "Inspections passed first time (12 months)", "value": pct(b["inspection_lots"] - b["failed_lots"], b["inspection_lots"]), "unit": "%",
         "standard": "SCOR - perfect order (condition)", "detail": f"{b['failed_lots']:,} of {b['inspection_lots']:,} inspected lots failed",
         "improved": pct(b["inspection_lots"] - b["failed_lots"] * (1 - eff["quality_reduction_pct"] / 100), b["inspection_lots"])},
        {"key": "invoice", "label": "Invoice accuracy (12 months)", "value": pct(b["accurate_invoices"], b["invoices"]), "unit": "%",
         "standard": "Procure-to-pay - first-time match", "detail": "within 1% of the order value", "improved": None},
        {"key": "lead", "label": "Lead-time reliability", "value": pct(b["lead_time_reliable"], b["lead_time_orders"]), "unit": "%",
         "standard": "SCOR - order fulfilment cycle time", "detail": "orders on the promised lead time (±2 days)", "improved": None},
        {"key": "coverage", "label": "Vendors scored every month", "value": 100.0, "unit": "%",
         "standard": "Supplier performance management", "detail": f"all {b['vendors']} vendors, same rules", "improved": None},
        {"key": "warning", "label": "High risk of decline (early warnings)", "value": b["high_risk_vendors"], "unit": "vendors",
         "standard": "Supplier risk management", "detail": "flagged before the score drops", "improved": None},
    ]
    other = [
        {"benefit": "Faster decisions", "detail": "Scorecards refresh with the data instead of a monthly or quarterly manual cycle."},
        {"benefit": "Consistent, fair scoring", "detail": "One published rule set for every vendor; regional fairness checked on the Trust Centre."},
        {"benefit": "Audit-ready", "detail": "Every score, AI answer, approval and setting change is logged."},
        {"benefit": "Better supplier conversations", "detail": "Fact-based scorecards with reasons, shared in quarterly business reviews."},
        {"benefit": "Supplier diversification", "detail": "Concentration above 35% of category spend is flagged; alternatives are ranked by fit."},
        {"benefit": "Controlled AI cost", "detail": "AI only explains; spend is tracked per question with a monthly hard stop."},
    ]
    return {
        "scenario": scenario, "scenarios": list(SCENARIOS), "currency": "GBP", "window": b["window"], "baseline": b,
        "levers": levers, "risk_mitigation": risk, "total_annual_gbp": round(total),
        "spend_share_pct": round(total / b["spend_gbp"] * 100, 3) if b["spend_gbp"] else 0.0,
        "run_cost_annual": run, "implementation_cost_gbp": round(impl),
        "first_year_roi_pct": round((total - first_year_cost) / first_year_cost * 100) if first_year_cost else None,
        "roi_multiple": round(total / first_year_cost, 1) if first_year_cost else None,
        "payback_months": round(impl / net_monthly, 1) if net_monthly > 0 else None,
        "operational": operational, "other_benefits": other,
        "assumptions": [{"key": k, "label": LABELS[k], "value": a[k], "applied": round(eff[k], 3), "min": BOUNDS[k][0], "max": BOUNDS[k][1],
                         "scaled_by_scenario": k in IMPROVEMENT_KEYS} for k in DEFAULT_ASSUMPTIONS],
        "method": "Measured 12-month baseline x editable planning assumptions. Categories follow common procurement savings "
                  "reporting (hard savings, cost avoidance, productivity; risk mitigation reported separately). "
                  "Operational measures follow SCOR-style definitions. Indicative estimate, not a forecast.",
    }
