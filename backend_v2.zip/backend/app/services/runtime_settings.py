"""Runtime-editable settings, persisted in ``app_settings``.

Secrets are never stored here; the Settings page can only change non-secret
values (weights, thresholds, cache flags, model routing names, demo mode).
"""
from __future__ import annotations

import hashlib
import json
import time

from sqlalchemy.orm import Session

from app.analytics.scoring import ScoringWeights
from app.config import get_settings
from app.models.entities import AppSetting


def defaults() -> dict:
    s = get_settings()
    return {
        "scoring": {"weights": {"delivery": s.weight_delivery, "quality": s.weight_quality,
                                "cost": s.weight_cost, "lead_time": s.weight_lead_time}},
        "risk": {"high_threshold": s.risk_high_threshold, "medium_threshold": s.risk_medium_threshold,
                 "deterioration_drop_points": s.deterioration_drop_points,
                 "approval_confidence_threshold": s.approval_confidence_threshold},
        "cache": {"enabled": s.cache_enabled, "ttl_seconds": s.cache_ttl_seconds,
                  "semantic_threshold": s.semantic_cache_threshold},
        "agent": {"max_agent_steps": s.max_agent_steps, "max_llm_calls": s.max_llm_calls,
                  "max_tool_calls": s.max_tool_calls, "token_budget_per_request": s.token_budget_per_request,
                  "context_budget_tokens": s.context_budget_tokens},
        "demo_mode": s.demo_mode,
    }


_cache: dict | None = None
_cache_at = 0.0


def get_runtime(db: Session) -> dict:
    global _cache, _cache_at
    if _cache is not None and time.time() - _cache_at < 5:
        return _cache
    merged = defaults()
    for row in db.query(AppSetting).all():
        if row.key in merged and isinstance(merged[row.key], dict) and isinstance(row.value, dict):
            merged[row.key] = {**merged[row.key], **row.value}
        elif row.key in ("demo_mode",):
            merged[row.key] = row.value.get("value", merged[row.key])
        elif row.key in ("data_version", "guardrails", "finops", "value"):
            merged[row.key] = row.value
    _cache, _cache_at = merged, time.time()
    return merged


def invalidate() -> None:
    global _cache
    _cache = None


def set_section(db: Session, key: str, value: dict) -> None:
    row = db.get(AppSetting, key)
    if row:
        row.value = value
    else:
        db.add(AppSetting(key=key, value=value))
    db.flush()
    invalidate()


def weights(db: Session) -> ScoringWeights:
    w = get_runtime(db)["scoring"]["weights"]
    return ScoringWeights(delivery=w["delivery"], quality=w["quality"], cost=w["cost"], lead_time=w["lead_time"]).validate()


def data_version(db: Session) -> str:
    row = db.get(AppSetting, "data_version")
    return row.value.get("version", "unseeded") if row else "unseeded"


def bump_data_version(db: Session, reason: str) -> str:
    rt = get_runtime(db)
    payload = json.dumps({"t": time.time(), "w": rt["scoring"]["weights"], "r": reason}, sort_keys=True)
    version = "dv-" + hashlib.sha1(payload.encode()).hexdigest()[:10]
    set_section(db, "data_version", {"version": version, "reason": reason, "at": time.strftime("%Y-%m-%dT%H:%M:%S")})
    return version
