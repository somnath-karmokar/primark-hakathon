"""Strongly-typed LangGraph state.

Agents exchange structured dicts (scores, KPIs, evidence items) - never free
text blobs. List fields that several agents append to use ``operator.add``
reducers so updates merge instead of overwrite.
"""
from __future__ import annotations

import operator
from typing import Annotated, Literal, TypedDict

Intent = Literal[
    "vendor_explain", "vendor_recommendation", "alternatives", "vendor_sla", "vendor_dependency", "vendor_overview",
    "portfolio_underperformers", "portfolio_deteriorated", "portfolio_segment", "portfolio_summary", "portfolio_ranking",
    "policy_question", "out_of_scope",
]
AgentName = Literal["performance", "risk", "knowledge", "recommendation"]


class Evidence(TypedDict, total=False):
    id: str
    kind: str          # metric | trend | risk | policy | graph | recommendation | portfolio | sla
    title: str
    value: object
    source: str        # postgres | scoring-engine | ml-model | chromadb | neo4j | postgres-fallback
    priority: int
    ref: str           # clause / document id / node id


class TraceStep(TypedDict, total=False):
    agent: str
    action: str
    tools: list[str]
    sources: list[str]
    status: str
    duration_ms: int
    detail: str


class CopilotState(TypedDict, total=False):
    # request
    request_id: str
    session_id: str
    actor: str
    role: str
    user_query: str
    intent: Intent
    intent_method: str
    segment: str | None
    ranking: dict | None
    vendor_id: str | None
    time_period: str | None
    # control
    plan: list[str]
    completed: Annotated[list[str], operator.add]
    next_agent: str
    step_count: int
    started_at: float
    # performance
    vendor_profile: dict | None
    performance_metrics: dict | None
    score_breakdown: dict | None
    trend_analysis: dict | None
    drivers: list[dict]
    sla_compliance: list[dict]
    portfolio: dict | None
    # risk
    risk_prediction: dict | None
    risk_drivers: list[dict]
    # knowledge
    vector_context: list[dict]
    graph_context: dict | None
    # recommendation
    candidate_vendors: list[dict]
    recommendation: dict | None
    # outputs
    evidence: Annotated[list[Evidence], operator.add]
    answer: dict | None
    confidence: float
    governance_result: dict | None
    agent_trace: Annotated[list[TraceStep], operator.add]
    llm_calls: Annotated[list[dict], operator.add]
    guardrail_flags: Annotated[list[str], operator.add]
    errors: Annotated[list[str], operator.add]
