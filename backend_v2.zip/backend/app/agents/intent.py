"""Supervisor intent classification + execution plans.

Deterministic rules first (fast, free, auditable). Only when the rules cannot
place a question does the Supervisor ask the *light* model, and its answer is
constrained to the enum below.
"""
from __future__ import annotations

import re

from pydantic import BaseModel, Field

VENDOR_RE = re.compile(r"\bV\s?-?(\d{4})\b", re.I)

PLANS: dict[str, list[str]] = {
    "vendor_explain": ["performance", "risk", "knowledge"],
    "vendor_recommendation": ["performance", "risk", "knowledge", "recommendation"],
    "alternatives": ["performance", "knowledge", "recommendation"],
    "vendor_sla": ["performance", "knowledge"],
    "vendor_dependency": ["knowledge"],
    "vendor_overview": ["performance", "risk"],
    "portfolio_underperformers": ["performance"],
    "portfolio_deteriorated": ["performance", "risk"],
    "portfolio_segment": ["performance"],
    "portfolio_summary": ["performance"],
    "portfolio_ranking": ["performance", "risk"],
    "policy_question": ["knowledge"],
    "out_of_scope": [],
}
VENDOR_INTENTS = {"vendor_explain", "vendor_recommendation", "alternatives", "vendor_sla", "vendor_dependency", "vendor_overview"}

SEGMENTS = [
    (re.compile(r"(strong|good|high)\s+quality.*(weak|poor|bad|late)\s+deliver", re.I), "strong_quality_weak_delivery"),
    (re.compile(r"(low[- ]cost|cheap).*(poor|weak|bad|low)\s+quality", re.I), "low_cost_poor_quality"),
    (re.compile(r"(expensive|premium|high[- ]cost).*(high|good|strong)\s+quality|(high|good|strong)\s+quality.*(expensive|premium)", re.I), "premium_high_quality"),
    (re.compile(r"lead[- ]?time\s+(variab|inconsist|unpredict)|(variable|inconsistent|unpredictable)\s+lead[- ]?time", re.I), "variable_lead_time"),
]


RANK_RE = re.compile(
    r"\b(top|best|highest|leading|strongest|bottom|worst|lowest|weakest)\b\s*(\d{1,3}\s+)?(\w+\s+){0,3}?(vendors?|suppliers?|performers?)\b"
    r"|\b(top|bottom|best|worst)\s+\d{1,3}\b|\brank(ing|ed)?\b|\blist (all |the )?(vendors|suppliers)\b|\b(show|give|list)( me)?( the)? \d{1,3}\b", re.I)
METRICS = [("lead_time", r"lead[- ]?time"), ("delivery", r"deliver|on[- ]time"), ("quality", r"quality|defect"),
           ("cost", r"\bcost|price|invoice|cheap")]
METRIC_LABELS = {"overall": "overall score", "delivery": "delivery score", "quality": "quality score", "cost": "cost score",
                 "lead_time": "lead-time score"}


def parse_ranking(query: str, categories: list[dict] | None = None, regions: list[str] | None = None) -> dict:
    """How many, which direction, which score area, and an optional category / region - all from plain words."""
    q = query.lower()
    q_no_ids = VENDOR_RE.sub(" ", q)
    m = re.search(r"\b(\d{1,3})\b", q_no_ids)
    n = max(1, min(int(m.group(1)), 25)) if m else 10
    order = "asc" if re.search(r"\b(bottom|worst|lowest|weakest|poorest)\b", q) else "desc"
    metric = next((k for k, rx in METRICS if re.search(rx, q)), "overall")
    cat = next((c for c in (categories or []) if re.search(rf"\b{re.escape(c['name'].lower())}\b", q)), None)
    reg = next((r for r in sorted(regions or [], key=len, reverse=True) if r.lower() in q), None)
    return {"n": n, "order": order, "metric": metric, "metric_label": METRIC_LABELS[metric],
            "category_id": cat["id"] if cat else None, "category": cat["name"] if cat else None, "region": reg}


def extract_vendor_id(text: str) -> str | None:
    m = VENDOR_RE.search(text)
    return f"V{m.group(1)}" if m else None


def classify(query: str, has_vendor: bool) -> tuple[str, str | None]:
    q = query.lower()
    for rx, seg in SEGMENTS:
        if rx.search(query):
            return "portfolio_segment", seg
    if re.search(r"polic(y|ies)\s.*\b(say|state|require|allow)|what (does|do) (the|our) .*(policy|standard|guideline)", q):
        return "policy_question", None
    if re.search(r"alternative|replac|back[- ]?up|substitut|switch (supplier|vendor|away)|other suppliers?|best (alternative|supplier)|"
                 r"second source|instead of|cover for|source (it |them )?elsewhere|who else (makes|supplies|can)", q):
        return "alternatives", None
    if re.search(r"recommend|what should|which action|next step|suggest|should (we|procurement)|what to do|course of action", q):
        return "vendor_recommendation", None
    if has_vendor and re.search(r"depend|which products|what products|affected (products|categories)|what does .* supply|categories", q):
        return "vendor_dependency", None
    if has_vendor and re.search(r"\bsla\b|service level|contract|terms|target", q):
        return "vendor_sla", None
    if has_vendor and re.search(r"why|explain|cause|causing|reason|driver|underperform|low|declin|deteriorat|drop|worse|problem|issue", q):
        return "vendor_explain", None
    if not has_vendor and RANK_RE.search(query):
        return "portfolio_ranking", None
    if not has_vendor and re.search(r"deteriorat|declin|worsen|dropped|biggest (fall|drop)|most decline", q):
        return "portfolio_deteriorated", None
    if not has_vendor and re.search(r"underperform|worst|bottom|at[- ]risk|critical|poor(ly)? perform|lowest", q):
        return "portfolio_underperformers", None
    if re.search(r"polic|standard|guideline|what does .* say|\baql\b|escalat|onboard|\bsla\b|service level|contract|clause|approval", q):
        return "policy_question", None
    if has_vendor:
        return "vendor_overview", None
    if re.search(r"how many|overall|portfolio|summary|dashboard|average score|top (vendors|suppliers)|best perform", q):
        return "portfolio_summary", None
    return "out_of_scope", None


class IntentLLM(BaseModel):
    """Constrained output for the light-model fallback classifier."""
    intent: str = Field(description="one of: " + ", ".join(PLANS))
