"""REST API v1 (OpenAPI at /docs)."""
from __future__ import annotations

import logging
import re
import sys
import threading
import time
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.agents import copilot
from app.agents.graph import mermaid
from app.agents import rules
from app.config import REPO_ROOT, get_settings
from app.database.session import SessionLocal, get_db
from app.governance.audit import audit
from app.graph import client as graph_client
from app.graph import queries as graph
from app.knowledge import store
from app.llm import gateway
from app.llm.provider import routing_table
from app.models.entities import AuditEvent, Recommendation, Vendor
from app.risk_intel import service as risk_intel
from app.schemas.requests import (
    AnomalyRequest, BudgetUpdate, ValueAssumptionsUpdate, PolicyDocument, ChatRequest, FeedbackRequest, CompareRequest, DecisionRequest, GuardrailTest, GuardrailUpdate, LoginRequest, SeedRequest,
    SettingsUpdate, TrainRequest,
)
from app import security
from app.governance import guardrails
from app.knowledge import editor as policy_editor
from app.security import Principal, authenticate, require
from app.services import alternatives as alt_service
from app.services import analytics_service as analytics
from app.services import cache, finops, model_lab, pipeline, risk_service, runtime_settings, trust, value
from app.tools.registry import catalogue

log = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1")
VENDOR_PATH = r"^[Vv]\d{4}$"


def _vendor_or_404(db: Session, vendor_id: str) -> str:
    """Input guardrail: vendor ids are validated before any lookup."""
    vid = vendor_id.strip().upper()
    if not re.fullmatch(VENDOR_PATH, vid) or not db.get(Vendor, vid):
        raise HTTPException(404, f"Vendor {vid} not found")
    return vid


# ------------------------------------------------------------------ system
@router.get("/health", tags=["system"])
def health(db: Session = Depends(get_db)):
    s = get_settings()
    try:
        vendors = db.execute(select(func.count()).select_from(Vendor)).scalar_one()
        db_ok = True
    except Exception:
        vendors, db_ok = 0, False
    return {"status": "ok" if db_ok else "degraded", "app": s.app_name, "time": datetime.now(timezone.utc).isoformat(),
            "demo_mode": runtime_settings.get_runtime(db)["demo_mode"] if db_ok else s.demo_mode,
            "components": {
                "postgres": {"ok": db_ok, "vendors": vendors},
                "neo4j": {"ok": graph_client.is_available(), **graph_client.status()},
                "chromadb": {"ok": store.count() > 0, "chunks": store.count(), "policy_version": store.policy_version()},
                "llm": gateway.llm_health(),
            },
            "data_version": runtime_settings.data_version(db) if db_ok else None,
            "latest_period": analytics.latest_period(db) if db_ok else None, "auth_mode": s.auth_mode}


@router.get("/meta/filters", tags=["system"])
def filters(db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    return analytics.filter_options(db)


@router.get("/tools", tags=["system"])
def tools(_: Principal = Depends(authenticate)):
    """MCP-ready tool catalogue used by the agents."""
    return catalogue()


# ------------------------------------------------------------------ dashboard
@router.get("/dashboard/summary", tags=["dashboard"])
def dashboard_summary(period: str | None = None, category: str | None = None, region: str | None = None,
                      status: str | None = None, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    return analytics.dashboard_summary(db, period, category, region, status)


@router.get("/dashboard/distribution", tags=["dashboard"])
def dashboard_distribution(period: str | None = None, category: str | None = None, region: str | None = None,
                           db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    df = analytics._apply_filters(analytics.current_table(db, period), category, region, None)
    return {"period": period or analytics.latest_period(db), "distribution": analytics.distribution(df)}


# ------------------------------------------------------------------ vendors
@router.get("/vendors", tags=["vendors"])
def list_vendors(search: str | None = Query(default=None, max_length=80), category: str | None = None, region: str | None = None,
                 status: str | None = None, band: str | None = None, sort: str = "overall", order: str = Query("desc", pattern="^(asc|desc)$"),
                 page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=100), deteriorating: bool = False,
                 risk: str | None = Query(default=None, pattern="^(High|Medium|Low)$"),
                 period: str | None = None, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    return analytics.list_vendors(db, period=period, category=category, region=region, status=status, band=band, search=search,
                                  sort=sort, order=order, page=page, page_size=page_size, deteriorating_only=deteriorating,
                                  risk_level=risk)


@router.get("/vendors/{vendor_id}", tags=["vendors"])
def vendor_360(vendor_id: str, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    vid = _vendor_or_404(db, vendor_id)
    prof = analytics.vendor_profile(db, vid)
    score = analytics.score_detail(db, vid)
    return {"profile": prof, "score": score, "sla_compliance": analytics.sla_compliance(prof, score["kpis"]),
            "transactions": analytics.vendor_transactions(db, vid), "rank": _rank(db, vid),
            "commercials": analytics.vendor_commercials(db, vid)}


def _rank(db: Session, vid: str) -> dict:
    t = analytics.current_table(db)
    row = t[t["vendor_id"] == vid].iloc[0]
    cat = t[t["category_id"] == row["category_id"]]
    return {"overall": int(row["rank"]), "of": int(len(t)),
            "in_category": int((cat["overall"] > row["overall"]).sum() + 1), "category_size": int(len(cat))}


@router.get("/vendors/{vendor_id}/score", tags=["vendors"])
def vendor_score(vendor_id: str, period: str | None = None, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    return analytics.score_detail(db, _vendor_or_404(db, vendor_id), period)


@router.get("/vendors/{vendor_id}/trend", tags=["vendors"])
def vendor_trend(vendor_id: str, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    return analytics.vendor_trend(db, _vendor_or_404(db, vendor_id))


@router.get("/vendors/{vendor_id}/risk", tags=["vendors"])
def vendor_risk(vendor_id: str, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    vid = _vendor_or_404(db, vendor_id)
    score = analytics.score_detail(db, vid)
    return {"performance": {"score": score["breakdown"]["overall"], "band": score["breakdown"]["band"]},
            "internal": risk_service.vendor_risk(db, vid), "external": risk_intel.vendor_external_risk(db, vid)}


@router.get("/vendors/{vendor_id}/recommendations", tags=["vendors"])
def vendor_recommendations(vendor_id: str, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    """Current deterministic engine recommendation (not persisted) + governed history."""
    vid = _vendor_or_404(db, vendor_id)
    prof = analytics.vendor_profile(db, vid)
    score = analytics.score_detail(db, vid)
    dep = graph.supplier_dependency(db, vid)
    decision = rules.decide(score["breakdown"], score["trend"], analytics.sla_compliance(prof, score["kpis"]),
                            risk_service.vendor_risk(db, vid), score["drivers"], dep)
    alts = alt_service.rank_alternatives(db, vid, limit=3) if decision["needs_backup_supplier"] else None
    return {"engine": {**decision, "alternatives": alts["alternatives"] if alts else []}, "history": analytics.vendor_recommendations(db, vid)}


@router.get("/vendors/{vendor_id}/alternatives", tags=["vendors"])
def vendor_alternatives(vendor_id: str, limit: int = Query(6, ge=1, le=15), db: Session = Depends(get_db),
                        _: Principal = Depends(authenticate)):
    return alt_service.rank_alternatives(db, _vendor_or_404(db, vendor_id), limit)


@router.get("/vendors/{vendor_id}/relationships", tags=["vendors"])
def vendor_relationships(vendor_id: str, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    vid = _vendor_or_404(db, vendor_id)
    return {"neighbourhood": graph.neighbourhood(db, vid), "dependency": graph.supplier_dependency(db, vid),
            "relationships": graph.vendor_relationships(db, vid), "quality_issues": graph.quality_issues(db, vid, 10),
            "open_pos": graph.vendor_pos(db, vid, "Open", 10)}


# ------------------------------------------------------------------ analytics
@router.get("/analytics/performance", tags=["analytics"])
def performance(period: str | None = None, category: str | None = None, region: str | None = None,
                db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    return analytics.performance_analytics(db, period, category, region)


@router.post("/analytics/compare", tags=["analytics"])
def compare(body: CompareRequest, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    try:
        out = analytics.compare_vendors(db, body.vendor_ids)
    except analytics.VendorNotFound as exc:
        raise HTTPException(404, f"Vendor(s) not found: {exc}")
    for v in out["vendors"]:
        v["external_risk"] = risk_intel.vendor_external_risk(db, v["vendor_id"])["external_risk"]
    return out


# ------------------------------------------------------------------ copilot
@router.post("/copilot/chat", tags=["copilot"])
def chat(body: ChatRequest, db: Session = Depends(get_db), p: Principal = Depends(require("copilot"))):
    try:
        return copilot.ask(db, body.message, body.session_id, actor=p.user, role=p.role)
    except copilot.InputRejected as exc:
        raise HTTPException(422, str(exc))


@router.get("/copilot/sessions/{session_id}", tags=["copilot"])
def chat_history(session_id: str, _: Principal = Depends(authenticate)):
    return {"session_id": session_id, "history": copilot.sessions.history(session_id)}


@router.get("/copilot/suggestions", tags=["copilot"])
def suggestions(_: Principal = Depends(authenticate)):
    return {"suggestions": [
        "Which vendors are currently underperforming?", "Why is Vendor V1024 underperforming?",
        "What procurement action do you recommend?", "Find the best alternative supplier.",
        "Which vendors deteriorated the most this month?", "What is the SLA for Vendor V1024?",
        "Which products depend on V1024?", "Which vendors have strong quality but weak delivery?",
        "What does our supplier SLA policy say?", "Why is V1035's quality score low?"]}


# ------------------------------------------------------------------ knowledge
@router.get("/knowledge/documents", tags=["knowledge"])
def documents(_: Principal = Depends(authenticate)):
    return store.list_documents()


@router.get("/knowledge/documents/{document_id}", tags=["knowledge"])
def document(document_id: str, _: Principal = Depends(authenticate)):
    d = store.get_document(document_id.upper())
    if not d:
        raise HTTPException(404, "Document not found")
    return d


@router.get("/knowledge/search", tags=["knowledge"])
def knowledge_search(q: str = Query(min_length=3, max_length=300), document_type: str | None = None, category: str | None = None,
                     document_id: str | None = None, k: int = Query(6, ge=1, le=12), _: Principal = Depends(authenticate)):
    filters = {k2: v for k2, v in {"document_type": document_type, "category": category, "document_id": document_id}.items() if v}
    return store.search(q, k, filters or None)


@router.get("/knowledge/documents/{document_id}/source", tags=["knowledge"])
def document_source(document_id: str, _: Principal = Depends(require("configure"))):
    try:
        return policy_editor.read_source(document_id.upper())
    except LookupError:
        raise HTTPException(404, "Document not found")


def _policy_change(db: Session, p: Principal, res: dict, event: str, summary: str) -> dict:
    cache.semantic_cache.invalidate()
    audit(db, request_id="-", actor=p.user, event_type=event, entity_type="policy_document", entity_id=res["document_id"],
          summary=summary, details=res)
    return res


@router.post("/knowledge/documents", tags=["knowledge"])
def document_create(body: PolicyDocument, db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    try:
        res = policy_editor.save(None, body.model_dump(), p.user)
    except policy_editor.PolicyError as exc:
        raise HTTPException(422, str(exc))
    return _policy_change(db, p, res, "policy_created", f"Created {res['document_id']} '{res['title']}' v{res['to_version']}: {res['change_note']}")


@router.put("/knowledge/documents/{document_id}", tags=["knowledge"])
def document_update(document_id: str, body: PolicyDocument, db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    try:
        res = policy_editor.save(document_id.upper(), body.model_dump(), p.user)
    except LookupError:
        raise HTTPException(404, "Document not found")
    except policy_editor.PolicyError as exc:
        raise HTTPException(422, str(exc))
    return _policy_change(db, p, res, "policy_changed",
                          f"Updated {res['document_id']} v{res['from_version']} -> v{res['to_version']}: {res['change_note']}")


@router.delete("/knowledge/documents/{document_id}", tags=["knowledge"])
def document_archive(document_id: str, db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    try:
        res = policy_editor.archive(document_id.upper())
    except LookupError:
        raise HTTPException(404, "Document not found")
    except policy_editor.PolicyError as exc:
        raise HTTPException(422, str(exc))
    return _policy_change(db, p, res, "policy_archived", f"Archived {res['document_id']} '{res['title']}'")


@router.get("/knowledge/documents/{document_id}/history", tags=["knowledge"])
def document_history(document_id: str, _: Principal = Depends(require("configure"))):
    return {"document_id": document_id.upper(), "versions": policy_editor.history(document_id)}


@router.get("/knowledge/documents/{document_id}/history/{file}", tags=["knowledge"])
def document_history_version(document_id: str, file: str, _: Principal = Depends(require("configure"))):
    try:
        return policy_editor.history_version(document_id, file)
    except LookupError:
        raise HTTPException(404, "Version not found")


@router.post("/knowledge/ingest", tags=["knowledge"])
def knowledge_ingest(db: Session = Depends(get_db), p: Principal = Depends(require("seed"))):
    res = store.ingest()
    cache.semantic_cache.invalidate()
    audit(db, request_id="-", actor=p.user, event_type="knowledge_ingest", entity_type="knowledge", entity_id="all",
          summary=f"Ingested {res['chunks']} chunks ({res['policy_version']})", details=res)
    return res


# ------------------------------------------------------------------ graph
@router.get("/graph/status", tags=["graph"])
def graph_status(_: Principal = Depends(authenticate)):
    return {"available": graph_client.is_available(force=True), **graph_client.status()}


@router.post("/graph/ingest", tags=["graph"])
def graph_ingest(db: Session = Depends(get_db), p: Principal = Depends(require("seed"))):
    from app.graph.ingest import ingest
    res = ingest(db)
    cache.retrieval_cache.invalidate()
    audit(db, request_id="-", actor=p.user, event_type="graph_ingest", entity_type="graph", entity_id="all",
          summary=f"Graph ingestion {res.get('status')}", details=res)
    return res


# ------------------------------------------------------------------ governance
@router.get("/governance/audit", tags=["governance"])
def audit_log(event_type: str | None = None, entity_id: str | None = None, limit: int = Query(50, ge=1, le=500),
              db: Session = Depends(get_db), _: Principal = Depends(require("audit"))):
    stmt = select(AuditEvent).order_by(AuditEvent.ts.desc()).limit(limit)
    if event_type:
        stmt = stmt.where(AuditEvent.event_type == event_type)
    if entity_id:
        stmt = stmt.where(AuditEvent.entity_id == entity_id.upper())
    return [{"id": e.id, "ts": e.ts.isoformat(), "request_id": e.request_id, "actor": e.actor, "event_type": e.event_type,
             "entity_type": e.entity_type, "entity_id": e.entity_id, "summary": e.summary, "details": e.details}
            for e in db.execute(stmt).scalars()]


@router.get("/governance/recommendations", tags=["governance"])
def recommendations(status: str | None = None, limit: int = Query(50, ge=1, le=200), db: Session = Depends(get_db),
                    _: Principal = Depends(require("audit"))):
    stmt = select(Recommendation).order_by(Recommendation.created_at.desc()).limit(limit)
    if status:
        stmt = stmt.where(Recommendation.status == status)
    rows = [analytics.recommendation_dict(r) for r in db.execute(stmt).scalars()]
    counts = dict(db.execute(select(Recommendation.status, func.count()).group_by(Recommendation.status)).all())
    return {"items": rows, "counts": counts}


@router.post("/governance/recommendations/{rec_id}/decision", tags=["governance"])
def decide(rec_id: int, body: DecisionRequest, db: Session = Depends(get_db), p: Principal = Depends(require("approve"))):
    r = db.get(Recommendation, rec_id)
    if not r:
        raise HTTPException(404, "Recommendation not found")
    if r.status != "pending_approval":
        raise HTTPException(409, f"Recommendation is already {r.status}")
    r.status, r.decided_by, r.decided_at, r.decision_note = body.decision, p.user, datetime.now(timezone.utc), body.note
    audit(db, request_id=r.request_id, actor=p.user, event_type=f"recommendation_{body.decision}", entity_type="recommendation",
          entity_id=str(r.id), summary=f"{body.decision.title()}: {r.title} for {r.vendor_id}", details={"note": body.note})
    return analytics.recommendation_dict(r)


@router.get("/governance/model", tags=["governance"])
def model_info(db: Session = Depends(get_db), _: Principal = Depends(require("audit"))):
    from app.analytics.scoring import SCORING_MODEL_VERSION
    s = get_settings()
    return {"scoring": {"model_version": SCORING_MODEL_VERSION, "weights": runtime_settings.weights(db).as_dict(),
                        "method": "deterministic weighted scoring over rolling 3-month windows (docs/SCORING.md)"},
            "risk_model": risk_service.model_report(), "llm": {"provider": s.llm_provider if s.llm_configured else "none",
                                                               "configured": s.llm_configured, "routing": routing_table(),
                                                               "prompt_version": s.prompt_version},
            "llm_telemetry": gateway.telemetry.as_dict(), "cache": cache.stats(), "graph": graph_client.status(),
            "knowledge": {"chunks": store.count(), "policy_version": store.policy_version()},
            "guardrails": {"max_agent_steps": s.max_agent_steps, "max_llm_calls": s.max_llm_calls, "max_tool_calls": s.max_tool_calls,
                           "agent_timeout_seconds": s.agent_timeout_seconds, "graph_max_depth": s.graph_max_depth,
                           "max_query_chars": s.max_query_chars},
            "agent_graph_mermaid": mermaid()}


# ------------------------------------------------------------------ settings
@router.get("/settings", tags=["settings"])
def get_settings_view(db: Session = Depends(get_db), _: Principal = Depends(require("configure"))):
    s = get_settings()
    rt = runtime_settings.get_runtime(db)
    return {**{k: v for k, v in rt.items() if k != "data_version"},
            "llm": {"provider": s.llm_provider, "configured": s.llm_configured, "routing": routing_table(),
                    "embedding_provider": s.embedding_provider, "note": "Provider credentials are set in the server .env and never exposed to the browser."},
            "data_version": runtime_settings.data_version(db)}


@router.put("/settings", tags=["settings"])
def update_settings(body: SettingsUpdate, db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    changed, result = [], {}
    if body.weights:
        runtime_settings.set_section(db, "scoring", {"weights": body.weights.model_dump()})
        changed.append("weights")
    if body.risk:
        runtime_settings.set_section(db, "risk", body.risk.model_dump())
        changed.append("risk")
    if body.cache:
        runtime_settings.set_section(db, "cache", body.cache.model_dump())
        cache.configure(body.cache.enabled, body.cache.ttl_seconds, body.cache.semantic_threshold)
        changed.append("cache")
    if body.agent:
        runtime_settings.set_section(db, "agent", body.agent.model_dump())
        changed.append("agent")
    if body.demo_mode is not None:
        runtime_settings.set_section(db, "demo_mode", {"value": body.demo_mode})
        changed.append("demo_mode")
    audit(db, request_id="-", actor=p.user, event_type="settings_changed", entity_type="settings", entity_id="runtime",
          summary=f"Updated {', '.join(changed) or 'nothing'}", details=body.model_dump(exclude_none=True))
    if "weights" in changed or "risk" in changed:
        result = pipeline.rescore(db, reason="settings: " + ", ".join(changed), actor=p.user, weights_only=True)
    return {"changed": changed, "rescore": result, "settings": get_settings_view(db, p)}


# ------------------------------------------------------------------ data
_seed_job: dict = {"status": "idle"}


def _run_seed(body: SeedRequest, actor: str) -> None:
    _seed_job.update(status="running", started_at=time.time(), error=None, result=None)
    try:
        if body.regenerate:
            sys.path.insert(0, str(REPO_ROOT / "scripts"))
            from generate_data import generate
            generate(body.vendors)
        db = SessionLocal()
        try:
            res = pipeline.run_all(db, graph=body.graph, knowledge=body.knowledge, actor=actor, request_id="seed-job")
            db.commit()
        finally:
            db.close()
        _seed_job.update(status="completed", result=res, finished_at=time.time())
    except Exception as exc:  # surfaced via /data/seed/status
        log.exception("seed failed")
        _seed_job.update(status="failed", error=f"{type(exc).__name__}: {str(exc)[:300]}", finished_at=time.time())


@router.post("/data/seed", tags=["data"], status_code=202)
def seed(body: SeedRequest, p: Principal = Depends(require("seed"))):
    if _seed_job.get("status") == "running":
        raise HTTPException(409, "A seed job is already running")
    threading.Thread(target=_run_seed, args=(body, p.user), daemon=True).start()
    return {"status": "started", "poll": "/api/v1/data/seed/status"}


@router.get("/data/seed/status", tags=["data"])
def seed_status(_: Principal = Depends(authenticate)):
    return _seed_job


# ------------------------------------------------------------------ Trust Centre (responsible AI, FinOps, security)
@router.get("/trust/responsible-ai", tags=["trust"])
def trust_rai(db: Session = Depends(get_db), _: Principal = Depends(require("audit"))):
    return trust.responsible_ai(db)


@router.get("/trust/finops", tags=["trust"])
def trust_finops(db: Session = Depends(get_db), _: Principal = Depends(require("audit"))):
    return finops.summary(db)


@router.put("/trust/finops/budget", tags=["trust"])
def trust_budget(body: BudgetUpdate, db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    cfg = finops.save_budget(db, body.model_dump())
    audit(db, request_id="-", actor=p.user, event_type="settings_changed", entity_type="finops", entity_id="budget",
          summary=f"AI budget set to GBP {body.monthly_budget_gbp:.2f}/month (alert {body.alert_pct}%, hard stop {body.hard_stop})",
          details=body.model_dump())
    return finops.budget_status(db) | {"config": cfg}


@router.get("/finops/summary", tags=["finops"])
def finops_summary(db: Session = Depends(get_db), _: Principal = Depends(require("audit"))):
    """LLM token usage and cost (same data as the Trust Centre, served for the FinOps page)."""
    return finops.summary(db)


# ------------------------------------------------------------------ Business value
@router.get("/value/benefits", tags=["value"])
def value_benefits(scenario: str = "expected", db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    return value.benefits(db, scenario)


@router.put("/value/assumptions", tags=["value"])
def value_assumptions(body: ValueAssumptionsUpdate, db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    unknown = set(body.values) - set(value.DEFAULT_ASSUMPTIONS)
    if unknown:
        raise HTTPException(422, f"Unknown assumptions: {', '.join(sorted(unknown))}")
    saved = value.save_assumptions(db, body.values)
    runtime_settings.invalidate()
    audit(db, request_id="-", actor=p.user, event_type="settings_changed", entity_type="value", entity_id="assumptions",
          summary="Business value assumptions changed", details={"changed": body.values, "now": saved})
    return value.benefits(db)


@router.get("/trust/security", tags=["trust"])
def trust_security(db: Session = Depends(get_db), _: Principal = Depends(require("audit"))):
    return trust.security(db)


@router.post("/copilot/feedback", tags=["copilot"])
def copilot_feedback(body: FeedbackRequest, db: Session = Depends(get_db), p: Principal = Depends(require("copilot"))):
    audit(db, request_id=body.request_id, actor=p.user, event_type="ai_feedback", entity_type="copilot_answer", entity_id=body.request_id,
          summary=f"{'Helpful' if body.rating == 'up' else 'Not helpful'}: {(body.question or '')[:120]}",
          details={"rating": body.rating, "comment": body.comment, "question": body.question, "role": p.role})
    return {"recorded": True}


# ------------------------------------------------------------------ auth
@router.post("/auth/login", tags=["auth"])
def auth_login(body: LoginRequest, db: Session = Depends(get_db)):
    try:
        principal, token, exp = security.login(body.username, body.password)
    except security.LoginError as exc:
        guardrails.record(db, actor=body.username[:60], role="anonymous", request_id="-", verdict="block",
                          triggered=[{"layer": "access", "rule": "login_lockout" if exc.locked else "login_failed",
                                      "action": "block", "detail": str(exc)}])
        db.commit()
        raise HTTPException(423 if exc.locked else 401, str(exc))
    audit(db, request_id="-", actor=principal.user, event_type="login", entity_type="user", entity_id=principal.user,
          summary=f"{principal.display_name} signed in ({principal.role})", details={"role": principal.role})
    return {"token": token, "expires_at": exp, "user": principal.public()}


@router.get("/auth/me", tags=["auth"])
def auth_me(p: Principal = Depends(authenticate)):
    return p.public()


@router.get("/auth/roles", tags=["auth"])
def auth_roles():
    """Role -> permission matrix and the demo personas (no secrets)."""
    s = get_settings()
    return {"roles": [{"role": r, "label": security.ROLE_LABELS[r], "permissions": sorted(perms)} for r, perms in security.ROLE_PERMISSIONS.items()],
            "permissions": security.PERMISSION_LABELS, "auth_mode": s.auth_mode,
            "personas": [{"username": u.username, "display_name": u.display_name, "title": u.title, "role": u.role}
                         for u in security.users().values()] if s.demo_mode else []}


# ------------------------------------------------------------------ guardrails
@router.get("/guardrails", tags=["guardrails"])
def guardrails_view(db: Session = Depends(get_db), _: Principal = Depends(require("configure"))):
    cfg = guardrails.config(db)
    return {"config": cfg, "catalogue": guardrails.catalogue(cfg), "stats": guardrails.stats(db),
            "injection_patterns": [n for n, _ in guardrails.INJECTION_PATTERNS], "pii_types": [n for n, _, _ in guardrails.PII_PATTERNS],
            "injection_rules": [{"name": n, "label": guardrails.INJECTION_LABELS[n][0], "example": guardrails.INJECTION_LABELS[n][1]}
                                for n, _ in guardrails.INJECTION_PATTERNS],
            "pii_rules": [{"name": n, "label": guardrails.PII_LABELS[n], "token": t} for n, _, t in guardrails.PII_PATTERNS],
            "roles": auth_roles()}


@router.put("/guardrails", tags=["guardrails"])
def guardrails_update(body: GuardrailUpdate, db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    if body.input:
        bad = (set(body.input.disabled_injection_rules) - {n for n, _ in guardrails.INJECTION_PATTERNS}) | \
              (set(body.input.disabled_pii_types) - {n for n, _, _ in guardrails.PII_PATTERNS})
        ids = [r.id for r in body.input.custom_rules]
        if bad:
            raise HTTPException(422, f"Unknown rule(s): {', '.join(sorted(bad))}")
        if len(ids) != len(set(ids)):
            raise HTTPException(422, "Custom rule ids must be unique")
    cfg = guardrails.save(db, body.input.model_dump() if body.input else None, body.output.model_dump() if body.output else None,
                          body.agent.model_dump() if body.agent else None)
    audit(db, request_id="-", actor=p.user, event_type="settings_changed", entity_type="guardrails", entity_id="runtime",
          summary="Updated guardrails: " + ", ".join(k for k in ("input", "output", "agent") if getattr(body, k)),
          details=body.model_dump(exclude_none=True))
    return {"config": cfg, "catalogue": guardrails.catalogue(cfg)}


@router.post("/guardrails/reset", tags=["guardrails"])
def guardrails_reset(db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    cfg = guardrails.reset(db)
    audit(db, request_id="-", actor=p.user, event_type="settings_changed", entity_type="guardrails", entity_id="runtime",
          summary="Reset AI safety rules to defaults", details={"input": cfg["input"], "output": cfg["output"]})
    return {"config": cfg, "catalogue": guardrails.catalogue(cfg)}


@router.post("/guardrails/test", tags=["guardrails"])
def guardrails_test(body: GuardrailTest, db: Session = Depends(get_db), _: Principal = Depends(require("configure"))):
    """Dry-run a question against the input guardrails (nothing is sent to agents or models)."""
    res = guardrails.check_input(body.text, guardrails.config(db), consume_rate=False)
    return {**res, "message": guardrails.block_message(res) if res["verdict"] == "block" else
            ("Allowed with warnings - personal data is redacted / suspicious patterns are logged." if res["verdict"] == "flag" else "Allowed.")}


# ------------------------------------------------------------------ Model Lab
@router.get("/ml/algorithms", tags=["model-lab"])
def ml_algorithms(_: Principal = Depends(require("configure"))):
    return model_lab.algorithms()


@router.get("/ml/dataset", tags=["model-lab"])
def ml_dataset(drop_points: float = Query(6.0, ge=2, le=20), test_periods: int = Query(1, ge=1, le=2),
               db: Session = Depends(get_db), _: Principal = Depends(require("configure"))):
    return model_lab.dataset(db, drop_points, test_periods)


@router.post("/ml/train", tags=["model-lab"])
def ml_train(body: TrainRequest, db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    return model_lab.train(db, [c.model_dump() for c in body.candidates], body.drop_points, body.test_periods, p.user)


@router.get("/ml/runs", tags=["model-lab"])
def ml_runs(db: Session = Depends(get_db), _: Principal = Depends(require("configure"))):
    active = model_lab.active_config(db)
    return {"runs": model_lab.runs(db), "active": active}


@router.post("/ml/runs/{run_id}/promote", tags=["model-lab"])
def ml_promote(run_id: int, db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    try:
        return model_lab.promote(db, run_id, p.user)
    except LookupError:
        raise HTTPException(404, "Run not found")
    except ValueError as exc:
        raise HTTPException(409, str(exc))


@router.post("/ml/reset", tags=["model-lab"])
def ml_reset(db: Session = Depends(get_db), p: Principal = Depends(require("configure"))):
    return model_lab.reset_to_default(db, p.user)


@router.post("/ml/anomaly", tags=["model-lab"])
def ml_anomaly(body: AnomalyRequest, db: Session = Depends(get_db), _: Principal = Depends(require("configure"))):
    return model_lab.anomaly_lab(db, body.contamination, body.n_estimators)


# ------------------------------------------------------------------ secondary: proactive supplier-risk intelligence
@router.get("/risk-intel/events", tags=["proactive-risk (secondary)"])
def risk_events(db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    return risk_intel.list_events(db)


@router.get("/risk-intel/events/{event_id}/impact", tags=["proactive-risk (secondary)"])
def risk_event_impact(event_id: str, db: Session = Depends(get_db), _: Principal = Depends(authenticate)):
    try:
        return risk_intel.event_impact(db, event_id)
    except LookupError:
        raise HTTPException(404, "Event not found")
