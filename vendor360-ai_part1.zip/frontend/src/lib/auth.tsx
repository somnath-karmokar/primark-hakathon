import * as React from "react";
import { useQueryClient } from "@tanstack/react-query";
import { api, setAuthToken } from "@/lib/api";

export type Permission = "read" | "copilot" | "audit" | "approve" | "configure" | "seed";
export interface AuthUser {
  username: string; role: "business" | "staff" | "admin"; role_label: string; display_name: string; title: string;
  permissions: Permission[]; menus: string[]; auth_mode: string;
}

const KEY = "vendor360.session";

interface Ctx {
  user: AuthUser | null;
  ready: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  can: (p: Permission) => boolean;
  sees: (menu: string) => boolean;
}
const AuthContext = React.createContext<Ctx | null>(null);

function readStored(): { token: string; user: AuthUser; expires_at: number } | null {
  try {
    const v = JSON.parse(sessionStorage.getItem(KEY) ?? "null");
    return v && v.expires_at * 1000 > Date.now() ? v : null;
  } catch { return null; }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const qc = useQueryClient();
  const [user, setUser] = React.useState<AuthUser | null>(() => {
    const s = readStored();
    if (s) setAuthToken(s.token);
    return s?.user ?? null;
  });
  const [ready, setReady] = React.useState(false);

  const logout = React.useCallback(() => {
    try { sessionStorage.removeItem(KEY); } catch { /* storage unavailable */ }
    setAuthToken(null);
    setUser(null);
    qc.clear();
  }, [qc]);

  React.useEffect(() => {
    // Validate a stored session (and support AUTH_MODE=demo where no token is needed).
    const probe = readStored()
      ? Promise.resolve(true)
      : api.get<{ auth_mode: string }>("/health").then((h) => h.auth_mode === "demo").catch(() => false);
    probe.then((check) => check ? api.get<AuthUser>("/auth/me").then((u) => setUser(u)) : undefined)
      .catch(() => { if (!readStored()) setUser(null); })
      .finally(() => setReady(true));
    const onExpired = () => logout();
    window.addEventListener("vendor360:auth-expired", onExpired);
    return () => window.removeEventListener("vendor360:auth-expired", onExpired);
  }, [logout]);

  const login = React.useCallback(async (username: string, password: string) => {
    const r = await api.post<{ token: string; expires_at: number; user: AuthUser }>("/auth/login", { username, password });
    setAuthToken(r.token);
    try { sessionStorage.setItem(KEY, JSON.stringify(r)); } catch { /* storage unavailable - session lasts for this tab only */ }
    qc.clear();
    setUser(r.user);
  }, [qc]);

  const can = React.useCallback((p: Permission) => !!user?.permissions.includes(p), [user]);
  const sees = React.useCallback((m: string) => !!user?.menus?.includes(m), [user]);
  return <AuthContext.Provider value={{ user, ready, login, logout, can, sees }}>{children}</AuthContext.Provider>;
}

export function useAuth(): Ctx {
  const c = React.useContext(AuthContext);
  if (!c) throw new Error("useAuth must be used inside AuthProvider");
  return c;
}
