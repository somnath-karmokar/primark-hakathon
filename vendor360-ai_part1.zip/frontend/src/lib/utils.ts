import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import type { Band, RiskLevel } from "@/types/api";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const BAND_COLOR: Record<Band, string> = {
  Excellent: "#1f8a4c", Good: "#0a8fc4", Watch: "#eaa400", "At Risk": "#dd5a24", Critical: "#a8223d",
};
export const BAND_ORDER: Band[] = ["Excellent", "Good", "Watch", "At Risk", "Critical"];
export const BAND_RANGE: Record<Band, string> = {
  Excellent: "90-100", Good: "75-89", Watch: "60-74", "At Risk": "40-59", Critical: "0-39",
};

export function bandOf(score: number): Band {
  const s = Math.round(score * 10) / 10;
  return s >= 90 ? "Excellent" : s >= 75 ? "Good" : s >= 60 ? "Watch" : s >= 40 ? "At Risk" : "Critical";
}

export const RISK_COLOR: Record<string, string> = {
  High: "#a8223d", Medium: "#dd5a24", Low: "#1f8a4c", None: "#8496ab", Unknown: "#8496ab",
};
export function riskTone(r: RiskLevel | string | null | undefined) {
  return r === "High" ? "critical" : r === "Medium" ? "warning" : r === "Low" ? "good" : "neutral";
}

/** Categorical slots for comparing up to 5 vendors (validated reference order). */
export const SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"];

export const COMPONENTS = [
  { key: "delivery", label: "Delivery", short: "DEL" },
  { key: "quality", label: "Quality", short: "QUA" },
  { key: "cost", label: "Cost", short: "CST" },
  { key: "lead_time", label: "Lead-time reliability", short: "LT" },
] as const;

export const fmt = {
  score: (n: number | null | undefined) => (n == null ? "-" : n.toFixed(1)),
  int: (n: number | null | undefined) => (n == null ? "-" : Math.round(n).toLocaleString("en-GB")),
  pct: (n: number | null | undefined, d = 1) => (n == null ? "-" : `${n.toFixed(d)}%`),
  delta: (n: number | null | undefined, d = 1) => (n == null ? "-" : `${n > 0 ? "+" : ""}${n.toFixed(d)}`),
  gbp: (n: number | null | undefined) =>
    n == null ? "-" : n >= 1_000_000 ? `£${(n / 1_000_000).toFixed(2)}m` : n >= 1000 ? `£${(n / 1000).toFixed(1)}k` : `£${n.toFixed(0)}`,
  month: (iso: string) => new Date(iso + "T00:00:00").toLocaleDateString("en-GB", { month: "short", year: "2-digit" }),
  date: (iso: string) => new Date(iso).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }),
  datetime: (iso: string) => new Date(iso).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }),
};

/** Render the copilot's light markdown (bold, italics, [E1] citations) safely - no HTML injection. */
export function mdSegments(text: string): { t: string; kind: "text" | "bold" | "em" | "cite" }[] {
  const out: { t: string; kind: "text" | "bold" | "em" | "cite" }[] = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\[[A-Z]{1,2}\d{1,2}\])/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push({ t: text.slice(last, m.index), kind: "text" });
    const s = m[0];
    if (s.startsWith("**")) out.push({ t: s.slice(2, -2), kind: "bold" });
    else if (s.startsWith("[")) out.push({ t: s.slice(1, -1), kind: "cite" });
    else out.push({ t: s.slice(1, -1), kind: "em" });
    last = m.index + s.length;
  }
  if (last < text.length) out.push({ t: text.slice(last), kind: "text" });
  return out;
}
