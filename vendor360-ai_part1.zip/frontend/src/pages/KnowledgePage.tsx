import * as React from "react";
import { useSearchParams } from "react-router-dom";
import { BookOpen, FileText, Search } from "lucide-react";
import { useDocument, useDocuments, useKnowledgeSearch } from "@/hooks/queries";
import { EmptyState, ErrorState, LoadingCard, PageHeader } from "@/components/domain";
import { Badge, Card, CardBody, CardHeader, Input, NativeSelect, Skeleton } from "@/components/ui/primitives";
import { cn, fmt } from "@/lib/utils";

const TYPE_TONE: Record<string, "brand" | "good" | "warning" | "neutral" | "serious"> = { policy: "brand", sla: "good", standard: "warning", guideline: "neutral", contract: "serious" };

/** Minimal, safe markdown renderer for the policy documents (headings, lists, tables, paragraphs). */
function Markdown({ md, highlight }: { md: string; highlight?: string }) {
  const blocks = md.split(/\n\s*\n/);
  return (
    <div className="space-y-3 text-[13px] leading-relaxed text-ink-800">
      {blocks.map((b, i) => {
        const t = b.trim();
        if (t.startsWith("## ") || t.startsWith("### ")) {
          const [h, ...rest] = t.split("\n");
          const title = h.replace(/^#+\s*/, "");
          const hit = highlight && title.toLowerCase().includes(highlight.toLowerCase());
          return (
            <div key={i} id={title} className={cn(hit && "-mx-3 rounded-lg bg-brand-50 px-3 py-2 ring-1 ring-brand-200")}>
              <h3 className="mt-2 text-[14px] font-semibold text-ink-950">{title}</h3>
              {rest.length > 0 && <Markdown md={rest.join("\n")} />}
            </div>
          );
        }
        if (t.startsWith("# ")) return <h2 key={i} className="text-[18px] font-bold">{t.slice(2)}</h2>;
        if (t.startsWith("|")) {
          const rows = t.split("\n").filter((r) => !/^\|\s*-/.test(r)).map((r) => r.split("|").slice(1, -1).map((c) => c.trim()));
          return (
            <div key={i} className="overflow-x-auto"><table className="w-full text-[12.5px]">
              <thead><tr>{rows[0].map((c) => <th key={c} className="border-b border-ink-200 bg-ink-50 px-2.5 py-1.5 text-left font-semibold">{c}</th>)}</tr></thead>
              <tbody>{rows.slice(1).map((r, j) => <tr key={j}>{r.map((c, k) => <td key={k} className="border-b border-ink-100 px-2.5 py-1.5">{c}</td>)}</tr>)}</tbody>
            </table></div>
          );
        }
        if (/^(\d+\.|-)\s/.test(t)) return <ul key={i} className="ml-4 list-disc space-y-1">{t.split("\n").map((l, j) => <li key={j}>{l.replace(/^(\d+\.|-)\s/, "")}</li>)}</ul>;
        return <p key={i}>{t}</p>;
      })}
    </div>
  );
}

export default function KnowledgePage() {
  const [sp, setSp] = useSearchParams();
  const docId = sp.get("doc") ?? undefined;
  const [q, setQ] = React.useState("");
  const [dq, setDq] = React.useState("");
  const [type, setType] = React.useState("");
  React.useEffect(() => { const t = setTimeout(() => setDq(q), 300); return () => clearTimeout(t); }, [q]);
  const { data: docs, isLoading, error } = useDocuments();
  const { data: doc, isLoading: docLoading } = useDocument(docId ?? docs?.[0]?.document_id);
  const { data: hits, isFetching } = useKnowledgeSearch(dq, type || undefined);
  const [highlight, setHighlight] = React.useState<string>();

  const open = (id: string, section?: string) => { setSp({ doc: id }); setHighlight(section); setTimeout(() => section && document.getElementById(section)?.scrollIntoView({ behavior: "smooth", block: "center" }), 250); };

  return (
    <>
      <PageHeader eyebrow="Policies & contracts" title="Procurement policies, contracts and standards"
        description="Search the rules the AI assistant relies on: procurement policy, delivery targets (SLAs), quality standards and contract terms." />
      {error ? <ErrorState error={error} /> : (
        <div className="grid gap-4 xl:grid-cols-12">
          <div className="space-y-4 xl:col-span-4">
            <Card>
              <CardHeader title="Search" subtitle="Type a question or topic - results match meaning, not just words" icon={<Search className="h-4 w-4 text-brand-500" />} />
              <CardBody className="space-y-2">
                <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="e.g. late delivery penalty, quality checks, backup supplier rules" aria-label="Search knowledge" />
                <NativeSelect value={type} onChange={(e) => setType(e.target.value)} aria-label="Document type" className="w-full">
                  <option value="">All document types</option>{["policy", "sla", "standard", "guideline", "contract"].map((t) => <option key={t} value={t}>{t}</option>)}
                </NativeSelect>
                {dq.length >= 3 && (
                  <div className="space-y-2 pt-1">
                    <div className="flex justify-between text-[11px] text-ink-400"><span>{isFetching ? "Searching..." : `${hits?.results.length ?? 0} passages`}</span><span>{hits?.embedding_model}{hits?.cache_hit && " · cached"}</span></div>
                    {hits?.results.map((h) => (
                      <button key={h.id} onClick={() => open(h.metadata.document_id, h.metadata.section)} className="w-full rounded-lg border border-ink-100 p-2.5 text-left hover:border-brand-300 hover:bg-brand-50/30">
                        <div className="flex items-center justify-between gap-2"><span className="truncate text-[12px] font-semibold">{h.metadata.section}</span><span className="num text-[11px] text-ink-400">{h.score.toFixed(2)}</span></div>
                        <div className="text-[11px] text-ink-500">{h.metadata.title} · v{h.metadata.policy_version}</div>
                        <p className="mt-1 line-clamp-3 text-[12px] text-ink-700">{h.text.split("\n").slice(1).join(" ")}</p>
                      </button>
                    ))}
                  </div>
                )}
              </CardBody>
            </Card>
            <Card>
              <CardHeader title="Documents" subtitle={docs ? `${docs.length} documents indexed` : ""} icon={<BookOpen className="h-4 w-4 text-brand-500" />} />
              <CardBody className="space-y-1.5">
                {isLoading && <Skeleton className="h-40 w-full" />}
                {docs?.map((d) => (
                  <button key={d.document_id} onClick={() => open(d.document_id)} className={cn("w-full rounded-lg border px-3 py-2 text-left transition-colors", (docId ?? docs[0].document_id) === d.document_id ? "border-brand-300 bg-brand-50/50" : "border-ink-100 hover:bg-ink-50")}>
                    <div className="flex items-center justify-between gap-2"><span className="flex items-center gap-2 text-[12.5px] font-semibold"><FileText className="h-3.5 w-3.5 text-ink-400" />{d.title}</span><Badge tone={TYPE_TONE[d.document_type] ?? "neutral"}>{d.document_type}</Badge></div>
                    <div className="mt-0.5 text-[11px] text-ink-500">{d.document_id} · v{d.policy_version} · effective {fmt.date(d.effective_date)} · {d.sections?.length} sections</div>
                  </button>
                ))}
              </CardBody>
            </Card>
          </div>
          <div className="xl:col-span-8">
            {docLoading || !doc ? <LoadingCard h="h-[520px]" /> : (
              <Card>
                <div className="border-b border-ink-100 px-6 py-4">
                  <div className="flex flex-wrap items-center gap-2"><Badge tone={TYPE_TONE[doc.document_type] ?? "neutral"}>{doc.document_type}</Badge><Badge>{doc.document_id}</Badge><Badge>v{doc.policy_version}</Badge><Badge>effective {fmt.date(doc.effective_date)}</Badge><Badge>{doc.chunks.length} chunks</Badge></div>
                  <h2 className="mt-2 text-[20px] font-bold">{doc.title}</h2>
                  <p className="text-[11.5px] text-ink-500">Source: {doc.source} · {doc.file}</p>
                </div>
                <CardBody className="max-h-[70vh] overflow-y-auto px-6 py-5 scrollbar-thin">
                  {doc.markdown ? <Markdown md={doc.markdown} highlight={highlight} /> : <EmptyState title="Empty document" />}
                </CardBody>
              </Card>
            )}
          </div>
        </div>
      )}
    </>
  );
}
