import * as React from "react";
import { Link, useSearchParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowUp, Bot, BrainCircuit, CheckCircle2, ChevronRight, CircleAlert, Cpu, Database, FileSearch, Gauge, Lightbulb, Network,
  RotateCcw, ShieldCheck, Sparkles, ThumbsDown, ThumbsUp, User, XCircle, Zap,
} from "lucide-react";
import { useChat, useFeedback, useSuggestions } from "@/hooks/queries";
import { useAuth } from "@/lib/auth";
import { BandBadge, EmptyState, SourcePill } from "@/components/domain";
import { Badge, Button, Card, Tabs, TabsContent, TabsList, TabsTrigger, Tip } from "@/components/ui/primitives";
import { cn, fmt, mdSegments } from "@/lib/utils";
import type { CopilotResponse, Evidence } from "@/types/api";

type Msg = { role: "user"; text: string } | { role: "assistant"; res: CopilotResponse } | { role: "error"; text: string };
const STORE = "vendor360.copilot";

const AGENT_STEPS = [
  { id: "supervisor", label: "Understand", icon: BrainCircuit, desc: "Working out what you're asking" },
  { id: "performance", label: "Scores", icon: Gauge, desc: "Checking scores and performance figures" },
  { id: "risk", label: "Warning signs", icon: Zap, desc: "Looking for signs of decline" },
  { id: "knowledge", label: "Policies", icon: FileSearch, desc: "Reading policies and supplier links" },
  { id: "recommendation", label: "Actions", icon: Lightbulb, desc: "Applying the escalation policy" },
  { id: "synthesizer", label: "Write", icon: Sparkles, desc: "Writing the answer from the facts" },
  { id: "governance", label: "Check", icon: ShieldCheck, desc: "Checking every figure against the facts" },
];

function load(): { session?: string; msgs: Msg[] } {
  try { return JSON.parse(sessionStorage.getItem(STORE) ?? "") as { session?: string; msgs: Msg[] }; } catch { return { msgs: [] }; }
}

function Answer({ text, onCite }: { text: string; onCite: (id: string) => void }) {
  return (
    <p className="prose-answer text-[13.5px] leading-relaxed text-ink-800">
      {mdSegments(text).map((s, i) => s.kind === "bold" ? <strong key={i}>{s.t}</strong>
        : s.kind === "em" ? <em key={i}>{s.t}</em>
        : s.kind === "cite" ? <button key={i} onClick={() => onCite(s.t)} className="num mx-0.5 rounded bg-brand-50 px-1 text-[11px] font-semibold text-brand-700 ring-1 ring-inset ring-brand-200 hover:bg-brand-100">{s.t}</button>
        : <React.Fragment key={i}>{s.t}</React.Fragment>)}
    </p>
  );
}

function Running() {
  const [i, setI] = React.useState(0);
  React.useEffect(() => { const t = setInterval(() => setI((x) => Math.min(x + 1, AGENT_STEPS.length - 1)), 420); return () => clearInterval(t); }, []);
  return (
    <div className="rounded-xl border border-brand-100 bg-brand-50/40 p-3">
      <div className="mb-2 flex items-center gap-2 text-[12px] font-semibold text-brand-700"><span className="h-2 w-2 animate-pulse-dot rounded-full bg-brand-500" />The AI assistant is working...</div>
      <div className="flex flex-wrap gap-1.5">
        {AGENT_STEPS.map((s, j) => (
          <span key={s.id} className={cn("inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium transition-all",
            j < i ? "bg-white text-ink-600 ring-1 ring-ink-100" : j === i ? "bg-brand-500 text-white shadow-sm" : "text-ink-400")}>
            <s.icon className="h-3 w-3" />{s.label}
          </span>
        ))}
      </div>
      <div className="mt-2 text-[11.5px] text-ink-500">{AGENT_STEPS[i].desc}</div>
    </div>
  );
}

function Feedback({ res }: { res: CopilotResponse }) {
  const fb = useFeedback();
  const [rated, setRated] = React.useState<"up" | "down" | null>(null);
  const [comment, setComment] = React.useState("");
  const [asking, setAsking] = React.useState(false);
  const send = (rating: "up" | "down", c?: string) => {
    fb.mutate({ request_id: res.request_id, rating, comment: c, question: res.question }, { onSuccess: () => { setRated(rating); setAsking(false); } });
  };
  if (rated) return <span className="ml-auto text-[11.5px] text-ink-500">Thanks for the feedback</span>;
  return (
    <span className="ml-auto flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
      {asking ? (
        <form className="flex items-center gap-1" onSubmit={(e) => { e.preventDefault(); send("down", comment); }}>
          <input autoFocus value={comment} onChange={(e) => setComment(e.target.value)} maxLength={500} placeholder="What was wrong? (optional)"
            className="h-7 w-52 rounded-md border border-ink-200 px-2 text-[11.5px] focus:border-brand-400 focus:outline-none" />
          <Button size="sm" variant="outline" type="submit" className="h-7">Send</Button>
        </form>
      ) : (
        <>
          <span className="text-[11px] text-ink-400">Helpful?</span>
          <button onClick={() => send("up")} className="rounded p-1 text-ink-400 hover:bg-emerald-50 hover:text-emerald-700" aria-label="Helpful"><ThumbsUp className="h-3.5 w-3.5" /></button>
          <button onClick={() => setAsking(true)} className="rounded p-1 text-ink-400 hover:bg-rose-50 hover:text-rose-700" aria-label="Not helpful"><ThumbsDown className="h-3.5 w-3.5" /></button>
        </>
      )}
    </span>
  );
}

function AssistantMessage({ res, active, onSelect, onCite, onAsk }: { res: CopilotResponse; active: boolean; onSelect: () => void; onCite: (id: string) => void; onAsk: (q: string) => void }) {
  const rec = res.recommendation;
  const conf = Math.round(res.confidence * 100);
  return (
    <div className={cn("rounded-2xl border bg-white p-4 shadow-card transition-all", active ? "border-brand-300 ring-2 ring-brand-100" : "border-ink-100")} onClick={onSelect}>
      <div className="mb-2 flex flex-wrap items-center gap-1.5">
        <Badge tone={res.mode === "llm" ? "brand" : "neutral"}>{res.mode === "llm" ? <><Cpu className="h-3 w-3" />{res.model}</> : <><Database className="h-3 w-3" />Fact-based summary</>}</Badge>
        {res.mode !== "llm" && res.fallback_reason && <Tip content={res.fallback_reason}><span className="text-[11px] text-ink-400 underline decoration-dotted">why?</span></Tip>}
        <Badge tone="neutral">{res.intent.replace(/_/g, " ")}</Badge>
        {res.vendor_id && <Link to={`/vendors/${res.vendor_id}`} onClick={(e) => e.stopPropagation()}><Badge tone="dark">{res.vendor_id}</Badge></Link>}
        {res.mode === "llm" && <Tip content="Written by an AI model from checked facts. Check key figures before acting."><Badge tone="warning"><Sparkles className="h-3 w-3" />AI-written</Badge></Tip>}
        {res.cache.semantic_hit && <Badge tone="good">instant answer (asked before)</Badge>}
        <span className="ml-auto text-[11px] text-ink-400">{(res.latency_ms / 1000).toFixed(1)}s</span>
      </div>
      <Answer text={res.answer} onCite={onCite} />
      {res.metrics.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {res.metrics.map((m) => (
            <span key={m.label} className="inline-flex items-center gap-1.5 rounded-lg bg-ink-50 px-2 py-1 text-[11.5px]">
              <span className="text-ink-500">{m.label}</span><span className="num font-semibold text-ink-900">{typeof m.value === "number" ? (m.unit === "pts" ? fmt.delta(m.value) : m.value.toFixed(1)) : m.value}</span>
              {m.band && <BandBadge band={m.band} />}{m.detail && <span className="text-ink-400">{m.detail}</span>}
            </span>
          ))}
        </div>
      )}
      {res.reasoning.length > 0 && (
        <div className="mt-3">
          <div className="eyebrow mb-1">Why</div>
          <ul className="space-y-1">{res.reasoning.map((r, i) => <li key={i} className="flex gap-2 text-[12.5px] text-ink-700"><ChevronRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-500" /><Answer text={r} onCite={onCite} /></li>)}</ul>
        </div>
      )}
      {rec && (
        <div className="mt-3 overflow-hidden rounded-xl border border-ink-200">
          <div className="flex items-center justify-between gap-2 bg-ink-950 px-3.5 py-2.5 text-white">
            <div><div className="text-[10px] font-semibold uppercase tracking-wider text-brand-300">Recommended action · step {rec.stage} of 4</div><div className="font-display text-[14px] font-semibold">{rec.title}</div></div>
            <Badge tone={rec.status === "pending_approval" ? "warning" : "good"}>{rec.status === "pending_approval" ? "Needs approval" : "No approval needed"}</Badge>
          </div>
          <div className="space-y-2 p-3.5 text-[12.5px]">
            <ol className="space-y-1">{rec.steps.slice(0, 4).map((s, i) => <li key={i} className="flex gap-2"><span className="num font-semibold text-brand-600">{i + 1}.</span>{s}</li>)}</ol>
            {rec.alternatives.length > 0 && (
              <div className="grid gap-1.5 sm:grid-cols-3">
                {rec.alternatives.map((a, i) => (
                  <Link key={a.vendor_id} to={`/vendors/${a.vendor_id}`} onClick={(e) => e.stopPropagation()} className={cn("rounded-lg border px-2.5 py-2 hover:border-brand-300", i === 0 && a.eligible ? "border-emerald-200 bg-emerald-50/50" : "border-ink-100")}>
                    <div className="flex items-center justify-between"><span className="num font-semibold">{a.vendor_id}</span><span className="num font-semibold">{a.overall.toFixed(1)}</span></div>
                    <div className="truncate text-[11px] text-ink-500">{a.name}</div>
                    <div className="mt-0.5 text-[10.5px] text-ink-500">fit {a.fit_score.toFixed(1)} · {a.product_overlap_pct.toFixed(0)}% overlap · {a.eligible ? <span className="text-emerald-700">eligible</span> : <span className="text-amber-700">not eligible</span>}</div>
                  </Link>
                ))}
              </div>
            )}
            <div className="flex flex-wrap items-center gap-1 pt-1 text-[11px] text-ink-500">Policy {rec.policy_refs.map((r) => <Badge key={r} tone="brand">{r}</Badge>)}<span className="ml-auto">Approved by: {rec.approver}</span></div>
          </div>
        </div>
      )}
      <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-ink-100 pt-2.5 text-[11.5px]">
        <span className="flex items-center gap-1.5">How sure
          <span className="h-1.5 w-16 rounded-full bg-ink-100"><span className={cn("block h-1.5 rounded-full", conf >= 80 ? "bg-emerald-500" : conf >= 60 ? "bg-amber-500" : "bg-rose-500")} style={{ width: `${conf}%` }} /></span>
          <span className="num font-semibold">{conf}%</span><span className="text-ink-400">({res.confidence_label})</span></span>
        <span className="flex items-center gap-1">{res.governance.status === "passed" ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" /> : <CircleAlert className="h-3.5 w-3.5 text-amber-600" />}{res.governance.status === "passed" ? "All checks passed" : "Some checks need attention"}</span>
        <span className="text-ink-500">{res.evidence.length} facts · {res.sources.length} policy quotes</span>
        <Feedback res={res} />
        <button onClick={(e) => { e.stopPropagation(); onSelect(); }} className="font-medium text-brand-600 hover:text-brand-700">See the facts →</button>
      </div>
      {res.suggested_followups.length > 0 && (
        <div className="mt-2.5 flex flex-wrap gap-1.5">{res.suggested_followups.map((q) => (
          <button key={q} onClick={(e) => { e.stopPropagation(); onAsk(q); }} className="rounded-full border border-ink-200 bg-white px-2.5 py-1 text-[11.5px] text-ink-700 hover:border-brand-300 hover:text-brand-700">{q}</button>))}</div>
      )}
    </div>
  );
}

function EvidenceValue({ v }: { v: unknown }) {
  if (typeof v === "string") return <p className="whitespace-pre-line text-[12px] text-ink-700">{v}</p>;
  if (Array.isArray(v)) return <ul className="space-y-0.5 text-[11.5px] text-ink-700">{v.map((x, i) => <li key={i} className="num">{typeof x === "object" ? Object.entries(x as object).map(([k, val]) => `${k}: ${Array.isArray(val) ? val.join(", ") : val}`).join(" · ") : String(x)}</li>)}</ul>;
  if (v && typeof v === "object") return (
    <dl className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11.5px]">
      {Object.entries(v as Record<string, unknown>).filter(([, x]) => x != null && x !== "").slice(0, 14).map(([k, x]) => (
        <React.Fragment key={k}><dt className="truncate text-ink-500">{k.replace(/_/g, " ")}</dt><dd className="num truncate text-right font-medium text-ink-800">{typeof x === "object" ? JSON.stringify(x).slice(0, 60) : String(x)}</dd></React.Fragment>))}
    </dl>
  );
  return <span>{String(v)}</span>;
}

function EvidencePanel({ res, focus }: { res?: CopilotResponse; focus?: string }) {
  const { can } = useAuth();
  const refs = React.useRef<Record<string, HTMLDivElement | null>>({});
  React.useEffect(() => { if (focus) refs.current[focus]?.scrollIntoView({ behavior: "smooth", block: "center" }); }, [focus]);
  if (!res) return <Card className="h-full"><EmptyState icon={FileSearch} title="The facts behind each answer appear here" hint="Every answer shows the figures, policy quotes and checks it is based on." /></Card>;
  const g = res.governance;
  return (
    <Card className="flex h-full flex-col overflow-hidden">
      <Tabs defaultValue="evidence" className="flex min-h-0 flex-1 flex-col">
        <div className="border-b border-ink-100 px-3 py-2.5"><TabsList className="w-full justify-between">
          <TabsTrigger value="evidence">Facts</TabsTrigger><TabsTrigger value="sources">Policies</TabsTrigger><TabsTrigger value="graph">Links</TabsTrigger>
          <TabsTrigger value="trace">How it worked</TabsTrigger><TabsTrigger value="gov">Checks</TabsTrigger></TabsList></div>
        <div className="min-h-0 flex-1 overflow-y-auto p-3 scrollbar-thin">
          <TabsContent value="evidence" className="space-y-2">
            {res.evidence.length === 0 && <EmptyState icon={FileSearch} title="No evidence gathered" hint="This question was outside the copilot's scope, so no agent ran and nothing was claimed." />}
            {res.evidence.map((e: Evidence) => (
              <div key={e.id} ref={(el) => { refs.current[e.id] = el; }} className={cn("rounded-lg border p-2.5 transition-colors", focus === e.id ? "border-brand-400 bg-brand-50/60" : res.cited_evidence.includes(e.id) ? "border-ink-200" : "border-ink-100 opacity-80")}>
                <div className="mb-1 flex items-center gap-1.5"><span className="num rounded bg-ink-900 px-1.5 text-[10.5px] font-bold text-white">{e.id}</span><span className="flex-1 truncate text-[12px] font-semibold text-ink-900">{e.title}</span><SourcePill source={e.source} /></div>
                <EvidenceValue v={e.value} />
                {e.ref && <div className="mt-1 text-[10.5px] text-ink-400">ref {e.ref}</div>}
              </div>
            ))}
          </TabsContent>
          <TabsContent value="sources" className="space-y-2">
            {res.sources.length === 0 ? <EmptyState icon={FileSearch} title="No policy passages needed" hint="This question did not need any policy text." /> : res.sources.map((s) => (
              <div key={s.id} className="rounded-lg border border-ink-100 p-2.5">
                <div className="flex items-center justify-between gap-2"><span className="text-[12px] font-semibold">{s.title}</span><Badge tone="brand">{s.clause || s.document_id}</Badge></div>
                <div className="text-[11px] text-ink-500">{s.section} · v{s.policy_version} · relevance {s.score.toFixed(2)}</div>
                <p className="mt-1.5 text-[12px] text-ink-700">{s.snippet}</p>
                <Link to={`/knowledge?doc=${s.document_id}`} className="mt-1 inline-block text-[11px] font-medium text-brand-600">Open document →</Link>
              </div>
            ))}
          </TabsContent>
          <TabsContent value="graph">
            {!res.graph_evidence ? <EmptyState icon={Network} title="No supplier links were needed for this question" /> : (
              <div className="space-y-2 text-[12px]">
                <SourcePill source={res.graph_evidence.source ?? "neo4j"} />
                {res.graph_evidence.dependency && (
                  <div className="rounded-lg border border-ink-100 p-2.5">
                    <div className="mb-1 font-semibold">Dependency · {res.graph_evidence.dependency.dependency_level}</div>
                    {res.graph_evidence.dependency.products.map((p) => <div key={p.product_id} className="flex justify-between gap-2 py-0.5"><span className="truncate">{p.product}{p.is_primary_source && " · primary"}</span><span className="num text-ink-500">{p.alt_sources} alt · {p.open_pos} open POs</span></div>)}
                  </div>
                )}
                {res.graph_evidence.relationships != null && <pre className="max-h-64 overflow-auto rounded-lg bg-ink-50 p-2.5 text-[10.5px] text-ink-700">{JSON.stringify(res.graph_evidence.relationships, null, 1).slice(0, 2500)}</pre>}
              </div>
            )}
          </TabsContent>
          <TabsContent value="trace">
            <ol className="relative space-y-3 border-l border-ink-200 pl-4">
              {res.agent_trace.map((t, i) => (
                <li key={i} className="relative">
                  <span className={cn("absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full ring-2 ring-white", t.status === "ok" ? "bg-emerald-500" : t.status === "skipped" ? "bg-ink-300" : "bg-amber-500")} />
                  <div className="flex items-center justify-between"><span className="text-[12px] font-semibold capitalize">{t.agent}</span><span className="num text-[11px] text-ink-400">{t.duration_ms} ms</span></div>
                  <div className="text-[12px] text-ink-700">{t.action}</div>
                  {t.tools.length > 0 && <div className="mt-1 flex flex-wrap gap-1">{t.tools.map((x, j) => <code key={j} className="rounded bg-ink-50 px-1 text-[10.5px] text-ink-600">{x}</code>)}</div>}
                  {t.detail && <div className="text-[11px] text-ink-500">{t.detail}</div>}
                </li>
              ))}
            </ol>
            <div className="mt-4 grid grid-cols-2 gap-2 text-[11.5px]">
              <div className="rounded-lg bg-ink-50 p-2"><div className="text-ink-500">Question type</div><div className="font-medium">{res.intent.replace(/_/g, " ")}</div></div>
              {res.cost && can("audit") && <div className="col-span-2 rounded-lg bg-emerald-50 p-2"><div className="text-emerald-800">Cost of this answer</div>
                <div className="num font-medium text-emerald-900">£{res.cost.cost_gbp.toFixed(5)} · {fmt.int(res.cost.tokens)} tokens · {res.cost.model_calls} AI call(s)</div></div>}
              <div className="rounded-lg bg-ink-50 p-2"><div className="text-ink-500">AI model calls</div><div className="font-medium">{res.budget ? `${res.budget.llm_calls} / ${res.budget.max_llm_calls}` : "-"}</div></div>
              {res.jev && can("configure") && <div className="col-span-2 rounded-lg bg-ink-50 p-2"><div className="text-ink-500">JEV context optimiser</div><div className="num font-medium">{res.jev.raw_tokens} → {res.jev.compressed_tokens} tokens ({Math.round((1 - res.jev.compressed_tokens / Math.max(1, res.jev.raw_tokens)) * 100)}% saved){res.jev.dropped.length > 0 && ` · dropped ${res.jev.dropped.join(", ")}`}</div></div>}
              {res.guardrails.length > 0 && <div className="col-span-2 rounded-lg bg-amber-50 p-2 text-amber-900"><div className="font-medium">Safety checks applied</div>{res.guardrails.map((x) => <div key={x}>{x.replace(/_/g, " ")}</div>)}</div>}
            </div>
          </TabsContent>
          <TabsContent value="gov" className="space-y-2">
            <div className="flex items-center justify-between rounded-lg bg-ink-50 p-2.5 text-[12px]"><span>Status <span className="font-semibold">{g.status}</span></span><span>Confidence <span className="num font-semibold">{Math.round(g.confidence * 100)}%</span></span></div>
            {g.checks.map((c) => (
              <div key={c.check} className="flex items-start gap-2 rounded-lg border border-ink-100 p-2 text-[12px]">
                {c.passed ? <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-600" /> : <XCircle className="mt-0.5 h-4 w-4 text-rose-600" />}
                <div><div className="font-medium">{c.check.replace(/_/g, " ")}</div><div className="text-ink-500">{c.detail}</div></div>
              </div>
            ))}
            {g.requires_approval && <div className="rounded-lg border border-amber-200 bg-amber-50 p-2.5 text-[12px] text-amber-900">Needs approval before acting: {g.approval_reason}.{can("audit") && <> <Link className="font-semibold underline" to="/governance">Open approvals</Link></>}</div>}
            {g.unsupported_claims.length > 0 && <div className="rounded-lg bg-rose-50 p-2.5 text-[12px] text-rose-900">Unsupported: {g.unsupported_claims.join("; ")}</div>}
            {g.rejected_llm_claims && <div className="rounded-lg bg-rose-50 p-2.5 text-[12px] text-rose-900">LLM draft rejected and replaced with grounded answer: {g.rejected_llm_claims.join("; ")}</div>}
            <div className="text-[11px] text-ink-400">Reference {res.request_id} · saved to the audit log</div>
          </TabsContent>
        </div>
      </Tabs>
    </Card>
  );
}

export default function CopilotPage() {
  const init = React.useMemo(load, []);
  const [msgs, setMsgs] = React.useState<Msg[]>(init.msgs ?? []);
  const [session, setSession] = React.useState<string | undefined>(init.session);
  const [input, setInput] = React.useState("");
  const [selected, setSelected] = React.useState<number | null>(null);
  const [focus, setFocus] = React.useState<string>();
  const chat = useChat();
  const { data: sugg } = useSuggestions();
  const [sp, setSp] = useSearchParams();
  const endRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => { try { sessionStorage.setItem(STORE, JSON.stringify({ session, msgs: msgs.slice(-30) })); } catch { /* storage unavailable */ } }, [msgs, session]);
  React.useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs.length, chat.isPending]);

  const ask = React.useCallback((q: string) => {
    const text = q.trim();
    if (text.length < 3 || chat.isPending) return;
    setMsgs((m) => [...m, { role: "user", text }]);
    setInput("");
    chat.mutate({ message: text, session_id: session }, {
      onSuccess: (res) => { setSession(res.session_id); setMsgs((m) => { const n: Msg[] = [...m, { role: "assistant", res }]; setSelected(n.length - 1); return n; }); setFocus(undefined); },
      onError: (e) => setMsgs((m) => [...m, { role: "error", text: e instanceof Error ? e.message : "Request failed" }]),
    });
  }, [chat, session]);

  React.useEffect(() => {
    const q = sp.get("q");
    if (q) { setSp({}, { replace: true }); ask(q); }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const lastAssistant = [...msgs.keys()].reverse().find((i) => msgs[i].role === "assistant");
  const selIdx = selected ?? lastAssistant;
  const selRes = selIdx != null && msgs[selIdx]?.role === "assistant" ? (msgs[selIdx] as { res: CopilotResponse }).res : undefined;

  return (
    <div className="grid h-[calc(100vh-8rem)] min-h-[620px] gap-4 xl:grid-cols-12">
      <div className="flex min-h-0 flex-col xl:col-span-7">
        <div className="mb-3 flex items-end justify-between gap-3">
          <div>
            <div className="eyebrow text-brand-600">AI assistant</div>
            <h1 className="text-[22px] font-bold">Ask anything about our vendors</h1>
            <p className="text-[12.5px] text-ink-500">Ask in plain English. The assistant checks scores, trends, policies and supplier links - and shows the facts behind every answer.</p>
          </div>
          {msgs.length > 0 && <Button variant="outline" size="sm" onClick={() => { setMsgs([]); setSession(undefined); setSelected(null); }}><RotateCcw />New chat</Button>}
        </div>
        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto pr-1 scrollbar-thin">
          {msgs.length === 0 && (
            <Card className="p-5">
              <div className="mb-3 flex items-center gap-2"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-500 text-white"><Bot className="h-5 w-5" /></div>
                <div><div className="font-semibold">Start with a question</div><div className="text-[12px] text-ink-500">Try: why is a vendor struggling → what should we do → who could replace them.</div></div></div>
              <div className="grid gap-2 sm:grid-cols-2">{(sugg?.suggestions ?? []).map((q) => (
                <button key={q} onClick={() => ask(q)} className="rounded-xl border border-ink-100 px-3 py-2.5 text-left text-[12.5px] text-ink-800 transition-colors hover:border-brand-300 hover:bg-brand-50/40">{q}</button>))}</div>
            </Card>
          )}
          <AnimatePresence initial={false}>
            {msgs.map((m, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={cn("flex gap-2.5", m.role === "user" && "justify-end")}>
                {m.role !== "user" && <div className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-ink-900 text-white"><Bot className="h-4 w-4" /></div>}
                {m.role === "user" ? <div className="max-w-[80%] rounded-2xl rounded-tr-md bg-ink-900 px-3.5 py-2.5 text-[13px] text-white">{m.text}</div>
                  : m.role === "error" ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-[12.5px] text-rose-800">{m.text}</div>
                  : <div className="min-w-0 flex-1"><AssistantMessage res={m.res} active={i === selIdx} onSelect={() => setSelected(i)} onCite={(id) => { setSelected(i); setFocus(id); }} onAsk={ask} /></div>}
                {m.role === "user" && <div className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-brand-100 text-brand-700"><User className="h-4 w-4" /></div>}
              </motion.div>
            ))}
          </AnimatePresence>
          {chat.isPending && <div className="pl-9"><Running /></div>}
          <div ref={endRef} />
        </div>
        <form className="mt-3" onSubmit={(e) => { e.preventDefault(); ask(input); }}>
          <div className="flex items-end gap-2 rounded-2xl border border-ink-200 bg-white p-2 shadow-card focus-within:border-brand-400 focus-within:ring-2 focus-within:ring-brand-100">
            <textarea value={input} onChange={(e) => setInput(e.target.value)} maxLength={600} rows={1}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(input); } }}
              placeholder="e.g. Why is Vendor V1024 underperforming?" aria-label="Ask the copilot"
              className="max-h-32 min-h-[38px] flex-1 resize-none bg-transparent px-2 py-2 text-[13.5px] focus:outline-none focus-visible:ring-0 focus-visible:ring-offset-0" />
            <Button type="submit" variant="brand" size="icon" disabled={input.trim().length < 3 || chat.isPending} aria-label="Send"><ArrowUp /></Button>
          </div>
          <div className="mt-1.5 flex justify-between px-1 text-[11px] text-ink-400"><span>Scores come from fixed rules - the AI explains them and suggests actions. Important actions need approval.</span><span>{input.length}/600</span></div>
        </form>
      </div>
      <div className="min-h-0 xl:col-span-5"><EvidencePanel res={selRes} focus={focus} /></div>
    </div>
  );
}
