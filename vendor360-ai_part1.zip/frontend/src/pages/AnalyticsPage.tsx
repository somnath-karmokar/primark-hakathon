import { useNavigate } from "react-router-dom";
import {
  Bar, BarChart, CartesianGrid, Legend, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis,
} from "recharts";
import { TrendingDown, TrendingUp, Minus, ArrowDownRight } from "lucide-react";
import { usePerformance } from "@/hooks/queries";
import { FilterBar, useUrlFilters } from "@/components/FilterBar";
import { BandBadge, ChartTooltip, Delta, ErrorState, LoadingCard, PageHeader, RiskBadge, VendorLink } from "@/components/domain";
import { Card, CardBody, CardHeader, Td, Th } from "@/components/ui/primitives";
import { BAND_COLOR, BAND_ORDER, SERIES, fmt } from "@/lib/utils";
import type { Band, VendorRow } from "@/types/api";

interface Pt { vendor_id: string; name: string; category: string; band: Band; overall: number; delivery: number; quality: number; cost: number; lead_time: number;
  benchmark_variance_pct: number | null; lead_time_cv: number | null; avg_lead_days: number | null; on_time_pct: number | null }

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function PointTip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const p: Pt = payload[0].payload;
  return (
    <div className="rounded-lg border border-ink-100 bg-white px-3 py-2 text-[12px] shadow-lift">
      <div className="font-semibold text-ink-950">{p.vendor_id} · {p.name}</div>
      <div className="mb-1 text-ink-500">{p.category}</div>
      <div className="num grid grid-cols-2 gap-x-4">
        <span>Score</span><span className="text-right font-semibold">{p.overall.toFixed(1)}</span>
        <span>Delivery</span><span className="text-right">{p.delivery.toFixed(1)}</span>
        <span>Quality</span><span className="text-right">{p.quality.toFixed(1)}</span>
        <span>Cost</span><span className="text-right">{p.cost.toFixed(1)}</span>
        <span>Lead-time</span><span className="text-right">{p.lead_time.toFixed(1)}</span>
        {p.lead_time_cv != null && <><span>Lead-time variation</span><span className="text-right">{Math.round(p.lead_time_cv * 100)}%</span></>}
        {p.benchmark_variance_pct != null && <><span>Price vs typical</span><span className="text-right">{fmt.delta(p.benchmark_variance_pct)}%</span></>}
      </div>
      <div className="mt-1 text-[11px] text-brand-600">Click to open the vendor profile</div>
    </div>
  );
}

function BandScatter({ points, x, y, xLabel, yLabel, xDomain, yDomain, refX, refY, xFmt }: {
  points: Pt[]; x: keyof Pt; y: keyof Pt; xLabel: string; yLabel: string; xDomain?: [number, number]; yDomain?: [number, number];
  refX?: number; refY?: number; xFmt?: (v: number) => string;
}) {
  const nav = useNavigate();
  return (
    <div className="h-[300px]">
      <ResponsiveContainer>
        <ScatterChart margin={{ top: 10, right: 16, bottom: 18, left: -6 }}>
          <CartesianGrid />
          <XAxis type="number" dataKey={x as string} name={xLabel} domain={xDomain ?? ["auto", "auto"]} tickLine={false} axisLine={false} tickFormatter={xFmt}
            label={{ value: xLabel, position: "insideBottom", offset: -10, fontSize: 11, fill: "#5f738b" }} />
          <YAxis type="number" dataKey={y as string} name={yLabel} domain={yDomain ?? ["auto", "auto"]} tickLine={false} axisLine={false}
            label={{ value: yLabel, angle: -90, position: "insideLeft", offset: 18, fontSize: 11, fill: "#5f738b" }} />
          <ZAxis range={[46, 46]} />
          {refX != null && <ReferenceLine x={refX} stroke="#b3bfce" strokeDasharray="4 4" />}
          {refY != null && <ReferenceLine y={refY} stroke="#b3bfce" strokeDasharray="4 4" />}
          <Tooltip content={<PointTip />} cursor={{ strokeDasharray: "3 3" }} />
          {BAND_ORDER.map((b) => (
            <Scatter key={b} name={b} data={points.filter((p) => p.band === b)} fill={BAND_COLOR[b]} fillOpacity={0.8} stroke="#fff" strokeWidth={1}
              onClick={(d: { vendor_id?: string; payload?: Pt }) => nav(`/vendors/${d.vendor_id ?? d.payload?.vendor_id}`)} className="cursor-pointer" />
          ))}
          <Legend iconType="circle" wrapperStyle={{ fontSize: 11.5, paddingTop: 14 }} />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}

const SEGMENTS: { key: string; title: string; hint: string }[] = [
  { key: "strong_quality_weak_delivery", title: "Strong quality, weak delivery", hint: "Good products, but often late - better suited to non-seasonal lines" },
  { key: "low_cost_poor_quality", title: "Low price, poor quality", hint: "Cheap, but quality problems cost more later" },
  { key: "premium_high_quality", title: "Premium price, high quality", hint: "Excellent quality, but priced above the norm - negotiate" },
  { key: "variable_lead_time", title: "Unpredictable lead times", hint: "Usually on time, but delivery dates are unpredictable" },
];

export default function AnalyticsPage() {
  const [f] = useUrlFilters();
  const { data, isLoading, error, refetch } = usePerformance(f);
  const header = <PageHeader eyebrow="Performance insights" title="Performance insights" description="Spot patterns across all vendors: who is strong or weak where, which categories lag, and who is getting worse." actions={<FilterBar show={["period", "category", "region"]} />} />;
  if (error) return <>{header}<ErrorState error={error} onRetry={() => refetch()} /></>;
  if (isLoading || !data) return <>{header}<div className="grid gap-4 md:grid-cols-2"><LoadingCard /><LoadingCard /><LoadingCard /><LoadingCard /></div></>;
  const pts: Pt[] = data.points;
  const dirs = data.trend_directions as Record<string, number>;
  return (
    <>
      {header}
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { k: "improving", icon: TrendingUp, cls: "text-emerald-700", label: "Improving" },
          { k: "stable", icon: Minus, cls: "text-ink-600", label: "Stable" },
          { k: "declining", icon: ArrowDownRight, cls: "text-amber-700", label: "Declining" },
          { k: "deteriorating", icon: TrendingDown, cls: "text-rose-700", label: "Getting worse" },
        ].map((d) => (
          <Card key={d.k} className="flex items-center gap-3 px-4 py-3">
            <d.icon className={`h-5 w-5 ${d.cls}`} />
            <div><div className="eyebrow">{d.label}</div><div className="num font-display text-[22px] font-bold">{dirs[d.k] ?? 0}</div></div>
            <div className="ml-auto text-[11px] text-ink-500">last 6 months</div>
          </Card>
        ))}
      </div>

      <div className="mb-4 grid gap-4 xl:grid-cols-2">
        <Card><CardHeader title="Delivery vs quality" subtitle="Each dot is a vendor · top-right is best · dashed lines mark a Good score (75)" />
          <CardBody><BandScatter points={pts} x="delivery" y="quality" xLabel="Delivery score" yLabel="Quality score" xDomain={[0, 100]} yDomain={[0, 100]} refX={75} refY={75} /></CardBody></Card>
        <Card><CardHeader title="Price vs performance" subtitle="How much more (or less) a vendor charges than the typical price, against its overall score" />
          <CardBody><BandScatter points={pts.filter((p) => p.benchmark_variance_pct != null)} x="benchmark_variance_pct" y="overall" xLabel="Price vs typical price (%)" yLabel="Overall score" refX={0} refY={75} xFmt={(v) => `${v > 0 ? "+" : ""}${v}`} /></CardBody></Card>
        <Card><CardHeader title="Lead-time reliability" subtitle="How much delivery times vary, against the lead-time score" />
          <CardBody><BandScatter points={pts.filter((p) => p.lead_time_cv != null)} x="lead_time_cv" y="lead_time" xLabel="Variation in delivery time (lower is better)" yLabel="Lead-time score" refX={0.2} yDomain={[0, 100]} /></CardBody></Card>
        <Card><CardHeader title="Category comparison" subtitle="Average score in each area, by product category" />
          <CardBody>
            <div className="h-[300px]">
              <ResponsiveContainer>
                <BarChart data={data.category_comparison} margin={{ top: 8, right: 8, left: -20, bottom: 30 }} barGap={2}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="category" tickLine={false} axisLine={false} interval={0} angle={-25} textAnchor="end" height={50} />
                  <YAxis domain={[40, 100]} tickLine={false} axisLine={false} />
                  <Tooltip content={<ChartTooltip />} />
                  <Legend wrapperStyle={{ fontSize: 11.5 }} verticalAlign="top" height={26} />
                  {(["delivery", "quality", "cost", "lead_time"] as const).map((k, i) => <Bar key={k} dataKey={k} name={["Delivery", "Quality", "Cost", "Lead-time"][i]} fill={SERIES[i]} radius={[3, 3, 0, 0]} />)}
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardBody>
        </Card>
      </div>

      <Card className="mb-4">
        <CardHeader title="Vendor patterns to act on" subtitle="Groups of vendors with the same strengths and weaknesses · click a vendor for detail" />
        <CardBody className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {SEGMENTS.map((s) => {
            const seg = data.segments[s.key];
            return (
              <div key={s.key} className="rounded-xl border border-ink-100 p-3">
                <div className="flex items-baseline justify-between"><span className="text-[13px] font-semibold">{s.title}</span><span className="num font-display text-[20px] font-bold">{seg.count}</span></div>
                <p className="mb-2 text-[11.5px] text-ink-500">{s.hint}</p>
                <ul className="space-y-1">{seg.vendors.slice(0, 4).map((v: VendorRow) => (
                  <li key={v.vendor_id} className="flex items-center justify-between gap-2"><VendorLink id={v.vendor_id} name={v.name} className="max-w-[150px]" /><span className="num text-[12px] font-semibold">{v.overall.toFixed(1)}</span></li>
                ))}</ul>
              </div>
            );
          })}
        </CardBody>
      </Card>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader title="Vendors getting worse" subtitle="Score has fallen steadily by 8 points or more in recent months" />
          <CardBody className="overflow-x-auto px-2 pt-2">
            <table className="w-full text-[12.5px]">
              <thead><tr><Th>Vendor</Th><Th className="text-right">Score</Th><Th>Band</Th><Th className="text-right">Change (3 months)</Th><Th>Risk</Th></tr></thead>
              <tbody>{data.deterioration.slice(0, 12).map((v: VendorRow) => (
                <tr key={v.vendor_id}><Td><VendorLink id={v.vendor_id} name={v.name} className="max-w-[220px]" /></Td><Td className="num text-right font-semibold">{v.overall.toFixed(1)}</Td>
                  <Td><BandBadge band={v.band} /></Td><Td className="text-right"><Delta value={v.change_3m} /></Td><Td><RiskBadge level={v.risk_level} label="" /></Td></tr>))}</tbody>
            </table>
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Top 25 vendors" subtitle="Ranked by overall score" />
          <CardBody className="max-h-[460px] overflow-auto px-2 pt-2 scrollbar-thin">
            <table className="w-full text-[12.5px]">
              <thead className="sticky top-0"><tr><Th>#</Th><Th>Vendor</Th><Th>Category</Th><Th className="text-right">Score</Th><Th>Band</Th></tr></thead>
              <tbody>{data.ranking.map((v: VendorRow) => (
                <tr key={v.vendor_id}><Td className="num text-ink-500">{v.rank}</Td><Td><VendorLink id={v.vendor_id} name={v.name} className="max-w-[200px]" /></Td><Td className="text-ink-600">{v.category}</Td>
                  <Td className="num text-right font-semibold">{v.overall.toFixed(1)}</Td><Td><BandBadge band={v.band} /></Td></tr>))}</tbody>
            </table>
          </CardBody>
        </Card>
      </div>
    </>
  );
}
