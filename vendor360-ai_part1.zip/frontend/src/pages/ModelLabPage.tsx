import * as React from "react";
import { motion } from "framer-motion";
import {
  Activity, BrainCircuit, CheckCircle2, ChevronDown, Crown, FlaskConical, Info, Loader2, Lock, Play, Radar, RotateCcw, Rocket, ShieldAlert, XCircle,
} from "lucide-react";
import {
  Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { useAuth } from "@/lib/auth";
import { useAnomalyLab, useMLAlgorithms, useMLDataset, useMLRuns, usePromote, useTrain } from "@/hooks/queries";
import { BandBadge, ChartTooltip, EmptyState, ErrorState, KpiTile, LoadingCard, PageHeader, VendorLink } from "@/components/domain";
import { Badge, Button, Card, CardBody, CardHeader, Input, Slider, Tabs, TabsContent, TabsList, TabsTrigger, Td, Th, Tip } from "@/components/ui/primitives";
import { SERIES, cn, fmt } from "@/lib/utils";
import type { Band } from "@/types/api";
import type { Confusion, MLAlgorithm, MLRun } from "@/types/ml";

/* One algorithm (XGBoost) - colour follows the algorithm, first validated categorical slot. */
const ALGO_COLOR: Record<string, string> = { xgboost: SERIES[0] };

const COLS: { key: keyof MLRun["metrics"] | "best_f1"; label: string; tip: string; higher: boolean; digits?: number }[] = [
  { key: "roc_auc", label: "ROC-AUC", tip: "Ranking quality on the held-out period (0.5 = random)", higher: true },
  { key: "pr_auc", label: "PR-AUC", tip: "Average precision - the key metric for a rare positive class", higher: true },
  { key: "f1", label: "F1 @0.5", tip: "F1 at the default 0.5 threshold", higher: true },
  { key: "best_f1", label: "Best F1", tip: "F1 at the F1-optimal threshold (reported, not used to select models)", higher: true },
  { key: "precision", label: "Precision", tip: "At threshold 0.5", higher: true },
  { key: "recall", label: "Recall", tip: "At threshold 0.5", higher: true },
  { key: "lift_top10pct", label: "Lift @10%", tip: "Hit-rate in the top-scored 10% vs the base rate", higher: true, digits: 2 },
  { key: "cv_roc_auc_mean", label: "Rolling CV AUC", tip: "Mean ROC-AUC across rolling-origin folds (stability)", higher: true },
  { key: "overfit_gap", label: "Overfit gap", tip: "Train ROC-AUC minus test ROC-AUC (lower is better)", higher: false },
  { key: "brier", label: "Brier", tip: "Probability calibration error (lower is better)", higher: false },
];

function metric(r: MLRun, key: (typeof COLS)[number]["key"]): number | null {
  return key === "best_f1" ? r.curves.best_threshold.f1 : (r.metrics[key] as number | null);
}

/* ---------------------------------------------------------------- setup panel */
interface Cand { enabled: boolean; params: Record<string, number> }

function AlgoCard({ a, c, onChange, color }: { a: MLAlgorithm; c: Cand; onChange: (c: Cand) => void; color: string }) {
  const [open, setOpen] = React.useState(true);
  return (
    <div className="rounded-xl border border-ink-200 bg-white">
      <div className="flex items-start gap-3 p-3">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1"><span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: color }} /><span className="whitespace-nowrap text-[13px] font-semibold">{a.label}</span><Badge>{a.family}</Badge></div>
          <p className="mt-0.5 text-[11.5px] leading-snug text-ink-500">{a.description}</p>
        </div>
        <button onClick={() => setOpen(!open)} className="rounded-md p-1 text-ink-400 hover:bg-ink-100 hover:text-ink-700" aria-label="Hyper-parameters" aria-expanded={open}>
          <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
        </button>
      </div>
      {open && (
        <div className="grid grid-cols-2 gap-x-3 gap-y-2 border-t border-ink-100 px-3 py-3">
          {a.params.map((p) => (
            <label key={p.name} className="block">
              <span className="flex items-center gap-1 text-[11px] font-medium text-ink-600">{p.name}<Tip content={`${p.help} (${p.min}-${p.max})`}><Info className="h-3 w-3 text-ink-400" /></Tip></span>
              <Input type="number" min={p.min} max={p.max} step={p.step} value={c.params[p.name] ?? p.default} className="mt-0.5 h-8"
                onChange={(e) => onChange({ ...c, params: { ...c.params, [p.name]: Number(e.target.value) } })} />
            </label>
          ))}
          <button className="col-span-2 justify-self-start text-[11px] font-medium text-brand-600" onClick={() => onChange({ ...c, params: {} })}>Reset to defaults</button>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- charts */
function CurveChart({ runs, kind }: { runs: MLRun[]; kind: "roc" | "pr" | "calibration" }) {
  const base = runs[0]?.metrics.base_rate ?? 0;
  const axis = kind === "roc" ? ["False positive rate", "True positive rate"] : kind === "pr" ? ["Recall", "Precision"] : ["Mean predicted probability", "Observed deterioration rate"];
  return (
    <div className="h-[270px]">
      <ResponsiveContainer>
        <LineChart margin={{ top: 8, right: 14, left: -8, bottom: 16 }}>
          <CartesianGrid />
          <XAxis type="number" dataKey="x" domain={[0, 1]} tickCount={6} tickLine={false} axisLine={false}
            label={{ value: axis[0], position: "insideBottom", offset: -8, fontSize: 11, fill: "#5f738b" }} />
          <YAxis type="number" domain={[0, 1]} tickCount={6} tickLine={false} axisLine={false}
            label={{ value: axis[1], angle: -90, position: "insideLeft", offset: 18, fontSize: 11, fill: "#5f738b" }} />
          <Tooltip content={<ChartTooltip labelFormatter={(v: number) => `${axis[0]} ${Number(v).toFixed(2)}`} valueFormatter={(v: number) => v.toFixed(3)} />} />
          {kind !== "pr" && <ReferenceLine segment={[{ x: 0, y: 0 }, { x: 1, y: 1 }]} stroke="#b3bfce" strokeDasharray="4 4" />}
          {kind === "pr" && <ReferenceLine y={base} stroke="#b3bfce" strokeDasharray="4 4" label={{ value: `base rate ${base.toFixed(2)}`, position: "insideTopRight", fontSize: 10, fill: "#8496ab" }} />}
          {runs.map((r) => (
            <Line key={r.id} data={r.curves[kind]} dataKey="y" name={r.algorithm_label} stroke={ALGO_COLOR[r.algorithm]} strokeWidth={2}
              dot={kind === "calibration" ? { r: 3 } : false} isAnimationActive={false} />
          ))}
          <Legend iconType="plainline" wrapperStyle={{ fontSize: 11.5, paddingTop: 10 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function ConfusionMatrix({ c, threshold }: { c: Confusion; threshold: number }) {
  const total = c.tn + c.fp + c.fn + c.tp;
  const cell = (v: number, label: string, good: boolean) => (
    <div className={cn("rounded-lg p-3 text-center", good ? "bg-emerald-50 ring-1 ring-inset ring-emerald-200" : "bg-rose-50 ring-1 ring-inset ring-rose-200")}>
      <div className="num font-display text-[22px] font-bold">{v}</div>
      <div className="text-[11px] text-ink-600">{label}</div>
      <div className="num text-[10.5px] text-ink-400">{((v / total) * 100).toFixed(1)}%</div>
    </div>
  );
  return (
    <div>
      <div className="mb-1.5 grid grid-cols-[88px_1fr_1fr] items-end gap-2 text-[10.5px] font-semibold uppercase tracking-wide text-ink-500">
        <span /><span className="text-center">Predicted stable</span><span className="text-center">Predicted deteriorating</span>
      </div>
      <div className="grid grid-cols-[88px_1fr_1fr] items-center gap-2">
        <span className="text-[10.5px] font-semibold uppercase tracking-wide text-ink-500">Actual stable</span>{cell(c.tn, "True negative", true)}{cell(c.fp, "False alarm", false)}
        <span className="text-[10.5px] font-semibold uppercase tracking-wide text-ink-500">Actual deteriorated</span>{cell(c.fn, "Missed", false)}{cell(c.tp, "Caught", true)}
      </div>
      <div className="mt-2 text-[11px] text-ink-500">Threshold {threshold.toFixed(3)} · {total} held-out vendor-periods</div>
    </div>
  );
}

/* ---------------------------------------------------------------- page */
export default function ModelLabPage() {
  const { can } = useAuth();
  const admin = can("configure");
  const { data: algos, error: algoErr } = useMLAlgorithms();
  const { data: hist, isLoading: histLoading } = useMLRuns();
  const train = useTrain();
  const promote = usePromote();
  const anomaly = useAnomalyLab();
  const [drop, setDrop] = React.useState(6);
  const [testPeriods, setTestPeriods] = React.useState(1);
  const { data: ds } = useMLDataset(drop, testPeriods);
  const [cands, setCands] = React.useState<Record<string, Cand>>({});
  const [experiment, setExperiment] = React.useState<string>();
  const [selected, setSelected] = React.useState<number>();
  const [thrMode, setThrMode] = React.useState<"half" | "best">("half");
  const [contamination, setContamination] = React.useState(0.05);
  const [isoTrees, setIsoTrees] = React.useState(200);

  React.useEffect(() => {
    if (algos && !Object.keys(cands).length) setCands(Object.fromEntries(algos.map((a) => [a.key, { enabled: true, params: {} }])));
  }, [algos, cands]);

  const experiments = React.useMemo(() => {
    const m = new Map<string, MLRun[]>();
    (hist?.runs ?? []).forEach((r) => m.set(r.experiment_id, [...(m.get(r.experiment_id) ?? []), r]));
    return [...m.entries()];
  }, [hist]);
  const expId = experiment ?? experiments[0]?.[0];
  const runs = (experiments.find(([id]) => id === expId)?.[1] ?? []).slice().sort((a, b) => a.algorithm.localeCompare(b.algorithm));
  const sel = runs.find((r) => r.id === selected) ?? [...runs].sort((a, b) => (b.metrics.pr_auc ?? 0) - (a.metrics.pr_auc ?? 0))[0];
  const active = hist?.runs.find((r) => r.is_active);

  const start = () => {
    const candidates = Object.entries(cands).filter(([, c]) => c.enabled).map(([algorithm, c]) => ({ algorithm, params: c.params }));
    train.mutate({ candidates, drop_points: drop, test_periods: testPeriods }, { onSuccess: (r) => { setExperiment(r.experiment_id); setSelected(r.best_run_id ?? undefined); } });
  };
  const best = (key: (typeof COLS)[number]["key"], higher: boolean) => {
    const vals = runs.map((r) => metric(r, key)).filter((v): v is number => v != null);
    return vals.length ? (higher ? Math.max(...vals) : Math.min(...vals)) : null;
  };

  if (algoErr) return <ErrorState error={algoErr} />;
  return (
    <>
      <PageHeader eyebrow="Risk prediction models" title="Risk prediction models"
        description="An XGBoost model predicts sustained vendor deterioration over the next 3 months; IsolationForest flags unusual vendors without labels. Every run is judged on a temporal hold-out - never on data from its own future."
        actions={
          <div className="flex items-center gap-2 rounded-xl border border-ink-100 bg-white px-3 py-2 shadow-card">
            <Rocket className="h-4 w-4 text-brand-500" />
            <div className="text-[12px] leading-tight"><div className="text-ink-500">Production risk model</div>
              <div className="font-semibold text-ink-950">{active ? `${active.algorithm_label} · run #${active.id}` : "XGBoost (default settings)"}</div></div>
            {active && admin && <Button variant="ghost" size="sm" onClick={() => promote.mutate("reset")} disabled={promote.isPending}><RotateCcw />Default</Button>}
          </div>
        } />

      <div className="grid gap-4 xl:grid-cols-12">
        {/* ---------------- setup */}
        <div className="space-y-4 xl:col-span-4">
          <Card>
            <CardHeader title="Experiment setup" icon={<FlaskConical className="h-4 w-4 text-brand-500" />} subtitle="Tune the XGBoost settings and train on the score history" />
            <CardBody className="space-y-4">
              <div>
                <div className="mb-1.5 flex justify-between text-[12.5px]"><span className="font-medium">Deterioration label threshold</span><span className="num font-semibold">≥ {drop} pts</span></div>
                <Slider value={[drop]} min={3} max={12} step={1} onValueChange={([v]) => setDrop(v)} aria-label="Label threshold" />
                <p className="mt-1.5 text-[11px] text-ink-500">{ds?.label_definition ?? "…"}</p>
              </div>
              <div className="flex items-center justify-between text-[12.5px]">
                <span className="font-medium">Held-out test periods</span>
                <div className="inline-flex rounded-lg bg-ink-100/70 p-1">{[1, 2].map((n) => (
                  <button key={n} onClick={() => setTestPeriods(n)} className={cn("rounded-md px-3 py-1 text-[12px] font-medium", testPeriods === n ? "bg-white shadow-sm" : "text-ink-600")}>{n} month{n > 1 && "s"}</button>))}</div>
              </div>
              <div className="space-y-2">{algos?.map((a) => cands[a.key] && <AlgoCard key={a.key} a={a} c={cands[a.key]} color={ALGO_COLOR[a.key]} onChange={(c) => setCands({ ...cands, [a.key]: c })} />)}</div>
              {!admin && <p className="flex items-center gap-1.5 rounded-lg bg-ink-100 px-3 py-2 text-[12px] text-ink-600"><Lock className="h-3.5 w-3.5" />Training and promoting models is limited to the Admin role.</p>}
              <Button variant="brand" className="w-full" size="lg" onClick={start} disabled={!admin || train.isPending || !Object.values(cands).some((c) => c.enabled)}>
                {train.isPending ? <><Loader2 className="animate-spin" />Training & validating…</> : <><Play />Train XGBoost</>}
              </Button>
              {train.isPending && <p className="text-center text-[11.5px] text-ink-500">Fitting the model plus rolling-origin folds - typically 10-15 s.</p>}
              {train.isError && <p className="rounded-lg bg-rose-50 p-2 text-[12px] text-rose-800">{(train.error as Error).message}</p>}
            </CardBody>
          </Card>
          <Card>
            <CardHeader title="Training data" icon={<Activity className="h-4 w-4 text-brand-500" />} subtitle="Vendor-month feature rows built from score snapshots" />
            <CardBody>
              {!ds ? <LoadingCard h="h-24" /> : (
                <>
                  <div className="grid grid-cols-2 gap-2 text-[12px]">
                    {[["Train rows", ds.n_train, `${ds.positives_train} deteriorations (${(ds.positive_rate_train * 100).toFixed(1)}%)`],
                      ["Test rows", ds.n_test, `${ds.positives_test} deteriorations (${(ds.positive_rate_test * 100).toFixed(1)}%)`]].map(([a, b, c]) => (
                      <div key={a as string} className="rounded-lg bg-ink-50 p-2.5"><div className="text-ink-500">{a}</div><div className="num font-display text-[18px] font-bold">{b}</div><div className="text-[11px] text-ink-500">{c}</div></div>))}
                  </div>
                  <div className="mt-3 h-[120px]">
                    <ResponsiveContainer>
                      <BarChart data={ds.per_period.map((p) => ({ ...p, split: ds.test_periods.includes(p.period) ? "test" : "train" }))} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
                        <XAxis dataKey="period" tickFormatter={fmt.month} tickLine={false} axisLine={false} />
                        <YAxis tickLine={false} axisLine={false} allowDecimals={false} />
                        <Tooltip content={<ChartTooltip labelFormatter={fmt.month} />} />
                        <Bar dataKey="positives" name="Deteriorations" radius={[3, 3, 0, 0]} fill="#0a8fc4" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="mt-1 text-[11px] text-ink-500">Train {ds.train_periods.map(fmt.month).join(", ")} → test {ds.test_periods.map(fmt.month).join(", ")}. {ds.features.length} features: score levels, 1- and 3-month changes, late POs, failed inspections, lead-time CV, invoice variance.</p>
                </>
              )}
            </CardBody>
          </Card>
        </div>

        {/* ---------------- results */}
        <div className="space-y-4 xl:col-span-8">
          {histLoading ? <LoadingCard /> : !runs.length ? (
            <Card><EmptyState icon={BrainCircuit} title="No experiments yet" hint="Adjust the settings on the left if needed and press Train. Results, curves and metrics appear here." /></Card>
          ) : (
            <>
              <Card>
                <CardHeader title="Results" icon={<Crown className="h-4 w-4 text-brand-500" />}
                  subtitle={`Experiment ${expId} · ${runs[0].dataset.n_test} held-out rows · base rate ${(runs[0].metrics.base_rate * 100).toFixed(1)}% · best value per column in bold`}
                  action={experiments.length > 1 && (
                    <select value={expId} onChange={(e) => { setExperiment(e.target.value); setSelected(undefined); }} className="h-8 rounded-lg border border-ink-200 bg-white px-2 text-[12px]" aria-label="Experiment">
                      {experiments.map(([id, rs]) => <option key={id} value={id}>{id} · {fmt.datetime(rs[0].created_at)} · {rs[0].metrics.roc_auc?.toFixed(3)} ROC-AUC</option>)}
                    </select>)} />
                <CardBody className="overflow-x-auto px-2 pt-2">
                  <table className="w-full text-[12.5px]">
                    <thead><tr><Th>Model</Th><Th>Status</Th>{COLS.map((c) => <Th key={c.key} className="text-right"><Tip content={c.tip}><span className="cursor-help border-b border-dotted border-ink-300">{c.label}</span></Tip></Th>)}<Th>Fit</Th></tr></thead>
                    <tbody>
                      {runs.map((r) => (
                        <tr key={r.id} onClick={() => setSelected(r.id)} className={cn("cursor-pointer transition-colors", sel?.id === r.id ? "bg-brand-50/60" : "hover:bg-ink-50/50")}>
                          <Td><div className="flex items-center gap-2"><span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: ALGO_COLOR[r.algorithm] }} /><span className="whitespace-nowrap font-semibold">{r.algorithm_label}</span></div><div className="pl-[18px] text-[10.5px] text-ink-400">run #{r.id}</div></Td>
                          <Td>
                            {r.is_active ? <Badge tone="brand"><Rocket className="h-3 w-3" />Production</Badge>
                              : r.credible ? <Button size="sm" variant="outline" disabled={!admin || promote.isPending} title={admin ? undefined : "Admin only"} onClick={(e) => { e.stopPropagation(); promote.mutate(r.id); }}>{promote.isPending && promote.variables === r.id ? <Loader2 className="animate-spin" /> : <Rocket />}Promote</Button>
                              : <Tip content={r.credibility_reason}><Badge tone="warning"><ShieldAlert className="h-3 w-3" />Not credible</Badge></Tip>}
                          </Td>
                          {COLS.map((c) => {
                            const v = metric(r, c.key);
                            const isBest = v != null && v === best(c.key, c.higher);
                            const shown = c.key === "cv_roc_auc_mean" && v != null ? `${v.toFixed(3)}±${(r.metrics.cv_roc_auc_std ?? 0).toFixed(2)}` : v == null ? "-" : v.toFixed(c.digits ?? 3);
                            return <Td key={c.key} className={cn("num text-right", isBest ? "font-bold text-ink-950" : "text-ink-700", c.key === "overfit_gap" && v != null && v > 0.15 && "text-rose-700")}>{shown}</Td>;
                          })}
                          <Td className="num text-ink-500">{r.train_seconds.toFixed(1)}s</Td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <p className="px-3 pt-3 text-[11.5px] text-ink-500">Promote retrains the production risk model with these XGBoost settings on all labelled history, re-scores every vendor's internal risk and writes an audit event. Models below the 0.65 ROC-AUC credibility bar cannot be promoted.</p>
                  {promote.isSuccess && <p className="mx-3 mt-2 flex items-center gap-1.5 rounded-lg bg-emerald-50 px-3 py-2 text-[12px] text-emerald-900"><CheckCircle2 className="h-4 w-4" />Production model updated and vendor risk re-scored.</p>}
                  {promote.isError && <p className="mx-3 mt-2 rounded-lg bg-rose-50 px-3 py-2 text-[12px] text-rose-900">{(promote.error as Error).message}</p>}
                </CardBody>
              </Card>

              <Card>
                <Tabs defaultValue="roc">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-100 px-4 py-3">
                    <TabsList><TabsTrigger value="roc">ROC curves</TabsTrigger><TabsTrigger value="pr">Precision-recall</TabsTrigger><TabsTrigger value="cal">Calibration</TabsTrigger><TabsTrigger value="folds">Rolling validation</TabsTrigger></TabsList>
                    <span className="text-[11.5px] text-ink-500">Held-out period</span>
                  </div>
                  <div className="p-4">
                    <TabsContent value="roc"><CurveChart runs={runs} kind="roc" /></TabsContent>
                    <TabsContent value="pr"><CurveChart runs={runs} kind="pr" /><p className="text-[11.5px] text-ink-500">With deteriorations this rare, precision-recall is more informative than ROC: the dashed line is a random guess.</p></TabsContent>
                    <TabsContent value="cal"><CurveChart runs={runs} kind="calibration" /><p className="text-[11.5px] text-ink-500">Points on the diagonal mean predicted probabilities can be read literally. Class re-weighting (balance_classes = 1) inflates probabilities, so it is off by default.</p></TabsContent>
                    <TabsContent value="folds">
                      <div className="h-[270px]"><ResponsiveContainer>
                        <LineChart margin={{ top: 8, right: 14, left: -12, bottom: 0 }}>
                          <CartesianGrid vertical={false} />
                          <XAxis dataKey="test_period" type="category" allowDuplicatedCategory={false} tickFormatter={fmt.month} tickLine={false} axisLine={false} />
                          <YAxis domain={[0.5, 0.9]} tickLine={false} axisLine={false} />
                          <ReferenceLine y={0.65} stroke="#a8223d" strokeDasharray="4 4" label={{ value: "credibility bar 0.65", position: "insideBottomRight", fontSize: 10, fill: "#a8223d" }} />
                          <Tooltip content={<ChartTooltip labelFormatter={fmt.month} valueFormatter={(v: number) => v.toFixed(3)} />} />
                          {runs.map((r) => <Line key={r.id} data={r.curves.folds} dataKey="roc_auc" name={r.algorithm_label} stroke={ALGO_COLOR[r.algorithm]} strokeWidth={2} dot={{ r: 3.5 }} isAnimationActive={false} />)}
                          <Legend iconType="plainline" wrapperStyle={{ fontSize: 11.5 }} />
                        </LineChart></ResponsiveContainer></div>
                      <p className="text-[11.5px] text-ink-500">Each point trains on all earlier months and tests on the next one - a flat line means stable performance over time.</p>
                    </TabsContent>
                  </div>
                </Tabs>
              </Card>

              {sel && (
                <div className="grid gap-4 lg:grid-cols-2">
                  <Card>
                    <CardHeader title={`Confusion matrix · ${sel.algorithm_label}`} subtitle="Held-out period" action={
                      <div className="inline-flex rounded-lg bg-ink-100/70 p-1">{(["half", "best"] as const).map((m) => (
                        <button key={m} onClick={() => setThrMode(m)} className={cn("rounded-md px-2.5 py-1 text-[11.5px] font-medium", thrMode === m ? "bg-white shadow-sm" : "text-ink-600")}>{m === "half" ? "@ 0.5" : "@ best F1"}</button>))}</div>} />
                    <CardBody>
                      <ConfusionMatrix c={thrMode === "half" ? sel.curves.confusion_at_0_5 : sel.curves.best_threshold.confusion} threshold={thrMode === "half" ? 0.5 : sel.curves.best_threshold.threshold} />
                      <div className="mt-3 grid grid-cols-4 gap-2 text-[11.5px]">
                        {(thrMode === "half" ? [["Precision", sel.metrics.precision], ["Recall", sel.metrics.recall], ["F1", sel.metrics.f1], ["MCC", sel.metrics.mcc]]
                          : [["Precision", sel.curves.best_threshold.precision], ["Recall", sel.curves.best_threshold.recall], ["F1", sel.curves.best_threshold.f1], ["Accuracy", sel.curves.best_threshold.accuracy]]).map(([k, v]) => (
                          <div key={k as string} className="rounded-lg bg-ink-50 p-2 text-center"><div className="text-ink-500">{k}</div><div className="num font-semibold">{(v as number).toFixed(3)}</div></div>))}
                      </div>
                      <details className="mt-3 text-[11.5px] text-ink-600"><summary className="cursor-pointer font-medium">Hyper-parameters</summary>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">{Object.entries(sel.params).map(([k, v]) => <code key={k} className="rounded bg-ink-50 px-1.5 py-0.5">{k}={v}</code>)}</div></details>
                    </CardBody>
                  </Card>
                  <Card>
                    <CardHeader title={`Feature importance · ${sel.algorithm_label}`} subtitle="Tree importance, normalised" />
                    <CardBody>
                      <div className="h-[300px]"><ResponsiveContainer>
                        <BarChart layout="vertical" data={sel.importance.slice(0, 10)} margin={{ left: 8, right: 16 }}>
                          <CartesianGrid horizontal={false} />
                          <XAxis type="number" tickLine={false} axisLine={false} tickFormatter={(v) => `${Math.round(v * 100)}%`} />
                          <YAxis type="category" dataKey="label" width={190} tickLine={false} axisLine={false} />
                          <Tooltip content={<ChartTooltip valueFormatter={(v: number) => `${(v * 100).toFixed(1)}%`} />} />
                          <Bar dataKey="importance" name="Importance" fill={ALGO_COLOR[sel.algorithm]} radius={[0, 4, 4, 0]} barSize={14} />
                        </BarChart></ResponsiveContainer></div>
                    </CardBody>
                  </Card>
                </div>
              )}
            </>
          )}

          {/* ---------------- unsupervised */}
          <Card>
            <CardHeader title="Anomaly detection · IsolationForest" icon={<Radar className="h-4 w-4 text-brand-500" />}
              subtitle="Unsupervised - no labels exist, so it is checked against current performance instead of accuracy metrics" />
            <CardBody>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-4">
                  <div><div className="mb-1.5 flex justify-between text-[12.5px]"><span className="font-medium">Contamination</span><span className="num font-semibold">{(contamination * 100).toFixed(0)}%</span></div>
                    <Slider value={[contamination * 100]} min={1} max={20} step={1} onValueChange={([v]) => setContamination(v / 100)} aria-label="Contamination" /></div>
                  <div><div className="mb-1.5 flex justify-between text-[12.5px]"><span className="font-medium">Trees</span><span className="num font-semibold">{isoTrees}</span></div>
                    <Slider value={[isoTrees]} min={50} max={600} step={50} onValueChange={([v]) => setIsoTrees(v)} aria-label="Trees" /></div>
                  <Button variant="outline" className="w-full" onClick={() => anomaly.mutate({ contamination, n_estimators: isoTrees })} disabled={anomaly.isPending}>
                    {anomaly.isPending ? <Loader2 className="animate-spin" /> : <Play />}Run anomaly detection</Button>
                </div>
                {anomaly.data ? (
                  <>
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <KpiTile label="Flagged" value={anomaly.data.flagged} sub={`of ${anomaly.data.vendors} vendors`} />
                        <KpiTile label="Lift" value={`${anomaly.data.sanity_check.lift ?? "-"}×`} sub="weak-vendor enrichment" accent={(anomaly.data.sanity_check.lift ?? 0) > 1.5 ? "#1f8a4c" : "#eaa400"} />
                      </div>
                      <p className="text-[11.5px] text-ink-600">{Math.round(anomaly.data.sanity_check.weak_share_among_flagged * 100)}% of flagged vendors are Watch-or-worse or deteriorating, vs {Math.round(anomaly.data.sanity_check.weak_share_overall * 100)}% of all vendors.</p>
                      <div className="h-[110px]"><ResponsiveContainer>
                        <BarChart data={anomaly.data.histogram} margin={{ top: 4, right: 4, left: -26, bottom: 0 }} barCategoryGap={1}>
                          <XAxis dataKey="from" tickLine={false} axisLine={false} tickFormatter={(v) => Number(v).toFixed(1)} interval={4} />
                          <YAxis tickLine={false} axisLine={false} allowDecimals={false} />
                          <Tooltip content={<ChartTooltip labelFormatter={(v: number) => `Anomaly score ${Number(v).toFixed(2)}+`} valueFormatter={(v: number) => `${v} vendors`} />} />
                          <Bar dataKey="count" name="Vendors" fill="#0a8fc4" radius={[2, 2, 0, 0]} />
                        </BarChart></ResponsiveContainer></div>
                    </div>
                    <div className="max-h-[300px] overflow-y-auto scrollbar-thin md:col-span-2">
                      <table className="w-full text-[12px]"><thead className="sticky top-0"><tr><Th>Vendor</Th><Th>Unusual signals (robust z ≤ -3)</Th><Th className="text-right">Score</Th><Th className="text-right">Anomaly</Th></tr></thead>
                        <tbody>{anomaly.data.top.map((t) => (
                          <tr key={t.vendor_id}><Td><VendorLink id={t.vendor_id} name={t.name} /></Td><Td className="text-ink-600">{t.reasons.join(", ") || "multivariate outlier"}</Td>
                            <Td className="text-right"><div className="flex items-center justify-end gap-1"><span className="num">{t.overall}</span><BandBadge band={t.band as Band} /></div></Td>
                            <Td className="num text-right font-semibold">{t.anomaly_score.toFixed(2)}</Td></tr>))}</tbody></table>
                    </div>
                  </>
                ) : (
                  <div><EmptyState icon={Radar} title="Run the detector" hint="Flags vendors whose component scores or recent changes are unusual relative to the whole supplier base." /></div>
                )}
              </div>
            </CardBody>
          </Card>

          {/* ---------------- history */}
          {hist && hist.runs.length > 0 && (
            <Card>
              <CardHeader title="Run history" subtitle="Every training run is persisted and audited" />
              <CardBody className="max-h-[320px] overflow-y-auto px-2 pt-2 scrollbar-thin">
                <table className="w-full text-[12px]">
                  <thead className="sticky top-0"><tr><Th>Run</Th><Th>Experiment</Th><Th>Model</Th><Th className="text-right">ROC-AUC</Th><Th className="text-right">PR-AUC</Th><Th className="text-right">Label</Th><Th>Trained</Th><Th>Status</Th></tr></thead>
                  <tbody>{hist.runs.map((r) => (
                    <tr key={r.id} className="cursor-pointer hover:bg-ink-50/50" onClick={() => { setExperiment(r.experiment_id); setSelected(r.id); }}>
                      <Td className="num">#{r.id}</Td><Td className="num text-ink-500">{r.experiment_id}</Td>
                      <Td><span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: ALGO_COLOR[r.algorithm] }} />{r.algorithm_label}</span></Td>
                      <Td className="num text-right">{r.metrics.roc_auc?.toFixed(3)}</Td><Td className="num text-right">{r.metrics.pr_auc?.toFixed(3)}</Td>
                      <Td className="num text-right">≥{r.dataset.drop_points ?? 6}</Td><Td className="text-ink-500">{fmt.datetime(r.created_at)}</Td>
                      <Td>{r.is_active ? <Badge tone="brand">Production</Badge> : r.credible ? <Badge tone="good"><CheckCircle2 className="h-3 w-3" />Credible</Badge> : <Badge tone="warning"><XCircle className="h-3 w-3" />Not credible</Badge>}</Td>
                    </tr>))}</tbody>
                </table>
              </CardBody>
            </Card>
          )}
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-[11.5px] text-ink-400">
            Metrics are real measurements on synthetic data. The production scoring itself is deterministic - these models only power the separate “internal risk” indicator.
          </motion.p>
        </div>
      </div>
    </>
  );
}
