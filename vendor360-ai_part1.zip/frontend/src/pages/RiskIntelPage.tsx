import * as React from "react";
import { motion } from "framer-motion";
import { Anchor, ArrowRight, BellRing, Boxes, CloudLightning, FileWarning, Globe2, Landmark, Package, ShoppingCart, Ship, Store, TrendingDown, Truck } from "lucide-react";
import { useEventImpact, useEvents } from "@/hooks/queries";
import { BandBadge, EmptyState, ErrorState, LoadingCard, PageHeader, RiskBadge, SourcePill, VendorLink } from "@/components/domain";
import { Badge, Card, CardBody, CardHeader, Td, Th } from "@/components/ui/primitives";
import { cn, fmt } from "@/lib/utils";
import type { Band } from "@/types/api";

const TYPE_ICON: Record<string, React.ElementType> = { logistics: Ship, weather: CloudLightning, geopolitical: Globe2, regulatory: Landmark, economic: TrendingDown };
const STEP_ICON: Record<string, React.ElementType> = { ExternalEvent: BellRing, Port: Anchor, Country: Globe2, Vendor: Store, PurchaseOrder: ShoppingCart, Product: Package, Category: Boxes, Impact: FileWarning };
const SEV_TONE: Record<string, "critical" | "warning" | "neutral"> = { high: "critical", medium: "warning", low: "neutral" };

export default function RiskIntelPage() {
  const { data: events, isLoading, error } = useEvents();
  const [sel, setSel] = React.useState<string>();
  const selected = sel ?? events?.[0]?.event_id;
  const { data: imp, isLoading: impLoading } = useEventImpact(selected);

  return (
    <>
      <PageHeader eyebrow="Supplier risk alerts · add-on" title="Outside events that could hit our suppliers"
        description="Storms, port delays, political or rule changes can disrupt suppliers before it shows in their performance. See which vendors, orders and products could be affected. This risk is shown separately and never changes a vendor's score." />
      <Card className="mb-4 border-amber-200 bg-amber-50/50 px-5 py-3 text-[12.5px] text-amber-900">
        <span className="font-semibold">Add-on feature.</span> The events below are demo examples. Three separate measures are shown and never mixed: <b>performance score</b> · <b>risk of decline</b> · <b>outside-event risk</b>.
      </Card>
      {error ? <ErrorState error={error} /> : isLoading || !events ? <LoadingCard /> : (
        <div className="grid gap-4 xl:grid-cols-12">
          <div className="space-y-2 xl:col-span-4">
            {events.map((e) => {
              const Icon = TYPE_ICON[e.event_type] ?? Globe2;
              return (
                <button key={e.event_id} onClick={() => setSel(e.event_id)} className={cn("w-full rounded-xl border bg-white p-4 text-left shadow-card transition-all", selected === e.event_id ? "border-brand-300 ring-2 ring-brand-100" : "border-ink-100 hover:border-ink-200")}>
                  <div className="flex items-start gap-3">
                    <div className="rounded-lg bg-ink-50 p-2"><Icon className="h-4 w-4 text-ink-600" /></div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5"><Badge tone={SEV_TONE[e.severity]}>{e.severity}</Badge><Badge>{e.event_type}</Badge><span className="text-[11px] text-ink-400">{fmt.date(e.detected_at)}</span></div>
                      <div className="mt-1 text-[13px] font-semibold text-ink-950">{e.title}</div>
                      <div className="mt-1 text-[11.5px] text-ink-500">{e.affected_countries.join(", ")}{e.affected_ports.length > 0 && ` · ${e.affected_ports.join(", ")}`}</div>
                      {e.impact && <div className="num mt-2 flex gap-3 text-[11.5px] text-ink-700"><span><b>{e.impact.vendors}</b> vendors</span><span><b>{e.impact.open_pos}</b> open POs</span><span><b>{e.impact.critical_pos_at_risk}</b> critical at risk</span></div>}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="space-y-4 xl:col-span-8">
            {impLoading || !imp ? <LoadingCard h="h-96" /> : (
              <>
                <Card>
                  <CardHeader title={imp.event.title} subtitle={imp.event.description} action={<SourcePill source={imp.graph_source} />} />
                  <CardBody>
                    <div className="mb-4 grid grid-cols-2 gap-2 md:grid-cols-5">
                      {[["Vendors affected", imp.totals.vendors], ["High risk vendors", imp.totals.high_risk_vendors], ["Orders on the way", imp.totals.open_pos], ["Key orders at risk", imp.totals.critical_pos_at_risk], ["Value on the way", fmt.gbp(imp.totals.open_value)]].map(([a, b]) => (
                        <div key={a as string} className="rounded-lg bg-ink-50 px-3 py-2"><div className="text-[11px] text-ink-500">{a}</div><div className="num font-display text-[18px] font-bold">{b}</div></div>))}
                    </div>
                    {imp.propagation_path && (
                      <>
                        <div className="eyebrow mb-2">How the event could reach us</div>
                        <div className="flex flex-wrap items-stretch gap-1.5">
                          {imp.propagation_path.map((s: { type: string; label: string }, i: number) => {
                            const Icon = STEP_ICON[s.type] ?? Truck;
                            return (
                              <React.Fragment key={i}>
                                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                                  className={cn("min-w-[110px] flex-1 rounded-lg border px-2.5 py-2", s.type === "Impact" ? "border-rose-200 bg-rose-50" : s.type === "ExternalEvent" ? "border-amber-200 bg-amber-50" : "border-ink-100 bg-white")}>
                                  <div className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-ink-500"><Icon className="h-3 w-3" />{s.type.replace("PurchaseOrder", "POs").replace("ExternalEvent", "Event")}</div>
                                  <div className="mt-0.5 text-[11.5px] font-medium leading-snug text-ink-900">{s.label}</div>
                                </motion.div>
                                {i < imp.propagation_path.length - 1 && <ArrowRight className="hidden h-4 w-4 self-center text-ink-300 md:block" />}
                              </React.Fragment>
                            );
                          })}
                        </div>
                      </>
                    )}
                    {imp.proactive_alert && (
                      <div className="mt-4 flex gap-3 rounded-xl border border-brand-200 bg-brand-50/60 p-3.5">
                        <BellRing className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
                        <div><div className="text-[12px] font-semibold uppercase tracking-wide text-brand-700">Early warning</div><div className="text-[13px] text-ink-900">{imp.proactive_alert}</div></div>
                      </div>
                    )}
                    <div className="mt-4"><div className="eyebrow mb-1.5">Suggested actions</div>
                      <ul className="grid gap-1.5 md:grid-cols-2">{imp.recommended_actions.map((a: string) => <li key={a} className="rounded-lg bg-ink-50 px-3 py-2 text-[12.5px]">{a}</li>)}</ul></div>
                  </CardBody>
                </Card>
                <Card>
                  <CardHeader title="Affected vendors" subtitle="Score, risk of decline and outside-event risk shown side by side - never combined" />
                  <CardBody className="overflow-x-auto px-2 pt-2">
                    {imp.vendors.length === 0 ? <EmptyState title="No vendors linked to this event" /> : (
                      <table className="w-full text-[12.5px]">
                        <thead><tr><Th>Vendor</Th><Th className="text-right">Score</Th><Th>Risk of decline</Th><Th>Outside-event risk</Th><Th className="text-right">Orders on the way</Th><Th className="text-right">Key orders at risk</Th><Th>Categories</Th></tr></thead>
                        <tbody>{imp.vendors.slice(0, 25).map((v: { vendor_id: string; name: string; performance_score: number; performance_band: Band; internal_risk: string; external_risk: string; open_pos: number; open_value: number; critical_pos_at_risk: number; categories: string[] }) => (
                          <tr key={v.vendor_id}>
                            <Td><VendorLink id={v.vendor_id} name={v.name} className="max-w-[220px]" /></Td>
                            <Td className="text-right"><div className="flex items-center justify-end gap-1.5"><span className="num font-semibold">{v.performance_score?.toFixed(1)}</span>{v.performance_band && <BandBadge band={v.performance_band} />}</div></Td>
                            <Td><RiskBadge level={v.internal_risk} label="" /></Td>
                            <Td><RiskBadge level={v.external_risk} label="" /></Td>
                            <Td className="num text-right">{v.open_pos} <span className="text-ink-400">({fmt.gbp(v.open_value)})</span></Td>
                            <Td className={cn("num text-right", v.critical_pos_at_risk > 0 && "font-semibold text-rose-700")}>{v.critical_pos_at_risk}</Td>
                            <Td className="text-ink-600">{v.categories.join(", ")}</Td>
                          </tr>))}</tbody>
                      </table>
                    )}
                    <p className="px-3 pt-3 text-[11.5px] text-ink-500">{imp.note}</p>
                  </CardBody>
                </Card>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
