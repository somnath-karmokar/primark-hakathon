import * as React from "react";
import {
  AlertTriangle, BadgeCheck, Ban, Calculator, CheckCircle2, CircleDollarSign, Eye, Fingerprint, Gauge, HandCoins, Lock, MessageSquareHeart,
  PiggyBank, Scale, ShieldCheck, ThumbsDown, TrendingUp, Users, UserCheck, XCircle,
} from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useSaveBudget, useTrustFinops, useTrustRAI, useTrustSecurity } from "@/hooks/queries";
import { ChartTooltip, ErrorState, KpiTile, LoadingCard, PageHeader } from "@/components/domain";
import { Badge, Button, Card, CardBody, CardHeader, Input, Slider, Switch, Tabs, TabsContent, TabsList, TabsTrigger, Td, Th, Tip } from "@/components/ui/primitives";
import { useAuth } from "@/lib/auth";
import { cn, fmt } from "@/lib/utils";

const PRINCIPLE_ICON: Record<string, React.ElementType> = {
  "Human in control": UserCheck, "Accuracy & grounding": BadgeCheck, Transparency: Eye, Fairness: Scale, Privacy: Fingerprint,
  "Safety & security": ShieldCheck, "Honest ML": Gauge, "Feedback & accountability": MessageSquareHeart,
};

const KEY_LABEL: Record<string, string> = {
  "-": "No AI call needed", semantic_cache: "Answer reused (cache)", performance_explanation: "Explain performance", recommendation: "Recommend action",
  summary: "Summarise", policy_explanation: "Explain policy", executive_synthesis: "Executive summary", classify: "Understand question",
};
const keyLabel = (k: string) => KEY_LABEL[k] ?? k.replace(/^(openai|azure):/, "").replace(/_/g, " ");

const money = (v: number | null | undefined, d = 2) => (v == null ? "-" : v < 0.01 && v > 0 ? `£${v.toFixed(4)}` : `£${v.toLocaleString("en-GB", { minimumFractionDigits: d, maximumFractionDigits: d })}`);

/* ================================================================ Responsible AI */
function ResponsibleAI() {
  const { data, isLoading, error } = useTrustRAI();
  if (error) return <ErrorState error={error} />;
  if (isLoading || !data) return <LoadingCard h="h-96" />;
  const m = data.metrics;
  const f = data.fairness;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 2xl:grid-cols-7">
        <KpiTile label="AI answers given" value={fmt.int(m.answers)} icon={MessageSquareHeart} sub={`${m.ai_written} written by AI · ${m.fact_based_fallback} fact-based`} />
        <KpiTile label="Passed every check" value={fmt.pct(m.fully_checked_pct)} icon={BadgeCheck} accent="#1f8a4c" sub="figures, citations, policy" />
        <KpiTile label="AI drafts rejected" value={m.drafts_rejected} icon={XCircle} accent="#dd5a24" sub="replaced by checked answer" />
        <KpiTile label="Questions blocked" value={m.blocked_questions} icon={Ban} accent="#a8223d" sub={`${m.injection_attempts} manipulation attempts`} />
        <KpiTile label="Personal data removed" value={m.personal_data_redactions} icon={Fingerprint} sub="before reaching the AI" />
        <KpiTile label="Waiting for approval" value={m.approvals_pending} icon={UserCheck} accent="#eaa400" sub={`${m.approvals_approved} approved · ${m.approvals_rejected} rejected`} />
        <KpiTile label="Rated helpful" value={m.feedback_positive_pct != null ? fmt.pct(m.feedback_positive_pct, 0) : "-"} icon={MessageSquareHeart} sub={`${m.feedback_up} helpful · ${m.feedback_down} not helpful`} />
      </div>

      <Card>
        <CardHeader title="How we use AI responsibly" subtitle="Each principle, the controls that enforce it, and live evidence from this system" icon={<ShieldCheck className="h-4 w-4 text-brand-500" />} />
        <CardBody className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {data.principles.map((p: { principle: string; what: string; controls: string[]; evidence: string }) => {
            const Icon = PRINCIPLE_ICON[p.principle] ?? ShieldCheck;
            return (
              <div key={p.principle} className="flex flex-col rounded-xl border border-ink-100 p-3.5">
                <div className="flex items-center gap-2"><span className="rounded-lg bg-brand-50 p-1.5"><Icon className="h-4 w-4 text-brand-600" /></span><span className="text-[13.5px] font-semibold">{p.principle}</span></div>
                <p className="mt-2 text-[12.5px] text-ink-700">{p.what}</p>
                <ul className="mt-2 flex-1 space-y-1 text-[12px] text-ink-600">{p.controls.map((c) => <li key={c} className="flex gap-1.5"><CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />{c}</li>)}</ul>
                <div className="mt-3 rounded-lg bg-ink-50 px-2.5 py-1.5 text-[11.5px] text-ink-700"><span className="font-semibold">Live: </span>{p.evidence}</div>
              </div>
            );
          })}
        </CardBody>
      </Card>

      <div className="grid gap-4 xl:grid-cols-12">
        <Card className="xl:col-span-12">
          <CardHeader title="Fairness check - are all sourcing regions treated the same way?" icon={<Scale className="h-4 w-4 text-brand-500" />}
            subtitle={`Average score by region (portfolio average ${f.portfolio_avg}). Largest gap: ${f.max_gap} points.`} />
          <CardBody className="overflow-x-auto px-2 pt-2">
            <table className="w-full text-[12.5px]">
              <thead><tr><Th>Region</Th><Th className="text-right">Vendors</Th><Th className="w-44">Average score</Th><Th className="text-right">Delivery</Th><Th className="text-right">Quality</Th><Th className="text-right">Cost</Th><Th className="text-right">Lead time</Th><Th className="text-right">Below 75</Th><Th>Main reason for difference</Th></tr></thead>
              <tbody>{f.by_region.map((r: { region: string; vendors: number; overall: number; delivery: number; quality: number; cost: number; lead_time: number; weak: number; explained_by: string }) => (
                <tr key={r.region}>
                  <Td className="font-medium">{r.region}</Td><Td className="num text-right">{r.vendors}</Td>
                  <Td><div className="flex items-center gap-2"><div className="h-1.5 flex-1 rounded-full bg-ink-100"><div className="h-1.5 rounded-full bg-brand-500" style={{ width: `${r.overall}%` }} /></div><span className="num w-9 text-right font-semibold">{r.overall}</span></div></Td>
                  {(["delivery", "quality", "cost", "lead_time"] as const).map((k) => <Td key={k} className="num text-right text-ink-700">{r[k]}</Td>)}
                  <Td className="num text-right">{r.weak}%</Td><Td className="text-ink-600">{r.explained_by}</Td>
                </tr>))}</tbody>
            </table>
            <p className="px-3 pt-3 text-[12px] text-ink-700">{f.verdict}</p>
            <p className="px-3 pt-1 text-[11.5px] text-ink-500">{f.threshold_note}</p>
          </CardBody>
        </Card>
        <Card className="xl:col-span-12">
          <CardHeader title="Answers people marked 'not helpful'" subtitle="Reviewed by the Procurement Excellence team" icon={<ThumbsDown className="h-4 w-4 text-brand-500" />} />
          <CardBody>
            {data.recent_negative_feedback.length === 0 ? <p className="text-[12.5px] text-ink-500">No negative feedback yet. Users can rate any answer with a thumbs up or down in the AI assistant.</p> : (
              <ul className="space-y-2">{data.recent_negative_feedback.map((n: { ts: string; user: string; question: string; comment: string | null; request_id: string }) => (
                <li key={n.request_id + n.ts} className="rounded-lg border border-ink-100 p-2.5 text-[12px]">
                  <div className="font-medium text-ink-900">{n.question || "(question not captured)"}</div>
                  {n.comment && <div className="mt-0.5 text-ink-600">"{n.comment}"</div>}
                  <div className="mt-1 text-[11px] text-ink-400">{n.user} · {fmt.datetime(n.ts)} · {n.request_id}</div>
                </li>))}</ul>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

/* ================================================================ FinOps */
function Finops() {
  const { data, isLoading, error } = useTrustFinops();
  const save = useSaveBudget();
  const { can } = useAuth();
  const admin = can("configure");
  const [budget, setBudget] = React.useState<{ monthly_budget_gbp: number; alert_pct: number; hard_stop: boolean }>();
  const [users, setUsers] = React.useState(50);
  const [qpd, setQpd] = React.useState(10);
  const [days, setDays] = React.useState(21);
  React.useEffect(() => { if (data && !budget) setBudget({ monthly_budget_gbp: data.budget.monthly_budget_gbp, alert_pct: data.budget.alert_pct, hard_stop: data.budget.hard_stop }); }, [data, budget]);
  if (error) return <ErrorState error={error} />;
  if (isLoading || !data || !budget) return <LoadingCard h="h-96" />;
  const b = data.budget;
  const fx = data.usd_to_gbp;
  const req = Math.max(1, data.requests);
  const avgPrompt = data.requests ? data.tokens.prompt / req : 1800;
  const avgCompletion = data.requests ? data.tokens.completion / req : 250;
  const cacheShare = data.share_answered_without_new_model_call / 100;
  const questions = users * qpd * days;
  const perQ = (model: string) => {
    const [pin, pout] = data.prices_usd_per_million[model] ?? [0, 0];
    return ((avgPrompt / 1e6) * pin + (avgCompletion / 1e6) * pout) * fx;
  };
  const scenario = (model: string) => questions * (1 - cacheShare) * perQ(model);
  const active = data.active_model as string;
  const fixedLow = data.infrastructure.filter((i: { low: number | null }) => i.low != null).reduce((a: number, i: { low: number }) => a + i.low, 0);
  const fixedHigh = data.infrastructure.filter((i: { high: number | null }) => i.high != null).reduce((a: number, i: { high: number }) => a + i.high, 0);

  return (
    <div className="space-y-4">
      {b.alert && <div className={cn("flex items-center gap-2 rounded-lg border px-4 py-2.5 text-[12.5px]", b.exhausted ? "border-rose-200 bg-rose-50 text-rose-900" : "border-amber-200 bg-amber-50 text-amber-900")}>
        <AlertTriangle className="h-4 w-4" />{b.exhausted ? (b.hard_stop ? "Monthly AI budget used up - the assistant now answers from facts only until next month." : "Monthly AI budget used up - spending continues (hard stop is off).") : `AI spend has passed ${b.alert_pct}% of the monthly budget.`}</div>}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 2xl:grid-cols-7">
        <KpiTile label={`AI spend - ${data.month}`} value={money(data.month_to_date_gbp, 4)} icon={CircleDollarSign} sub={`${fmt.int(data.model_calls)} AI model calls`} />
        <KpiTile label="Month-end forecast" value={money(data.forecast_month_gbp, 2)} icon={TrendingUp} sub="at the current daily rate" />
        <KpiTile label="Budget used" value={fmt.pct(b.used_pct, 1)} icon={HandCoins} accent={b.exhausted ? "#a8223d" : b.alert ? "#eaa400" : "#1f8a4c"} sub={`${money(b.spent_gbp, 4)} of ${money(b.monthly_budget_gbp, 0)} / month`} />
        <KpiTile label="Cost per question" value={money(data.avg_cost_per_question_gbp, 4)} icon={Calculator} sub={`${fmt.int(data.requests)} questions this month`} />
        <KpiTile label="Answered without a new AI call" value={fmt.pct(data.share_answered_without_new_model_call, 0)} icon={PiggyBank} accent="#1f8a4c" sub="cache or fact-based answers" />
        <KpiTile label="Saved by optimisation" value={money(data.savings.total_saving_gbp, 4)} icon={PiggyBank} sub={`${data.savings.cache_hits} cached · ${fmt.int(data.savings.jev_tokens_saved)} tokens trimmed`} />
        <KpiTile label="Tokens used" value={fmt.int(data.tokens.prompt + data.tokens.completion)} icon={Gauge} sub={`${fmt.int(data.tokens.prompt)} in · ${fmt.int(data.tokens.completion)} out`} />
      </div>

      <div className="grid gap-4 xl:grid-cols-12">
        <Card className="xl:col-span-8">
          <CardHeader title="Daily AI spend (last 30 days)" subtitle={`Model: ${active} · prices in GBP at ${fx} per USD`} />
          <CardBody><div className="h-[220px]"><ResponsiveContainer>
            <BarChart data={data.daily} margin={{ top: 6, right: 8, left: -6, bottom: 0 }}>
              <CartesianGrid vertical={false} /><XAxis dataKey="date" tickFormatter={(d) => d.slice(5)} tickLine={false} axisLine={false} interval={4} />
              <YAxis tickLine={false} axisLine={false} tickFormatter={(v) => `£${Number(v).toFixed(4)}`} width={66} />
              <Tooltip content={<ChartTooltip valueFormatter={(v: number) => `£${v.toFixed(5)}`} />} />
              <Bar dataKey="cost_gbp" name="AI spend" fill="#0a8fc4" radius={[3, 3, 0, 0]} />
            </BarChart></ResponsiveContainer></div></CardBody>
        </Card>
        <Card className="xl:col-span-4">
          <CardHeader title="Monthly AI budget" subtitle={admin ? "Admins can change the budget; changes are audited" : "Set by the administrator"} icon={<Lock className="h-4 w-4 text-brand-500" />} />
          <CardBody className="space-y-4">
            <div className="h-2.5 overflow-hidden rounded-full bg-ink-100"><div className={cn("h-2.5 rounded-full", b.exhausted ? "bg-band-critical" : b.alert ? "bg-band-watch" : "bg-band-excellent")} style={{ width: `${Math.min(100, b.used_pct)}%` }} /></div>
            <label className="block"><span className="text-[12px] font-medium text-ink-600">Budget per month (£)</span>
              <Input type="number" min={0} value={budget.monthly_budget_gbp} disabled={!admin} onChange={(e) => setBudget({ ...budget, monthly_budget_gbp: Number(e.target.value) })} className="mt-1 h-9" /></label>
            <div><div className="mb-1.5 flex justify-between text-[12px]"><span className="font-medium text-ink-600">Warn at</span><span className="num font-semibold">{budget.alert_pct}%</span></div>
              <Slider value={[budget.alert_pct]} min={10} max={100} step={5} disabled={!admin} onValueChange={([v]) => setBudget({ ...budget, alert_pct: v })} aria-label="Alert threshold" /></div>
            <label className="flex items-start justify-between gap-3"><span><span className="block text-[12.5px] font-medium">Hard stop at 100%</span><span className="block text-[11px] text-ink-500">Assistant keeps working from facts only - no surprise bills</span></span>
              <Switch checked={budget.hard_stop} disabled={!admin} onCheckedChange={(v) => setBudget({ ...budget, hard_stop: v })} /></label>
            {admin && <Button className="w-full" onClick={() => save.mutate(budget)} disabled={save.isPending}>Save budget</Button>}
            {save.isSuccess && <p className="text-[12px] text-emerald-700">Budget saved.</p>}
          </CardBody>
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-12">
        <Card className="xl:col-span-7">
          <CardHeader title="What would it cost at scale?" subtitle="Uses the measured tokens per question and cache rate from this system" icon={<Calculator className="h-4 w-4 text-brand-500" />} />
          <CardBody>
            <div className="grid gap-4 md:grid-cols-3">
              {[["People using it", users, setUsers, 5, 500, 5], ["Questions per person per day", qpd, setQpd, 1, 50, 1], ["Working days per month", days, setDays, 5, 23, 1]].map(([l, v, set, mn, mx, st]) => (
                <div key={l as string}><div className="mb-1.5 flex justify-between text-[12px]"><span className="font-medium text-ink-600">{l as string}</span><span className="num font-semibold">{v as number}</span></div>
                  <Slider value={[v as number]} min={mn as number} max={mx as number} step={st as number} onValueChange={([x]) => (set as (n: number) => void)(x)} aria-label={l as string} /></div>
              ))}
            </div>
            <div className="mt-4 rounded-xl bg-ink-50 p-3 text-[12.5px] text-ink-700">{fmt.int(questions)} questions a month · {Math.round(cacheShare * 100)}% answered without a new AI call · ~{fmt.int(avgPrompt)} tokens in / {fmt.int(avgCompletion)} out per AI answer</div>
            <table className="mt-3 w-full text-[12.5px]">
              <thead><tr><Th>AI model</Th><Th className="text-right">Cost per AI answer</Th><Th className="text-right">Monthly AI cost</Th><Th className="text-right">Per person / month</Th></tr></thead>
              <tbody>{Object.keys(data.prices_usd_per_million).filter((k) => !k.startsWith("text-embedding")).map((k) => (
                <tr key={k} className={cn(k === active && "bg-brand-50/50")}><Td className="font-medium">{k}{k === active && <Badge tone="brand" className="ml-2">in use</Badge>}</Td>
                  <Td className="num text-right">{money(perQ(k), 5)}</Td><Td className="num text-right font-semibold">{money(scenario(k), 2)}</Td><Td className="num text-right">{money(scenario(k) / users, 3)}</Td></tr>))}</tbody>
            </table>
            <p className="mt-2 text-[11px] text-ink-500">List prices per million tokens (configurable). Fixed-rule scoring means no AI cost for scores, rankings or recommended actions.</p>
          </CardBody>
        </Card>
        <Card className="xl:col-span-5">
          <CardHeader title="Expected monthly running cost (pilot)" subtitle="Indicative planning ranges - confirm with the Azure / Neo4j pricing calculators" icon={<CircleDollarSign className="h-4 w-4 text-brand-500" />} />
          <CardBody className="px-2 pt-2">
            <table className="w-full text-[12.5px]">
              <thead><tr><Th>Item</Th><Th className="text-right">£ / month</Th></tr></thead>
              <tbody>{data.infrastructure.map((i: { item: string; low: number | null; high: number | null; basis: string }) => (
                <tr key={i.item}><Td><div className="font-medium">{i.item}</div><div className="text-[11px] text-ink-500">{i.basis}</div></Td>
                  <Td className="num whitespace-nowrap text-right">{i.low == null ? money(scenario(active), 2) : i.low === i.high ? money(i.low, 0) : `${money(i.low, 0)} - ${money(i.high, 0)}`}</Td></tr>))}
                <tr className="bg-ink-50/70"><Td className="font-semibold">Total (with the scenario above)</Td><Td className="num whitespace-nowrap text-right font-semibold">{money(fixedLow + scenario(active), 0)} - {money(fixedHigh + scenario(active), 0)}</Td></tr></tbody>
            </table>
          </CardBody>
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-12">
        <Card className="xl:col-span-7">
          <CardHeader title="Who and what is spending" subtitle="Cost attribution for showback / chargeback (this month)" icon={<Users className="h-4 w-4 text-brand-500" />} />
          <CardBody className="grid gap-4 px-2 pt-2 md:grid-cols-2">
            {[["By role", data.by_role], ["By person", data.by_user], ["By AI task", data.by_task], ["By model", data.by_model]].map(([title, rows]) => (
              <div key={title as string}>
                <div className="eyebrow mb-1 px-3">{title as string}</div>
                <table className="w-full text-[12px]"><thead><tr><Th></Th><Th className="text-right">Questions</Th><Th className="text-right">AI calls</Th><Th className="text-right">Cost</Th></tr></thead>
                  <tbody>{(rows as { key: string; requests: number; calls: number; cost_gbp: number }[]).slice(0, 6).map((r) => (
                    <tr key={r.key}><Td>{keyLabel(r.key)}</Td><Td className="num text-right">{r.requests}</Td><Td className="num text-right">{r.calls}</Td><Td className="num text-right font-medium">{money(r.cost_gbp, 4)}</Td></tr>))}</tbody></table>
              </div>
            ))}
          </CardBody>
        </Card>
        <Card className="xl:col-span-5">
          <CardHeader title="How the solution keeps AI costs down" icon={<PiggyBank className="h-4 w-4 text-brand-500" />} />
          <CardBody><ul className="space-y-2.5">{data.levers.map((l: { lever: string; effect: string }) => (
            <li key={l.lever} className="flex gap-2.5 text-[12.5px]"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /><span><span className="font-semibold text-ink-900">{l.lever}.</span> <span className="text-ink-600">{l.effect}</span></span></li>))}</ul>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

/* ================================================================ Security */
const STATUS = {
  pass: { icon: CheckCircle2, cls: "text-emerald-600", label: "In place", tone: "good" as const },
  warn: { icon: AlertTriangle, cls: "text-amber-600", label: "Demo setting", tone: "warning" as const },
  fail: { icon: XCircle, cls: "text-rose-600", label: "Fix needed", tone: "critical" as const },
};

function Security() {
  const { data, isLoading, error } = useTrustSecurity();
  if (error) return <ErrorState error={error} />;
  if (isLoading || !data) return <LoadingCard h="h-96" />;
  const areas = [...new Set(data.checks.map((c: { area: string }) => c.area))] as string[];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <KpiTile label="Controls in place" value={data.summary.pass} icon={CheckCircle2} accent="#1f8a4c" sub="checked live on this system" />
        <KpiTile label="Demo-only settings" value={data.summary.warn} icon={AlertTriangle} accent="#eaa400" sub="acceptable locally; changed for production" />
        <KpiTile label="Fix needed" value={data.summary.fail} icon={XCircle} accent="#a8223d" sub="should be zero" />
      </div>
      <Card>
        <CardHeader title="Security checks - today and in an enterprise rollout" subtitle="Checked automatically each time this page loads" icon={<ShieldCheck className="h-4 w-4 text-brand-500" />} />
        <CardBody className="overflow-x-auto px-2 pt-2">
          <table className="w-full text-[12.5px]">
            <thead><tr><Th>Area</Th><Th>Check</Th><Th>Status</Th><Th>In this build</Th><Th>Enterprise implementation</Th></tr></thead>
            <tbody>{areas.map((a) => data.checks.filter((c: { area: string }) => c.area === a).map((c: { area: string; check: string; status: "pass" | "warn" | "fail"; detail: string; enterprise: string }, i: number) => {
              const st = STATUS[c.status];
              return (
                <tr key={c.check} className="align-top">
                  <Td className="font-semibold text-ink-700">{i === 0 ? a : ""}</Td>
                  <Td className="font-medium">{c.check}</Td>
                  <Td><span className="inline-flex items-center gap-1 whitespace-nowrap"><st.icon className={cn("h-4 w-4", st.cls)} /><Badge tone={st.tone}>{st.label}</Badge></span></Td>
                  <Td className="text-ink-600">{c.detail}</Td>
                  <Td className="text-ink-600">{c.enterprise}</Td>
                </tr>
              );
            }))}</tbody>
          </table>
        </CardBody>
      </Card>
      <Card>
        <CardHeader title="Enterprise security plan" subtitle="How security would be delivered in a Primark production rollout on Azure" icon={<Lock className="h-4 w-4 text-brand-500" />} />
        <CardBody className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {data.enterprise_plan.map((p: { area: string; items: string[] }) => (
            <div key={p.area} className="rounded-xl border border-ink-100 p-3">
              <div className="mb-1.5 text-[13px] font-semibold">{p.area}</div>
              <ul className="space-y-1 text-[12px] text-ink-600">{p.items.map((i) => <li key={i} className="flex gap-1.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-ink-400" />{i}</li>)}</ul>
            </div>
          ))}
        </CardBody>
      </Card>
    </div>
  );
}

export default function TrustCentrePage() {
  return (
    <>
      <PageHeader eyebrow="Trust Centre" title="Responsible AI, costs and security"
        description="How the solution uses AI responsibly, what it costs to run and how it is kept secure - backed by live evidence from this system." />
      <Tabs defaultValue="rai">
        <TabsList className="mb-4">
          <TabsTrigger value="rai"><span className="inline-flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" />Responsible AI</span></TabsTrigger>
          <TabsTrigger value="cost"><span className="inline-flex items-center gap-1.5"><CircleDollarSign className="h-3.5 w-3.5" />AI costs (FinOps)</span></TabsTrigger>
          <TabsTrigger value="security"><span className="inline-flex items-center gap-1.5"><Lock className="h-3.5 w-3.5" />Security</span></TabsTrigger>
        </TabsList>
        <TabsContent value="rai"><ResponsibleAI /></TabsContent>
        <TabsContent value="cost"><Finops /></TabsContent>
        <TabsContent value="security"><Security /></TabsContent>
      </Tabs>
      <p className="mt-4 text-[11.5px] text-ink-400"><Tip content="Figures come from the audit log, AI usage records and live configuration."><span className="cursor-help underline decoration-dotted">Where do these numbers come from?</span></Tip></p>
    </>
  );
}
