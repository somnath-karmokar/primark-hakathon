import * as React from "react";
import { useSearchParams } from "react-router-dom";
import { Crown, Plus, X } from "lucide-react";
import {
  CartesianGrid, Legend, Line, LineChart, PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { useAlternatives, useCompare, useVendors } from "@/hooks/queries";
import { BandBadge, ChartTooltip, Delta, EmptyState, ErrorState, LoadingCard, PageHeader, RiskBadge, VendorLink } from "@/components/domain";
import { Button, Card, CardBody, CardHeader, Input, Td, Th } from "@/components/ui/primitives";
import { SERIES, cn, fmt } from "@/lib/utils";
import type { VendorRow } from "@/types/api";

function AddVendor({ onAdd, exclude }: { onAdd: (id: string) => void; exclude: string[] }) {
  const [q, setQ] = React.useState("");
  const { data } = useVendors({ search: q, page_size: 6 });
  const items = q.length >= 2 ? (data?.items ?? []).filter((v) => !exclude.includes(v.vendor_id)) : [];
  return (
    <div className="relative w-72">
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Add vendor (ID or name)" aria-label="Add vendor to comparison" />
      {items.length > 0 && (
        <ul className="absolute z-30 mt-1 w-full overflow-hidden rounded-lg border border-ink-100 bg-white shadow-lift">
          {items.map((v) => (
            <li key={v.vendor_id}><button className="flex w-full items-center justify-between px-3 py-2 text-left text-[12.5px] hover:bg-ink-50" onClick={() => { onAdd(v.vendor_id); setQ(""); }}>
              <span><span className="num font-semibold">{v.vendor_id}</span> <span className="text-ink-500">{v.name}</span></span><Plus className="h-3.5 w-3.5 text-ink-400" /></button></li>
          ))}
        </ul>
      )}
    </div>
  );
}

const ROWS: { key: keyof VendorRow; label: string; type: "score" | "text" | "risk" | "delta" }[] = [
  { key: "overall", label: "Overall score", type: "score" }, { key: "delivery", label: "Delivery", type: "score" },
  { key: "quality", label: "Quality", type: "score" }, { key: "cost", label: "Cost", type: "score" },
  { key: "lead_time", label: "Lead-time consistency", type: "score" }, { key: "change_3m", label: "Change in 3 months", type: "delta" },
  { key: "risk_level", label: "Risk of decline", type: "risk" }, { key: "external_risk", label: "Outside-event risk", type: "risk" },
  { key: "category", label: "Category", type: "text" }, { key: "region", label: "Region", type: "text" }, { key: "tier", label: "Tier", type: "text" },
];

export default function ComparePage() {
  const [sp, setSp] = useSearchParams();
  const ids = (sp.get("ids") ?? "V1024,V1112,V1203").split(",").filter(Boolean).slice(0, 5);
  const setIds = (n: string[]) => setSp({ ids: n.join(",") }, { replace: true });
  const { data, isLoading, error } = useCompare(ids);
  const single = ids.length === 1 ? ids[0] : undefined;
  const { data: alts } = useAlternatives(single ?? ids[0], 4);

  return (
    <>
      <PageHeader eyebrow="Compare vendors" title="Compare vendors side by side" description="Pick 2 to 5 vendors to compare their scores, risks and trends. The best value in each row is highlighted."
        actions={<AddVendor exclude={ids} onAdd={(id) => ids.length < 5 && setIds([...ids, id])} />} />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {ids.map((id, i) => (
          <span key={id} className="inline-flex items-center gap-2 rounded-full border border-ink-200 bg-white py-1 pl-2.5 pr-1.5 text-[12.5px] font-semibold">
            <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: SERIES[i] }} />{id}
            <button onClick={() => setIds(ids.filter((x) => x !== id))} className="rounded-full p-0.5 hover:bg-ink-100" aria-label={`Remove ${id}`}><X className="h-3.5 w-3.5" /></button>
          </span>
        ))}
        {alts && ids.length < 5 && alts.alternatives.filter((a) => !ids.includes(a.vendor_id)).slice(0, 3).map((a) => (
          <Button key={a.vendor_id} variant="subtle" size="sm" onClick={() => setIds([...ids, a.vendor_id])}><Plus />{a.vendor_id} <span className="font-normal">(could replace {alts.vendor.vendor_id})</span></Button>
        ))}
      </div>
      {ids.length < 2 ? <Card><EmptyState title="Select at least two vendors" hint="Add vendors with the search box, or pick a suggested alternative." /></Card>
        : error ? <ErrorState error={error} /> : isLoading || !data ? <div className="grid gap-4 md:grid-cols-2"><LoadingCard /><LoadingCard /></div> : (
        <>
          <Card className="mb-4 overflow-x-auto">
            <table className="w-full text-[13px]">
              <thead><tr><Th className="w-48">Metric</Th>{data.vendors.map((v: VendorRow, i: number) => (
                <Th key={v.vendor_id} className="normal-case"><div className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: SERIES[i] }} /><VendorLink id={v.vendor_id} name={v.name} className="max-w-[200px]" /></div></Th>))}</tr></thead>
              <tbody>
                <tr><Td className="text-ink-500">Band</Td>{data.vendors.map((v: VendorRow) => <Td key={v.vendor_id}><BandBadge band={v.band} /></Td>)}</tr>
                {ROWS.map((r) => (
                  <tr key={r.key as string}>
                    <Td className="text-ink-500">{r.label}</Td>
                    {data.vendors.map((v: VendorRow) => {
                      const best = data.best[r.key as string] === v.vendor_id;
                      const val = v[r.key];
                      return (
                        <Td key={v.vendor_id} className={cn(best && "bg-emerald-50/60")}>
                          {r.type === "score" ? <span className="num inline-flex items-center gap-1.5 font-semibold">{(val as number).toFixed(1)}{best && <Crown className="h-3.5 w-3.5 text-emerald-600" aria-label="best" />}</span>
                            : r.type === "delta" ? <Delta value={val as number} />
                            : r.type === "risk" ? <RiskBadge level={val as string} label="" />
                            : <span className="text-ink-700">{String(val ?? "-")}</span>}
                        </Td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
          <div className="grid gap-4 xl:grid-cols-2">
            <Card><CardHeader title="Strengths at a glance" subtitle="The four score areas - bigger shape is better" />
              <CardBody><div className="h-[320px]"><ResponsiveContainer>
                <RadarChart data={["delivery", "quality", "cost", "lead_time"].map((k, j) => ({ comp: ["Delivery", "Quality", "Cost", "Lead-time"][j], ...Object.fromEntries(data.vendors.map((v: VendorRow) => [v.vendor_id, v[k as keyof VendorRow]])) }))}>
                  <PolarGrid stroke="#e9edf3" /><PolarAngleAxis dataKey="comp" tick={{ fontSize: 11.5, fill: "#33445a" }} /><PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                  {data.vendors.map((v: VendorRow, i: number) => <Radar key={v.vendor_id} dataKey={v.vendor_id} stroke={SERIES[i]} fill={SERIES[i]} fillOpacity={0.08} strokeWidth={2} />)}
                  <Legend wrapperStyle={{ fontSize: 11.5 }} /><Tooltip content={<ChartTooltip />} />
                </RadarChart></ResponsiveContainer></div></CardBody></Card>
            <Card><CardHeader title="Score over time" subtitle="Overall score by month" />
              <CardBody><div className="h-[320px]"><ResponsiveContainer>
                <LineChart data={(data.series[data.vendors[0].vendor_id] ?? []).map((p: { period: string }, idx: number) => ({ period: p.period, ...Object.fromEntries(data.vendors.map((v: VendorRow) => [v.vendor_id, data.series[v.vendor_id]?.[idx]?.overall])) }))} margin={{ top: 8, right: 12, left: -18, bottom: 0 }}>
                  <CartesianGrid vertical={false} /><XAxis dataKey="period" tickFormatter={fmt.month} tickLine={false} axisLine={false} /><YAxis domain={[40, 100]} tickLine={false} axisLine={false} />
                  <Tooltip content={<ChartTooltip labelFormatter={fmt.month} />} /><Legend iconType="plainline" wrapperStyle={{ fontSize: 11.5 }} />
                  {data.vendors.map((v: VendorRow, i: number) => <Line key={v.vendor_id} dataKey={v.vendor_id} stroke={SERIES[i]} strokeWidth={2} dot={false} />)}
                </LineChart></ResponsiveContainer></div></CardBody></Card>
          </div>
        </>
      )}
    </>
  );
}
