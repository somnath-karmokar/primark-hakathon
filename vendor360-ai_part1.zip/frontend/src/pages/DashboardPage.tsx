import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Activity, AlertOctagon, AlertTriangle, ArrowRight, Award, Building2, ShieldAlert, Sparkles, TrendingDown, Users,
  PoundSterling, Truck, ShieldCheck, Receipt, Timer, FileCheck2, PackageOpen,
} from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useDashboard } from "@/hooks/queries";
import { FilterBar, useUrlFilters } from "@/components/FilterBar";
import {
  BandBadge, ChartTooltip, Delta, ErrorState, KpiTile, LoadingCard, PageHeader, RiskBadge, SectionLink, VendorLink,
} from "@/components/domain";
import { Card, CardBody, CardHeader, Td, Th } from "@/components/ui/primitives";
import { BAND_COLOR, BAND_ORDER, SERIES, fmt } from "@/lib/utils";
import type { VendorRow } from "@/types/api";

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } };

function VendorTable({ rows, showChange }: { rows: VendorRow[]; showChange?: boolean }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-[12.5px]">
        <thead><tr><Th>Vendor</Th><Th className="text-right">Score</Th><Th>Band</Th>{showChange && <Th className="text-right">3m</Th>}</tr></thead>
        <tbody>
          {rows.map((v) => (
            <tr key={v.vendor_id} className="hover:bg-ink-50/50">
              <Td><VendorLink id={v.vendor_id} name={`${v.name} · ${v.category}`} className="max-w-[260px]" /></Td>
              <Td className="num text-right font-semibold">{fmt.score(v.overall)}</Td>
              <Td><BandBadge band={v.band} /></Td>
              {showChange && <Td className="text-right"><Delta value={v.change_3m} className="text-[12px]" /></Td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function DashboardPage() {
  const [f] = useUrlFilters();
  const { data, isLoading, error, refetch } = useDashboard(f);

  const header = (
    <PageHeader eyebrow="Dashboard" title="How our vendors are performing"
      description={data ? <>{data.kpis.total_vendors} vendors scored out of 100 on delivery, quality, cost and lead-time reliability, based on the 3 months to {fmt.month(data.period)}. Scores are calculated by fixed, published rules - not by AI - so every number can be explained.</> : "Loading..."}
      actions={<FilterBar />} />
  );
  if (error) return <>{header}<ErrorState error={error} onRetry={() => refetch()} /></>;
  if (isLoading || !data) return <>{header}<div className="grid gap-4 md:grid-cols-2"><LoadingCard /><LoadingCard /><LoadingCard /><LoadingCard /></div></>;

  const k = data.kpis;
  const total = Math.max(1, k.total_vendors);
  const featured = data.spotlight;

  return (
    <>
      {header}
      <div className="mb-2 flex items-baseline justify-between"><h2 className="text-[14px] font-semibold">Vendor scores</h2><span className="text-[11.5px] text-ink-500">Score out of 100 · same rules for every vendor</span></div>
      <motion.div variants={stagger} initial="hidden" animate="show" className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-8">
        {[
          { label: "Vendors scored", value: fmt.int(k.total_vendors), icon: Users, sub: "All active vendors", to: "/vendors" },
          { label: "Average score", value: fmt.score(k.avg_score), icon: Activity, delta: k.avg_score_change, sub: "change vs last month" },
          { label: "Excellent", value: k.excellent, icon: Award, accent: BAND_COLOR.Excellent, sub: `${Math.round((k.excellent / total) * 100)}% · score 90+`, to: "/vendors?band=Excellent" },
          { label: "Good", value: k.good, icon: Building2, accent: BAND_COLOR.Good, sub: `${Math.round((k.good / total) * 100)}% · 75-89`, to: "/vendors?band=Good" },
          { label: "Watch", value: k.watch, icon: AlertTriangle, accent: BAND_COLOR.Watch, sub: "60-74 · keep an eye on", to: "/vendors?band=Watch" },
          { label: "At risk", value: k.at_risk, icon: ShieldAlert, accent: BAND_COLOR["At Risk"], sub: "40-59 · improvement plan needed", to: "/vendors?band=At%20Risk" },
          { label: "Critical", value: k.critical, icon: AlertOctagon, accent: BAND_COLOR.Critical, sub: "below 40 · escalate now", to: "/vendors?band=Critical" },
          { label: "Getting worse", value: k.deteriorating, icon: TrendingDown, accent: "#33445a", sub: `${k.high_risk} likely to keep declining`, to: "/vendors?deteriorating=true&sort=change_3m&order=asc" },
        ].map((t) => <motion.div key={t.label} variants={item}><KpiTile {...t} /></motion.div>)}
      </motion.div>

      {data.operational && (() => {
        const o = data.operational; const d = o.delta;
        const tiles = [
          { label: "Spend (3 months)", value: fmt.gbp(o.spend), icon: PoundSterling, sub: `Invoiced ${fmt.month(o.window.start)} - ${fmt.month(o.window.end)}`, tip: "Total invoiced by the vendors shown, in the last 3 months" },
          { label: "Spend at risk", value: fmt.pct(o.spend_at_risk_pct), icon: ShieldAlert, accent: "#dd5a24", delta: d.spend_at_risk_pct, invertDelta: true, deltaSuffix: " pts", sub: `${fmt.gbp(o.spend_at_risk)} with vendors scoring below 75`, tip: "Share of spend placed with vendors in the Watch, At Risk or Critical bands" },
          { label: "On-time delivery", value: fmt.pct(o.on_time_delivery_pct), icon: Truck, delta: d.on_time_delivery_pct, deltaSuffix: " pts", sub: `${fmt.int(o.pos_completed)} orders delivered`, tip: "Orders fully delivered on or before the promised date" },
          { label: "Defect rate", value: fmt.pct(o.defect_rate_pct, 2), icon: ShieldCheck, delta: d.defect_rate_pct, invertDelta: true, deltaSuffix: " pts", sub: "Faulty items found in quality checks", tip: "Faulty items as a share of all items inspected in the last 3 months (lower is better)" },
          { label: "Invoice accuracy", value: fmt.pct(o.invoice_accuracy_pct), icon: Receipt, delta: d.invoice_accuracy_pct, deltaSuffix: " pts", sub: `Invoices within ±${o.invoice_tolerance_pct}% of the order value`, tip: "Invoices that match the agreed order value (contract allows ±1%)" },
          { label: "Avg lead time", value: o.avg_lead_time_days != null ? `${o.avg_lead_time_days.toFixed(0)}d` : "-", icon: Timer, delta: d.avg_lead_time_days, invertDelta: true, deltaSuffix: "d", sub: `${fmt.delta(o.avg_lead_time_variance_days)} days vs promised date`, tip: "Average days from placing an order to final delivery (lower is better)" },
          { label: "Meeting contract targets", value: fmt.pct(o.sla_compliance_pct), icon: FileCheck2, accent: "#1f8a4c", delta: d.sla_compliance_pct, deltaSuffix: " pts", sub: `${fmt.int(o.sla_breaches)} targets missed`, tip: "Vendors meeting every target in their contract (SLA): on-time delivery, quality and invoice accuracy" },
          { label: "Orders on the way", value: fmt.gbp(o.open_po_value), icon: PackageOpen, sub: `${fmt.int(o.open_po_count)} orders · ${fmt.gbp(o.open_po_value_at_risk)} with weaker vendors`, tip: "Orders placed but not yet delivered" },
        ];
        return (
          <>
            <div className="mb-2 flex items-baseline justify-between"><h2 className="text-[14px] font-semibold">Spend, delivery and quality</h2><span className="text-[11.5px] text-ink-500">Last 3 months · arrows show change vs last month</span></div>
            <motion.div variants={stagger} initial="hidden" animate="show" className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4 2xl:grid-cols-8">
              {tiles.map((t) => <motion.div key={t.label} variants={item}><KpiTile {...t} /></motion.div>)}
            </motion.div>
          </>
        );
      })()}

      {featured && (
        <Card className="mb-4 overflow-hidden border-brand-100 bg-gradient-to-r from-brand-50/80 via-white to-white">
          <div className="flex flex-wrap items-center gap-4 px-5 py-3.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-500 text-white"><Sparkles className="h-4 w-4" /></div>
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-semibold text-ink-950">
                {featured.vendor_id} · {featured.name} is getting worse: score {fmt.score(featured.overall)} ({featured.band}), <span className="text-rose-700">{fmt.delta(featured.change_3m)} pts in 3 months</span>
              </div>
              <div className="text-[12px] text-ink-500">Key {featured.category.toLowerCase()} supplier · risk of further decline: {featured.risk_level}. Open the vendor profile to see why, or ask the AI assistant.</div>
            </div>
            <div className="flex gap-2">
              <Link to={`/vendors/${featured.vendor_id}`} className="inline-flex h-8 items-center gap-1 rounded-lg bg-ink-900 px-3 text-[12.5px] font-medium text-white hover:bg-ink-800">View profile <ArrowRight className="h-3.5 w-3.5" /></Link>
              <Link to={`/copilot?q=${encodeURIComponent(`Why is Vendor ${featured.vendor_id} underperforming?`)}`} className="inline-flex h-8 items-center gap-1 rounded-lg border border-ink-200 bg-white px-3 text-[12.5px] font-medium text-ink-800 hover:bg-ink-50">Ask the AI</Link>
            </div>
          </div>
        </Card>
      )}

      <div className="mb-4 grid gap-4 xl:grid-cols-12">
        <Card className="xl:col-span-7">
          <CardHeader title="How scores are spread" subtitle="Number of vendors in each 5-point score range" />
          <CardBody>
            <div className="h-[250px]">
              <ResponsiveContainer>
                <BarChart data={data.distribution} margin={{ top: 8, right: 8, left: -18, bottom: 0 }} barCategoryGap={2}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="from" tickLine={false} axisLine={false} tickFormatter={(v) => `${v}`} />
                  <YAxis tickLine={false} axisLine={false} allowDecimals={false} />
                  <Tooltip cursor={{ fill: "rgba(0,159,214,0.06)" }} content={<ChartTooltip labelFormatter={(v: number) => `Score ${v}-${v + 5}`} valueFormatter={(v: number) => `${v} vendors`} />} />
                  <Bar dataKey="count" name="Vendors" radius={[4, 4, 0, 0]}>
                    {data.distribution.map((d) => <Cell key={d.bucket} fill={BAND_COLOR[d.band]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 flex flex-wrap gap-3 text-[11.5px] text-ink-600">
              {BAND_ORDER.map((b) => <span key={b} className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: BAND_COLOR[b] }} />{b}</span>)}
            </div>
          </CardBody>
        </Card>
        <Card className="xl:col-span-5">
          <CardHeader title="Vendors by score band" subtitle="Share of vendors in each band" />
          <CardBody>
            <div className="mb-4 flex h-3 overflow-hidden rounded-full" role="img" aria-label="Band mix">
              {data.band_counts.map((b) => b.count > 0 && (
                <div key={b.band} style={{ width: `${(b.count / total) * 100}%`, backgroundColor: BAND_COLOR[b.band] }} className="border-r-2 border-white last:border-r-0" />
              ))}
            </div>
            <ul className="space-y-2.5">
              {data.band_counts.map((b) => (
                <li key={b.band} className="flex items-center justify-between gap-3">
                  <BandBadge band={b.band} />
                  <div className="flex flex-1 items-center gap-3">
                    <div className="h-1.5 flex-1 rounded-full bg-ink-100"><div className="h-1.5 rounded-full" style={{ width: `${(b.count / total) * 100}%`, backgroundColor: BAND_COLOR[b.band] }} /></div>
                    <span className="num w-10 text-right font-semibold">{b.count}</span>
                    <span className="num w-10 text-right text-ink-500">{Math.round((b.count / total) * 100)}%</span>
                  </div>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      </div>

      <div className="mb-4 grid gap-4 xl:grid-cols-12">
        <Card className="xl:col-span-8">
          <CardHeader title="Trend over time" subtitle="Average scores by month" />
          <CardBody>
            <div className="h-[330px]">
              <ResponsiveContainer>
                <LineChart data={data.trend} margin={{ top: 8, right: 12, left: -18, bottom: 0 }}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="period" tickFormatter={fmt.month} tickLine={false} axisLine={false} />
                  <YAxis domain={[60, 100]} tickLine={false} axisLine={false} />
                  <Tooltip content={<ChartTooltip labelFormatter={fmt.month} />} />
                  <Legend iconType="plainline" wrapperStyle={{ fontSize: 11.5, paddingTop: 8 }} />
                  <Line dataKey="avg" name="Overall" stroke="#0f1d30" strokeWidth={2.5} dot={false} />
                  <Line dataKey="delivery" name="Delivery" stroke={SERIES[0]} strokeWidth={2} dot={false} />
                  <Line dataKey="quality" name="Quality" stroke={SERIES[1]} strokeWidth={2} dot={false} />
                  <Line dataKey="cost" name="Cost" stroke={SERIES[2]} strokeWidth={2} dot={false} />
                  <Line dataKey="lead_time" name="Lead-time" stroke={SERIES[3]} strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardBody>
        </Card>
        <Card className="xl:col-span-4">
          <CardHeader title="Vendors getting worse" subtitle="Biggest drop in score over 3 months" action={<SectionLink to="/vendors?deteriorating=true&sort=change_3m&order=asc">All</SectionLink>} />
          <CardBody className="pt-1">
            <ul className="divide-y divide-ink-100">
              {data.deteriorating_vendors.slice(0, 7).map((v) => (
                <li key={v.vendor_id} className="flex items-center justify-between gap-3 py-2.5">
                  <VendorLink id={v.vendor_id} name={v.name} className="max-w-[170px]" />
                  <div className="flex items-center gap-2">
                    <RiskBadge level={v.risk_level} label="" />
                    <span className="num w-10 text-right font-semibold">{fmt.score(v.overall)}</span>
                    <Delta value={v.change_3m} className="w-14 justify-end text-[12px]" />
                  </div>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      </div>

      <div className="mb-4 grid gap-4 xl:grid-cols-2">
        <Card><CardHeader title="Top performers" subtitle="Highest scores right now" action={<SectionLink to="/vendors">All scorecards</SectionLink>} /><CardBody className="px-2 pt-2"><VendorTable rows={data.top_vendors} showChange /></CardBody></Card>
        <Card><CardHeader title="Lowest performers" subtitle="May need an improvement plan or escalation" action={<SectionLink to="/vendors?sort=overall&order=asc">All scorecards</SectionLink>} /><CardBody className="px-2 pt-2"><VendorTable rows={data.bottom_vendors} showChange /></CardBody></Card>
      </div>

      <Card>
        <CardHeader title="Performance by category" subtitle="Average scores for each product category" />
        <CardBody className="px-2 pt-2">
          <div className="overflow-x-auto">
            <table className="w-full text-[12.5px]">
              <thead><tr><Th>Category</Th><Th className="text-right">Vendors</Th><Th className="w-[220px]">Average score</Th><Th className="text-right">Delivery</Th><Th className="text-right">Quality</Th><Th className="text-right">Cost</Th><Th className="text-right">Lead-time</Th><Th className="text-right">At risk / critical</Th></tr></thead>
              <tbody>
                {data.category_performance.map((c) => (
                  <tr key={c.category_id} className="hover:bg-ink-50/50">
                    <Td className="font-medium text-ink-900">{c.category}</Td>
                    <Td className="num text-right">{c.vendors}</Td>
                    <Td><div className="flex items-center gap-2"><div className="h-1.5 flex-1 rounded-full bg-ink-100"><div className="h-1.5 rounded-full bg-brand-500" style={{ width: `${c.avg}%` }} /></div><span className="num w-9 text-right font-semibold">{c.avg.toFixed(1)}</span></div></Td>
                    {(["delivery", "quality", "cost", "lead_time"] as const).map((k2) => <Td key={k2} className="num text-right text-ink-700">{c[k2].toFixed(1)}</Td>)}
                    <Td className="num text-right">{c.at_risk > 0 ? <span className="font-semibold text-rose-700">{c.at_risk}</span> : <span className="text-ink-400">0</span>}</Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </>
  );
}
