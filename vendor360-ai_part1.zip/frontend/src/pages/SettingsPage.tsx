import * as React from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { CheckCircle2, KeyRound, Loader2, Lock, Save } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useSaveSettings, useSettings } from "@/hooks/queries";
import { ErrorState, LoadingCard, PageHeader } from "@/components/domain";
import { Badge, Button, Card, CardBody, CardHeader, Input, Slider, Switch, Td, Th } from "@/components/ui/primitives";

const schema = z.object({
  weights: z.object({ delivery: z.number().min(0).max(1), quality: z.number().min(0).max(1), cost: z.number().min(0).max(1), lead_time: z.number().min(0).max(1) })
    .refine((w) => Math.abs(w.delivery + w.quality + w.cost + w.lead_time - 1) < 0.001, { message: "Weights must sum to 100%" }),
  risk: z.object({
    high_threshold: z.number().min(0.05).max(0.99), medium_threshold: z.number().min(0.01).max(0.95),
    deterioration_drop_points: z.number().min(2).max(40), approval_confidence_threshold: z.number().min(0.3).max(0.99),
  }).refine((r) => r.medium_threshold < r.high_threshold, { message: "Medium threshold must be below high threshold", path: ["medium_threshold"] }),
  cache: z.object({ enabled: z.boolean(), ttl_seconds: z.number().int().min(30).max(86400), semantic_threshold: z.number().min(0.8).max(0.999) }),
  agent: z.object({ max_agent_steps: z.number().int().min(3).max(20), max_llm_calls: z.number().int().min(0).max(10), max_tool_calls: z.number().int().min(5).max(60),
    token_budget_per_request: z.number().int().min(1000).max(60000), context_budget_tokens: z.number().int().min(300).max(16000) }),
  demo_mode: z.boolean(),
});
type Form = z.infer<typeof schema>;

const WEIGHTS = [["delivery", "Delivery"], ["quality", "Quality"], ["cost", "Cost"], ["lead_time", "Lead-time consistency"]] as const;

const NumField = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement> & { label: string; hint?: string }>(({ label, hint, ...p }, ref) => (
  <label className="block"><span className="eyebrow">{label}</span><Input ref={ref} type="number" step="any" className="mt-1" {...p} />{hint && <span className="text-[11px] text-ink-500">{hint}</span>}</label>
));
NumField.displayName = "NumField";

export default function SettingsPage() {
  const { can } = useAuth();
  const admin = can("configure");
  const { data, isLoading, error } = useSettings();
  const save = useSaveSettings();
  const { control, register, handleSubmit, reset, watch, formState } = useForm<Form>({ resolver: zodResolver(schema) });
  React.useEffect(() => {
    if (data) reset({ weights: data.scoring.weights, risk: data.risk, cache: data.cache, agent: data.agent, demo_mode: data.demo_mode });
  }, [data, reset]);
  const w = watch("weights");
  const total = w ? Math.round((w.delivery + w.quality + w.cost + w.lead_time) * 100) : 100;
  const onSubmit = (f: Form) => save.mutate({ weights: f.weights, risk: f.risk, cache: f.cache, agent: f.agent, demo_mode: f.demo_mode });
  const num = { valueAsNumber: true } as const;

  if (error) return <ErrorState error={error} />;
  if (isLoading || !data) return <LoadingCard />;
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <PageHeader eyebrow="Administration" title="Platform settings" description="Non-secret runtime settings. Changing weights re-scores every vendor snapshot and is written to the audit trail."
        actions={admin ? <Button type="submit" variant="brand" disabled={save.isPending || !formState.isDirty}>{save.isPending ? <Loader2 className="animate-spin" /> : <Save />}Save & apply</Button>
          : <span className="inline-flex items-center gap-1.5 rounded-lg bg-ink-100 px-3 py-2 text-[12px] font-medium text-ink-600"><Lock className="h-3.5 w-3.5" />View only - admin can change settings</span>} />
      <fieldset disabled={!admin} className="contents">
      {save.isSuccess && <div className="mb-4 flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-[12.5px] text-emerald-900"><CheckCircle2 className="h-4 w-4" />Saved: {save.data.changed.join(", ") || "no changes"}{save.data.rescore?.scoring && ` · re-scored ${save.data.rescore.scoring.snapshots} snapshots in ${save.data.rescore.scoring.seconds}s`}</div>}
      {save.isError && <div className="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-2.5 text-[12.5px] text-rose-900">{(save.error as Error).message}</div>}
      <div className="grid gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader title="Scoring weights" subtitle="Overall = Σ component × weight · must total 100%" action={<Badge tone={total === 100 ? "good" : "critical"}>{total}%</Badge>} />
          <CardBody className="space-y-5">
            {WEIGHTS.map(([k, label]) => (
              <Controller key={k} control={control} name={`weights.${k}`} render={({ field }) => (
                <div>
                  <div className="mb-2 flex justify-between text-[12.5px]"><span className="font-medium">{label}</span><span className="num font-semibold">{Math.round((field.value ?? 0) * 100)}%</span></div>
                  <Slider value={[Math.round((field.value ?? 0) * 100)]} min={0} max={60} step={5} onValueChange={([v]) => field.onChange(v / 100)} aria-label={`${label} weight`} />
                </div>
              )} />
            ))}
            {formState.errors.weights && <p className="text-[12px] text-rose-700">{formState.errors.weights.message ?? formState.errors.weights.root?.message}</p>}
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Risk & governance thresholds" />
          <CardBody className="grid grid-cols-2 gap-4">
            <NumField label="High risk probability" step="0.01" {...register("risk.high_threshold", num)} />
            <NumField label="Medium risk probability" step="0.01" {...register("risk.medium_threshold", num)} hint={formState.errors.risk?.medium_threshold?.message} />
            <NumField label="Deterioration drop (pts)" step="1" {...register("risk.deterioration_drop_points", num)} hint="SEV-4 threshold" />
            <NumField label="Approval confidence" step="0.01" {...register("risk.approval_confidence_threshold", num)} hint="Below this, recommendations need approval (PP-5)" />
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Agent guardrails & token budgets" />
          <CardBody className="grid grid-cols-2 gap-4 md:grid-cols-3">
            <NumField label="Max agent steps" {...register("agent.max_agent_steps", num)} />
            <NumField label="Max LLM calls" {...register("agent.max_llm_calls", num)} />
            <NumField label="Max tool calls" {...register("agent.max_tool_calls", num)} />
            <NumField label="Token budget / request" {...register("agent.token_budget_per_request", num)} />
            <NumField label="JEV context budget" {...register("agent.context_budget_tokens", num)} />
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Caching & demo" />
          <CardBody className="space-y-4">
            <Controller control={control} name="cache.enabled" render={({ field }) => <label className="flex items-center justify-between text-[12.5px]"><span><span className="font-medium">Caching enabled</span><span className="block text-ink-500">Analytics, retrieval, exact and semantic response caches</span></span><Switch checked={field.value} onCheckedChange={field.onChange} /></label>} />
            <div className="grid grid-cols-2 gap-4"><NumField label="Cache TTL (s)" {...register("cache.ttl_seconds", num)} /><NumField label="Semantic similarity" step="0.005" {...register("cache.semantic_threshold", num)} /></div>
            <Controller control={control} name="demo_mode" render={({ field }) => <label className="flex items-center justify-between text-[12.5px]"><span><span className="font-medium">Demo mode</span><span className="block text-ink-500">Shows the demo badge; seeded synthetic data and labelled fallback answers</span></span><Switch checked={field.value} onCheckedChange={field.onChange} /></label>} />
          </CardBody>
        </Card>
        <Card className="xl:col-span-2">
          <CardHeader title="LLM provider" icon={<KeyRound className="h-4 w-4 text-brand-500" />} subtitle={data.llm.note} action={<Badge tone={data.llm.configured ? "good" : "warning"}>{data.llm.configured ? `${data.llm.provider} configured` : "Not configured - deterministic fallback"}</Badge>} />
          <CardBody>
            <table className="w-full text-[12.5px]"><thead><tr><Th>Task</Th><Th>Tier</Th><Th>Model / deployment</Th></tr></thead>
              <tbody>{data.llm.routing.map((r: { task: string; tier: string; model: string }) => <tr key={r.task}><Td>{r.task.replace(/_/g, " ")}</Td><Td><Badge>{r.tier}</Badge></Td><Td className="num">{r.model}</Td></tr>)}</tbody></table>
            <p className="mt-3 text-[12px] text-ink-500">Set <code className="rounded bg-ink-50 px-1">LLM_PROVIDER=azure|openai</code> and the matching keys in the server <code className="rounded bg-ink-50 px-1">.env</code>, then restart the API. Embeddings: <span className="font-medium">{data.llm.embedding_provider}</span>. Data version {data.data_version}.</p>
          </CardBody>
        </Card>
      </div>
      </fieldset>
    </form>
  );
}
