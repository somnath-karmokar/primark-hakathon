import * as React from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import {
  BarChart3, BookOpenText, Bot, Columns3, Gauge, Globe2, LayoutDashboard, ListOrdered, Menu, Scale, Search, Settings2,
  ShieldCheck, X, Lightbulb, FlaskConical, ShieldHalf, LogOut, BadgeCheck,
} from "lucide-react";
import { useHealth, useRecommendations, useVendors } from "@/hooks/queries";
import { useAuth } from "@/lib/auth";
import { BandBadge } from "@/components/domain";
import { Tip } from "@/components/ui/primitives";
import { cn, fmt } from "@/lib/utils";

/** `key` must match the role menu lists in backend app/security.py (ROLE_MENUS). */
export const NAV = [
  { group: "Performance", items: [
    { key: "dashboard", to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
    { key: "vendors", to: "/vendors", label: "All Vendors", icon: ListOrdered, end: true },
    { key: "vendor360", to: "/vendors/V1024", label: "Vendor Profile", icon: Gauge, match: /^\/vendors\/V/, lastVendor: true },
    { key: "insights", to: "/analytics", label: "Performance Insights", icon: BarChart3 },
    { key: "compare", to: "/compare", label: "Compare Vendors", icon: Columns3 },
  ] },
  { group: "AI Assistant", items: [
    { key: "assistant", to: "/copilot", label: "Ask the AI Assistant", icon: Bot },
    { key: "alternatives", to: "/recommendations", label: "Find Alternative Suppliers", icon: Lightbulb },
    { key: "policies", to: "/knowledge", label: "Policies & Contracts", icon: BookOpenText },
  ] },
  { group: "Risk Alerts", items: [
    { key: "risk_alerts", to: "/risk-intel", label: "Supplier Risk Alerts", icon: Globe2, tag: "Add-on" },
  ] },
  { group: "Oversight", items: [
    { key: "approvals", to: "/governance", label: "Approvals & Audit Log", icon: ShieldCheck, badge: "pending" },
    { key: "trust", to: "/trust", label: "Trust Centre", icon: BadgeCheck },
    { key: "safety", to: "/guardrails", label: "AI Safety Rules", icon: ShieldHalf },
    { key: "models", to: "/model-lab", label: "Risk Prediction Models", icon: FlaskConical },
  ] },
  { group: "Admin", items: [
    { key: "settings", to: "/settings", label: "Settings", icon: Settings2 },
  ] },
];

function lastVendor(): string {
  try { return sessionStorage.getItem("vendor360.lastVendor") ?? "V1024"; } catch { return "V1024"; }
}

function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const loc = useLocation();
  const { sees, can } = useAuth();
  const { data: recs } = useRecommendations("pending_approval", can("audit"));
  const pending = recs?.counts.pending_approval ?? 0;
  React.useEffect(() => {
    const m = loc.pathname.match(/^\/vendors\/(V\d{4})$/i);
    if (m) { try { sessionStorage.setItem("vendor360.lastVendor", m[1].toUpperCase()); } catch { /* storage unavailable */ } }
  }, [loc.pathname]);
  return (
    <div className="flex h-full flex-col bg-ink-950 text-ink-200">
      <div className="px-5 pb-4 pt-5">
        <img src="/brand/primark-logo-white.png" alt="Primark" className="h-[18px] w-auto opacity-95" />
        <div className="mt-3 flex items-center gap-2">
          <span className="font-display text-[15px] font-bold tracking-tight text-white">Vendor360</span>
          <span className="rounded bg-brand-500 px-1.5 py-[1px] text-[10px] font-bold uppercase tracking-wider text-white">AI</span>
        </div>
        <p className="mt-0.5 text-[11px] text-ink-400">Supplier performance, made simple</p>
      </div>
      <nav className="flex-1 space-y-3.5 overflow-y-auto px-3 pb-4 scrollbar-thin" aria-label="Main">
        {NAV.map((g) => ({ ...g, items: g.items.filter((it) => sees(it.key)) })).filter((g) => g.items.length > 0).map((g) => (
          <div key={g.group}>
            <div className="px-2 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-ink-500">{g.group}</div>
            <ul className="space-y-0.5">
              {g.items.map((it) => {
                const Icon = it.icon;
                const forced = "match" in it && it.match ? it.match.test(loc.pathname) : undefined;
                return (
                  <li key={it.to}>
                    <NavLink to={"lastVendor" in it && it.lastVendor ? `/vendors/${lastVendor()}` : it.to} end={"end" in it ? it.end : false} onClick={onNavigate}
                      className={({ isActive }) => cn(
                        "group relative flex items-center gap-2.5 rounded-lg px-2.5 py-[7px] text-[13px] font-medium transition-colors",
                        (forced ?? isActive) ? "bg-white/[0.08] text-white" : "text-ink-300 hover:bg-white/[0.04] hover:text-white")}>
                      {({ isActive }) => (
                        <>
                          {(forced ?? isActive) && <motion.span layoutId="nav-active" className="absolute left-0 top-1.5 h-[calc(100%-12px)] w-[3px] rounded-r bg-brand-400" />}
                          <Icon className={cn("h-4 w-4", (forced ?? isActive) ? "text-brand-300" : "text-ink-400 group-hover:text-ink-200")} />
                          <span className="flex-1">{it.label}</span>
                          {"tag" in it && it.tag && <span className="rounded bg-white/10 px-1.5 text-[9.5px] font-semibold uppercase tracking-wide text-ink-300">{it.tag}</span>}
                          {"badge" in it && it.badge === "pending" && pending > 0 && <span className="num rounded-full bg-amber-400 px-1.5 text-[10.5px] font-bold text-ink-950" title={`${pending} recommendation(s) awaiting approval`}>{pending}</span>}
                        </>
                      )}
                    </NavLink>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
      <div className="border-t border-white/5 px-5 py-3 text-[10.5px] text-ink-500">
        <div className="flex items-center gap-1.5"><Scale className="h-3 w-3" />Synthetic demo data · TCS for Primark</div>
      </div>
    </div>
  );
}

function UserMenu() {
  const { user, logout } = useAuth();
  const [open, setOpen] = React.useState(false);
  if (!user) return null;
  const initials = user.display_name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} onBlur={() => setTimeout(() => setOpen(false), 150)} className="flex items-center gap-2 rounded-full py-0.5 pl-0.5 pr-2 hover:bg-ink-50" aria-label="Account menu">
        <span className={cn("flex h-8 w-8 items-center justify-center rounded-full text-[11px] font-bold", user.role === "admin" ? "bg-ink-900 text-white" : "bg-brand-500 text-white")}>{initials}</span>
        <span className="hidden whitespace-nowrap text-left leading-tight lg:block"><span className="block text-[12px] font-semibold">{user.display_name}</span>
          <span className={cn("block text-[10.5px] font-semibold uppercase tracking-wide", user.role === "admin" ? "text-ink-600" : "text-brand-600")}>{user.role}</span></span>
      </button>
      {open && (
        <div className="absolute right-0 top-11 z-40 w-64 rounded-xl border border-ink-100 bg-white p-3 shadow-lift">
          <div className="text-[13px] font-semibold">{user.display_name}</div>
          <div className="text-[11.5px] text-ink-500">{user.title}</div>
          <div className="mt-2 flex flex-wrap gap-1">{user.permissions.map((p) => <span key={p} className="rounded bg-ink-50 px-1.5 py-0.5 text-[10px] font-medium text-ink-600">{p}</span>)}</div>
          <button onMouseDown={logout} className="mt-3 flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-[12.5px] font-medium text-ink-700 hover:bg-ink-50"><LogOut className="h-4 w-4" />Sign out</button>
        </div>
      )}
    </div>
  );
}

function StatusPills() {
  const { data } = useHealth();
  const { can } = useAuth();
  if (!data || !can("configure")) return null;   // technical status is for administrators
  const c = data.components;
  const pills = [
    { label: "PostgreSQL", ok: c.postgres.ok, tip: `${c.postgres.vendors} vendors` },
    { label: "Neo4j", ok: c.neo4j.ok, tip: c.neo4j.ok ? c.neo4j.host : `Unavailable - relational fallback (${c.neo4j.error})` },
    { label: "ChromaDB", ok: c.chromadb.ok, tip: `${c.chromadb.chunks} chunks · ${c.chromadb.policy_version}` },
    { label: c.llm.ok ? `LLM · ${c.llm.provider}` : "LLM · fallback", ok: c.llm.ok, warn: !c.llm.ok,
      tip: c.llm.ok ? "Live model via optimisation layer" : "No LLM configured: copilot uses labelled deterministic answers" },
  ];
  return (
    <div className="hidden items-center gap-1.5 2xl:flex">
      {pills.map((p) => (
        <Tip key={p.label} content={p.tip} side="bottom">
          <span className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border border-ink-100 bg-white px-2.5 py-1 text-[11px] font-medium text-ink-600">
            <span className={cn("h-1.5 w-1.5 rounded-full", p.ok ? "bg-emerald-500" : p.warn ? "bg-amber-500" : "bg-rose-500")} />{p.label}
          </span>
        </Tip>
      ))}
    </div>
  );
}

function GlobalSearch() {
  const [q, setQ] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [debounced, setDebounced] = React.useState("");
  const nav = useNavigate();
  React.useEffect(() => { const t = setTimeout(() => setDebounced(q), 180); return () => clearTimeout(t); }, [q]);
  const { data } = useVendors({ search: debounced, page_size: 7 });
  const items = debounced.length >= 2 ? data?.items ?? [] : [];
  const go = (id: string) => { setQ(""); setOpen(false); nav(`/vendors/${id}`); };
  return (
    <div className="relative w-full max-w-md">
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
      <input value={q} onChange={(e) => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)} onBlur={() => setTimeout(() => setOpen(false), 150)}
        onKeyDown={(e) => { if (e.key === "Enter" && items[0]) go(items[0].vendor_id); }}
        placeholder="Find a vendor by name or ID (e.g. Ningbo, V1024)" aria-label="Search vendors"
        className="h-9 w-full rounded-lg border border-ink-200 bg-ink-50/60 pl-9 pr-3 text-[13px] placeholder:text-ink-400 focus:border-brand-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-100" />
      <AnimatePresence>
        {open && items.length > 0 && (
          <motion.ul initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="absolute left-0 right-0 top-11 z-40 overflow-hidden rounded-xl border border-ink-100 bg-white py-1 shadow-lift">
            {items.map((v) => (
              <li key={v.vendor_id}>
                <button onMouseDown={() => go(v.vendor_id)} className="flex w-full items-center justify-between gap-3 px-3 py-2 text-left hover:bg-ink-50">
                  <span className="min-w-0"><span className="num font-semibold text-ink-950">{v.vendor_id}</span><span className="ml-2 truncate text-ink-500">{v.name}</span></span>
                  <span className="flex shrink-0 items-center gap-2"><span className="num font-semibold">{fmt.score(v.overall)}</span><BandBadge band={v.band} /></span>
                </button>
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function AppShell() {
  const [mobile, setMobile] = React.useState(false);
  const { data: health } = useHealth();
  const loc = useLocation();
  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-[244px] shrink-0 lg:block"><Sidebar /></aside>
      <AnimatePresence>
        {mobile && (
          <motion.div className="fixed inset-0 z-50 lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-ink-950/50" onClick={() => setMobile(false)} />
            <motion.div className="absolute inset-y-0 left-0 w-[260px]" initial={{ x: -260 }} animate={{ x: 0 }} exit={{ x: -260 }}>
              <Sidebar onNavigate={() => setMobile(false)} />
              <button className="absolute right-3 top-4 text-white" onClick={() => setMobile(false)} aria-label="Close menu"><X className="h-5 w-5" /></button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-ink-100 bg-white/85 px-4 backdrop-blur md:px-6">
          <button className="lg:hidden" onClick={() => setMobile(true)} aria-label="Open menu"><Menu className="h-5 w-5" /></button>
          <img src="/brand/primark-logo-blue.png" alt="Primark" className="h-3.5 lg:hidden" />
          <GlobalSearch />
          <div className="ml-auto flex items-center gap-3">
            <StatusPills />
            {health?.latest_period && <span className="hidden whitespace-nowrap rounded-full bg-brand-50 px-2.5 py-1 text-[11px] font-semibold text-brand-700 xl:inline">Data up to {fmt.month(health.latest_period)}</span>}
            {health?.demo_mode && <span className="hidden whitespace-nowrap rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-semibold text-amber-800 ring-1 ring-inset ring-amber-200 lg:inline">Demo mode</span>}
            <UserMenu />
          </div>
        </header>
        <main className="mx-auto w-full max-w-[1480px] flex-1 px-4 py-6 md:px-6">
          <AnimatePresence mode="wait">
            <motion.div key={loc.pathname} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.18 }}>
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
