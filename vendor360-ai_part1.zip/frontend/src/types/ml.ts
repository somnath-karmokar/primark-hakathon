export interface MLParam { name: string; kind: "int" | "float"; default: number; min: number; max: number; step: number; help: string }
export interface MLAlgorithm { key: string; label: string; family: string; description: string; tree: boolean; params: MLParam[] }

export interface MLDataset {
  label_definition: string; features: { name: string; label: string }[]; train_periods: string[]; test_periods: string[];
  n_train: number; n_test: number; positives_train: number; positives_test: number; positive_rate_train: number; positive_rate_test: number;
  per_period: { period: string; rows: number; positives: number }[]; split: string; drop_points?: number;
}

export interface Confusion { tn: number; fp: number; fn: number; tp: number }
export interface Pt { x: number; y: number }

export interface MLRun {
  id: number; experiment_id: string; algorithm: string; algorithm_label: string; params: Record<string, number>; dataset: MLDataset;
  metrics: {
    roc_auc: number; pr_auc: number; brier: number; log_loss: number; train_roc_auc: number; overfit_gap: number;
    precision_top10pct: number; lift_top10pct: number; base_rate: number; threshold: number; accuracy: number; precision: number;
    recall: number; f1: number; balanced_accuracy: number; mcc: number; cv_roc_auc_mean: number | null; cv_roc_auc_std: number | null;
  };
  curves: {
    roc: Pt[]; pr: Pt[]; calibration: Pt[]; confusion_at_0_5: Confusion;
    best_threshold: { threshold: number; precision: number; recall: number; f1: number; accuracy: number; confusion: Confusion };
    folds: { test_period: string; train_periods: number; n_test: number; roc_auc: number; pr_auc: number }[];
  };
  importance: { feature: string; label: string; importance: number }[];
  credible: boolean; credibility_reason: string; is_active: boolean; train_seconds: number; trained_by: string; created_at: string; promoted_at: string | null;
}

export interface TrainResult { experiment_id: string; dataset: MLDataset; runs: MLRun[]; best_run_id: number | null; seconds: number }

export interface AnomalyResult {
  algorithm: string; params: { contamination: number; n_estimators: number }; period: string; vendors: number; flagged: number;
  sanity_check: { weak_share_among_flagged: number; weak_share_overall: number; lift: number | null; note: string };
  histogram: { from: number; count: number }[];
  top: { vendor_id: string; name: string; band: string; overall: number; anomaly_score: number; reasons: string[] }[];
  seconds: number;
}
