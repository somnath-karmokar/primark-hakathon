import { useNavigate } from "react-router-dom";
import type { GraphNode } from "@/types/api";

const TYPE_STYLE: Record<string, { fill: string; stroke: string; text: string; r: number }> = {
  Vendor: { fill: "#0f1d30", stroke: "#0f1d30", text: "#ffffff", r: 26 },
  Alt: { fill: "#eaf7fc", stroke: "#26b0df", text: "#006a93", r: 20 },
  Product: { fill: "#ffffff", stroke: "#b3bfce", text: "#33445a", r: 7 },
  Category: { fill: "#fff7e6", stroke: "#eaa400", text: "#8a6100", r: 9 },
  SLA: { fill: "#eef7f1", stroke: "#1f8a4c", text: "#1f6a3c", r: 9 },
  Region: { fill: "#f5f7fa", stroke: "#8496ab", text: "#475a70", r: 9 },
};

/** Radial view of the vendor's Neo4j neighbourhood: products/categories on the left arc, alternatives on the right. */
export function RelationshipMap({ nodes, edges, height = 340 }: { nodes: GraphNode[]; edges: { from: string; to: string; type: string }[]; height?: number }) {
  const nav = useNavigate();
  const W = 720, H = height, cx = W / 2, cy = H / 2;
  const center = nodes.find((n) => n.primary);
  const alts = nodes.filter((n) => n.type === "Vendor" && !n.primary);
  const products = nodes.filter((n) => n.type === "Product");
  const cats = nodes.filter((n) => n.type === "Category");
  const others = nodes.filter((n) => n.type === "SLA" || n.type === "Region");
  const pos: Record<string, { x: number; y: number }> = {};
  if (center) pos[center.id] = { x: cx, y: cy };
  const arc = (list: GraphNode[], r: number, from: number, to: number) => list.forEach((n, i) => {
    const a = list.length === 1 ? (from + to) / 2 : from + ((to - from) * i) / (list.length - 1);
    pos[n.id] = { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) * 0.82 };
  });
  arc(products, 150, (Math.PI * 2) / 3, (Math.PI * 4) / 3);
  arc(cats, 300, (Math.PI * 5) / 6, (Math.PI * 7) / 6);
  arc(alts, 220, -Math.PI / 3, Math.PI / 3);
  arc(others, 120, -Math.PI * 0.62, -Math.PI * 0.38);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label="Supplier relationship graph">
      {edges.map((e, i) => {
        const a = pos[e.from], b = pos[e.to];
        if (!a || !b) return null;
        const alt = e.type === "ALTERNATIVE_TO";
        return <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={alt ? "#26b0df" : "#d5dce6"} strokeWidth={alt ? 1.5 : 1} strokeDasharray={alt ? "4 4" : undefined} />;
      })}
      {nodes.map((n) => {
        const p = pos[n.id];
        if (!p) return null;
        const style = n.primary ? TYPE_STYLE.Vendor : n.type === "Vendor" ? TYPE_STYLE.Alt : TYPE_STYLE[n.type] ?? TYPE_STYLE.Region;
        const left = p.x < cx - 10;
        const isVendor = n.type === "Vendor";
        return (
          <g key={n.id} className={isVendor && !n.primary ? "cursor-pointer" : undefined} onClick={() => isVendor && !n.primary && nav(`/vendors/${n.id}`)}>
            <title>{`${n.type}: ${n.label}${n.critical ? " (critical product)" : ""}`}</title>
            <circle cx={p.x} cy={p.y} r={style.r} fill={style.fill} stroke={n.critical ? "#a8223d" : style.stroke} strokeWidth={n.critical ? 2 : 1.5} />
            {isVendor ? (
              <text x={p.x} y={p.y + 3.5} textAnchor="middle" fontSize={n.primary ? 11 : 10} fontWeight={700} fill={style.text}>{n.label}</text>
            ) : (
              <text x={p.x + (left ? -style.r - 5 : style.r + 5)} y={p.y + 3.5} textAnchor={left ? "end" : "start"} fontSize={10.5} fill={style.text}>
                {n.label.length > 30 ? n.label.slice(0, 29) + "…" : n.label}
              </text>
            )}
          </g>
        );
      })}
      <g fontSize={10} fill="#5f738b">
        <text x={16} y={H - 12}>● Products / categories (supplied)</text>
        <text x={W - 16} y={H - 12} textAnchor="end">- - Alternative suppliers (shared products)</text>
      </g>
    </svg>
  );
}
