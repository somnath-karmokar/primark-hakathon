import { useSearchParams } from "react-router-dom";
import { RotateCcw } from "lucide-react";
import { useFilters, type DashFilters } from "@/hooks/queries";
import { Button, NativeSelect } from "@/components/ui/primitives";
import { fmt } from "@/lib/utils";

/** Filters live in the URL so views are shareable and survive refresh. */
export function useUrlFilters(): [DashFilters, (k: keyof DashFilters, v: string) => void, () => void] {
  const [sp, setSp] = useSearchParams();
  const f: DashFilters = {
    period: sp.get("period") ?? undefined, category: sp.get("category") ?? undefined,
    region: sp.get("region") ?? undefined, status: sp.get("status") ?? undefined,
  };
  const set = (k: keyof DashFilters, v: string) => {
    const n = new URLSearchParams(sp);
    if (v) n.set(k, v); else n.delete(k);
    setSp(n, { replace: true });
  };
  return [f, set, () => setSp(new URLSearchParams(), { replace: true })];
}

export function FilterBar({ show = ["period", "category", "region", "status"] }: { show?: (keyof DashFilters)[] }) {
  const { data } = useFilters();
  const [f, set, reset] = useUrlFilters();
  const active = Object.values(f).some(Boolean);
  if (!data) return null;
  return (
    <div className="flex flex-wrap items-end gap-2" role="group" aria-label="Filters">
      {show.includes("period") && (
        <NativeSelect label="Period" value={f.period ?? ""} onChange={(e) => set("period", e.target.value)}>
          <option value="">Latest ({fmt.month(data.periods[data.periods.length - 1])})</option>
          {[...data.periods].reverse().map((p) => <option key={p} value={p}>{fmt.month(p)} (3-month window)</option>)}
        </NativeSelect>
      )}
      {show.includes("category") && (
        <NativeSelect label="Category" value={f.category ?? ""} onChange={(e) => set("category", e.target.value)}>
          <option value="">All categories</option>
          {data.categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </NativeSelect>
      )}
      {show.includes("region") && (
        <NativeSelect label="Region" value={f.region ?? ""} onChange={(e) => set("region", e.target.value)}>
          <option value="">All regions</option>
          {data.regions.map((r) => <option key={r} value={r}>{r}</option>)}
        </NativeSelect>
      )}
      {show.includes("status") && (
        <NativeSelect label="Vendor status" value={f.status ?? ""} onChange={(e) => set("status", e.target.value)}>
          <option value="">All statuses</option>
          {data.statuses.map((s) => <option key={s} value={s}>{s}</option>)}
        </NativeSelect>
      )}
      {active && <Button variant="ghost" size="md" onClick={reset}><RotateCcw />Reset</Button>}
    </div>
  );
}
