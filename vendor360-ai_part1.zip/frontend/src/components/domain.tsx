import * as React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  AlertOctagon, AlertTriangle, ArrowDownRight, ArrowRight, ArrowUpRight, CheckCircle2, CircleDot, Database, FileText,
  Inbox, Minus, Network, ShieldAlert, ShieldCheck, Sparkles, TrendingDown, Cpu,
} from "lucide-react";
import { Line, LineChart, ResponsiveContainer, YAxis } from "recharts";
import { Badge, Button, Card, Skeleton, Tip } from "@/components/ui/primitives";
import { BAND_COLOR, BAND_RANGE, bandOf, cn, fmt, riskTone } from "@/lib/utils";
import type { Band, RiskLevel } from "@/types/api";

/* ---------------------------------------------------------------- Bands & risk */
const BAND_ICON: Record<Band, React.ElementType> = {
  Excellent: CheckCircle2, Good: CircleDot, Watch: AlertTriangle, "At Risk": ShieldAlert, Critical: AlertOctagon,
};
export function BandBadge({ band, size = "sm" }: { band: Band; size?: "sm" | "lg" }) {
  const Icon = BAND_ICON[band] ?? CircleDot;
  return (
    <Tip content={`${band} band · ${BAND_RANGE[band]}`}>
      <span className={cn("inline-flex items-center gap-1 whitespace-nowrap rounded-md font-semibold ring-1 ring-inset",
        size === "lg" ? "px-2.5 py-1 text-[12px] uppercase tracking-wide" : "px-1.5 py-0.5 text-[11px]")}
        style={{ color: band === "Watch" ? "#8a6100" : BAND_COLOR[band], backgroundColor: `${BAND_COLOR[band]}14`, boxShadow: `inset 0 0 0 1px ${BAND_COLOR[band]}40` }}>
        <Icon className={size === "lg" ? "h-3.5 w-3.5" : "h-3 w-3"} aria-hidden />{band}
      </span>
    </Tip>
  );
}

export function RiskBadge({ level, label = "risk", prob }: { level: RiskLevel | string | null | undefined; label?: string; prob?: number | null }) {
  const tone = riskTone(level);
  const Icon = level === "High" ? ShieldAlert : level === "Medium" ? AlertTriangle : ShieldCheck;
  return (
    <Badge tone={tone as "critical" | "warning" | "good" | "neutral"}>
      <Icon className="h-3 w-3" aria-hidden />{level ?? "Unknown"} {label}{prob != null && <span className="font-normal opacity-80"> · p={prob.toFixed(2)}</span>}
    </Badge>
  );
}

/* ---------------------------------------------------------------- Score ring */
export function ScoreRing({ score, size = 116, stroke = 9, label = "Score" }: { score: number; size?: number; stroke?: number; label?: string }) {
  const band = bandOf(score);
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative" style={{ width: size, height: size }} role="img" aria-label={`${label} ${score.toFixed(1)} (${band})`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#e9edf3" strokeWidth={stroke} />
        <motion.circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={BAND_COLOR[band]} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} initial={{ strokeDashoffset: c }} animate={{ strokeDashoffset: c * (1 - score / 100) }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="num font-display text-[30px] font-bold leading-none text-ink-950" style={{ fontSize: size * 0.27 }}>{score.toFixed(1)}</span>
        <span className="mt-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-ink-400">{label}</span>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- Component bar */
export function ComponentBar({ label, score, benchmark, weight, change }: { label: string; score: number; benchmark?: number; weight?: number; change?: number }) {
  const band = bandOf(score);
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between gap-2">
        <span className="text-[12.5px] font-medium text-ink-700">{label}{weight != null && <span className="ml-1.5 text-[11px] font-normal text-ink-400">{Math.round(weight * 100)}%</span>}</span>
        <span className="flex items-baseline gap-2">
          {change != null && Math.abs(change) >= 0.5 && <Delta value={change} className="text-[11px]" />}
          <span className="num text-[14px] font-semibold text-ink-950">{score.toFixed(1)}</span>
        </span>
      </div>
      <div className="relative h-2 rounded-full bg-ink-100">
        <motion.div className="h-2 rounded-full" style={{ backgroundColor: BAND_COLOR[band] }} initial={{ width: 0 }} animate={{ width: `${score}%` }} transition={{ duration: 0.7 }} />
        {benchmark != null && (
          <Tip content={`Category average ${benchmark.toFixed(1)}`}>
            <span className="absolute -top-1 h-4 w-[2px] rounded bg-ink-700" style={{ left: `calc(${benchmark}% - 1px)` }} />
          </Tip>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- Delta */
export function Delta({ value, className, suffix = "", invert = false }: { value: number | null | undefined; className?: string; suffix?: string; invert?: boolean }) {
  if (value == null) return <span className={cn("text-ink-400", className)}>-</span>;
  const good = invert ? value < 0 : value > 0;
  const flat = Math.abs(value) < 0.5;
  const Icon = flat ? Minus : value > 0 ? ArrowUpRight : ArrowDownRight;
  return (
    <span className={cn("num inline-flex items-center gap-0.5 font-semibold", flat ? "text-ink-500" : good ? "text-emerald-700" : "text-rose-700", className)}>
      <Icon className="h-3.5 w-3.5" aria-hidden />{fmt.delta(value)}{suffix}
    </span>
  );
}

/* ---------------------------------------------------------------- KPI tile */
export function KpiTile({ label, value, sub, icon: Icon, accent, delta, to, loading, invertDelta, deltaSuffix, tip }: {
  label: string; value: React.ReactNode; sub?: React.ReactNode; icon?: React.ElementType; accent?: string; delta?: number | null; to?: string; loading?: boolean;
  invertDelta?: boolean; deltaSuffix?: string; tip?: string;
}) {
  const body = (
    <Card className={cn("group relative h-full overflow-hidden px-4 py-3.5 transition-shadow", to && "hover:shadow-lift")}>
      {accent && <span className="absolute inset-x-0 top-0 h-[3px]" style={{ backgroundColor: accent }} />}
      <div className="flex items-center justify-between">
        {tip ? <Tip content={tip}><span className="eyebrow cursor-help">{label}</span></Tip> : <span className="eyebrow">{label}</span>}
        {Icon && <Icon className="h-4 w-4 text-ink-300 transition-colors group-hover:text-brand-500" aria-hidden />}
      </div>
      {loading ? <Skeleton className="mt-2 h-8 w-20" /> : (
        <div className="mt-1.5 flex items-baseline gap-2">
          <span className="num font-display text-[26px] font-bold leading-none text-ink-950">{value}</span>
          {delta != null && <Delta value={delta} className="text-[12px]" invert={invertDelta} suffix={deltaSuffix} />}
        </div>
      )}
      {sub && <div className="mt-1.5 text-[11.5px] text-ink-500">{sub}</div>}
    </Card>
  );
  return to ? <Link to={to} className="block h-full">{body}</Link> : body;
}

/* ---------------------------------------------------------------- Page header */
export function PageHeader({ eyebrow, title, description, actions }: { eyebrow?: string; title: React.ReactNode; description?: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0">
        {eyebrow && <div className="eyebrow mb-1 text-brand-600">{eyebrow}</div>}
        <h1 className="text-[24px] font-bold leading-tight">{title}</h1>
        {description && <p className="mt-1 max-w-3xl text-[13px] text-ink-500">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-end gap-2">{actions}</div>}
    </div>
  );
}

/* ---------------------------------------------------------------- States */
export function EmptyState({ title, hint, icon: Icon = Inbox, action }: { title: string; hint?: string; icon?: React.ElementType; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-10 text-center">
      <div className="mb-3 rounded-full bg-ink-50 p-3"><Icon className="h-5 w-5 text-ink-400" /></div>
      <p className="font-medium text-ink-800">{title}</p>
      {hint && <p className="mt-1 max-w-sm text-[12.5px] text-ink-500">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
export function ErrorState({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  const msg = error instanceof Error ? error.message : "Something went wrong";
  return (
    <Card className="border-rose-200 bg-rose-50/40">
      <EmptyState icon={AlertOctagon} title="Couldn't load this view" hint={`${msg}. Check that the API is running on port 8040.`}
        action={onRetry && <Button variant="outline" size="sm" onClick={onRetry}>Retry</Button>} />
    </Card>
  );
}
export function LoadingCard({ h = "h-64" }: { h?: string }) {
  return <Card className="p-5"><Skeleton className="mb-4 h-4 w-40" /><Skeleton className={cn("w-full", h)} /></Card>;
}

/* ---------------------------------------------------------------- Sparkline */
export function Sparkline({ values, color, width = 88, height = 26 }: { values: number[]; color?: string; width?: number; height?: number }) {
  const data = values.map((v, i) => ({ i, v }));
  const c = color ?? BAND_COLOR[bandOf(values[values.length - 1] ?? 0)];
  return (
    <div style={{ width, height }} aria-hidden>
      <ResponsiveContainer>
        <LineChart data={data} margin={{ top: 3, bottom: 3, left: 2, right: 2 }}>
          <YAxis hide domain={["dataMin - 2", "dataMax + 2"]} />
          <Line dataKey="v" stroke={c} strokeWidth={2} dot={false} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ---------------------------------------------------------------- Chart tooltip */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function ChartTooltip({ active, payload, label, labelFormatter, valueFormatter }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-ink-100 bg-white/95 px-3 py-2 text-[12px] shadow-lift backdrop-blur">
      {label != null && <div className="mb-1 font-semibold text-ink-900">{labelFormatter ? labelFormatter(label) : label}</div>}
      {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
      {payload.map((p: any) => (
        <div key={p.dataKey ?? p.name} className="flex items-center justify-between gap-4">
          <span className="flex items-center gap-1.5 text-ink-600"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: p.color ?? p.payload?.fill }} />{p.name}</span>
          <span className="num font-semibold text-ink-900">{valueFormatter ? valueFormatter(p.value) : typeof p.value === "number" ? p.value.toFixed(1) : p.value}</span>
        </div>
      ))}
    </div>
  );
}

/* ---------------------------------------------------------------- Misc */
export function VendorLink({ id, name, className }: { id: string; name?: string; className?: string }) {
  return (
    <Link to={`/vendors/${id}`} className={cn("group inline-flex min-w-0 flex-col", className)}>
      <span className="num text-[12.5px] font-semibold text-ink-950 group-hover:text-brand-600">{id}</span>
      {name && <span className="truncate text-[11.5px] text-ink-500">{name}</span>}
    </Link>
  );
}

const SOURCE_META: Record<string, { icon: React.ElementType; label: string }> = {
  neo4j: { icon: Network, label: "Neo4j graph" }, chromadb: { icon: FileText, label: "ChromaDB" }, postgres: { icon: Database, label: "PostgreSQL" },
  "scoring-engine": { icon: Cpu, label: "Scoring engine" }, "ml-model": { icon: Sparkles, label: "ML model" },
  "postgres-fallback": { icon: Database, label: "Relational fallback" }, statistical: { icon: TrendingDown, label: "Statistical" },
  "policy-rules": { icon: ShieldCheck, label: "Policy rules" }, "isolation-forest": { icon: Sparkles, label: "IsolationForest" },
};
export function SourcePill({ source }: { source: string }) {
  const key = source.split("+")[0];
  const m = SOURCE_META[key] ?? { icon: Database, label: source };
  const Icon = m.icon;
  return <span className="inline-flex items-center gap-1 rounded bg-ink-50 px-1.5 py-0.5 text-[10.5px] font-medium text-ink-600 ring-1 ring-inset ring-ink-100"><Icon className="h-3 w-3" />{m.label}</span>;
}

export function SectionLink({ to, children }: { to: string; children: React.ReactNode }) {
  return <Link to={to} className="inline-flex items-center gap-1 text-[12px] font-medium text-brand-600 hover:text-brand-700">{children}<ArrowRight className="h-3.5 w-3.5" /></Link>;
}
