/* shadcn/ui-style primitives (Radix + Tailwind + cva), themed for the Primark-inspired palette. */
import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import * as TabsPrimitive from "@radix-ui/react-tabs";
import * as TooltipPrimitive from "@radix-ui/react-tooltip";
import * as SliderPrimitive from "@radix-ui/react-slider";
import * as SwitchPrimitive from "@radix-ui/react-switch";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/* ---------------------------------------------------------------- Button */
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-1.5 whitespace-nowrap rounded-lg text-[13px] font-medium transition-colors disabled:pointer-events-none disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-ink-900 text-white hover:bg-ink-800 shadow-sm",
        brand: "bg-brand-500 text-white hover:bg-brand-600 shadow-sm",
        outline: "border border-ink-200 bg-white text-ink-800 hover:bg-ink-50 hover:border-ink-300",
        ghost: "text-ink-700 hover:bg-ink-100",
        subtle: "bg-brand-50 text-brand-700 hover:bg-brand-100",
        danger: "bg-band-critical text-white hover:opacity-90",
        success: "bg-band-excellent text-white hover:opacity-90",
      },
      size: { sm: "h-8 px-3", md: "h-9 px-3.5", lg: "h-10 px-5 text-sm", icon: "h-9 w-9" },
    },
    defaultVariants: { variant: "default", size: "md" },
  },
);
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> { asChild?: boolean }
export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, asChild, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";
  return <Comp ref={ref} className={cn(buttonVariants({ variant, size }), className)} {...props} />;
});
Button.displayName = "Button";

/* ---------------------------------------------------------------- Card */
export function Card({ className, ...p }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("min-w-0 rounded-xl border border-ink-100 bg-white shadow-card", className)} {...p} />;
}
export function CardHeader({ title, subtitle, action, className, icon }: {
  title: React.ReactNode; subtitle?: React.ReactNode; action?: React.ReactNode; className?: string; icon?: React.ReactNode;
}) {
  return (
    <div className={cn("flex items-start justify-between gap-3 px-5 pt-4", className)}>
      <div className="min-w-0">
        <h3 className="flex items-center gap-2 text-[14px] font-semibold text-ink-950">{icon}{title}</h3>
        {subtitle && <p className="mt-0.5 text-[12px] text-ink-500">{subtitle}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}
export function CardBody({ className, ...p }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("px-5 pb-5 pt-3", className)} {...p} />;
}

/* ---------------------------------------------------------------- Badge */
const badgeVariants = cva("inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[11px] font-semibold leading-4 ring-1 ring-inset", {
  variants: {
    tone: {
      neutral: "bg-ink-50 text-ink-700 ring-ink-200",
      brand: "bg-brand-50 text-brand-700 ring-brand-200",
      good: "bg-emerald-50 text-emerald-800 ring-emerald-200",
      warning: "bg-amber-50 text-amber-800 ring-amber-200",
      serious: "bg-orange-50 text-orange-800 ring-orange-200",
      critical: "bg-rose-50 text-rose-800 ring-rose-200",
      dark: "bg-ink-900 text-white ring-ink-900",
    },
  },
  defaultVariants: { tone: "neutral" },
});
export const Badge = React.forwardRef<HTMLSpanElement, React.HTMLAttributes<HTMLSpanElement> & VariantProps<typeof badgeVariants>>(
  ({ className, tone, ...p }, ref) => <span ref={ref} className={cn(badgeVariants({ tone }), className)} {...p} />,
);
Badge.displayName = "Badge";

/* ---------------------------------------------------------------- Inputs */
export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(({ className, ...p }, ref) => (
  <input ref={ref} className={cn("h-9 w-full rounded-lg border border-ink-200 bg-white px-3 text-[13px] text-ink-900 placeholder:text-ink-400 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-100", className)} {...p} />
));
Input.displayName = "Input";

export function NativeSelect({ className, label, children, ...p }: React.SelectHTMLAttributes<HTMLSelectElement> & { label?: string }) {
  return (
    <label className="flex flex-col gap-1">
      {label && <span className="eyebrow">{label}</span>}
      <select className={cn("h-9 min-w-[140px] cursor-pointer rounded-lg border border-ink-200 bg-white px-2.5 text-[13px] text-ink-800 hover:border-ink-300 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-100", className)} {...p}>
        {children}
      </select>
    </label>
  );
}

/* ---------------------------------------------------------------- Skeleton */
export function Skeleton({ className }: { className?: string }) {
  return (
    <div className={cn("relative overflow-hidden rounded-md bg-ink-100", className)}>
      <div className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/60 to-transparent" />
    </div>
  );
}

/* ---------------------------------------------------------------- Tabs */
export const Tabs = TabsPrimitive.Root;
export function TabsList({ className, ...p }: React.ComponentProps<typeof TabsPrimitive.List>) {
  return <TabsPrimitive.List className={cn("inline-flex max-w-full items-center gap-1 overflow-x-auto rounded-lg bg-ink-100/70 p-1 scrollbar-thin", className)} {...p} />;
}
export function TabsTrigger({ className, ...p }: React.ComponentProps<typeof TabsPrimitive.Trigger>) {
  return <TabsPrimitive.Trigger className={cn("shrink-0 whitespace-nowrap rounded-md px-3 py-1.5 text-[12.5px] font-medium text-ink-600 transition-all hover:text-ink-900 data-[state=active]:bg-white data-[state=active]:text-ink-950 data-[state=active]:shadow-sm", className)} {...p} />;
}
export const TabsContent = TabsPrimitive.Content;

/* ---------------------------------------------------------------- Tooltip */
export const TooltipProvider = TooltipPrimitive.Provider;
export function Tip({ content, children, side = "top" }: { content: React.ReactNode; children: React.ReactNode; side?: "top" | "bottom" | "left" | "right" }) {
  return (
    <TooltipPrimitive.Root delayDuration={150}>
      <TooltipPrimitive.Trigger asChild>{children}</TooltipPrimitive.Trigger>
      <TooltipPrimitive.Portal>
        <TooltipPrimitive.Content side={side} sideOffset={6} className="z-50 max-w-xs rounded-md bg-ink-950 px-2.5 py-1.5 text-[12px] leading-snug text-white shadow-lift animate-in fade-in-0 zoom-in-95">
          {content}
          <TooltipPrimitive.Arrow className="fill-ink-950" />
        </TooltipPrimitive.Content>
      </TooltipPrimitive.Portal>
    </TooltipPrimitive.Root>
  );
}

/* ---------------------------------------------------------------- Slider / Switch */
export function Slider({ className, ...p }: React.ComponentProps<typeof SliderPrimitive.Root>) {
  return (
    <SliderPrimitive.Root className={cn("relative flex h-5 w-full touch-none select-none items-center", className)} {...p}>
      <SliderPrimitive.Track className="relative h-1.5 w-full grow overflow-hidden rounded-full bg-ink-100">
        <SliderPrimitive.Range className="absolute h-full bg-brand-500" />
      </SliderPrimitive.Track>
      <SliderPrimitive.Thumb className="block h-4 w-4 rounded-full border-2 border-brand-500 bg-white shadow transition-transform hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-200" aria-label="value" />
    </SliderPrimitive.Root>
  );
}
export function Switch({ className, ...p }: React.ComponentProps<typeof SwitchPrimitive.Root>) {
  return (
    <SwitchPrimitive.Root className={cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full transition-colors data-[state=checked]:bg-brand-500 data-[state=unchecked]:bg-ink-200", className)} {...p}>
      <SwitchPrimitive.Thumb className="block h-4 w-4 translate-x-0.5 rounded-full bg-white shadow transition-transform data-[state=checked]:translate-x-[18px]" />
    </SwitchPrimitive.Root>
  );
}

/* ---------------------------------------------------------------- Table helpers */
export function Th({ className, ...p }: React.ThHTMLAttributes<HTMLTableCellElement>) {
  return <th className={cn("whitespace-nowrap border-b border-ink-100 bg-ink-50/60 px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-ink-500", className)} {...p} />;
}
export function Td({ className, ...p }: React.TdHTMLAttributes<HTMLTableCellElement>) {
  return <td className={cn("border-b border-ink-100/70 px-3 py-2.5 align-middle", className)} {...p} />;
}
