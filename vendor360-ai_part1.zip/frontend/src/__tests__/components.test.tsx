import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { TooltipProvider } from "@/components/ui/primitives";
import { BandBadge, Delta, ScoreRing, VendorLink } from "@/components/domain";

const wrap = (ui: React.ReactNode) => render(<MemoryRouter><TooltipProvider>{ui}</TooltipProvider></MemoryRouter>);

describe("domain components", () => {
  it("band badge always carries a text label (never colour alone)", () => {
    wrap(<BandBadge band="Watch" />);
    expect(screen.getByText("Watch")).toBeInTheDocument();
  });
  it("score ring exposes an accessible label with band", () => {
    wrap(<ScoreRing score={63.9} />);
    expect(screen.getByRole("img", { name: "Score 63.9 (Watch)" })).toBeInTheDocument();
  });
  it("delta shows sign", () => {
    wrap(<Delta value={-12.2} />);
    expect(screen.getByText("-12.2")).toBeInTheDocument();
  });
  it("vendor link routes to Vendor 360", () => {
    wrap(<VendorLink id="V1024" name="Ningbo Bluewave Denim" />);
    expect(screen.getByRole("link")).toHaveAttribute("href", "/vendors/V1024");
  });
});
