import { bandOf, fmt, mdSegments } from "@/lib/utils";

describe("score bands", () => {
  it.each([[95, "Excellent"], [90, "Excellent"], [89.94, "Good"], [75, "Good"], [74.9, "Watch"], [60, "Watch"], [59.9, "At Risk"], [40, "At Risk"], [39.9, "Critical"]])(
    "%s -> %s", (s, b) => expect(bandOf(s as number)).toBe(b));
});

describe("copilot markdown", () => {
  it("parses bold, emphasis and citations without HTML", () => {
    const segs = mdSegments("**V1024** scores 63.9 [P1] see *policy* <script>x</script>");
    expect(segs.find((s) => s.kind === "bold")?.t).toBe("V1024");
    expect(segs.find((s) => s.kind === "cite")?.t).toBe("P1");
    expect(segs.find((s) => s.kind === "em")?.t).toBe("policy");
    expect(segs.filter((s) => s.kind === "text").map((s) => s.t).join("")).toContain("<script>");
  });
});

describe("formatters", () => {
  it("formats money and deltas", () => {
    expect(fmt.gbp(1_250_000)).toBe("£1.25m");
    expect(fmt.delta(-9.5)).toBe("-9.5");
    expect(fmt.delta(3)).toBe("+3.0");
  });
});
