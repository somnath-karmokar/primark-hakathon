import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, qs } from "@/lib/api";
import type {
  Alternatives, CopilotResponse, DashboardSummary, EngineDecision, ExternalEvent, Filters, Health, KnowledgeDoc, KnowledgeHit,
  RecommendationRecord, Relationships, TrendPoint, Vendor360, VendorRisk, VendorRow,
} from "@/types/api";
import type { AnomalyResult, MLAlgorithm, MLDataset, MLRun, TrainResult } from "@/types/ml";

export interface DashFilters { period?: string; category?: string; region?: string; status?: string }

export const useHealth = () => useQuery({ queryKey: ["health"], queryFn: () => api.get<Health>("/health"), refetchInterval: 60_000 });
export const useFilters = () => useQuery({ queryKey: ["filters"], queryFn: () => api.get<Filters>("/meta/filters"), staleTime: 300_000 });

export const useDashboard = (f: DashFilters) =>
  useQuery({ queryKey: ["dashboard", f], queryFn: () => api.get<DashboardSummary>(`/dashboard/summary${qs({ ...f })}`), placeholderData: keepPreviousData });

export interface VendorQuery extends DashFilters { search?: string; band?: string; sort?: string; order?: string; page?: number; page_size?: number; deteriorating?: boolean }
export const useVendors = (q: VendorQuery) =>
  useQuery({ queryKey: ["vendors", q], queryFn: () => api.get<{ items: VendorRow[]; total: number; page: number; page_size: number; period: string }>(`/vendors${qs({ ...q })}`), placeholderData: keepPreviousData });

export const useVendor360 = (id?: string) =>
  useQuery({ queryKey: ["vendor", id], queryFn: () => api.get<Vendor360>(`/vendors/${id}`), enabled: !!id, retry: false });
export const useVendorTrend = (id?: string) =>
  useQuery({ queryKey: ["vendor-trend", id], queryFn: () => api.get<TrendPoint[]>(`/vendors/${id}/trend`), enabled: !!id });
export const useVendorRisk = (id?: string) =>
  useQuery({ queryKey: ["vendor-risk", id], queryFn: () => api.get<VendorRisk>(`/vendors/${id}/risk`), enabled: !!id });
export const useVendorRecs = (id?: string) =>
  useQuery({ queryKey: ["vendor-recs", id], queryFn: () => api.get<{ engine: EngineDecision; history: RecommendationRecord[] }>(`/vendors/${id}/recommendations`), enabled: !!id });
export const useAlternatives = (id?: string, limit = 6) =>
  useQuery({ queryKey: ["alternatives", id, limit], queryFn: () => api.get<Alternatives>(`/vendors/${id}/alternatives${qs({ limit })}`), enabled: !!id });
export const useRelationships = (id?: string) =>
  useQuery({ queryKey: ["relationships", id], queryFn: () => api.get<Relationships>(`/vendors/${id}/relationships`), enabled: !!id });

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const usePerformance = (f: DashFilters) => useQuery({ queryKey: ["performance", f], queryFn: () => api.get<any>(`/analytics/performance${qs({ ...f })}`), placeholderData: keepPreviousData });
export const useCompare = (ids: string[]) =>
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  useQuery({ queryKey: ["compare", ids], queryFn: () => api.post<any>("/analytics/compare", { vendor_ids: ids }), enabled: ids.length >= 2 });

export const useSuggestions = () => useQuery({ queryKey: ["suggestions"], queryFn: () => api.get<{ suggestions: string[] }>("/copilot/suggestions"), staleTime: Infinity });
export const useChat = () => useMutation({ mutationFn: (b: { message: string; session_id?: string }) => api.post<CopilotResponse>("/copilot/chat", b) });

export const useDocuments = () => useQuery({ queryKey: ["docs"], queryFn: () => api.get<KnowledgeDoc[]>("/knowledge/documents") });
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const useDocument = (id?: string) => useQuery({ queryKey: ["doc", id], queryFn: () => api.get<any>(`/knowledge/documents/${id}`), enabled: !!id });
export const useKnowledgeSearch = (q: string, document_type?: string) =>
  useQuery({ queryKey: ["ksearch", q, document_type], queryFn: () => api.get<{ results: KnowledgeHit[]; cache_hit: boolean; embedding_model: string; filters: Record<string, string> }>(`/knowledge/search${qs({ q, document_type, k: 8 })}`), enabled: q.trim().length >= 3 });

export const useRecommendations = (status?: string, enabled = true) =>
  useQuery({ queryKey: ["recs", status], enabled, queryFn: () => api.get<{ items: RecommendationRecord[]; counts: Record<string, number> }>(`/governance/recommendations${qs({ status })}`) });
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const useAudit = (event_type?: string) => useQuery({ queryKey: ["audit", event_type], queryFn: () => api.get<any[]>(`/governance/audit${qs({ event_type, limit: 80 })}`) });
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const useModelInfo = () => useQuery({ queryKey: ["model"], queryFn: () => api.get<any>("/governance/model") });

export function useDecision() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (b: { id: number; decision: "approved" | "rejected"; note?: string }) =>
      api.post<RecommendationRecord>(`/governance/recommendations/${b.id}/decision`, { decision: b.decision, note: b.note }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["recs"] }); qc.invalidateQueries({ queryKey: ["audit"] }); qc.invalidateQueries({ queryKey: ["vendor-recs"] }); },
  });
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const useSettings = () => useQuery({ queryKey: ["settings"], queryFn: () => api.get<any>("/settings") });
export function useSaveSettings() {
  const qc = useQueryClient();
  return useMutation({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    mutationFn: (b: unknown) => api.put<any>("/settings", b),
    onSuccess: () => qc.invalidateQueries(),
  });
}

export const useEvents = () => useQuery({ queryKey: ["events"], queryFn: () => api.get<ExternalEvent[]>("/risk-intel/events") });
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const useEventImpact = (id?: string) => useQuery({ queryKey: ["event", id], queryFn: () => api.get<any>(`/risk-intel/events/${id}/impact`), enabled: !!id });

// ---------------------------------------------------------------- Model Lab

export const useMLAlgorithms = () => useQuery({ queryKey: ["ml-algos"], queryFn: () => api.get<MLAlgorithm[]>("/ml/algorithms"), staleTime: Infinity });
export const useMLDataset = (drop_points: number, test_periods: number) =>
  useQuery({ queryKey: ["ml-dataset", drop_points, test_periods], queryFn: () => api.get<MLDataset>(`/ml/dataset${qs({ drop_points, test_periods })}`) });
export const useMLRuns = () => useQuery({ queryKey: ["ml-runs"], queryFn: () => api.get<{ runs: MLRun[]; active: { algorithm: string; run_id: number | null } }>("/ml/runs") });
export function useTrain() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (b: { candidates: { algorithm: string; params: Record<string, number> }[]; drop_points: number; test_periods: number }) => api.post<TrainResult>("/ml/train", b),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["ml-runs"] }); qc.invalidateQueries({ queryKey: ["audit"] }); },
  });
}
export function usePromote() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number | "reset") => id === "reset" ? api.post<unknown>("/ml/reset", {}) : api.post<unknown>(`/ml/runs/${id}/promote`, {}),
    onSuccess: () => qc.invalidateQueries(),
  });
}
export const useAnomalyLab = () => useMutation({ mutationFn: (b: { contamination: number; n_estimators: number }) => api.post<AnomalyResult>("/ml/anomaly", b) });

// ---------------------------------------------------------------- Guardrails
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const useGuardrails = () => useQuery({ queryKey: ["guardrails"], queryFn: () => api.get<any>("/guardrails"), refetchInterval: 20_000 });
export function useSaveGuardrails() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (b: unknown) => api.put<unknown>("/guardrails", b),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["guardrails"] }); qc.invalidateQueries({ queryKey: ["settings"] }); },
  });
}
export const useGuardrailTest = () => useMutation({
  mutationFn: (text: string) => api.post<{ verdict: "allow" | "flag" | "block"; message: string; sanitized_text: string;
    triggered: { layer: string; rule: string; action: string; detail: string }[] }>("/guardrails/test", { text }),
});

// ---------------------------------------------------------------- Trust Centre
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const useTrustRAI = () => useQuery({ queryKey: ["trust-rai"], queryFn: () => api.get<any>("/trust/responsible-ai") });
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const useTrustFinops = () => useQuery({ queryKey: ["trust-finops"], queryFn: () => api.get<any>("/trust/finops"), refetchInterval: 30_000 });
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const useTrustSecurity = () => useQuery({ queryKey: ["trust-security"], queryFn: () => api.get<any>("/trust/security") });
export function useSaveBudget() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (b: { monthly_budget_gbp: number; alert_pct: number; hard_stop: boolean }) => api.put<unknown>("/trust/finops/budget", b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["trust-finops"] }),
  });
}
export const useFeedback = () => useMutation({
  mutationFn: (b: { request_id: string; rating: "up" | "down"; comment?: string; question?: string }) => api.post<{ recorded: boolean }>("/copilot/feedback", b),
});
