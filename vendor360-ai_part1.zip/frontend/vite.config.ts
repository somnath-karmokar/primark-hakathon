import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          react: ["react", "react-dom", "react-router-dom", "@tanstack/react-query"],
          charts: ["recharts"],
          ui: ["framer-motion", "lucide-react", "@radix-ui/react-tabs", "@radix-ui/react-tooltip", "@radix-ui/react-slider", "@radix-ui/react-switch"],
        },
      },
    },
  },
  server: {
    port: 5200,
    proxy: { "/api": { target: process.env.VITE_API_PROXY ?? "http://127.0.0.1:8040", changeOrigin: true } },
  },
  test: { environment: "jsdom", globals: true, setupFiles: ["./src/test-setup.ts"] },
} as never);
