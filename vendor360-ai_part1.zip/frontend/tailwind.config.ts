import type { Config } from "tailwindcss";
import animate from "tailwindcss-animate";

/**
 * Primark-inspired premium retail palette.
 * brand  = Primark blue (#009FD6, sampled from the supplied logo)
 * ink    = deep navy used for navigation / headings
 * band.* = score bands - validated as a set (dataviz validator: CVD + normal-vision floors pass);
 *          Watch is < 3:1 on white, so every band mark is always accompanied by a text label.
 */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["'Inter Variable'", "Inter", "system-ui", "sans-serif"],
        display: ["'Manrope Variable'", "Manrope", "'Inter Variable'", "sans-serif"],
      },
      colors: {
        brand: {
          50: "#eaf7fc", 100: "#cdeef9", 200: "#9edcf1", 300: "#63c6e8", 400: "#26b0df",
          500: "#009fd6", 600: "#0084b6", 700: "#006a93", 800: "#075573", 900: "#0b465e",
        },
        ink: {
          50: "#f5f7fa", 100: "#e9edf3", 200: "#d5dce6", 300: "#b3bfce", 400: "#8496ab", 500: "#5f738b",
          600: "#475a70", 700: "#33445a", 800: "#1d2c40", 900: "#0f1d30", 950: "#081322",
        },
        band: {
          excellent: "#1f8a4c", good: "#0a8fc4", watch: "#eaa400", atrisk: "#dd5a24", critical: "#a8223d",
        },
        canvas: "#f4f6f9",
      },
      boxShadow: {
        card: "0 1px 2px rgba(15,29,48,0.04), 0 1px 1px rgba(15,29,48,0.03)",
        lift: "0 8px 24px -8px rgba(15,29,48,0.14), 0 2px 6px rgba(15,29,48,0.05)",
      },
      borderRadius: { xl: "0.875rem", "2xl": "1.125rem" },
      keyframes: {
        shimmer: { "100%": { transform: "translateX(100%)" } },
        pulseDot: { "0%,100%": { opacity: "1" }, "50%": { opacity: ".35" } },
      },
      animation: { shimmer: "shimmer 1.6s infinite", "pulse-dot": "pulseDot 1.2s ease-in-out infinite" },
    },
  },
  plugins: [animate],
} satisfies Config;
