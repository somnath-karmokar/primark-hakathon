"""SECONDARY MODULE - Proactive Supplier-Risk Intelligence.

    External event -> classification -> Neo4j supplier graph -> impact propagation
      -> affected vendors -> open POs / products / categories -> future risk -> proactive alert

Deliberately separate from the primary capability: external risk is reported
as its own indicator and is NEVER blended into the Vendor Performance Score or
the internal performance risk.
"""
from __future__ import annotations

from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.graph import queries as graph
from app.models.entities import ExternalEvent, Vendor
from app.services import analytics_service

AS_OF = date(2026, 10, 12)  # synthetic "today" of the demo dataset
SEVERITY = {"high": 3, "medium": 2, "low": 1}
EVENT_ACTIONS = {
    "logistics": ["Pre-alert UK DCs and adjust in-store launch dates for affected lines",
                  "Ask freight forwarder for alternative port / air-freight options for critical POs"],
    "weather": ["Confirm factory business-continuity plans and finished-goods storage",
                "Pull forward shipments that are ready to leave before the event window"],
    "geopolitical": ["Re-plan sea-freight lead times (+transit days) for affected routes",
                     "Review safety stock for critical core lines"],
    "regulatory": ["Verify supplier documentation readiness before the effective date",
                   "Brief customs broker; expect first-shipment holds"],
    "economic": ["Ask suppliers for revised production schedules",
                 "Check capacity at alternative suppliers for critical products"],
}


def _event_dict(e: ExternalEvent) -> dict:
    return {"event_id": e.event_id, "event_type": e.event_type, "title": e.title, "description": e.description,
            "affected_countries": [c for c in e.affected_countries.split(";") if c],
            "affected_ports": [p for p in e.affected_ports.split(";") if p], "severity": e.severity,
            "detected_at": e.detected_at.isoformat(), "expected_duration_days": e.expected_duration_days,
            "expected_delay_days": e.expected_delay_days, "source": e.source, "synthetic": True}


def list_events(db: Session) -> list[dict]:
    rows = sorted(db.execute(select(ExternalEvent).where(ExternalEvent.active.is_(True))).scalars(),
                  key=lambda e: (-SEVERITY.get(e.severity, 1), -e.detected_at.toordinal()))
    out = []
    for e in rows:
        d = _event_dict(e)
        imp = event_impact(db, e.event_id, summary_only=True)
        d["impact"] = imp["totals"]
        out.append(d)
    return out


def _vendor_level(severity: str, open_pos: list[dict], delay: int, duration: int) -> tuple[str, int, int]:
    """External risk = event severity + exposure. Only POs due while the disruption
    (plus its knock-on delay) is active count as exposed."""
    window_end = AS_OF + timedelta(days=duration + delay)
    at_risk = [p for p in open_pos if p.get("promised_date") and
               AS_OF <= date.fromisoformat(str(p["promised_date"])[:10]) <= window_end]
    critical = [p for p in at_risk if p.get("is_critical")]
    lvl = SEVERITY.get(severity, 1) + (1 if at_risk else 0) + (1 if critical else 0)
    return ("High" if lvl >= 5 else "Medium" if lvl >= 3 else "Low"), len(at_risk), len(critical)


def event_impact(db: Session, event_id: str, summary_only: bool = False) -> dict:
    e = db.get(ExternalEvent, event_id)
    if not e:
        raise LookupError(event_id)
    g = graph.event_impact(db, event_id)
    cur = analytics_service.current_table(db).set_index("vendor_id")
    vendors, products, categories = [], set(), set()
    total_value = total_pos = critical_pos = 0
    for v in g["vendors"]:
        pos = [p for p in (v.get("open_pos") or []) if p]
        level, n_risk, n_crit = _vendor_level(e.severity, pos, e.expected_delay_days, e.expected_duration_days)
        for p in pos:
            products.add(p["product"]); categories.add(p["category"])
        value = sum(float(p.get("value") or 0) for p in pos)
        total_value += value; total_pos += len(pos); critical_pos += n_crit
        row = cur.loc[v["vendor_id"]] if v["vendor_id"] in cur.index else None
        vendors.append({
            "vendor_id": v["vendor_id"], "name": v["name"], "tier": v.get("tier"),
            "performance_score": round(float(row["overall"]), 1) if row is not None else v.get("score"),
            "performance_band": row["band"] if row is not None else v.get("band"),
            "internal_risk": row["risk_level"] if row is not None and "risk_level" in row else None,
            "external_risk": level, "open_pos": len(pos), "open_value": round(value, 2), "pos_at_risk": n_risk,
            "critical_pos_at_risk": n_crit, "products": sorted({p["product"] for p in pos})[:6],
            "categories": sorted({p["category"] for p in pos}),
        })
    vendors.sort(key=lambda x: ({"High": 0, "Medium": 1, "Low": 2}[x["external_risk"]], -x["open_value"]))
    totals = {"vendors": len(vendors), "high_risk_vendors": sum(v["external_risk"] == "High" for v in vendors),
              "open_pos": total_pos, "critical_pos_at_risk": critical_pos, "open_value": round(total_value, 2),
              "products": len(products), "categories": len(categories)}
    if summary_only:
        return {"totals": totals}
    top = vendors[0] if vendors else None
    path = None
    if top:
        vrow = db.get(Vendor, top["vendor_id"])
        loc = vrow.port if vrow and vrow.port in e.affected_ports.split(";") else (vrow.country if vrow else "")
        path = [{"type": "ExternalEvent", "label": e.title}, {"type": "Port" if vrow and loc == vrow.port else "Country", "label": loc},
                {"type": "Vendor", "label": f"{top['vendor_id']} {top['name']}"},
                {"type": "PurchaseOrder", "label": f"{top['open_pos']} open POs (GBP {top['open_value']:,.0f})"},
                {"type": "Product", "label": ", ".join(top["products"][:2]) or "-"},
                {"type": "Category", "label": ", ".join(top["categories"]) or "-"},
                {"type": "Impact", "label": f"~{e.expected_delay_days} days delay; {top['critical_pos_at_risk']} critical POs at risk"}]
    strong_but_exposed = [v for v in vendors if v["performance_band"] in ("Excellent", "Good") and v["external_risk"] == "High"]
    alert = None
    if strong_but_exposed:
        v = strong_but_exposed[0]
        alert = (f"Vendor {v['vendor_id']} currently has a strong performance score of {v['performance_score']:.0f} ({v['performance_band']}), "
                 f"but {e.title.lower()} may affect {v['open_pos']} active POs and {v['critical_pos_at_risk']} critical POs.")
    return {
        "event": _event_dict(e), "graph_source": g["source"], "totals": totals, "vendors": vendors[:40], "propagation_path": path,
        "proactive_alert": alert,
        "recommended_actions": EVENT_ACTIONS.get(e.event_type, []) + (
            ["Engage SEP-4.2-eligible alternatives for critical POs at risk"] if critical_pos else []),
        "note": "External supplier risk is a separate indicator and is not included in the Vendor Performance Score.",
    }


def vendor_external_risk(db: Session, vendor_id: str) -> dict:
    v = db.get(Vendor, vendor_id.upper())
    if not v:
        raise analytics_service.VendorNotFound(vendor_id)
    events = []
    for e in db.execute(select(ExternalEvent).where(ExternalEvent.active.is_(True))).scalars():
        if v.country in e.affected_countries.split(";") or v.port in e.affected_ports.split(";"):
            events.append(e)
    if not events:
        return {"vendor_id": v.vendor_id, "external_risk": "None", "events": [], "indicator": "external_supplier_risk"}
    worst = max(events, key=lambda e: SEVERITY.get(e.severity, 1))
    imp = event_impact(db, worst.event_id)
    mine = next((x for x in imp["vendors"] if x["vendor_id"] == v.vendor_id), None)
    level = mine["external_risk"] if mine else {"high": "Medium", "medium": "Low", "low": "Low"}[worst.severity]
    return {"vendor_id": v.vendor_id, "external_risk": level, "indicator": "external_supplier_risk",
            "events": [{"event_id": e.event_id, "title": e.title, "severity": e.severity, "event_type": e.event_type,
                        "expected_delay_days": e.expected_delay_days} for e in events],
            "exposure": mine, "graph_source": imp["graph_source"]}
