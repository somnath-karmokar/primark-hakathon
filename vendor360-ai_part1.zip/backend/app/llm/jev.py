"""JEV - JSON Evidence Vector: the token/context optimiser.

Agents never hand the LLM raw rows or verbose JSON. They hand it *evidence
items* (already-computed facts). JEV turns those into the smallest faithful
context that fits a token budget:

1. canonicalise  - drop nulls/empties, round floats (2 dp), shorten known keys
2. deduplicate   - identical facts from different agents are sent once
3. prioritise    - items carry a priority; highest first
4. budget        - greedily pack items until ``budget_tokens``; report what was dropped
5. encode        - one compact line per item: ``E3|metric|Delivery score|55.4|src=postgres``

The output keeps evidence ids (E1..En) so the model can cite them and the
Governance Agent can verify the citations.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from functools import lru_cache

KEY_MAP = {
    "vendor_id": "vid", "overall": "ovr", "delivery": "del", "quality": "qua", "lead_time": "lt", "cost": "cst",
    "on_time_pct": "otd%", "defect_rate_pct": "def%", "variance_pct": "var%", "coefficient_of_variation": "cv",
    "change_3m": "d3m", "risk_probability": "p_risk", "risk_level": "risk", "category": "cat", "status": "st",
    "document_id": "doc", "section": "sec", "similarity": "sim",
}


@lru_cache
def _encoder():
    try:
        import tiktoken
        return tiktoken.get_encoding("o200k_base")
    except Exception:  # offline / unknown encoding -> heuristic
        return None


def count_tokens(text: str) -> int:
    enc = _encoder()
    if enc is not None:
        return len(enc.encode(text))
    return max(1, len(text) // 4)


def _empty(x) -> bool:
    if x is None:
        return True
    if isinstance(x, (str, list, tuple, dict)):
        return len(x) == 0
    return False


def _canon(v):
    if hasattr(v, "tolist") and not isinstance(v, (str, bytes)):  # numpy scalars / arrays
        v = v.tolist()
    if isinstance(v, bool):
        return v
    if isinstance(v, float):
        return round(v, 2)
    if isinstance(v, dict):
        return {KEY_MAP.get(k, k): _canon(x) for k, x in v.items() if not _empty(x)}
    if isinstance(v, (list, tuple)):
        return [_canon(x) for x in v if not _empty(x)]
    return v


@dataclass
class EvidenceItem:
    id: str
    kind: str            # metric | trend | risk | policy | graph | recommendation | portfolio
    title: str
    value: object
    source: str
    priority: int = 5    # 1 = most important
    ref: str = ""

    def encode(self) -> str:
        val = self.value if isinstance(self.value, str) else json.dumps(_canon(self.value), separators=(",", ":"), default=str)
        ref = f"|ref={self.ref}" if self.ref else ""
        return f"{self.id}|{self.kind}|{self.title}|{val}|src={self.source}{ref}"


@dataclass
class JEVResult:
    context: str
    included: list[str]
    dropped: list[str]
    raw_tokens: int
    compressed_tokens: int
    stats: dict = field(default_factory=dict)

    @property
    def saved_tokens(self) -> int:
        return max(0, self.raw_tokens - self.compressed_tokens)


def compress(items: list[EvidenceItem], budget_tokens: int = 1800) -> JEVResult:
    raw = json.dumps([it.__dict__ for it in items], default=str, indent=2)
    raw_tokens = count_tokens(raw)
    seen, unique = set(), []
    for it in sorted(items, key=lambda x: (x.priority, x.id)):
        sig = (it.kind, it.title, json.dumps(_canon(it.value), sort_keys=True, default=str) if not isinstance(it.value, str) else it.value)
        if sig in seen:
            continue
        seen.add(sig)
        unique.append(it)
    lines, included, dropped, used = [], [], [], 0
    for it in unique:
        line = it.encode()
        t = count_tokens(line) + 1
        if used + t > budget_tokens:
            # long policy passages are truncated before being dropped outright
            if it.kind == "policy" and isinstance(it.value, str) and used + 80 < budget_tokens:
                room = (budget_tokens - used - 20) * 4
                it2 = EvidenceItem(it.id, it.kind, it.title, it.value[:max(80, room)] + "...", it.source, it.priority, it.ref)
                line = it2.encode()
                t = count_tokens(line) + 1
                if used + t <= budget_tokens:
                    lines.append(line); included.append(it.id); used += t
                    continue
            dropped.append(it.id)
            continue
        lines.append(line); included.append(it.id); used += t
    ctx = "\n".join(lines)
    return JEVResult(ctx, included, dropped, raw_tokens, count_tokens(ctx),
                     {"items_in": len(items), "items_unique": len(unique), "budget": budget_tokens})
