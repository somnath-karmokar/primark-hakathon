"""LLM Optimisation Layer - the only path from agents to a model.

    LangGraph node -> LLMGateway -> [exact cache] -> [token budget] -> [model router] -> provider
                                   (JEV-compressed context is built by the caller)

Guarantees: max LLM calls per request, per-request token budget, timeout,
exact response cache keyed by model + prompt version, usage telemetry, and a
clean ``None`` result (never an exception) when no model can be used, so the
caller falls back to deterministic output and says so.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeout
from dataclasses import asdict, dataclass, field

from pydantic import BaseModel

from app.config import get_settings
from app.llm.jev import count_tokens
from app.llm.provider import ModelRoute, chat_model, route
from app.services.cache import response_cache, stable_key

log = logging.getLogger(__name__)
_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="llm")


@dataclass
class RequestBudget:
    max_llm_calls: int
    token_budget: int
    llm_calls: int = 0
    tokens_used: int = 0
    blocked_reason: str = ""          # set when the monthly AI budget is used up (FinOps hard stop)

    def can_call(self, estimated_tokens: int) -> tuple[bool, str]:
        if self.blocked_reason:
            return False, self.blocked_reason
        if self.llm_calls >= self.max_llm_calls:
            return False, f"max LLM calls reached ({self.max_llm_calls})"
        if self.tokens_used + estimated_tokens > self.token_budget:
            return False, f"token budget exceeded ({self.tokens_used}+{estimated_tokens} > {self.token_budget})"
        return True, ""


@dataclass
class CallRecord:
    task: str
    model: str
    tier: str
    status: str            # ok | cache_hit | fallback | error | timeout | budget
    reason: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    latency_ms: int = 0
    cache_hit: bool = False

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class Telemetry:
    calls: int = 0
    cache_hits: int = 0
    fallbacks: int = 0
    errors: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    jev_raw_tokens: int = 0
    jev_compressed_tokens: int = 0
    by_model: dict = field(default_factory=dict)
    lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def record(self, rec: CallRecord) -> None:
        with self.lock:
            if rec.status == "ok":
                self.calls += 1
                self.prompt_tokens += rec.prompt_tokens
                self.completion_tokens += rec.completion_tokens
                m = self.by_model.setdefault(rec.model, {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0})
                m["calls"] += 1
                m["prompt_tokens"] += rec.prompt_tokens
                m["completion_tokens"] += rec.completion_tokens
            elif rec.status == "cache_hit":
                self.cache_hits += 1
            elif rec.status in ("error", "timeout"):
                self.errors += 1
            else:
                self.fallbacks += 1

    def record_jev(self, raw: int, compressed: int) -> None:
        with self.lock:
            self.jev_raw_tokens += raw
            self.jev_compressed_tokens += compressed

    def as_dict(self) -> dict:
        saved = self.jev_raw_tokens - self.jev_compressed_tokens
        return {"llm_calls": self.calls, "cache_hits": self.cache_hits, "fallbacks": self.fallbacks, "errors": self.errors,
                "prompt_tokens": self.prompt_tokens, "completion_tokens": self.completion_tokens,
                "jev_raw_tokens": self.jev_raw_tokens, "jev_compressed_tokens": self.jev_compressed_tokens,
                "jev_tokens_saved": saved,
                "jev_compression_ratio": round(self.jev_compressed_tokens / self.jev_raw_tokens, 3) if self.jev_raw_tokens else None,
                "by_model": self.by_model}


telemetry = Telemetry()


def structured_call(task: str, system: str, user: str, schema: type[BaseModel],
                    budget: RequestBudget) -> tuple[BaseModel | None, CallRecord]:
    s = get_settings()
    r: ModelRoute | None = route(task)
    if r is None:
        rec = CallRecord(task, "none", "-", "fallback", "LLM provider not configured (LLM_PROVIDER=none or missing credentials)")
        telemetry.record(rec)
        return None, rec
    est = count_tokens(system) + count_tokens(user) + 700
    ok, why = budget.can_call(est)
    if not ok:
        rec = CallRecord(task, r.model_id, r.tier, "budget", why)
        telemetry.record(rec)
        return None, rec
    key = stable_key("llm", r.model_id, s.prompt_version, schema.__name__, system, user)
    cached = response_cache.get(key)
    if cached is not None:
        rec = CallRecord(task, r.model_id, r.tier, "cache_hit", cache_hit=True)
        telemetry.record(rec)
        return schema.model_validate(cached), rec

    budget.llm_calls += 1
    t0 = time.perf_counter()

    def invoke():
        llm = chat_model(r.provider, r.model).with_structured_output(schema, include_raw=True)
        return llm.invoke([("system", system), ("human", user)])

    try:
        out = _pool.submit(invoke).result(timeout=s.llm_timeout_seconds)
    except FutureTimeout:
        rec = CallRecord(task, r.model_id, r.tier, "timeout", f"no response within {s.llm_timeout_seconds}s",
                         latency_ms=int((time.perf_counter() - t0) * 1000))
        telemetry.record(rec)
        return None, rec
    except Exception as exc:
        log.warning("LLM call failed: %s", type(exc).__name__)
        rec = CallRecord(task, r.model_id, r.tier, "error", f"{type(exc).__name__}: {str(exc)[:160]}",
                         latency_ms=int((time.perf_counter() - t0) * 1000))
        telemetry.record(rec)
        return None, rec
    parsed = out.get("parsed")
    usage = getattr(out.get("raw"), "usage_metadata", None) or {}
    rec = CallRecord(task, r.model_id, r.tier, "ok" if parsed is not None else "error",
                     "" if parsed is not None else f"unparseable structured output: {out.get('parsing_error')}",
                     prompt_tokens=int(usage.get("input_tokens", est - 700)),
                     completion_tokens=int(usage.get("output_tokens", 0)),
                     latency_ms=int((time.perf_counter() - t0) * 1000))
    budget.tokens_used += rec.prompt_tokens + rec.completion_tokens
    telemetry.record(rec)
    if parsed is not None:
        response_cache.set(key, parsed.model_dump(), tags={"model": r.model_id})
    return parsed, rec
