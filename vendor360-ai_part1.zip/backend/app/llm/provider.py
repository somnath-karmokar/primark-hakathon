"""LLM provider factory + model routing (Azure OpenAI | OpenAI).

Tier routing keeps cheap work on cheap models:

    classify / simple summary -> light
    policy explanation        -> standard
    recommendation / executive synthesis -> strong

Each tier maps to an env-configured model/deployment and falls back to the
standard model when a tier is not configured.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from app.config import get_settings

TASK_TIER = {
    "classify": "light",
    "summary": "light",
    "policy_explanation": "standard",
    "performance_explanation": "standard",
    "recommendation": "strong",
    "executive_synthesis": "strong",
}


@dataclass(frozen=True)
class ModelRoute:
    provider: str
    tier: str
    model: str

    @property
    def model_id(self) -> str:
        return f"{self.provider}:{self.model}"


def route(task: str) -> ModelRoute | None:
    s = get_settings()
    tier = TASK_TIER.get(task, "standard")
    if not s.llm_configured:
        return None
    if s.llm_provider == "azure":
        names = {"light": s.azure_openai_deployment_light, "standard": s.azure_openai_deployment,
                 "strong": s.azure_openai_deployment_strong}
        return ModelRoute("azure", tier, names[tier] or s.azure_openai_deployment)
    names = {"light": s.openai_model_light, "standard": s.openai_model, "strong": s.openai_model_strong}
    return ModelRoute("openai", tier, names[tier] or s.openai_model)


@lru_cache(maxsize=8)
def chat_model(provider: str, model: str):
    s = get_settings()
    if provider == "azure":
        from langchain_openai import AzureChatOpenAI
        return AzureChatOpenAI(azure_endpoint=s.azure_openai_endpoint, api_key=s.azure_openai_api_key,
                               api_version=s.azure_openai_api_version, azure_deployment=model,
                               temperature=s.llm_temperature, timeout=s.llm_timeout_seconds, max_retries=1)
    from langchain_openai import ChatOpenAI
    return ChatOpenAI(api_key=s.openai_api_key, model=model, temperature=s.llm_temperature,
                      timeout=s.llm_timeout_seconds, max_retries=1)


def routing_table() -> list[dict]:
    out = []
    for task, tier in TASK_TIER.items():
        r = route(task)
        out.append({"task": task, "tier": tier, "model": r.model_id if r else "deterministic-fallback"})
    return out
