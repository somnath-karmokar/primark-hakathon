"""Vendor360 AI - FastAPI application."""
from __future__ import annotations

import logging
import os
import threading
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1 import router
from app.config import get_settings
from app.observability import RequestContextMiddleware, configure_logging
from app.services import analytics_service, cache

log = logging.getLogger("vendor360")


def _warm_up() -> None:
    """Load embedder / tokenizer / analytics frames so the first user request is fast."""
    try:
        from app.database.session import session_scope
        from app.graph import client as graph_client
        from app.knowledge import store
        from app.knowledge.embeddings import get_embedder
        from app.llm.jev import count_tokens
        from app.services import runtime_settings
        from app.llm.provider import chat_model, route
        r = route("summary")
        if r is not None:  # import + construct the client now, so the first copilot call isn't a cold start
            chat_model(r.provider, r.model)
        get_embedder().embed(["warm up"])
        count_tokens("warm up")
        store.policy_version()
        graph_client.is_available(force=True)
        with session_scope() as db:
            rt = runtime_settings.get_runtime(db)
            cache.configure(rt["cache"]["enabled"], rt["cache"]["ttl_seconds"], rt["cache"]["semantic_threshold"])
            if analytics_service.latest_period(db):
                analytics_service.current_table(db)
        log.info("warm-up complete")
    except Exception as exc:  # never block startup
        log.warning("warm-up skipped: %s", exc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    if s.langsmith_tracing and s.langsmith_api_key:
        os.environ.setdefault("LANGSMITH_TRACING", "true")
        os.environ.setdefault("LANGSMITH_API_KEY", s.langsmith_api_key)
    threading.Thread(target=_warm_up, daemon=True).start()
    yield
    from app.graph import client
    client.close()


def create_app() -> FastAPI:
    s = get_settings()
    configure_logging(s.log_level)
    app = FastAPI(title="Vendor360 AI API", version="1.0.0", lifespan=lifespan,
                  description="Agentic Vendor Performance Scoring & Supplier Intelligence Platform. "
                              "Scores are deterministic; AI explains, recommends and is governed.")
    app.add_middleware(RequestContextMiddleware)
    app.add_middleware(CORSMiddleware, allow_origins=s.cors_origin_list, allow_methods=["GET", "POST", "PUT"],
                       allow_headers=["Content-Type", "X-API-Key", "X-Request-ID"], expose_headers=["X-Request-ID"])
    app.include_router(router)

    @app.exception_handler(analytics_service.VendorNotFound)
    async def _not_found(_: Request, exc: analytics_service.VendorNotFound):
        return JSONResponse(status_code=404, content={"detail": f"Vendor {exc} not found"})

    @app.exception_handler(Exception)
    async def _unhandled(_: Request, exc: Exception):
        log.exception("unhandled error")
        return JSONResponse(status_code=500, content={"detail": "Internal error - see server logs (request id in X-Request-ID)"})

    @app.get("/", include_in_schema=False)
    def root():
        return {"app": s.app_name, "docs": "/docs", "health": "/api/v1/health"}

    return app


app = create_app()
