"""Supplier-relationship queries.

Neo4j is the primary source. If the graph is unreachable the same question is
answered from the relational tables and the result is labelled
``source = "postgres-fallback"`` - real data, never fabricated.
"""
from __future__ import annotations

import logging

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.graph import client
from app.models.entities import (
    Category, Contract, ExternalEvent, Product, PurchaseOrder, QualityInspection, Vendor, VendorProduct,
)
from app.services.cache import retrieval_cache, stable_key

log = logging.getLogger(__name__)


def _graph(query: str, **params) -> list[dict] | None:
    if not client.is_available():
        return None
    try:
        return client.run(query, **params)
    except Exception as exc:
        log.warning("graph query failed, using relational fallback: %s", type(exc).__name__)
        return None


def _cached(name: str, vendor_id: str, fn):
    key = stable_key("graph", name, vendor_id)
    val, hit = retrieval_cache.get_or_set(key, fn, tags={"vendor_id": vendor_id, "kind": "graph"})
    return {**val, "cache_hit": hit}


# ---------------------------------------------------------------------------
def vendor_relationships(db: Session, vendor_id: str) -> dict:
    """Products, categories, contract + SLA, region for one vendor."""
    def fn():
        q = """
        MATCH (v:Vendor {vendor_id: $vid})
        OPTIONAL MATCH (v)-[s:SUPPLIES]->(p:Product)-[:BELONGS_TO]->(c:Category)
        WITH v, collect(DISTINCT {product_id: p.product_id, name: p.name, category: c.name, is_critical: p.is_critical,
                                  is_primary_source: s.is_primary_source}) AS products,
             collect(DISTINCT c.name) AS categories
        OPTIONAL MATCH (v)-[:HAS_CONTRACT]->(ct:Contract)-[:GOVERNED_BY]->(sla:SLA)
        OPTIONAL MATCH (v)-[:OPERATES_IN]->(r:Region)
        OPTIONAL MATCH (v)-[:SHIPS_VIA]->(pt:Port)
        RETURN v.vendor_id AS vendor_id, v.name AS name, products, categories,
               ct {.*} AS contract, sla {.*} AS sla, r.name AS region, pt.name AS port
        """
        rows = _graph(q, vid=vendor_id)
        if rows:
            r = rows[0]
            r["products"] = [p for p in r["products"] if p.get("product_id")]
            return {"source": "neo4j", "cypher": " ".join(q.split()), **r}
        return {"source": "postgres-fallback", **_rel_vendor_relationships(db, vendor_id)}
    return _cached("relationships", vendor_id, fn)


def _rel_vendor_relationships(db: Session, vendor_id: str) -> dict:
    v = db.get(Vendor, vendor_id)
    prods = db.execute(select(Product.product_id, Product.name, Category.name, Product.is_critical, VendorProduct.is_primary_source)
                       .join(VendorProduct, VendorProduct.product_id == Product.product_id)
                       .join(Category, Category.category_id == Product.category_id)
                       .where(VendorProduct.vendor_id == vendor_id)).all()
    c = db.execute(select(Contract).where(Contract.vendor_id == vendor_id)).scalar_one_or_none()
    return {"vendor_id": vendor_id, "name": v.name if v else None,
            "products": [{"product_id": a, "name": b, "category": cn, "is_critical": d, "is_primary_source": e} for a, b, cn, d, e in prods],
            "categories": sorted({cn for _, _, cn, _, _ in prods}),
            "contract": {"contract_id": c.contract_id, "contract_type": c.contract_type, "end_date": c.end_date.isoformat(),
                         "payment_terms_days": c.payment_terms_days} if c else None,
            "sla": {"sla_id": c.sla_id, "otd_target_pct": c.sla_otd_target_pct, "max_defect_rate_pct": c.sla_max_defect_rate_pct,
                    "max_invoice_variance_pct": c.sla_max_invoice_variance_pct} if c else None,
            "region": v.region if v else None, "port": v.port if v else None}


# ---------------------------------------------------------------------------
def supplier_dependency(db: Session, vendor_id: str) -> dict:
    """Which products/categories depend on this vendor and how many other sources exist."""
    def fn():
        q = """
        MATCH (v:Vendor {vendor_id: $vid})-[s:SUPPLIES]->(p:Product)-[:BELONGS_TO]->(c:Category)
        OPTIONAL MATCH (other:Vendor)-[:SUPPLIES]->(p) WHERE other <> v AND other.status <> 'Under Review'
        WITH p, c, s, count(DISTINCT other) AS alt_sources
        OPTIONAL MATCH (:Vendor {vendor_id: $vid})-[:HAS_PO]->(po:PurchaseOrder {status: 'Open'})-[:FOR_PRODUCT]->(p)
        RETURN p.product_id AS product_id, p.name AS product, c.name AS category, p.is_critical AS is_critical,
               s.is_primary_source AS is_primary_source, alt_sources, count(po) AS open_pos, sum(coalesce(po.value,0)) AS open_value
        ORDER BY is_primary_source DESC, alt_sources ASC
        """
        rows = _graph(q, vid=vendor_id)
        source = "neo4j"
        if rows is None:
            source, rows = "postgres-fallback", _rel_dependency(db, vendor_id)
        cats: dict[str, dict] = {}
        for r in rows:
            c = cats.setdefault(r["category"], {"category": r["category"], "products": 0, "primary_source_for": 0, "open_pos": 0})
            c["products"] += 1
            c["primary_source_for"] += int(bool(r["is_primary_source"]))
            c["open_pos"] += int(r["open_pos"] or 0)
        level = "High" if any(r["is_primary_source"] and r["alt_sources"] <= 2 for r in rows) else \
                "Medium" if any(r["is_primary_source"] for r in rows) else "Low"
        return {"source": source, "vendor_id": vendor_id, "products": rows, "categories": list(cats.values()),
                "dependency_level": level, "cypher": " ".join(q.split()) if source == "neo4j" else None}
    return _cached("dependency", vendor_id, fn)


def _rel_dependency(db: Session, vendor_id: str) -> list[dict]:
    mine = db.execute(select(VendorProduct.product_id, Product.name, Category.name, Product.is_critical, VendorProduct.is_primary_source)
                      .join(Product, Product.product_id == VendorProduct.product_id)
                      .join(Category, Category.category_id == Product.category_id)
                      .where(VendorProduct.vendor_id == vendor_id)).all()
    out = []
    for pid, pname, cname, crit, prim in mine:
        alts = db.execute(select(func.count()).select_from(VendorProduct).join(Vendor, Vendor.vendor_id == VendorProduct.vendor_id)
                          .where(VendorProduct.product_id == pid, VendorProduct.vendor_id != vendor_id, Vendor.status != "Under Review")).scalar_one()
        open_pos = db.execute(select(func.count(), func.coalesce(func.sum(PurchaseOrder.expected_value), 0))
                              .where(PurchaseOrder.vendor_id == vendor_id, PurchaseOrder.product_id == pid, PurchaseOrder.status == "Open")).one()
        out.append({"product_id": pid, "product": pname, "category": cname, "is_critical": crit, "is_primary_source": prim,
                    "alt_sources": alts, "open_pos": open_pos[0], "open_value": float(open_pos[1])})
    out.sort(key=lambda r: (not r["is_primary_source"], r["alt_sources"]))
    return out


# ---------------------------------------------------------------------------
def alternative_candidates(db: Session, vendor_id: str, limit: int = 15) -> dict:
    """Vendors linked by ALTERNATIVE_TO (shared products), depth-bounded."""
    def fn():
        depth = min(2, get_settings().graph_max_depth)
        q = f"""
        MATCH (v:Vendor {{vendor_id: $vid}})-[a:ALTERNATIVE_TO*1..{depth}]-(alt:Vendor)
        WHERE alt <> v AND alt.status IN ['Active', 'Onboarding']
        WITH v, alt, min(size(a)) AS hops
        OPTIONAL MATCH (alt)-[:SUPPLIES]->(p:Product)<-[:SUPPLIES]-(v)
        WITH v, alt, hops, count(DISTINCT p) AS shared_products, collect(DISTINCT p.name)[0..4] AS shared_names
        WHERE shared_products > 0 OR alt.primary_category_id = v.primary_category_id
        RETURN alt.vendor_id AS vendor_id, alt.name AS name, hops, shared_products, shared_names
        ORDER BY shared_products DESC, hops ASC LIMIT $limit
        """
        rows = _graph(q, vid=vendor_id, limit=limit * 3)
        if rows is not None:
            return {"source": "neo4j", "candidates": rows, "cypher": " ".join(q.split())}
        mine = select(VendorProduct.product_id).where(VendorProduct.vendor_id == vendor_id)
        rel = db.execute(select(VendorProduct.vendor_id, Vendor.name, func.count(VendorProduct.product_id))
                         .join(Vendor, Vendor.vendor_id == VendorProduct.vendor_id)
                         .where(VendorProduct.product_id.in_(mine), VendorProduct.vendor_id != vendor_id,
                                Vendor.status.in_(["Active", "Onboarding"]))
                         .group_by(VendorProduct.vendor_id, Vendor.name)
                         .order_by(func.count(VendorProduct.product_id).desc()).limit(limit * 3)).all()
        return {"source": "postgres-fallback",
                "candidates": [{"vendor_id": a, "name": b, "hops": 1, "shared_products": n, "shared_names": []} for a, b, n in rel]}
    return _cached("alternatives", vendor_id, fn)


# ---------------------------------------------------------------------------
def vendor_pos(db: Session, vendor_id: str, status: str | None = "Open", limit: int = 20) -> dict:
    q = """
    MATCH (v:Vendor {vendor_id: $vid})-[:HAS_PO]->(po:PurchaseOrder)-[:FOR_PRODUCT]->(p:Product)
    WHERE $status IS NULL OR po.status = $status
    RETURN po.po_id AS po_id, po.status AS status, po.value AS value, po.po_date AS po_date,
           po.promised_date AS promised_date, po.is_critical AS is_critical, p.name AS product
    ORDER BY po.po_date DESC LIMIT $limit
    """
    rows = _graph(q, vid=vendor_id, status=status, limit=limit)
    if rows is not None:
        return {"source": "neo4j", "purchase_orders": rows}
    stmt = select(PurchaseOrder, Product.name).join(Product, Product.product_id == PurchaseOrder.product_id).where(PurchaseOrder.vendor_id == vendor_id)
    if status:
        stmt = stmt.where(PurchaseOrder.status == status)
    res = db.execute(stmt.order_by(PurchaseOrder.po_date.desc()).limit(limit)).all()
    return {"source": "postgres-fallback", "purchase_orders": [
        {"po_id": p.po_id, "status": p.status, "value": p.expected_value, "po_date": p.po_date.isoformat(),
         "promised_date": p.promised_date.isoformat(), "is_critical": p.is_critical, "product": n} for p, n in res]}


def quality_issues(db: Session, vendor_id: str, limit: int = 20) -> dict:
    q = """
    MATCH (v:Vendor {vendor_id: $vid})-[:HAS_QUALITY_ISSUE]->(qi:QualityIssue)
    RETURN qi.issue_id AS issue_id, qi.date AS date, qi.reason AS reason, qi.defect_rate_pct AS defect_rate_pct, qi.po_id AS po_id
    ORDER BY qi.date DESC LIMIT $limit
    """
    rows = _graph(q, vid=vendor_id, limit=limit)
    if rows is not None:
        return {"source": "neo4j", "issues": rows}
    res = db.execute(select(QualityInspection).where(QualityInspection.vendor_id == vendor_id, QualityInspection.result == "FAIL")
                     .order_by(QualityInspection.inspection_date.desc()).limit(limit)).scalars()
    return {"source": "postgres-fallback", "issues": [
        {"issue_id": i.inspection_id, "date": i.inspection_date.isoformat(), "reason": i.rejection_reason or "AQL failure",
         "defect_rate_pct": round(i.defect_qty / i.inspected_qty * 100, 2) if i.inspected_qty else 0, "po_id": i.po_id} for i in res]}


# ---------------------------------------------------------------------------
def neighbourhood(db: Session, vendor_id: str, max_alts: int = 5) -> dict:
    """Small node/edge set for the Vendor 360 relationship map."""
    rel = vendor_relationships(db, vendor_id)
    alts = alternative_candidates(db, vendor_id)["candidates"][:max_alts]
    nodes = [{"id": vendor_id, "label": vendor_id, "type": "Vendor", "primary": True}]
    edges = []
    for c in rel.get("categories", []):
        nodes.append({"id": f"cat:{c}", "label": c, "type": "Category"})
    for p in rel.get("products", [])[:8]:
        nodes.append({"id": p["product_id"], "label": p["name"], "type": "Product", "critical": p.get("is_critical")})
        edges.append({"from": vendor_id, "to": p["product_id"], "type": "SUPPLIES"})
        edges.append({"from": p["product_id"], "to": f"cat:{p['category']}", "type": "BELONGS_TO"})
    if rel.get("sla"):
        nodes.append({"id": rel["sla"]["sla_id"], "label": rel["sla"]["sla_id"], "type": "SLA"})
        edges.append({"from": vendor_id, "to": rel["sla"]["sla_id"], "type": "HAS_SLA"})
    if rel.get("region"):
        nodes.append({"id": f"reg:{rel['region']}", "label": rel["region"], "type": "Region"})
        edges.append({"from": vendor_id, "to": f"reg:{rel['region']}", "type": "OPERATES_IN"})
    for a in alts:
        nodes.append({"id": a["vendor_id"], "label": a["vendor_id"], "type": "Vendor"})
        edges.append({"from": vendor_id, "to": a["vendor_id"], "type": "ALTERNATIVE_TO"})
    return {"source": rel["source"], "nodes": nodes, "edges": edges}


# ---------------------------------------------------------------------------
def event_impact(db: Session, event_id: str) -> dict:
    """Secondary module: Event -> Country/Port -> Vendor -> open PO -> Product -> Category."""
    key = stable_key("graph", "event_impact", event_id)
    val, hit = retrieval_cache.get_or_set(key, lambda: _event_impact(db, event_id), tags={"kind": "graph", "event_id": event_id})
    return {**val, "cache_hit": hit}


def _event_impact(db: Session, event_id: str) -> dict:
    q = """
    MATCH (e:ExternalEvent {event_id: $eid})-[:AFFECTS]->(loc)
    MATCH (v:Vendor)-[:LOCATED_IN|SHIPS_VIA]->(loc)
    WITH DISTINCT e, v
    OPTIONAL MATCH (v)-[:HAS_PO]->(po:PurchaseOrder {status: 'Open'})-[:FOR_PRODUCT]->(p:Product)-[:BELONGS_TO]->(c:Category)
    RETURN v.vendor_id AS vendor_id, v.name AS name, v.overall_score AS score, v.band AS band, v.tier AS tier,
           collect(DISTINCT CASE WHEN po IS NULL THEN NULL ELSE {po_id: po.po_id, value: po.value, promised_date: po.promised_date,
                   is_critical: po.is_critical, product: p.name, category: c.name} END) AS open_pos
    """
    rows = _graph(q, eid=event_id)
    if rows is not None:
        return {"source": "neo4j", "vendors": rows, "cypher": " ".join(q.split())}
    ev = db.get(ExternalEvent, event_id)
    if not ev:
        return {"source": "postgres-fallback", "vendors": []}
    countries = [c for c in ev.affected_countries.split(";") if c]
    ports = [p for p in ev.affected_ports.split(";") if p]
    vs = db.query(Vendor).filter((Vendor.country.in_(countries)) | (Vendor.port.in_(ports))).all()
    out = []
    for v in vs:
        pos = db.execute(select(PurchaseOrder, Product.name, Category.name).join(Product, Product.product_id == PurchaseOrder.product_id)
                         .join(Category, Category.category_id == Product.category_id)
                         .where(PurchaseOrder.vendor_id == v.vendor_id, PurchaseOrder.status == "Open")).all()
        out.append({"vendor_id": v.vendor_id, "name": v.name, "score": None, "band": None, "tier": v.tier,
                    "open_pos": [{"po_id": p.po_id, "value": p.expected_value, "promised_date": p.promised_date.isoformat(),
                                  "is_critical": p.is_critical, "product": pn, "category": cn} for p, pn, cn in pos]})
    return {"source": "postgres-fallback", "vendors": out}
