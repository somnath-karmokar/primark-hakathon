"""Neo4j driver lifecycle + availability probing."""
from __future__ import annotations

import logging
import threading
import time
from typing import Any

from app.config import get_settings

log = logging.getLogger(__name__)

_driver = None
_lock = threading.Lock()
_status: dict[str, Any] = {"available": False, "checked_at": 0.0, "error": "not checked"}


def get_driver():
    global _driver
    s = get_settings()
    if not (s.neo4j_enabled and s.neo4j_uri and s.neo4j_password):
        return None
    with _lock:
        if _driver is None:
            from neo4j import GraphDatabase
            _driver = GraphDatabase.driver(s.neo4j_uri, auth=(s.neo4j_username, s.neo4j_password),
                                           connection_timeout=8, max_connection_lifetime=300)
        return _driver


def is_available(force: bool = False) -> bool:
    now = time.time()
    if not force and now - _status["checked_at"] < 60:
        return _status["available"]
    drv = get_driver()
    if drv is None:
        _status.update(available=False, checked_at=now, error="Neo4j not configured")
        return False
    try:
        drv.verify_connectivity()
        _status.update(available=True, checked_at=now, error="")
    except Exception as exc:  # network / auth / paused Aura instance
        log.warning("Neo4j unavailable: %s", type(exc).__name__)
        _status.update(available=False, checked_at=now, error=f"{type(exc).__name__}: {str(exc)[:160]}")
    return _status["available"]


def status() -> dict:
    s = get_settings()
    uri = s.neo4j_uri
    host = uri.split("://")[-1] if uri else ""
    return {"available": _status["available"], "error": _status["error"], "host": host, "database": s.neo4j_database}


def run(query: str, **params) -> list[dict]:
    drv = get_driver()
    if drv is None:
        raise RuntimeError("Neo4j not configured")
    records, _, _ = drv.execute_query(query, params, database_=get_settings().neo4j_database)
    return [r.data() for r in records]


def close() -> None:
    global _driver
    if _driver is not None:
        _driver.close()
        _driver = None
