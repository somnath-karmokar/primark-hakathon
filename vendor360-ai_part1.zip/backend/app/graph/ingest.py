"""Idempotent Postgres -> Neo4j supplier knowledge-graph ingestion.

Every write is a MERGE on a business key, so re-running is safe. Only
relationship-relevant data goes to the graph: transactional analytics stay in
PostgreSQL.
"""
from __future__ import annotations

import logging
import time
from datetime import timedelta
from itertools import combinations

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.graph import client
from app.models.entities import (
    Category, Contract, ExternalEvent, Product, PurchaseOrder, QualityInspection, Vendor, VendorProduct,
)
from app.services import analytics_service

log = logging.getLogger(__name__)

CONSTRAINTS = [
    "CREATE CONSTRAINT vendor_id IF NOT EXISTS FOR (n:Vendor) REQUIRE n.vendor_id IS UNIQUE",
    "CREATE CONSTRAINT product_id IF NOT EXISTS FOR (n:Product) REQUIRE n.product_id IS UNIQUE",
    "CREATE CONSTRAINT category_id IF NOT EXISTS FOR (n:Category) REQUIRE n.category_id IS UNIQUE",
    "CREATE CONSTRAINT po_id IF NOT EXISTS FOR (n:PurchaseOrder) REQUIRE n.po_id IS UNIQUE",
    "CREATE CONSTRAINT qi_id IF NOT EXISTS FOR (n:QualityIssue) REQUIRE n.issue_id IS UNIQUE",
    "CREATE CONSTRAINT contract_id IF NOT EXISTS FOR (n:Contract) REQUIRE n.contract_id IS UNIQUE",
    "CREATE CONSTRAINT sla_id IF NOT EXISTS FOR (n:SLA) REQUIRE n.sla_id IS UNIQUE",
    "CREATE CONSTRAINT region_name IF NOT EXISTS FOR (n:Region) REQUIRE n.name IS UNIQUE",
    "CREATE CONSTRAINT country_name IF NOT EXISTS FOR (n:Country) REQUIRE n.name IS UNIQUE",
    "CREATE CONSTRAINT port_name IF NOT EXISTS FOR (n:Port) REQUIRE n.name IS UNIQUE",
    "CREATE CONSTRAINT event_id IF NOT EXISTS FOR (n:ExternalEvent) REQUIRE n.event_id IS UNIQUE",
]


def _batched(rows: list[dict], query: str, size: int = 1000) -> int:
    for i in range(0, len(rows), size):
        client.run(query, rows=rows[i:i + size])
    return len(rows)


def ingest(db: Session, po_months: int = 6, max_alternatives: int = 15) -> dict:
    if not client.is_available(force=True):
        return {"status": "unavailable", **client.status()}
    t0 = time.perf_counter()
    for c in CONSTRAINTS:
        client.run(c)
    counts: dict[str, int] = {}

    cur = analytics_service.current_table(db).set_index("vendor_id")
    counts["Category"] = _batched([{"id": c.category_id, "name": c.name} for c in db.query(Category)],
                                  "UNWIND $rows AS r MERGE (c:Category {category_id: r.id}) SET c.name = r.name")
    counts["Product"] = _batched(
        [{"id": p.product_id, "name": p.name, "cat": p.category_id, "crit": p.is_critical} for p in db.query(Product)],
        "UNWIND $rows AS r MERGE (p:Product {product_id: r.id}) SET p.name = r.name, p.is_critical = r.crit "
        "WITH p, r MATCH (c:Category {category_id: r.cat}) MERGE (p)-[:BELONGS_TO]->(c)")
    vrows = []
    for v in db.query(Vendor):
        sc = cur.loc[v.vendor_id] if v.vendor_id in cur.index else None
        vrows.append({"id": v.vendor_id, "name": v.name, "tier": v.tier, "status": v.status, "country": v.country,
                      "region": v.region, "port": v.port, "cat": v.primary_category_id,
                      "score": float(sc["overall"]) if sc is not None else None, "band": sc["band"] if sc is not None else None})
    counts["Vendor"] = _batched(vrows, """
        UNWIND $rows AS r
        MERGE (v:Vendor {vendor_id: r.id})
        SET v.name = r.name, v.tier = r.tier, v.status = r.status, v.overall_score = r.score, v.band = r.band,
            v.primary_category_id = r.cat
        MERGE (reg:Region {name: r.region})
        MERGE (co:Country {name: r.country})
        MERGE (pt:Port {name: r.port})
        MERGE (co)-[:IN_REGION]->(reg)
        MERGE (v)-[:OPERATES_IN]->(reg)
        MERGE (v)-[:LOCATED_IN]->(co)
        MERGE (v)-[:SHIPS_VIA]->(pt)
        MERGE (pt)-[:IN_COUNTRY]->(co)""")
    vp = db.execute(select(VendorProduct.vendor_id, VendorProduct.product_id, VendorProduct.is_primary_source)).all()
    counts["SUPPLIES"] = _batched([{"v": a, "p": b, "prim": c} for a, b, c in vp],
                                  "UNWIND $rows AS r MATCH (v:Vendor {vendor_id: r.v}), (p:Product {product_id: r.p}) "
                                  "MERGE (v)-[s:SUPPLIES]->(p) SET s.is_primary_source = r.prim")
    contracts = db.query(Contract).all()
    counts["Contract"] = _batched([{
        "id": c.contract_id, "v": c.vendor_id, "type": c.contract_type, "start": c.start_date.isoformat(), "end": c.end_date.isoformat(),
        "sla": c.sla_id, "otd": c.sla_otd_target_pct, "defect": c.sla_max_defect_rate_pct, "inv": c.sla_max_invoice_variance_pct,
        "terms": c.payment_terms_days, "excl": c.exclusivity} for c in contracts], """
        UNWIND $rows AS r MATCH (v:Vendor {vendor_id: r.v})
        MERGE (c:Contract {contract_id: r.id})
        SET c.contract_type = r.type, c.start_date = r.start, c.end_date = r.end, c.payment_terms_days = r.terms, c.exclusivity = r.excl
        MERGE (s:SLA {sla_id: r.sla})
        SET s.otd_target_pct = r.otd, s.max_defect_rate_pct = r.defect, s.max_invoice_variance_pct = r.inv
        MERGE (v)-[:HAS_CONTRACT]->(c)
        MERGE (c)-[:GOVERNED_BY]->(s)
        MERGE (v)-[:HAS_SLA]->(s)""")

    max_date = db.execute(select(func.max(PurchaseOrder.po_date))).scalar_one()
    since = max_date - timedelta(days=30 * po_months)
    pos = db.query(PurchaseOrder).filter(PurchaseOrder.po_date >= since).all()
    counts["PurchaseOrder"] = _batched([{
        "id": p.po_id, "v": p.vendor_id, "p": p.product_id, "status": p.status, "value": round(p.expected_value, 2),
        "date": p.po_date.isoformat(), "promised": p.promised_date.isoformat(), "crit": p.is_critical} for p in pos], """
        UNWIND $rows AS r MATCH (v:Vendor {vendor_id: r.v}), (pr:Product {product_id: r.p})
        MERGE (po:PurchaseOrder {po_id: r.id})
        SET po.status = r.status, po.value = r.value, po.po_date = r.date, po.promised_date = r.promised, po.is_critical = r.crit
        MERGE (v)-[:HAS_PO]->(po)
        MERGE (po)-[:FOR_PRODUCT]->(pr)""")
    issues = db.query(QualityInspection).filter(QualityInspection.result == "FAIL", QualityInspection.inspection_date >= since).all()
    counts["QualityIssue"] = _batched([{
        "id": q.inspection_id, "v": q.vendor_id, "po": q.po_id, "date": q.inspection_date.isoformat(),
        "reason": q.rejection_reason or "AQL failure", "rate": round(q.defect_qty / q.inspected_qty * 100, 2) if q.inspected_qty else 0}
        for q in issues], """
        UNWIND $rows AS r MATCH (v:Vendor {vendor_id: r.v})
        MERGE (qi:QualityIssue {issue_id: r.id})
        SET qi.date = r.date, qi.reason = r.reason, qi.defect_rate_pct = r.rate, qi.po_id = r.po
        MERGE (v)-[:HAS_QUALITY_ISSUE]->(qi)
        WITH qi, r OPTIONAL MATCH (po:PurchaseOrder {po_id: r.po})
        FOREACH (_ IN CASE WHEN po IS NULL THEN [] ELSE [1] END | MERGE (qi)-[:RAISED_ON]->(po))""")

    # ALTERNATIVE_TO: vendors sharing products; keep the strongest candidates per vendor.
    by_product: dict[str, list[str]] = {}
    for v, p, _ in vp:
        by_product.setdefault(p, []).append(v)
    shared: dict[tuple[str, str], int] = {}
    for vids in by_product.values():
        for a, b in combinations(sorted(set(vids)), 2):
            shared[(a, b)] = shared.get((a, b), 0) + 1
    per_vendor: dict[str, list[tuple[str, int]]] = {}
    for (a, b), n in shared.items():
        per_vendor.setdefault(a, []).append((b, n))
        per_vendor.setdefault(b, []).append((a, n))
    alt_rows = []
    for a, lst in per_vendor.items():
        lst.sort(key=lambda t: (-t[1], -(float(cur.loc[t[0], "overall"]) if t[0] in cur.index else 0)))
        alt_rows += [{"a": a, "b": b, "n": n} for b, n in lst[:max_alternatives]]
    client.run("MATCH (:Vendor)-[r:ALTERNATIVE_TO]->(:Vendor) DELETE r")
    counts["ALTERNATIVE_TO"] = _batched(alt_rows, "UNWIND $rows AS r MATCH (a:Vendor {vendor_id: r.a}), (b:Vendor {vendor_id: r.b}) "
                                                  "MERGE (a)-[x:ALTERNATIVE_TO]->(b) SET x.shared_products = r.n", size=2000)

    events = db.query(ExternalEvent).all()
    counts["ExternalEvent"] = _batched([{
        "id": e.event_id, "type": e.event_type, "title": e.title, "severity": e.severity, "detected": e.detected_at.isoformat(),
        "countries": [c for c in e.affected_countries.split(";") if c], "ports": [p for p in e.affected_ports.split(";") if p],
        "delay": e.expected_delay_days} for e in events], """
        UNWIND $rows AS r
        MERGE (e:ExternalEvent {event_id: r.id})
        SET e.event_type = r.type, e.title = r.title, e.severity = r.severity, e.detected_at = r.detected, e.expected_delay_days = r.delay
        WITH e, r
        FOREACH (cn IN r.countries | MERGE (c:Country {name: cn}) MERGE (e)-[:AFFECTS]->(c))
        FOREACH (pn IN r.ports | MERGE (p:Port {name: pn}) MERGE (e)-[:AFFECTS]->(p))""")

    # Remove POs that aged out of the window (keeps re-runs idempotent and bounded).
    client.run("MATCH (po:PurchaseOrder) WHERE po.po_date < $since DETACH DELETE po", since=since.isoformat())
    elapsed = round(time.perf_counter() - t0, 1)
    log.info("graph ingestion complete in %ss: %s", elapsed, counts)
    return {"status": "ok", "counts": counts, "seconds": elapsed}
