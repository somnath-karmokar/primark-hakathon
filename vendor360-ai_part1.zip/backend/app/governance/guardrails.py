"""Guardrails - one place for every rule that protects the AI copilot.

Layers
------
* **input**  - length limits, prompt-injection detection (flag or block), personal-data
               redaction before anything reaches a model, blocked terms, per-user rate limit,
               vendor-id / date validation (in the copilot service).
* **agent**  - max agent steps, tool calls, LLM calls, token budget, graph depth, timeout.
* **output** - numeric grounding, citation validity, deterministic-ranking protection,
               minimum confidence (low-confidence answers are qualified), policy grounding.
* **access** - role-based permissions (staff vs admin); every denial is logged.

Configuration lives in ``app_settings['guardrails']`` (editable by admins on the
Guardrails page); every triggered rule is written to the audit trail as a
``guardrail`` event.
"""
from __future__ import annotations

import re
import threading
import time
from collections import defaultdict, deque

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings

DEFAULTS = {
    "input": {
        "min_query_chars": 3,
        "max_query_chars": 600,
        "injection_action": "flag",        # flag | block
        "pii_redaction": True,
        "rate_limit_per_minute": 20,
        "blocked_terms": ["bribe", "kickback", "falsify"],
    },
    "output": {
        "max_unsupported_figures": 1,      # more than this -> LLM draft rejected
        "enforce_ranking": True,           # reject drafts that re-rank deterministic alternatives
        "require_citations": True,         # LLM answers must cite evidence ids
        "min_confidence": 0.5,             # below -> answer is qualified with a warning
    },
}

INJECTION_PATTERNS = [
    ("ignore_instructions", r"\b(ignore|disregard|forget)\b.{0,30}\b(previous|prior|above|all|your)\b.{0,20}\b(instructions?|rules?|prompts?)"),
    ("reveal_system_prompt", r"\b(system prompt|developer message|hidden instructions?|reveal your (prompt|instructions))"),
    ("role_override", r"\byou are now\b|\bact as\b.{0,30}\b(admin|developer|unrestricted|dan)\b|\bjailbreak\b"),
    ("tool_coercion", r"\b(drop|delete|truncate)\s+(table|database)\b|;\s*--|<script\b"),
    ("score_manipulation", r"\b(set|change|override|make)\b.{0,25}\b(score|band|rating)\b.{0,25}\b(to|=)\s*\d+"),
]
PII_PATTERNS = [
    ("email", r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", "[EMAIL]"),
    ("card_number", r"\b\d(?:[ -]?\d){12,15}\b", "[CARD]"),
    ("uk_ni_number", r"\b[A-CEGHJ-PR-TW-Z]{2}\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b", "[NI-NUMBER]"),
    ("phone", r"(?:\+44\s?|\b0)(?:\d[\s-]?){9,10}\b", "[PHONE]"),
]

_rate: dict[str, deque] = defaultdict(deque)
_rate_lock = threading.Lock()


# ---------------------------------------------------------------- config
def config(db: Session) -> dict:
    from app.services import runtime_settings
    rt = runtime_settings.get_runtime(db)
    stored = rt.get("guardrails") or {}
    cfg = {layer: {**vals, **(stored.get(layer) or {})} for layer, vals in DEFAULTS.items()}
    s = get_settings()
    cfg["agent"] = {**rt["agent"], "graph_max_depth": s.graph_max_depth, "agent_timeout_seconds": s.agent_timeout_seconds,
                    "llm_timeout_seconds": s.llm_timeout_seconds}
    return cfg


def save(db: Session, input_cfg: dict | None, output_cfg: dict | None, agent_cfg: dict | None) -> dict:
    from app.services import runtime_settings
    current = config(db)
    new = {"input": {**current["input"], **(input_cfg or {})}, "output": {**current["output"], **(output_cfg or {})}}
    runtime_settings.set_section(db, "guardrails", new)
    if agent_cfg:
        runtime_settings.set_section(db, "agent", {**runtime_settings.get_runtime(db)["agent"], **agent_cfg})
    return config(db)


# ---------------------------------------------------------------- input checks
def _luhn(digits: str) -> bool:
    d = [int(c) for c in digits if c.isdigit()]
    if not 13 <= len(d) <= 16:
        return False
    total = 0
    for i, n in enumerate(reversed(d)):
        if i % 2:
            n *= 2
            n = n - 9 if n > 9 else n
        total += n
    return total % 10 == 0


def check_input(text: str, cfg: dict, user: str | None = None, consume_rate: bool = True) -> dict:
    """Evaluate a question against the input guardrails.

    Returns verdict ``allow`` | ``flag`` | ``block``, the triggered rules and the
    sanitised text (personal data redacted) that is safe to pass to agents / LLMs.
    """
    c = cfg["input"]
    q = (text or "").strip()
    triggered: list[dict] = []

    def hit(rule: str, action: str, detail: str):
        triggered.append({"layer": "input", "rule": rule, "action": action, "detail": detail})

    if len(q) < c["min_query_chars"]:
        hit("min_length", "block", f"question shorter than {c['min_query_chars']} characters")
    if len(q) > c["max_query_chars"]:
        hit("max_length", "block", f"question is {len(q)} characters (limit {c['max_query_chars']})")
    for name, rx in INJECTION_PATTERNS:
        m = re.search(rx, q, re.I)
        if m:
            hit(f"prompt_injection:{name}", c["injection_action"], f"matched '{m.group(0)[:60]}'")
    for term in c.get("blocked_terms") or []:
        if term and re.search(rf"\b{re.escape(term)}\b", q, re.I):
            hit("blocked_term", "block", f"contains blocked term '{term}'")
    sanitized = q
    if c["pii_redaction"]:
        for name, rx, token in PII_PATTERNS:
            def repl(m, name=name, token=token):
                if name == "card_number" and not _luhn(m.group(0)):
                    return m.group(0)
                hit(f"pii:{name}", "redact", f"{name.replace('_', ' ')} redacted")
                return token
            sanitized = re.sub(rx, repl, sanitized)
    if user and consume_rate and c["rate_limit_per_minute"] > 0:
        now = time.time()
        with _rate_lock:
            dq = _rate[user]
            while dq and now - dq[0] > 60:
                dq.popleft()
            if len(dq) >= c["rate_limit_per_minute"]:
                hit("rate_limit", "block", f"more than {c['rate_limit_per_minute']} questions per minute")
            else:
                dq.append(now)
    actions = {t["action"] for t in triggered}
    verdict = "block" if "block" in actions else "flag" if actions & {"flag", "redact"} else "allow"
    return {"verdict": verdict, "triggered": triggered, "sanitized_text": sanitized, "original_length": len(q)}


def block_message(result: dict) -> str:
    rules = [t for t in result["triggered"] if t["action"] == "block"]
    first = rules[0]["rule"] if rules else "policy"
    if first.startswith("prompt_injection"):
        return "Blocked by guardrail: the question looks like an attempt to override the assistant's instructions."
    if first == "blocked_term":
        return f"Blocked by guardrail: {rules[0]['detail']}. Raise this through the ethics / compliance channel."
    if first == "rate_limit":
        return "Blocked by guardrail: too many questions in the last minute - please wait a moment."
    return f"Blocked by guardrail: {rules[0]['detail']}."


# ---------------------------------------------------------------- event logging
def record(db: Session, *, actor: str, role: str, request_id: str, triggered: list[dict], verdict: str, question: str | None = None) -> None:
    from app.governance.audit import audit
    if not triggered:
        return
    audit(db, request_id=request_id, actor=actor, event_type="guardrail", entity_type="guardrail", entity_id=verdict,
          summary=f"[{verdict}] " + ", ".join(sorted({t['rule'] for t in triggered}))[:250],
          details={"verdict": verdict, "role": role, "rules": triggered,
                   "question_preview": (question or "")[:120]})


def record_access_denied(principal, permission: str, path: str) -> None:
    from app.database.session import session_scope
    try:
        with session_scope() as db:
            record(db, actor=principal.user, role=principal.role, request_id="-", verdict="block",
                   triggered=[{"layer": "access", "rule": f"rbac:{permission}", "action": "block",
                               "detail": f"{principal.role} attempted {path}"}])
    except Exception:  # logging must never break the request
        pass


def stats(db: Session, limit: int = 200) -> dict:
    from app.models.entities import AuditEvent
    rows = db.execute(select(AuditEvent).where(AuditEvent.event_type == "guardrail").order_by(AuditEvent.ts.desc()).limit(limit)).scalars().all()
    by_rule: dict[str, int] = defaultdict(int)
    by_layer: dict[str, int] = defaultdict(int)
    by_verdict: dict[str, int] = defaultdict(int)
    for r in rows:
        by_verdict[r.details.get("verdict", "flag")] += 1
        for t in r.details.get("rules", []):
            by_rule[t["rule"].split(":")[0] if t["rule"].startswith("rbac") else t["rule"]] += 1
            by_layer[t["layer"]] += 1
    rejected = db.execute(select(func.count()).select_from(AuditEvent).where(
        AuditEvent.event_type == "copilot_answer", AuditEvent.details["governance"].as_string() != "passed")).scalar_one()
    return {"total": len(rows), "by_verdict": dict(by_verdict), "by_layer": dict(by_layer),
            "by_rule": dict(sorted(by_rule.items(), key=lambda kv: -kv[1])), "qualified_answers": rejected,
            "events": [{"id": r.id, "ts": r.ts.isoformat(), "actor": r.actor, "role": r.details.get("role"),
                        "verdict": r.details.get("verdict"), "rules": r.details.get("rules", []),
                        "question": r.details.get("question_preview"), "request_id": r.request_id} for r in rows[:80]]}


def catalogue(cfg: dict) -> list[dict]:
    """Human-readable list of every guardrail and its current setting (for the Guardrails page)."""
    i, o, a = cfg["input"], cfg["output"], cfg["agent"]
    return [
        {"layer": "input", "rule": "Question length", "setting": f"{i['min_query_chars']}-{i['max_query_chars']} characters", "action": "block"},
        {"layer": "input", "rule": "Prompt-injection detection", "setting": f"{len(INJECTION_PATTERNS)} pattern families", "action": i["injection_action"]},
        {"layer": "input", "rule": "Personal-data redaction", "setting": "email, phone, card (Luhn), NI number" if i["pii_redaction"] else "off", "action": "redact"},
        {"layer": "input", "rule": "Blocked terms", "setting": ", ".join(i["blocked_terms"]) or "none", "action": "block"},
        {"layer": "input", "rule": "Per-user rate limit", "setting": f"{i['rate_limit_per_minute']} / minute", "action": "block"},
        {"layer": "input", "rule": "Vendor id & date validation", "setting": "V1001-V1500; periods with scored data", "action": "block / qualify"},
        {"layer": "agent", "rule": "Max agent steps", "setting": str(a["max_agent_steps"]), "action": "stop -> synthesise"},
        {"layer": "agent", "rule": "Max tool calls per request", "setting": str(a["max_tool_calls"]), "action": "stop"},
        {"layer": "agent", "rule": "Max LLM calls per request", "setting": str(a["max_llm_calls"]), "action": "deterministic fallback"},
        {"layer": "agent", "rule": "Token budget per request", "setting": f"{a['token_budget_per_request']} tokens", "action": "deterministic fallback"},
        {"layer": "agent", "rule": "Tool allow-list per agent", "setting": "enforced", "action": "block"},
        {"layer": "agent", "rule": "Graph traversal depth", "setting": str(a["graph_max_depth"]), "action": "bounded"},
        {"layer": "agent", "rule": "Timeouts", "setting": f"agent {a['agent_timeout_seconds']}s / LLM {a['llm_timeout_seconds']}s", "action": "stop / fallback"},
        {"layer": "output", "rule": "Numeric grounding", "setting": f"reject draft if > {o['max_unsupported_figures']} unsupported figure(s)", "action": "reject draft"},
        {"layer": "output", "rule": "Citation validity", "setting": "required" if o["require_citations"] else "checked only", "action": "reject draft" if o["require_citations"] else "flag"},
        {"layer": "output", "rule": "Deterministic ranking protection", "setting": "on" if o["enforce_ranking"] else "off", "action": "reject draft"},
        {"layer": "output", "rule": "Minimum confidence", "setting": f"{o['min_confidence']:.2f}", "action": "qualify answer"},
        {"layer": "output", "rule": "Human approval for supplier-facing actions", "setting": "Stage 2+ (PP-5, SEP-5)", "action": "approval queue"},
        {"layer": "access", "rule": "Role-based permissions", "setting": "staff: read, copilot - admin: all", "action": "403 + log"},
    ]
