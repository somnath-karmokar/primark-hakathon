"""Append-only audit trail for scoring runs, AI answers, recommendations and approvals."""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.entities import AuditEvent


def audit(db: Session, *, request_id: str, actor: str, event_type: str, entity_type: str, entity_id: str,
          summary: str, details: dict | None = None) -> AuditEvent:
    ev = AuditEvent(request_id=request_id, actor=actor, event_type=event_type, entity_type=entity_type,
                    entity_id=entity_id, summary=summary[:300], details=details or {})
    db.add(ev)
    db.flush()
    return ev
