"""Governance Agent checks - deterministic verification of an AI answer.

* evidence present for an in-scope question
* every cited evidence id exists
* every number in the answer is grounded in evidence (numeric grounding)
* policy grounding when the intent requires it
* data sufficiency of the underlying score
* confidence score + whether human approval is required
"""
from __future__ import annotations

import json
import re

NUM = re.compile(r"(?<![A-Za-z\-])(\d+(?:\.\d+)?)(?![A-Za-z]*\d)")
CITE = re.compile(r"\[([A-Z]{1,2}\d{1,2})\]")
POLICY_INTENTS = {"vendor_recommendation", "vendor_sla", "policy_question", "alternatives"}
SAFE_NUMBERS = {str(n) for n in range(0, 13)} | {"100", "30", "60", "90", "120", "2025", "2026"}


def _numbers_in(obj) -> set[str]:
    text = json.dumps(obj, default=str)
    out = set()
    for m in re.findall(r"-?\d+(?:\.\d+)?", text):
        try:
            f = abs(float(m))
        except ValueError:
            continue
        out |= {f"{f:g}", f"{round(f, 1):g}", f"{round(f):g}", f"{round(f, 2):g}"}
        if f < 1:  # fractions also appear as percentages
            out |= {f"{f * 100:g}", f"{round(f * 100, 1):g}", f"{round(f * 100):g}"}
    return out


def numeric_grounding(answer_text: str, evidence: list[dict]) -> tuple[list[str], list[str]]:
    allowed = _numbers_in(evidence) | SAFE_NUMBERS
    # Clause ids (SEP-4.2, DSLA-4), vendor ids (V1024) and evidence ids ([P3]) are not figures.
    cleaned = re.sub(r"\b[A-Z]{1,4}-\d+(?:\.\d+)?\b|\bV\d{4}\b|\[[A-Z]{1,2}\d{1,2}\]|\b\d{4}-\d{2}(?:-\d{2})?\b", " ", answer_text)
    found = [m for m in NUM.findall(cleaned)]
    grounded, unsupported = [], []
    for n in found:
        f = float(n)
        variants = {f"{f:g}", f"{round(f, 1):g}", f"{round(f):g}"}
        (grounded if variants & allowed else unsupported).append(n)
    return grounded, unsupported


def evaluate(*, intent: str, answer: dict, evidence: list[dict], score_sufficient: bool | None,
             recommendation: dict | None, graph_source: str | None, llm_used: bool,
             approval_threshold: float, guardrail_flags: list[str]) -> dict:
    checks = []
    in_scope = intent != "out_of_scope"
    ev_ids = {e["id"] for e in evidence}

    has_evidence = bool(evidence) or not in_scope
    checks.append({"check": "evidence_present", "passed": has_evidence,
                   "detail": f"{len(evidence)} evidence items" if evidence else "no evidence gathered"})

    cited = set(answer.get("cited_evidence", [])) | set(CITE.findall(answer.get("text", "")))
    invalid = sorted(cited - ev_ids)
    checks.append({"check": "citations_valid", "passed": not invalid,
                   "detail": f"{len(cited)} citations" + (f"; unknown: {', '.join(invalid)}" if invalid else "")})

    grounded, unsupported = numeric_grounding(answer.get("text", "") + " " + " ".join(answer.get("reasoning", [])), evidence)
    checks.append({"check": "numeric_grounding", "passed": not unsupported,
                   "detail": f"{len(grounded)} figures grounded" + (f"; unsupported: {', '.join(unsupported[:6])}" if unsupported else "")})

    needs_policy = intent in POLICY_INTENTS
    policy_items = [e for e in evidence if e.get("kind") == "policy"]
    policy_ok = (not needs_policy) or bool(policy_items)
    checks.append({"check": "policy_grounding", "passed": policy_ok,
                   "detail": f"{len(policy_items)} policy passages" + ("" if needs_policy else " (not required)")})

    checks.append({"check": "data_sufficiency", "passed": score_sufficient is not False,
                   "detail": "score window has sufficient POs" if score_sufficient else
                   ("n/a" if score_sufficient is None else "fewer than 3 completed POs in window (SEV-5)")})
    if graph_source:
        checks.append({"check": "graph_source", "passed": True,
                       "detail": "Neo4j supplier graph" if graph_source == "neo4j" else "relational fallback (Neo4j unavailable)"})
    ranking_violation = None
    if recommendation:
        alts = recommendation.get("alternatives", [])
        bad = [a["vendor_id"] for a in alts if not a.get("eligible")]
        checks.append({"check": "alternatives_policy_eligible", "passed": not bad,
                       "detail": "all proposed alternatives meet SEP-4.2" if not bad else f"ineligible: {', '.join(bad)}"})
        # The deterministic fit ranking may not be overridden: the first alternative the answer
        # names must be the top-ranked eligible one.
        best = next((a["vendor_id"] for a in alts if a.get("eligible")), None)
        alt_ids = {a["vendor_id"] for a in alts}
        mentioned = [m for m in re.findall(r"\bV\d{4}\b", answer.get("text", "")) if m in alt_ids]
        if best and mentioned and mentioned[0] != best:
            ranking_violation = f"answer leads with {mentioned[0]} but the deterministic rank-1 alternative is {best}"
        checks.append({"check": "alternative_ranking_respected", "passed": ranking_violation is None,
                       "detail": ranking_violation or (f"rank-1 alternative {best} preserved" if best else "no eligible alternative")})

    # ---- confidence -------------------------------------------------------
    data_q = 1.0 if score_sufficient is not False else 0.6
    coverage = min(1.0, len(evidence) / 6) if in_scope else 0.0
    policy_g = 1.0 if policy_ok else 0.4
    answer_g = 1.0 if not unsupported and not invalid else max(0.2, 1 - 0.25 * (len(unsupported) + len(invalid)))
    if ranking_violation:
        answer_g = min(answer_g, 0.4)
    graph_pen = 0.05 if graph_source and graph_source != "neo4j" else 0.0
    confidence = round(max(0.0, 0.3 * data_q + 0.25 * coverage + 0.2 * policy_g + 0.25 * answer_g - graph_pen), 2) if in_scope else 0.0
    label = "High" if confidence >= 0.8 else "Medium" if confidence >= 0.6 else "Low"

    unsupported_claims = [f"figure {n} not found in evidence" for n in unsupported] + [f"citation {c} not in evidence" for c in invalid]
    if ranking_violation:
        unsupported_claims.append(f"overrides deterministic ranking: {ranking_violation}")
    requires_approval = bool(recommendation and recommendation.get("requires_approval")) or \
        (recommendation is not None and confidence < approval_threshold)
    status = "passed" if all(c["passed"] for c in checks) else ("qualified" if has_evidence else "insufficient_evidence")
    return {"status": status, "checks": checks, "ranking_violation": ranking_violation, "confidence": confidence, "confidence_label": label,
            "unsupported_claims": unsupported_claims, "requires_approval": requires_approval,
            "approval_reason": ("Supplier-facing / volume-changing action (PP-5, SEP-5)" if recommendation and recommendation.get("requires_approval")
                                else f"Confidence below {approval_threshold}" if requires_approval else None),
            "llm_used": llm_used, "guardrail_flags": guardrail_flags}
