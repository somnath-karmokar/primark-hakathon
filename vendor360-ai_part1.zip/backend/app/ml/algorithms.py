"""The risk model's algorithm: XGBoost only.

XGBoost was chosen after comparing it with Logistic Regression, Random Forest and
scikit-learn Gradient Boosting on the same temporal hold-out. With shallow, regularised
trees it matched or beat all three on every metric (ROC-AUC 0.735, PR-AUC 0.40,
Brier 0.100, lift@10% 3.7x on the demo data), so one model is kept - simpler to
explain, run and govern. The registry shape is kept so the API can validate the
tunable hyper-parameters against their bounds.

Class re-weighting is off by default: it inflates probabilities, and risk levels use
fixed probability thresholds (High >= 0.60, Medium >= 0.35).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable



@dataclass(frozen=True)
class Param:
    name: str
    kind: str            # int | float
    default: float
    min: float
    max: float
    step: float
    help: str


@dataclass(frozen=True)
class Algorithm:
    key: str
    label: str
    family: str
    description: str
    params: list[Param]
    build: Callable[[dict, float], Any] = field(repr=False)   # (params, pos_weight) -> estimator
    tree: bool = True

    def resolve(self, params: dict | None) -> dict:
        """Defaults + user overrides, clamped to bounds and cast."""
        out = {}
        for p in self.params:
            v = (params or {}).get(p.name, p.default)
            v = min(max(float(v), p.min), p.max)
            out[p.name] = int(round(v)) if p.kind == "int" else round(v, 6)
        return out


def _xgb(p: dict, w: float):
    from xgboost import XGBClassifier
    return XGBClassifier(n_estimators=p["n_estimators"], max_depth=p["max_depth"], learning_rate=p["learning_rate"],
                         subsample=p["subsample"], colsample_bytree=p["colsample_bytree"], min_child_weight=p["min_child_weight"],
                         scale_pos_weight=w if p["balance_classes"] >= 0.5 else 1.0, eval_metric="logloss",
                         tree_method="hist", n_jobs=4, random_state=p["random_state"])


SEED = Param("random_state", "int", 7, 0, 9999, 1, "Random seed (reproducibility)")

ALGORITHMS: dict[str, Algorithm] = {a.key: a for a in [
    Algorithm("xgboost", "XGBoost", "Boosted trees",
              "Regularised gradient-boosted decision trees (histogram algorithm). Shallow trees and a minimum leaf weight keep it from memorising the training months.",
              [Param("n_estimators", "int", 200, 50, 1500, 50, "Boosting rounds"),
               Param("max_depth", "int", 2, 1, 10, 1, "Tree depth"),
               Param("learning_rate", "float", 0.05, 0.005, 0.5, 0.005, "Shrinkage (eta)"),
               Param("subsample", "float", 0.8, 0.5, 1.0, 0.05, "Row subsampling"),
               Param("colsample_bytree", "float", 0.8, 0.3, 1.0, 0.05, "Feature subsampling per tree"),
               Param("min_child_weight", "float", 5.0, 0.0, 20.0, 0.5, "Minimum child hessian weight"),
               Param("balance_classes", "int", 0, 0, 1, 1, "1 = re-weight positives by the class ratio (inflates probabilities)"), SEED], _xgb),
]}

DEFAULT_ALGORITHM = "xgboost"


def feature_importance(model, algorithm: Algorithm, features: list[str]) -> list[float]:
    """Global importance: the tree ensemble's gain-based importances."""
    return [float(v) for v in model.feature_importances_]
