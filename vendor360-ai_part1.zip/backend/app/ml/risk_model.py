"""Internal performance-risk prediction + anomaly detection.

Question the model answers: *will this vendor's performance deteriorate in a
sustained way over the next 3 months?*  Label = the average score of the next
three monthly snapshots is >= 6 points below the trailing three-month average.
A smoothed label is used deliberately: a single-month drop label was dominated
by sampling noise (held-out ROC-AUC 0.64 vs 0.72). Labels come from the score
history itself (observed future outcomes), not invented targets.

Honesty rules (spec section 16):
* temporal split - train on earlier periods, evaluate on a later, unseen period;
* metrics are reported exactly as measured;
* if the model is not credible (too few positives or ROC-AUC < 0.65 on the
  held-out period) it is NOT used for predictions - the platform falls back to
  the statistical trend + IsolationForest anomaly layer and says so.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.metrics import accuracy_score, average_precision_score, f1_score, precision_score, recall_score, roc_auc_score

from app.ml.algorithms import ALGORITHMS, DEFAULT_ALGORITHM, feature_importance

log = logging.getLogger(__name__)
MODEL_VERSION = "risk-1.3"
HORIZON = 3

FEATURES = [
    "overall", "delivery", "quality", "cost", "lead_time",
    "change_1m", "change_3m", "delivery_change_3m", "quality_change_3m", "lead_time_change_3m", "cost_change_3m",
    "late_pos", "failed_inspections", "lt_cv", "invoice_variance_pct", "slope_3m",
]
FEATURE_LABELS = {
    "overall": "Current overall score", "delivery": "Delivery score", "quality": "Quality score", "cost": "Cost score",
    "lead_time": "Lead-time score", "change_1m": "Score change (1 month)", "change_3m": "Score change (3 months)",
    "delivery_change_3m": "Delivery deterioration (3m)", "quality_change_3m": "Quality trend (3m)",
    "lead_time_change_3m": "Lead-time variability trend (3m)", "cost_change_3m": "Cost variance trend (3m)",
    "late_pos": "Late POs in window", "failed_inspections": "Failed inspections in window",
    "lt_cv": "Lead-time coefficient of variation", "invoice_variance_pct": "Invoice variance %",
    "slope_3m": "Score slope (3 months)",
}


def build_feature_frame(snapshots: pd.DataFrame) -> pd.DataFrame:
    """snapshots: vendor_id, period, overall, delivery, quality, cost, lead_time, kpis(dict)."""
    df = snapshots.sort_values(["vendor_id", "period"]).copy()
    g = df.groupby("vendor_id")
    df["change_1m"] = df["overall"] - g["overall"].shift(1)
    df["change_3m"] = df["overall"] - g["overall"].shift(3)
    for comp in ("delivery", "quality", "lead_time", "cost"):
        df[f"{comp}_change_3m"] = df[comp] - g[comp].shift(3)
    df["slope_3m"] = (df["overall"] - g["overall"].shift(2)) / 2
    df["late_pos"] = df["kpis"].map(lambda k: k["delivery"]["late_pos"])
    df["failed_inspections"] = df["kpis"].map(lambda k: k["quality"]["failed_inspections"])
    df["lt_cv"] = df["kpis"].map(lambda k: k["lead_time"]["coefficient_of_variation"])
    df["invoice_variance_pct"] = df["kpis"].map(lambda k: k["cost"]["variance_pct"])
    df["future_overall"] = g["overall"].shift(-HORIZON)
    df["trailing_avg_3m"] = g["overall"].transform(lambda x: x.rolling(3).mean())
    df["future_avg_3m"] = g["overall"].transform(lambda x: x[::-1].rolling(3).mean()[::-1].shift(-1))
    df["period_idx"] = df.groupby("vendor_id").cumcount()
    return df


@dataclass
class ModelReport:
    credible: bool
    model_version: str
    algorithm: str
    label_definition: str
    train_periods: list[str]
    test_periods: list[str]
    n_train: int
    n_test: int
    positive_rate_train: float
    positive_rate_test: float
    metrics: dict[str, float]
    baseline_metrics: dict[str, float]
    feature_importance: list[dict]
    reason: str = ""
    trained_at: str = ""
    shap_available: bool = False
    extra: dict = field(default_factory=dict)


def _metrics(y_true, y_pred, y_prob) -> dict[str, float]:
    out = {
        "accuracy": round(float(accuracy_score(y_true, y_pred)), 3),
        "precision": round(float(precision_score(y_true, y_pred, zero_division=0)), 3),
        "recall": round(float(recall_score(y_true, y_pred, zero_division=0)), 3),
        "f1": round(float(f1_score(y_true, y_pred, zero_division=0)), 3),
    }
    two = len(set(y_true)) > 1
    out["roc_auc"] = round(float(roc_auc_score(y_true, y_prob)), 3) if two else float("nan")
    out["pr_auc"] = round(float(average_precision_score(y_true, y_prob)), 3) if two else float("nan")
    return out


@dataclass
class Dataset:
    labelled: pd.DataFrame
    train: pd.DataFrame
    test: pd.DataFrame
    train_periods: list
    test_periods: list
    label_definition: str


def prepare_dataset(snapshots: pd.DataFrame, drop_points: float = 6.0, test_periods: int = 1) -> Dataset:
    """Labelled feature frame + temporal split (train on earlier periods, test on the latest ``test_periods``)."""
    df = build_feature_frame(snapshots)
    labelled = df.dropna(subset=["future_avg_3m", "change_3m"]).copy()
    labelled["label"] = ((labelled["future_avg_3m"] - labelled["trailing_avg_3m"]) <= -drop_points).astype(int)
    periods = sorted(labelled["period"].unique())
    label_def = (f"Average score over the next {HORIZON} months falls >= {drop_points:g} points "
                 f"below the trailing {HORIZON}-month average")
    k = max(1, min(test_periods, len(periods) - 1)) if len(periods) >= 2 else 0
    test_p, train_p = (periods[-k:], periods[:-k]) if k else ([], periods)
    return Dataset(labelled, labelled[labelled["period"].isin(train_p)], labelled[labelled["period"].isin(test_p)],
                   list(train_p), list(test_p), label_def)


def pos_weight(y) -> float:
    pos = float(np.sum(y))
    return (len(y) - pos) / pos if pos else 1.0


class RiskModel:
    def __init__(self, drop_points: float = 6.0, algorithm: str = DEFAULT_ALGORITHM, params: dict | None = None):
        self.drop_points = drop_points
        self.algorithm = ALGORITHMS.get(algorithm, ALGORITHMS[DEFAULT_ALGORITHM])
        self.params = self.algorithm.resolve(params)
        self.model = None
        self.report: ModelReport | None = None
        self._explainer = None

    def _fit(self, X, y):
        m = self.algorithm.build(self.params, pos_weight(y))
        m.fit(X, y)
        return m

    # -------------------------------------------------------------- training
    def train(self, snapshots: pd.DataFrame) -> ModelReport:
        ds = prepare_dataset(snapshots, self.drop_points)
        algo_name = self.algorithm.label
        tp, ep = [str(p)[:10] for p in ds.train_periods], [str(p)[:10] for p in ds.test_periods]
        if not ds.test_periods:
            self.report = ModelReport(False, MODEL_VERSION, algo_name, ds.label_definition, [], [], 0, 0, 0, 0, {}, {}, [],
                                      reason="Not enough scored history for a temporal train/test split.")
            return self.report
        tr, te = ds.train, ds.test
        Xtr, ytr, Xte, yte = tr[FEATURES].fillna(0).values, tr["label"].values, te[FEATURES].fillna(0).values, te["label"].values
        if len(set(ytr)) < 2 or len(set(yte)) < 2:
            self.model = None
            self.report = ModelReport(False, MODEL_VERSION, algo_name, ds.label_definition, tp, ep, int(len(tr)), int(len(te)),
                                      round(float(ytr.mean()), 3), round(float(yte.mean()), 3), {}, {}, [],
                                      reason="No observed deteriorations in the history - labels are single-class, so no model is trained.")
            return self.report

        # No-skill reference: a random ranking (ROC-AUC 0.5; PR-AUC = share of vendors that declined).
        baseline = {"roc_auc": 0.5, "pr_auc": round(float(yte.mean()), 4)}

        model = self._fit(Xtr, ytr)
        prob = model.predict_proba(Xte)[:, 1]
        metrics = _metrics(yte, (prob >= 0.5).astype(int), prob)
        imp = feature_importance(model, self.algorithm, FEATURES)
        total = sum(imp) or 1.0
        importance = sorted([{"feature": f, "label": FEATURE_LABELS[f], "importance": round(v / total, 4)} for f, v in zip(FEATURES, imp)],
                            key=lambda d: -d["importance"])
        n_pos = int(ytr.sum())
        reason, credible = "", True
        if n_pos < 15 or int(yte.sum()) < 5:
            credible, reason = False, f"Too few observed deteriorations to learn from (train positives={n_pos}, test positives={int(yte.sum())})."
        elif not (metrics["roc_auc"] >= 0.65):
            credible, reason = False, f"Held-out ROC-AUC {metrics['roc_auc']} is below the 0.65 credibility bar."
        self.model = None
        self.report = ModelReport(
            credible=credible, model_version=MODEL_VERSION, algorithm=algo_name, label_definition=ds.label_definition,
            train_periods=tp, test_periods=ep, n_train=int(len(tr)), n_test=int(len(te)),
            positive_rate_train=round(float(ytr.mean()), 3), positive_rate_test=round(float(yte.mean()), 3),
            metrics=metrics, baseline_metrics=baseline, feature_importance=importance, reason=reason,
            trained_at=date.today().isoformat(), extra={"algorithm_key": self.algorithm.key, "params": self.params},
        )
        if credible:
            # Refit on all labelled history for scoring the current period.
            lab = ds.labelled
            self.model = self._fit(lab[FEATURES].fillna(0).values, lab["label"].values)
            if self.algorithm.tree:
                try:
                    import shap
                    self._explainer = shap.TreeExplainer(self.model)
                    self.report.shap_available = True
                except Exception as exc:  # pragma: no cover - environment dependent
                    log.warning("SHAP unavailable, using global importances: %s", exc)
        return self.report

    # -------------------------------------------------------------- inference
    def predict(self, features: pd.DataFrame) -> pd.DataFrame:
        """features: rows from build_feature_frame for the period to score."""
        X = features[FEATURES].fillna(0).values
        out = features[["vendor_id"]].copy()
        if self.model is None:
            out["risk_probability"] = np.nan
            out["drivers"] = [[] for _ in range(len(out))]
            return out
        out["risk_probability"] = self.model.predict_proba(X)[:, 1].round(4)
        contrib = None
        method = "importance"
        if self._explainer is not None:
            sv = self._explainer.shap_values(X)
            contrib = sv[1] if isinstance(sv, list) else sv
            if getattr(contrib, "ndim", 2) == 3:  # shape (n, features, classes)
                contrib = contrib[:, :, 1]
            method = "shap"
        if contrib is not None:
            drivers = []
            for i in range(len(X)):
                pairs = sorted(zip(FEATURES, contrib[i], X[i]), key=lambda t: -abs(t[1]))[:4]
                drivers.append([{"feature": f, "label": FEATURE_LABELS[f], "value": round(float(v), 3),
                                 "contribution": round(float(c), 4), "method": method} for f, c, v in pairs])
        else:
            imp = dict(zip(FEATURES, feature_importance(self.model, self.algorithm, FEATURES)))
            drivers = [[{"feature": f, "label": FEATURE_LABELS[f], "value": round(float(v), 3),
                         "contribution": round(float(imp[f]), 4), "method": method}
                        for f, v in sorted(zip(FEATURES, row), key=lambda t: -imp[t[0]])[:4]] for row in X]
        out["drivers"] = drivers
        return out


# ---------------------------------------------------------------------------
# Anomaly detection (label-free)
# ---------------------------------------------------------------------------
ANOMALY_FEATURES = ["delivery", "quality", "cost", "lead_time", "change_1m", "delivery_change_3m",
                    "quality_change_3m", "lead_time_change_3m", "cost_change_3m"]


def detect_anomalies(current: pd.DataFrame, contamination: float = 0.05, n_estimators: int = 200) -> pd.DataFrame:
    """IsolationForest over the current period + robust z-scores to name the anomalous component."""
    X = current[ANOMALY_FEATURES].fillna(0)
    iso = IsolationForest(n_estimators=n_estimators, contamination=contamination, random_state=11)
    iso.fit(X.values)
    raw = -iso.score_samples(X.values)  # higher = more anomalous
    out = current[["vendor_id"]].copy()
    out["anomaly_score"] = np.round((raw - raw.min()) / (raw.max() - raw.min() + 1e-9), 4)
    out["is_anomaly"] = iso.predict(X.values) == -1
    reasons = []
    med, mad = X.median(), (X - X.median()).abs().median() + 1e-6
    for _, row in X.iterrows():
        z = ((row - med) / (1.4826 * mad)).sort_values()
        rs = [{"feature": f, "label": FEATURE_LABELS.get(f, f), "robust_z": round(float(v), 2), "value": round(float(row[f]), 2)}
              for f, v in z.items() if v <= -3][:3]
        reasons.append(rs)
    out["anomaly_reasons"] = reasons
    return out


def save_report(report: ModelReport, model_dir: str) -> None:
    Path(model_dir).mkdir(parents=True, exist_ok=True)
    (Path(model_dir) / "risk_model_report.json").write_text(json.dumps(report.__dict__, indent=2, default=str))
