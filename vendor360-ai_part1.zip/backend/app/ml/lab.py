"""Model Lab evaluation engine.

Every candidate is judged the same way:

* **temporal hold-out** - train on earlier score periods, test on the latest period(s);
  no vendor-period from the future ever leaks into training;
* **rolling-origin validation** - re-train on periods [0..i) and test on period i for every
  i, to show how *stable* the model is, not just one lucky split;
* the full metric set at the 0.5 threshold and at the F1-optimal threshold, plus ROC,
  precision-recall and calibration curves, confusion matrices, lift and train-vs-test gap.

Nothing here is tuned on the test period: thresholds are reported, not selected for metrics.
"""
from __future__ import annotations

import time

import numpy as np
from sklearn.calibration import calibration_curve
from sklearn.metrics import (
    accuracy_score, average_precision_score, balanced_accuracy_score, brier_score_loss, confusion_matrix, f1_score, log_loss,
    matthews_corrcoef, precision_recall_curve, precision_score, recall_score, roc_auc_score, roc_curve,
)

from app.ml.algorithms import ALGORITHMS, feature_importance
from app.ml.risk_model import FEATURE_LABELS, FEATURES, Dataset, pos_weight


def _r(v: float, n: int = 4) -> float | None:
    return None if v is None or (isinstance(v, float) and np.isnan(v)) else round(float(v), n)


def _thin(xs, ys, n: int = 60) -> list[dict]:
    """Down-sample a curve to <= n points (always keeping the end points)."""
    idx = np.unique(np.linspace(0, len(xs) - 1, min(n, len(xs))).astype(int))
    return [{"x": _r(xs[i]), "y": _r(ys[i])} for i in idx]


def _threshold_metrics(y, prob, t: float) -> dict:
    pred = (prob >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"threshold": _r(t, 3), "accuracy": _r(accuracy_score(y, pred)), "precision": _r(precision_score(y, pred, zero_division=0)),
            "recall": _r(recall_score(y, pred, zero_division=0)), "f1": _r(f1_score(y, pred, zero_division=0)),
            "balanced_accuracy": _r(balanced_accuracy_score(y, pred)), "mcc": _r(matthews_corrcoef(y, pred)) if len(set(pred)) > 1 else 0.0,
            "confusion": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}}


def evaluate(algorithm_key: str, params: dict | None, ds: Dataset) -> dict:
    algo = ALGORITHMS[algorithm_key]
    p = algo.resolve(params)
    X = lambda d: d[FEATURES].fillna(0).values  # noqa: E731
    Xtr, ytr, Xte, yte = X(ds.train), ds.train["label"].values, X(ds.test), ds.test["label"].values
    if len(set(ytr)) < 2 or len(set(yte)) < 2:
        return {"algorithm": algorithm_key, "params": p, "error": "single-class labels in train or test split", "credible": False}

    t0 = time.perf_counter()
    model = algo.build(p, pos_weight(ytr))
    model.fit(Xtr, ytr)
    train_seconds = time.perf_counter() - t0
    prob = model.predict_proba(Xte)[:, 1]
    prob_tr = model.predict_proba(Xtr)[:, 1]

    # thresholds
    at_half = _threshold_metrics(yte, prob, 0.5)
    prec, rec, thr = precision_recall_curve(yte, prob)
    f1s = np.where(prec[:-1] + rec[:-1] > 0, 2 * prec[:-1] * rec[:-1] / (prec[:-1] + rec[:-1] + 1e-12), 0)
    best_t = float(thr[int(np.argmax(f1s))]) if len(thr) else 0.5
    at_best = _threshold_metrics(yte, prob, best_t)

    # ranking quality
    k = max(1, int(round(0.1 * len(yte))))
    top = np.argsort(-prob)[:k]
    base_rate = float(yte.mean())
    precision_top10 = float(yte[top].mean())
    metrics = {
        "roc_auc": _r(roc_auc_score(yte, prob)), "pr_auc": _r(average_precision_score(yte, prob)),
        "brier": _r(brier_score_loss(yte, prob)), "log_loss": _r(log_loss(yte, np.clip(prob, 1e-6, 1 - 1e-6))),
        "train_roc_auc": _r(roc_auc_score(ytr, prob_tr)),
        "precision_top10pct": _r(precision_top10), "lift_top10pct": _r(precision_top10 / base_rate if base_rate else 0, 2),
        "base_rate": _r(base_rate), **{k2: v for k2, v in at_half.items() if k2 != "confusion"},
    }
    metrics["overfit_gap"] = _r(metrics["train_roc_auc"] - metrics["roc_auc"])

    # rolling-origin validation over all labelled periods
    periods = sorted(ds.labelled["period"].unique())
    folds = []
    for i in range(1, len(periods)):
        tr_f, te_f = ds.labelled[ds.labelled["period"].isin(periods[:i])], ds.labelled[ds.labelled["period"] == periods[i]]
        if len(set(tr_f["label"])) < 2 or len(set(te_f["label"])) < 2:
            continue
        m = algo.build(p, pos_weight(tr_f["label"].values))
        m.fit(X(tr_f), tr_f["label"].values)
        pf = m.predict_proba(X(te_f))[:, 1]
        folds.append({"test_period": str(periods[i])[:10], "train_periods": i, "n_test": int(len(te_f)),
                      "roc_auc": _r(roc_auc_score(te_f["label"], pf)), "pr_auc": _r(average_precision_score(te_f["label"], pf))})
    aucs = [f["roc_auc"] for f in folds]
    metrics["cv_roc_auc_mean"] = _r(float(np.mean(aucs))) if aucs else None
    metrics["cv_roc_auc_std"] = _r(float(np.std(aucs))) if aucs else None

    fpr, tpr, _ = roc_curve(yte, prob)
    frac_pos, mean_pred = calibration_curve(yte, prob, n_bins=8, strategy="quantile")
    imp = feature_importance(model, algo, FEATURES)
    total = sum(imp) or 1.0
    importance = sorted([{"feature": f, "label": FEATURE_LABELS[f], "importance": _r(v / total)} for f, v in zip(FEATURES, imp)],
                        key=lambda d: -d["importance"])

    n_pos_tr, n_pos_te = int(ytr.sum()), int(yte.sum())
    reason = ""
    if n_pos_tr < 15 or n_pos_te < 5:
        reason = f"Too few observed deteriorations (train positives={n_pos_tr}, test positives={n_pos_te})."
    elif not (metrics["roc_auc"] >= 0.65):
        reason = f"Held-out ROC-AUC {metrics['roc_auc']} is below the 0.65 credibility bar."
    return {
        "algorithm": algorithm_key, "algorithm_label": algo.label, "params": p, "metrics": metrics,
        "curves": {"roc": _thin(fpr, tpr), "pr": _thin(rec[::-1], prec[::-1]),
                   "calibration": [{"x": _r(a), "y": _r(b)} for a, b in zip(mean_pred, frac_pos)],
                   "confusion_at_0_5": at_half["confusion"], "best_threshold": {k2: v for k2, v in at_best.items()},
                   "folds": folds},
        "importance": importance, "credible": reason == "", "credibility_reason": reason,
        "train_seconds": round(train_seconds, 3),
    }


def dataset_summary(ds: Dataset) -> dict:
    ytr, yte = ds.train["label"], ds.test["label"]
    by_period = (ds.labelled.groupby("period")["label"].agg(["count", "sum"]).reset_index())
    return {
        "label_definition": ds.label_definition, "features": [{"name": f, "label": FEATURE_LABELS[f]} for f in FEATURES],
        "train_periods": [str(p)[:10] for p in ds.train_periods], "test_periods": [str(p)[:10] for p in ds.test_periods],
        "n_train": int(len(ds.train)), "n_test": int(len(ds.test)),
        "positives_train": int(ytr.sum()), "positives_test": int(yte.sum()),
        "positive_rate_train": round(float(ytr.mean()), 4) if len(ytr) else 0, "positive_rate_test": round(float(yte.mean()), 4) if len(yte) else 0,
        "per_period": [{"period": str(r["period"])[:10], "rows": int(r["count"]), "positives": int(r["sum"])} for _, r in by_period.iterrows()],
        "split": "temporal hold-out (train on earlier periods, test on the latest) + rolling-origin validation",
    }
