"""Authentication + role-based access control.

Modes (``AUTH_MODE``):

* ``login``   (default) - username/password -> HMAC-signed bearer token (``Authorization: Bearer ...``).
                          Three demo personas: **business** (buying lead), **staff** (sourcing analyst), **admin**.
* ``api_key`` - ``X-API-Key`` must match one of ``API_KEYS`` (service-to-service).
* ``demo``    - no login; every caller is the admin persona (local experiments only).

Passwords are stored as PBKDF2-SHA256 hashes. Tokens are stateless (HMAC-SHA256 over
user, role and expiry) so no session store is needed. Swap ``authenticate`` for an
OIDC validator (e.g. Entra ID) without touching any route.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import threading
import time
from dataclasses import dataclass, field

from fastapi import Depends, Header, HTTPException, Request, status

from app.config import get_settings

ROLE_PERMISSIONS: dict[str, set[str]] = {
    "business": {"read", "copilot"},
    "staff": {"read", "copilot", "audit"},
    "admin": {"read", "copilot", "audit", "approve", "configure", "seed"},
}
ROLE_LABELS = {
    "business": "Business User - Buying & Merchandising",
    "staff": "Staff - Sourcing Analyst",
    "admin": "Admin - Procurement Administrator",
}
PERMISSION_LABELS = {
    "read": "See dashboards, vendors and reports",
    "copilot": "Ask the AI assistant",
    "audit": "See the approvals queue and audit log",
    "approve": "Approve or reject recommended actions",
    "configure": "Change settings, AI safety rules and risk prediction models",
    "seed": "Reload the demo data",
}
# Menu items each role sees (keys match the frontend NAV). Hidden pages are also blocked by the API.
ROLE_MENUS: dict[str, list[str]] = {
    "business": ["dashboard", "vendors", "vendor360", "insights", "compare", "assistant", "alternatives", "policies", "risk_alerts"],
    "staff": ["dashboard", "vendors", "vendor360", "insights", "compare", "assistant", "alternatives", "policies", "risk_alerts",
              "approvals", "trust"],
    "admin": ["dashboard", "vendors", "vendor360", "insights", "compare", "assistant", "alternatives", "policies", "risk_alerts",
              "approvals", "trust", "safety", "models", "settings"],
}


@dataclass
class Principal:
    user: str
    role: str = "admin"
    display_name: str = ""
    title: str = ""
    auth_mode: str = "login"
    roles: list[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.roles:
            self.roles = [self.role]

    @property
    def permissions(self) -> set[str]:
        out: set[str] = set()
        for r in self.roles:
            out |= ROLE_PERMISSIONS.get(r, set())
        return out

    def public(self) -> dict:
        return {"username": self.user, "role": self.role, "role_label": ROLE_LABELS.get(self.role, self.role),
                "display_name": self.display_name, "title": self.title, "permissions": sorted(self.permissions),
                "menus": ROLE_MENUS.get(self.role, ROLE_MENUS["business"]), "auth_mode": self.auth_mode}


# ---------------------------------------------------------------- password hashing
def hash_password(password: str, salt: bytes | None = None, iterations: int = 120_000) -> str:
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    return f"pbkdf2${iterations}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    _, it, salt, digest = stored.split("$")
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(it))
    return hmac.compare_digest(dk.hex(), digest)


# ---------------------------------------------------------------- demo user directory
@dataclass(frozen=True)
class User:
    username: str
    display_name: str
    title: str
    role: str
    password_hash: str


_users: dict[str, User] | None = None
_users_lock = threading.Lock()


def users() -> dict[str, User]:
    """Three demo personas. Passwords come from env (DEMO_BUSINESS_PASSWORD / DEMO_STAFF_PASSWORD / DEMO_ADMIN_PASSWORD)."""
    global _users
    with _users_lock:
        if _users is None:
            s = get_settings()
            _users = {
                "business": User("business", "Alex Morgan", "Head of Buying - Womenswear", "business", hash_password(s.demo_business_password)),
                "staff": User("staff", "Sam Patel", "Sourcing Analyst - Denim & Menswear", "staff", hash_password(s.demo_staff_password)),
                "admin": User("admin", "Jordan Lee", "Procurement Administrator", "admin", hash_password(s.demo_admin_password)),
            }
        return _users


def reset_users() -> None:
    global _users
    _users = None


# ---------------------------------------------------------------- tokens
def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _secret() -> bytes:
    return get_settings().auth_secret.encode()


def issue_token(u: User) -> tuple[str, int]:
    exp = int(time.time()) + get_settings().token_ttl_minutes * 60
    payload = _b64(json.dumps({"sub": u.username, "role": u.role, "exp": exp}, separators=(",", ":")).encode())
    sig = _b64(hmac.new(_secret(), payload.encode(), hashlib.sha256).digest())
    return f"{payload}.{sig}", exp


def verify_token(token: str) -> dict | None:
    try:
        payload, sig = token.split(".")
        good = _b64(hmac.new(_secret(), payload.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, good):
            return None
        data = json.loads(_unb64(payload))
        return data if data.get("exp", 0) > time.time() else None
    except Exception:
        return None


# ---------------------------------------------------------------- login with lockout
_failures: dict[str, list[float]] = {}
LOCKOUT_ATTEMPTS, LOCKOUT_WINDOW = 5, 300


class LoginError(Exception):
    def __init__(self, msg: str, locked: bool = False):
        super().__init__(msg)
        self.locked = locked


def login(username: str, password: str) -> tuple[Principal, str, int]:
    key = username.strip().lower()
    now = time.time()
    recent = [t for t in _failures.get(key, []) if now - t < LOCKOUT_WINDOW]
    if len(recent) >= LOCKOUT_ATTEMPTS:
        raise LoginError("Too many failed attempts - account locked for 5 minutes.", locked=True)
    u = users().get(key)
    if not u or not verify_password(password, u.password_hash):
        _failures[key] = recent + [now]
        raise LoginError("Invalid username or password.")
    _failures.pop(key, None)
    token, exp = issue_token(u)
    return _principal(u), token, exp


def _principal(u: User, mode: str = "login") -> Principal:
    return Principal(user=u.username, role=u.role, display_name=u.display_name, title=u.title, auth_mode=mode)


# ---------------------------------------------------------------- FastAPI dependencies
def authenticate(authorization: str | None = Header(default=None), x_api_key: str | None = Header(default=None, alias="X-API-Key")) -> Principal:
    s = get_settings()
    if s.auth_mode == "api_key":
        if not x_api_key or not any(hmac.compare_digest(x_api_key, k) for k in s.api_key_list):
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Missing or invalid API key")
        return Principal(user="api-client", role="admin", display_name="API client", auth_mode="api_key")
    if s.auth_mode == "demo":
        return _principal(users()["admin"], mode="demo")
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Sign in required", headers={"WWW-Authenticate": "Bearer"})
    data = verify_token(authorization.split(" ", 1)[1].strip())
    u = users().get(data["sub"]) if data else None
    if not u:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session expired or invalid - please sign in again",
                            headers={"WWW-Authenticate": "Bearer"})
    return _principal(u)


def require(permission: str):
    def dep(request: Request, p: Principal = Depends(authenticate)) -> Principal:
        if permission not in p.permissions:
            from app.governance import guardrails
            guardrails.record_access_denied(p, permission, f"{request.method} {request.url.path}")
            raise HTTPException(status.HTTP_403_FORBIDDEN,
                                f"Your role ({ROLE_LABELS.get(p.role, p.role)}) does not have the '{permission}' permission.")
        return p
    return dep
