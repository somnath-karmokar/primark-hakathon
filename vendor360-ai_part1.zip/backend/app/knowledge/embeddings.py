"""Embedding provider abstraction: azure | openai | local.

``local`` uses Chroma's on-device ONNX all-MiniLM-L6-v2 model. If that model
cannot be loaded (e.g. no network to fetch it on first run) a deterministic
hashing embedder is used and reported as such - retrieval still works, with
lower semantic quality.
"""
from __future__ import annotations

import hashlib
import logging
import math
import re
from functools import lru_cache

from app.config import get_settings

log = logging.getLogger(__name__)
TOKEN = re.compile(r"[a-z0-9][a-z0-9\-\.]*")


class HashingEmbedder:
    name = "local-hashing-384"
    dim = 384

    def embed(self, texts: list[str]) -> list[list[float]]:
        out = []
        for t in texts:
            vec = [0.0] * self.dim
            toks = TOKEN.findall(t.lower())
            grams = toks + [f"{a} {b}" for a, b in zip(toks, toks[1:])]
            for g in grams:
                h = int(hashlib.md5(g.encode()).hexdigest(), 16)
                vec[h % self.dim] += 1.0 if (h >> 8) & 1 else -1.0
            n = math.sqrt(sum(v * v for v in vec)) or 1.0
            out.append([v / n for v in vec])
        return out


class OnnxMiniLMEmbedder:
    name = "local-onnx-all-MiniLM-L6-v2"

    def __init__(self):
        from chromadb.utils.embedding_functions import ONNXMiniLM_L6_V2
        self._fn = ONNXMiniLM_L6_V2()
        self._fn(["warm up"])  # forces model download/load now so failures surface here

    def embed(self, texts: list[str]) -> list[list[float]]:
        return [list(map(float, v)) for v in self._fn(texts)]


class LangChainEmbedder:
    def __init__(self, provider: str):
        s = get_settings()
        if provider == "azure":
            from langchain_openai import AzureOpenAIEmbeddings
            self._e = AzureOpenAIEmbeddings(azure_endpoint=s.azure_openai_endpoint, api_key=s.azure_openai_api_key,
                                            api_version=s.azure_openai_api_version,
                                            azure_deployment=s.azure_openai_embedding_deployment)
            self.name = f"azure:{s.azure_openai_embedding_deployment}"
        else:
            from langchain_openai import OpenAIEmbeddings
            self._e = OpenAIEmbeddings(api_key=s.openai_api_key, model=s.openai_embedding_model)
            self.name = f"openai:{s.openai_embedding_model}"

    def embed(self, texts: list[str]) -> list[list[float]]:
        return self._e.embed_documents(texts)


@lru_cache
def get_embedder():
    s = get_settings()
    provider = s.embedding_provider.lower()
    if provider == "azure" and s.azure_openai_api_key and s.azure_openai_embedding_deployment:
        return LangChainEmbedder("azure")
    if provider == "openai" and s.openai_api_key:
        return LangChainEmbedder("openai")
    try:
        return OnnxMiniLMEmbedder()
    except Exception as exc:
        log.warning("ONNX MiniLM unavailable (%s); using hashing embedder", type(exc).__name__)
        return HashingEmbedder()
