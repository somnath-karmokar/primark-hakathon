"""ChromaDB knowledge base: ingestion pipeline + filtered hybrid retrieval.

Pipeline: documents -> load -> clean -> chunk -> metadata -> embeddings -> ChromaDB

Only policy / SLA / contract / guideline documents are embedded. Transactional
records are never embedded (they live in PostgreSQL).
"""
from __future__ import annotations

import hashlib
import logging
import re
import threading
from dataclasses import dataclass
from pathlib import Path

from app.config import get_settings
from app.knowledge.embeddings import get_embedder
from app.services.cache import retrieval_cache, stable_key

log = logging.getLogger(__name__)
CLAUSE = re.compile(r"\b([A-Z]{1,4}-\d+(?:\.\d+)?)\b")
_lock = threading.Lock()
_collection = None
_policy_version = "unindexed"


@dataclass
class Chunk:
    id: str
    text: str
    metadata: dict


# ------------------------------------------------------------------ load/clean
def parse_document(path: Path) -> tuple[dict, str]:
    raw = path.read_text(encoding="utf-8")
    meta: dict = {}
    body = raw
    if raw.startswith("---"):
        _, fm, body = raw.split("---", 2)
        for line in fm.strip().splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip().strip('"')
    meta.setdefault("document_id", path.stem.upper())
    meta.setdefault("title", path.stem.replace("_", " ").title())
    meta["source"] = meta.get("source", path.name)
    meta["file"] = path.name
    return meta, clean(body)


def clean(text: str) -> str:
    text = text.replace("\r\n", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


# ------------------------------------------------------------------ chunk
def chunk_document(meta: dict, body: str, max_chars: int = 900, overlap: int = 120) -> list[Chunk]:
    """Section-aware chunking: split on '## ' headings, then by size with overlap."""
    sections: list[tuple[str, str]] = []
    current_title, buf = meta.get("title", ""), []
    for line in body.splitlines():
        if line.startswith("## ") or line.startswith("### "):
            if buf and "".join(buf).strip():
                sections.append((current_title, "\n".join(buf).strip()))
            current_title, buf = line.lstrip("#").strip(), []
        elif line.startswith("# "):
            continue
        else:
            buf.append(line)
    if buf and "".join(buf).strip():
        sections.append((current_title, "\n".join(buf).strip()))

    chunks: list[Chunk] = []
    for title, text in sections:
        clause = CLAUSE.search(title)
        pieces = [text] if len(text) <= max_chars else [text[i:i + max_chars] for i in range(0, len(text), max_chars - overlap)]
        for n, piece in enumerate(pieces):
            content = f"{meta['title']} - {title}\n{piece}"
            cid = f"{meta['document_id']}::{hashlib.sha1((title + str(n)).encode()).hexdigest()[:10]}"
            chunks.append(Chunk(cid, content, {
                "document_id": meta["document_id"], "title": meta["title"], "document_type": meta.get("document_type", "policy"),
                "category": meta.get("category", "all"), "policy_version": meta.get("policy_version", "1.0"),
                "effective_date": meta.get("effective_date", ""), "source": meta["source"], "file": meta["file"],
                "section": title, "clause": clause.group(1) if clause else "", "chunk_index": n,
            }))
    return chunks


# ------------------------------------------------------------------ store
def _get_collection():
    global _collection
    with _lock:
        if _collection is None:
            import chromadb
            s = get_settings()
            Path(s.chroma_path).mkdir(parents=True, exist_ok=True)
            client = chromadb.PersistentClient(path=s.chroma_path)
            _collection = client.get_or_create_collection(s.chroma_collection, metadata={"hnsw:space": "cosine"})
        return _collection


def reset_collection() -> None:
    global _collection
    with _lock:
        _collection = None


def ingest(knowledge_dir: str | None = None) -> dict:
    """Idempotent: upserts every chunk by stable id and deletes chunks that no longer exist."""
    global _policy_version
    base = Path(knowledge_dir or get_settings().knowledge_dir)
    files = sorted(base.glob("*.md"))
    if not files:
        raise FileNotFoundError(f"No knowledge documents in {base}")
    chunks: list[Chunk] = []
    docs = []
    for f in files:
        meta, body = parse_document(f)
        cs = chunk_document(meta, body)
        chunks += cs
        docs.append({"document_id": meta["document_id"], "title": meta["title"], "chunks": len(cs),
                     "policy_version": meta.get("policy_version"), "document_type": meta.get("document_type")})
    embedder = get_embedder()
    vectors = embedder.embed([c.text for c in chunks])
    col = _get_collection()
    existing = set(col.get(include=[])["ids"])
    new_ids = {c.id for c in chunks}
    stale = list(existing - new_ids)
    if stale:
        col.delete(ids=stale)
    col.upsert(ids=[c.id for c in chunks], documents=[c.text for c in chunks], embeddings=vectors,
               metadatas=[{**c.metadata, "embedding_model": embedder.name} for c in chunks])
    _policy_version = policy_version_from(docs)
    retrieval_cache.invalidate(lambda t: t.get("kind") == "vector")
    return {"documents": docs, "chunks": len(chunks), "deleted_stale": len(stale), "embedding_model": embedder.name,
            "policy_version": _policy_version}


def policy_version_from(docs: list[dict]) -> str:
    raw = ";".join(f"{d['document_id']}@{d['policy_version']}" for d in sorted(docs, key=lambda d: d["document_id"]))
    return "pv-" + hashlib.sha1(raw.encode()).hexdigest()[:8]


def policy_version() -> str:
    global _policy_version
    if _policy_version == "unindexed":
        try:
            metas = _get_collection().get(include=["metadatas"])["metadatas"] or []
            docs = {m["document_id"]: {"document_id": m["document_id"], "policy_version": m["policy_version"]} for m in metas}
            if docs:
                _policy_version = policy_version_from(list(docs.values()))
        except Exception:
            pass
    return _policy_version


def count() -> int:
    try:
        return _get_collection().count()
    except Exception:
        return 0


# ------------------------------------------------------------------ retrieve
def _where(filters: dict | None) -> dict | None:
    if not filters:
        return None
    clauses = [{k: v} for k, v in filters.items() if v not in (None, "", [])]
    clauses = [{k: {"$in": v}} if isinstance(v, list) else {k: v} for c in clauses for k, v in c.items()]
    if not clauses:
        return None
    return clauses[0] if len(clauses) == 1 else {"$and": clauses}


def search(query: str, k: int = 5, filters: dict | None = None) -> dict:
    """Hybrid retrieval: vector similarity + exact clause-id boost, with metadata filtering."""
    key = stable_key("vector", query.strip().lower(), k, filters, policy_version())

    def run():
        col = _get_collection()
        if col.count() == 0:
            return {"results": [], "embedding_model": None}
        emb = get_embedder()
        res = col.query(query_embeddings=emb.embed([query]), n_results=min(k * 2, col.count()), where=_where(filters),
                        include=["documents", "metadatas", "distances"])
        out = []
        wanted = {c.upper() for c in CLAUSE.findall(query.upper())}
        q_terms = set(re.findall(r"[a-z]{4,}", query.lower()))
        for cid, doc, meta, dist in zip(res["ids"][0], res["documents"][0], res["metadatas"][0], res["distances"][0]):
            sim = 1 - float(dist)
            lexical = len(q_terms & set(re.findall(r"[a-z]{4,}", doc.lower()))) / (len(q_terms) or 1)
            boost = 0.35 if meta.get("clause") and meta["clause"].upper() in wanted else 0.0
            out.append({"id": cid, "text": doc, "metadata": meta, "similarity": round(sim, 4),
                        "score": round(0.75 * sim + 0.25 * lexical + boost, 4)})
        out.sort(key=lambda r: -r["score"])
        return {"results": out[:k], "embedding_model": emb.name}

    val, hit = retrieval_cache.get_or_set(key, run, tags={"kind": "vector"})
    return {**val, "cache_hit": hit, "filters": filters or {}}


def list_documents() -> list[dict]:
    col = _get_collection()
    got = col.get(include=["metadatas"])
    docs: dict[str, dict] = {}
    for m in got["metadatas"] or []:
        d = docs.setdefault(m["document_id"], {k: m.get(k) for k in ("document_id", "title", "document_type", "category",
                                                                     "policy_version", "effective_date", "source", "file")})
        d.setdefault("sections", []).append({"section": m["section"], "clause": m.get("clause", "")})
    return sorted(docs.values(), key=lambda d: d["title"])


def get_document(document_id: str) -> dict | None:
    col = _get_collection()
    got = col.get(where={"document_id": document_id}, include=["documents", "metadatas"])
    if not got["ids"]:
        return None
    items = sorted(zip(got["documents"], got["metadatas"]), key=lambda t: (t[1]["section"], t[1]["chunk_index"]))
    meta = items[0][1]
    path = Path(get_settings().knowledge_dir) / meta["file"]
    body = parse_document(path)[1] if path.exists() else "\n\n".join(d for d, _ in items)
    return {"document_id": document_id, "title": meta["title"], "document_type": meta["document_type"],
            "category": meta["category"], "policy_version": meta["policy_version"], "effective_date": meta["effective_date"],
            "source": meta["source"], "file": meta["file"], "markdown": body,
            "chunks": [{"section": m["section"], "clause": m.get("clause", ""), "text": d} for d, m in items]}
