"""Supervisor intent classification + execution plans.

Deterministic rules first (fast, free, auditable). Only when the rules cannot
place a question does the Supervisor ask the *light* model, and its answer is
constrained to the enum below.
"""
from __future__ import annotations

import re

from pydantic import BaseModel, Field

VENDOR_RE = re.compile(r"\bV\s?-?(\d{4})\b", re.I)

PLANS: dict[str, list[str]] = {
    "vendor_explain": ["performance", "risk", "knowledge"],
    "vendor_recommendation": ["performance", "risk", "knowledge", "recommendation"],
    "alternatives": ["performance", "knowledge", "recommendation"],
    "vendor_sla": ["performance", "knowledge"],
    "vendor_dependency": ["knowledge"],
    "vendor_overview": ["performance", "risk"],
    "portfolio_underperformers": ["performance"],
    "portfolio_deteriorated": ["performance", "risk"],
    "portfolio_segment": ["performance"],
    "portfolio_summary": ["performance"],
    "policy_question": ["knowledge"],
    "out_of_scope": [],
}
VENDOR_INTENTS = {"vendor_explain", "vendor_recommendation", "alternatives", "vendor_sla", "vendor_dependency", "vendor_overview"}

SEGMENTS = [
    (re.compile(r"(strong|good|high)\s+quality.*(weak|poor|bad|late)\s+deliver", re.I), "strong_quality_weak_delivery"),
    (re.compile(r"(low[- ]cost|cheap).*(poor|weak|bad|low)\s+quality", re.I), "low_cost_poor_quality"),
    (re.compile(r"(expensive|premium|high[- ]cost).*(high|good|strong)\s+quality|(high|good|strong)\s+quality.*(expensive|premium)", re.I), "premium_high_quality"),
    (re.compile(r"lead[- ]?time\s+(variab|inconsist|unpredict)|(variable|inconsistent|unpredictable)\s+lead[- ]?time", re.I), "variable_lead_time"),
]


def extract_vendor_id(text: str) -> str | None:
    m = VENDOR_RE.search(text)
    return f"V{m.group(1)}" if m else None


def classify(query: str, has_vendor: bool) -> tuple[str, str | None]:
    q = query.lower()
    for rx, seg in SEGMENTS:
        if rx.search(query):
            return "portfolio_segment", seg
    if re.search(r"polic(y|ies)\s.*\b(say|state|require|allow)|what (does|do) (the|our) .*(policy|standard|guideline)", q):
        return "policy_question", None
    if re.search(r"alternative|replace|backup|substitut|switch (supplier|vendor)|other supplier|best (alternative|supplier)|second source", q):
        return "alternatives", None
    if re.search(r"recommend|what should|which action|next step|suggest|should (we|procurement)|what to do|course of action", q):
        return "vendor_recommendation", None
    if has_vendor and re.search(r"depend|which products|what products|affected (products|categories)|what does .* supply|categories", q):
        return "vendor_dependency", None
    if has_vendor and re.search(r"\bsla\b|service level|contract|terms|target", q):
        return "vendor_sla", None
    if has_vendor and re.search(r"why|explain|cause|causing|reason|driver|underperform|low|declin|deteriorat|drop|worse|problem|issue", q):
        return "vendor_explain", None
    if not has_vendor and re.search(r"deteriorat|declin|worsen|dropped|biggest (fall|drop)|most decline", q):
        return "portfolio_deteriorated", None
    if not has_vendor and re.search(r"underperform|worst|bottom|at[- ]risk|critical|poor(ly)? perform|lowest", q):
        return "portfolio_underperformers", None
    if re.search(r"polic|standard|guideline|what does .* say|\baql\b|escalat|onboard|\bsla\b|service level|contract|clause|approval", q):
        return "policy_question", None
    if has_vendor:
        return "vendor_overview", None
    if re.search(r"how many|overall|portfolio|summary|dashboard|average score|top (vendors|suppliers)|best perform", q):
        return "portfolio_summary", None
    return "out_of_scope", None


class IntentLLM(BaseModel):
    """Constrained output for the light-model fallback classifier."""
    intent: str = Field(description="one of: " + ", ".join(PLANS))
