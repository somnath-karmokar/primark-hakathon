"""AI Procurement Copilot service: input guardrails, session memory, semantic
cache, LangGraph execution and response assembly."""
from __future__ import annotations

import logging
import re
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.agents.compose import followups
from app.agents.graph import build_graph
from app.agents.intent import classify, extract_vendor_id
from app.governance import guardrails
from app.services import finops
from app.config import get_settings
from app.knowledge import store
from app.knowledge.embeddings import get_embedder
from app.llm.gateway import RequestBudget
from app.llm.provider import route
from app.models.entities import Vendor
from app.services import analytics_service, runtime_settings
from app.services.cache import semantic_cache

log = logging.getLogger(__name__)
PRONOUN = re.compile(r"\b(it|its|it's|they|their|them|this (vendor|supplier)|that (vendor|supplier)|the vendor|the supplier)\b", re.I)
DATE_RE = re.compile(r"\b(20\d{2})-(0[1-9]|1[0-2])\b")


class InputRejected(ValueError):
    pass


class SessionStore:
    def __init__(self, max_turns: int = 20):
        self._s: dict[str, dict] = {}
        self._lock = threading.Lock()
        self.max_turns = max_turns

    def get(self, sid: str) -> dict:
        with self._lock:
            return self._s.setdefault(sid, {"last_vendor_id": None, "history": deque(maxlen=self.max_turns)})

    def history(self, sid: str) -> list[dict]:
        return list(self.get(sid)["history"])


sessions = SessionStore()


def _resolve_vendor(db: Session, query: str, session: dict) -> tuple[str | None, list[str]]:
    flags = []
    vid = extract_vendor_id(query)
    if vid:
        if not db.get(Vendor, vid):
            raise InputRejected(f"Unknown vendor id {vid}. Vendor ids look like V1001-V1500.")
        return vid, flags
    # name match (e.g. "Ningbo Bluewave")
    words = [w for w in re.findall(r"[A-Za-z]{4,}", query) if w.lower() not in {"vendor", "supplier", "which", "what", "about", "should", "their", "score"}]
    if words:
        names = analytics_service.vendors_df(db)
        for i in range(len(words) - 1):
            pat = f"{words[i]} {words[i + 1]}".lower()
            hit = names[names["name"].str.lower().str.contains(pat, regex=False)]
            if len(hit) == 1:
                flags.append("vendor_resolved_by_name")
                return hit.iloc[0]["vendor_id"], flags
    # Conversation context only carries into vendor-scoped follow-ups ("what do you recommend?",
    # "find an alternative", "why is it low?") - never into portfolio or policy questions.
    if session.get("last_vendor_id"):
        intent, _ = classify(query, has_vendor=False)
        if intent in ("vendor_recommendation", "alternatives") or PRONOUN.search(query):
            flags.append("vendor_from_conversation_context")
            return session["last_vendor_id"], flags
    return None, flags


def ask(db: Session, query: str, session_id: str | None = None, actor: str = "demo-user", role: str = "admin") -> dict:
    s = get_settings()
    t0 = time.perf_counter()
    request_id = f"req-{uuid.uuid4().hex[:12]}"
    # ---- input guardrails: block, flag, or redact personal data before anything reaches an agent/LLM ----
    gcfg = guardrails.config(db)
    gres = guardrails.check_input(query, gcfg, user=actor)
    guardrails.record(db, actor=actor, role=role, request_id=request_id, triggered=gres["triggered"], verdict=gres["verdict"],
                      question=gres["sanitized_text"])
    if gres["verdict"] == "block":
        db.commit()  # keep the guardrail event even though the request is rejected
        raise InputRejected(guardrails.block_message(gres))
    q = gres["sanitized_text"]
    session_id = session_id or f"ses-{uuid.uuid4().hex[:10]}"
    sess = sessions.get(session_id)
    flags: list[str] = [t["rule"] for t in gres["triggered"]]
    period = analytics_service.latest_period(db)
    m = DATE_RE.search(q)
    if m:
        asked = f"{m.group(1)}-{m.group(2)}"
        if asked not in {p[:7] for p in analytics_service.periods(db)}:
            flags.append(f"requested_period_{asked}_unavailable_using_{period[:7]}")
    vendor_id, vflags = _resolve_vendor(db, q, sess)
    flags += vflags

    # ---- semantic cache (only valid while every version stamp matches) ----
    r = route("executive_synthesis")
    versions = {"data": runtime_settings.data_version(db), "policy": store.policy_version(), "prompt": s.prompt_version,
                "model": r.model_id if r else "deterministic", "vendor_id": vendor_id}
    emb = None
    try:
        emb = get_embedder().embed([q.lower()])[0]
        hit, sim = semantic_cache.lookup(emb, versions)
    except Exception:
        hit, sim = None, 0.0
    if hit is not None:
        resp = {**hit.response, "request_id": request_id, "session_id": session_id,
                "cache": {"semantic_hit": True, "similarity": round(sim, 3), "matched_question": hit.question},
                "latency_ms": int((time.perf_counter() - t0) * 1000)}
        resp["agent_trace"] = [{"agent": "cache", "action": f"semantic cache hit (similarity {sim:.2f}); versions unchanged",
                                "tools": [], "sources": ["semantic-cache"], "status": "ok", "duration_ms": resp["latency_ms"], "detail": ""}] + resp["agent_trace"]
        if resp.get("vendor_id"):
            sess["last_vendor_id"] = resp["vendor_id"]
        resp["cost"] = finops.record(db, request_id=request_id, user=actor, role=role, feature="copilot", calls=[], semantic_hit=True)
        _remember(sess, q, resp)
        return resp

    rt = runtime_settings.get_runtime(db)["agent"]
    budget = RequestBudget(max_llm_calls=rt["max_llm_calls"], token_budget=rt["token_budget_per_request"])
    bstatus = finops.budget_status(db)
    if bstatus["blocking"]:
        budget.blocked_reason = f"monthly AI budget of £{bstatus['monthly_budget_gbp']:.2f} used up - answering from facts only"
        flags.append("finops:monthly_budget_reached")
    init = {"request_id": request_id, "session_id": session_id, "actor": actor, "role": role, "user_query": q, "vendor_id": vendor_id,
            "time_period": period, "started_at": time.perf_counter(), "guardrail_flags": flags, "completed": [],
            "evidence": [], "agent_trace": [], "llm_calls": [], "errors": []}
    limits = {"max_agent_steps": rt["max_agent_steps"], "max_tool_calls": rt["max_tool_calls"]}
    final = build_graph().invoke(init, config={"configurable": {"db": db, "budget": budget, "limits": limits},
                                               "recursion_limit": 4 * rt["max_agent_steps"] + 6})
    resp = assemble(final, session_id, request_id)
    resp["latency_ms"] = int((time.perf_counter() - t0) * 1000)
    resp["cache"] = {"semantic_hit": False, "similarity": round(sim, 3)}
    resp["cost"] = finops.record(db, request_id=request_id, user=actor, role=role, feature="copilot",
                                 calls=final.get("llm_calls", []), jev=(final.get("answer") or {}).get("jev"))
    resp["ai_written"] = resp.get("mode") == "llm"
    resp["budget"] = {"llm_calls": budget.llm_calls, "max_llm_calls": budget.max_llm_calls,
                      "tokens_used": budget.tokens_used, "token_budget": budget.token_budget}
    if emb is not None and final.get("intent") != "out_of_scope" and not final.get("recommendation"):
        # recommendations are never served from cache: each one must be governed and logged
        semantic_cache.store(emb, q, {k: v for k, v in resp.items() if k not in ("request_id", "session_id", "cost")}, versions)
    if final.get("vendor_id"):
        sess["last_vendor_id"] = final["vendor_id"]
    _remember(sess, q, resp)
    return resp


def _remember(sess: dict, q: str, resp: dict) -> None:
    sess["history"].append({"at": datetime.now(timezone.utc).isoformat(), "question": q, "request_id": resp["request_id"],
                            "intent": resp["intent"], "vendor_id": resp["vendor_id"], "answer": resp["answer"],
                            "confidence": resp["confidence"]})


def _metrics(state: dict) -> list[dict]:
    b = state.get("score_breakdown")
    out = []
    if b:
        t = state.get("trend_analysis") or {}
        out += [{"label": "Overall score", "value": b["overall"], "unit": "", "band": b["band"]},
                {"label": "Delivery", "value": b["delivery"], "unit": ""}, {"label": "Quality", "value": b["quality"], "unit": ""},
                {"label": "Cost", "value": b["cost"], "unit": ""}, {"label": "Lead-time", "value": b["lead_time"], "unit": ""},
                {"label": "3-month change", "value": t.get("change_3m"), "unit": "pts"}]
        r = state.get("risk_prediction")
        if r:
            out.append({"label": "Internal risk", "value": r.get("risk_level"), "unit": "",
                        "detail": f"p={r['risk_probability']:.2f}" if r.get("risk_probability") is not None else "statistical"})
    elif state.get("portfolio"):
        p = state["portfolio"]
        out.append({"label": "Vendors matched", "value": p.get("count"), "unit": ""})
        if p.get("kpis"):
            out.append({"label": "Average score", "value": p["kpis"]["avg_score"], "unit": ""})
    return out


def assemble(state: dict, session_id: str, request_id: str) -> dict:
    gov = state.get("governance_result") or {}
    ans = state.get("answer") or {}
    rec = state.get("recommendation")
    evidence = state.get("evidence", [])
    sources = [{"id": c["id"], "document_id": c["document_id"], "title": c["title"], "section": c["section"], "clause": c["clause"],
                "policy_version": c["policy_version"], "score": c["score"], "snippet": c["text"].split("\n", 1)[-1][:400]}
               for c in state.get("vector_context", [])]
    gc = state.get("graph_context") or {}
    return {
        "request_id": request_id, "session_id": session_id, "question": state["user_query"],
        "intent": state.get("intent"), "intent_method": state.get("intent_method"), "vendor_id": state.get("vendor_id"),
        "vendor_name": (state.get("vendor_profile") or {}).get("name"),
        "answer": ans.get("text", ""), "reasoning": ans.get("reasoning", []), "cited_evidence": ans.get("cited_evidence", []),
        "mode": ans.get("mode"), "model": ans.get("model"), "fallback_reason": ans.get("fallback_reason"), "jev": ans.get("jev"),
        "metrics": _metrics(state), "evidence": evidence, "sources": sources,
        "graph_evidence": {"source": (gc.get("relationships") or gc.get("dependency") or {}).get("source"),
                           "relationships": gc.get("relationships"), "dependency": gc.get("dependency")} if gc else None,
        "recommendation": None if not rec else {**rec, "id": gov.get("recommendation_id"), "status":
                                                "pending_approval" if gov.get("requires_approval") else "auto_approved"},
        "portfolio": state.get("portfolio"),
        "confidence": gov.get("confidence", 0.0), "confidence_label": gov.get("confidence_label", "Low"),
        "governance": gov, "agent_trace": state.get("agent_trace", []), "llm_calls": state.get("llm_calls", []),
        "guardrails": state.get("guardrail_flags", []), "errors": state.get("errors", []),
        "suggested_followups": followups(state.get("intent", "out_of_scope"), state.get("vendor_id")),
    }
