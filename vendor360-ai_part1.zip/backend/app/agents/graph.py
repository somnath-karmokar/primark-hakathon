"""LangGraph workflow.

    START -> supervisor -(route)-> performance | risk | knowledge | recommendation -> supervisor ...
                       \\-> synthesize -> governance -> END

The Supervisor owns the plan and loops: every specialist returns to it, it
picks the next agent, and it enforces max steps / timeout before synthesis.
"""
from __future__ import annotations

from functools import lru_cache

from langgraph.graph import END, START, StateGraph

from app.agents import nodes
from app.agents.state import CopilotState


@lru_cache
def build_graph():
    g = StateGraph(CopilotState)
    g.add_node("supervisor", nodes.supervisor)
    g.add_node("performance", nodes.performance_agent)
    g.add_node("risk", nodes.risk_agent)
    g.add_node("knowledge", nodes.knowledge_agent)
    g.add_node("recommendation", nodes.recommendation_agent)
    g.add_node("synthesize", nodes.synthesize)
    g.add_node("governance", nodes.governance_agent)
    g.add_edge(START, "supervisor")
    g.add_conditional_edges("supervisor", nodes.route_next,
                            {"performance": "performance", "risk": "risk", "knowledge": "knowledge",
                             "recommendation": "recommendation", "synthesize": "synthesize"})
    for n in ("performance", "risk", "knowledge", "recommendation"):
        g.add_edge(n, "supervisor")
    g.add_edge("synthesize", "governance")
    g.add_edge("governance", END)
    return g.compile()


def mermaid() -> str:
    return build_graph().get_graph().draw_mermaid()
