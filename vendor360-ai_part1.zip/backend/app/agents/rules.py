"""Deterministic procurement-action rules (Supplier Escalation Policy SEP-2).

The Recommendation Agent decides *what* to recommend here, from scored facts.
The LLM may only phrase the explanation; it can never change the action.
"""
from __future__ import annotations

STAGES = {
    0: ("maintain", "Maintain relationship", "Business as usual; eligible for volume growth if Excellent."),
    1: ("monitor", "Stage 1 - Monitor", "Category Manager monitors monthly (SEP-2 Stage 1)."),
    2: ("corrective_action", "Stage 2 - Corrective Action Request and performance review", "Issue a CAR; supplier responds within 5 working days (SEP-2 Stage 2)."),
    3: ("pip", "Stage 3 - Performance Improvement Plan", "90-day PIP with monthly checkpoints (SEP-2 Stage 3)."),
    4: ("probation_reallocate", "Stage 4 - Probation and volume re-allocation", "Up to 30% of open volume may move to qualified alternatives (SEP-2 Stage 4)."),
}
COMPONENT_ACTIONS = {
    "delivery": "Agree a delivery recovery plan with weekly on-time tracking against the SLA target (DSLA-4).",
    "quality": "Request root-cause analysis and corrective action plan within 10 working days (QS-3).",
    "cost": "Challenge invoice variance and unit price premium in the next negotiation round (CTG-2, CG-6).",
    "lead_time": "Require a capacity plan addressing lead-time variability (DSLA-5).",
}


def decide(score: dict, trend: dict, sla: list[dict], risk: dict | None, drivers: list[dict],
           dependency: dict | None = None) -> dict:
    """Return the recommended stage/action with the facts that triggered it."""
    band = score["band"]
    overall = score["overall"]
    breaches = [s for s in sla if s["status"] == "breached"]
    risk_level = (risk or {}).get("risk_level", "Unknown")
    triggers: list[str] = []

    stage = 0
    if band == "Critical":
        stage = 4; triggers.append(f"Score {overall:.1f} is in the Critical band (SEV-2)")
    elif band == "At Risk":
        stage = 3; triggers.append(f"Score {overall:.1f} is in the At Risk band (SEV-2)")
    if trend.get("is_deteriorating"):
        stage = max(stage, 2)
        triggers.append(f"Score fell {abs(trend['drop_from_peak']):.1f} pts from its 6-month peak of {trend['peak_score']:.1f} (SEV-4)")
    if breaches:
        # A breach alone means monitor; a breach on a Watch-or-worse / deteriorating vendor means CAR (DSLA-4).
        weak = band in ("Watch", "At Risk", "Critical") or trend.get("is_deteriorating")
        stage = max(stage, 2 if weak else 1)
        triggers += [f"SLA breach: {b['metric']} {b['actual']}{b['unit']} vs target {b['operator']} {b['target']}{b['unit']}" for b in breaches]
    if band == "Watch":
        stage = max(stage, 1)
        triggers.append(f"Score {overall:.1f} is in the Watch band (SEV-2)")
    if risk_level == "High":
        stage = max(stage, 2)
        triggers.append("Internal performance risk is High")

    code, title, policy_text = STAGES[stage]
    negative = [d for d in drivers if d["impact"] == "negative"]
    steps = [COMPONENT_ACTIONS[d["component"]] for d in negative[:3]]
    critical_dependency = bool(dependency and any(p.get("is_critical") and p.get("is_primary_source") for p in dependency.get("products", [])))
    needs_backup = stage >= 2
    if needs_backup:
        steps.append("Qualify a backup supplier for affected products (SEP-4.1)" +
                     (" - required: vendor is primary source for critical products (PP-3.4)" if critical_dependency else ""))
    if stage >= 3:
        steps.append("Schedule Category Manager review and confirm PIP milestones (PP-4)")
    if stage == 4:
        steps.append("Prepare re-allocation of up to 30% of open volume to eligible alternatives (SEP-2 Stage 4, SEP-4.3)")
    if stage == 0:
        steps.append("No intervention needed; continue standard review cadence (PP-3.2)")

    refs = ["SEV-2", "SEP-2"]
    if trend.get("is_deteriorating"):
        refs.append("SEV-4")
    if breaches:
        refs.append("DSLA-4")
    if needs_backup:
        refs.append("SEP-4.1")
    refs.append("PP-5")
    return {
        "stage": stage, "action": code, "title": title, "policy_basis": policy_text, "triggers": triggers,
        "steps": steps, "needs_backup_supplier": needs_backup, "critical_dependency": critical_dependency,
        # PP-5 / SEP-5: supplier-facing or volume-changing actions need human approval.
        "requires_approval": stage >= 2,
        "approver": {0: "None", 1: "Category Manager (informational)", 2: "Category Manager", 3: "Category Manager",
                     4: "Head of Sourcing"}[stage],
        "policy_refs": refs,
    }
