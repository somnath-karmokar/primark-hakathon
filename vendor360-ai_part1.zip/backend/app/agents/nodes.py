"""LangGraph nodes: Supervisor, Performance, Risk, Knowledge, Recommendation,
Synthesis and Governance.

Non-serialisable runtime objects (DB session, budgets) arrive through
``config["configurable"]`` - the state itself stays plain, typed data.
"""
from __future__ import annotations

import logging
import time

from langchain_core.runnables import RunnableConfig

from app.agents import compose, rules
from app.agents.intent import PLANS, VENDOR_INTENTS, IntentLLM, classify
from app.config import get_settings
from app.governance import checks as gov
from app.governance import guardrails
from app.governance.audit import audit
from app.llm import gateway
from app.llm.jev import EvidenceItem, compress
from app.models.entities import Recommendation
from app.services import analytics_service as analytics
from app.services import runtime_settings
from app.tools.registry import ToolAccessDenied, ToolContext, ToolLimitExceeded

log = logging.getLogger(__name__)

SEGMENT_LABELS = {
    "strong_quality_weak_delivery": "with strong quality (>= 85) but weak delivery (< 70)",
    "low_cost_poor_quality": "with low cost (cost score >= 90) but poor quality (< 65)",
    "premium_high_quality": "with premium pricing (cost score < 75) and high quality (>= 90)",
    "variable_lead_time": "with acceptable delivery but variable lead times (lead-time score < 65)",
}


def _rt(config: RunnableConfig) -> dict:
    return config["configurable"]


def _ctx(config: RunnableConfig, agent: str) -> ToolContext:
    rt = _rt(config)
    ctx = ToolContext(db=rt["db"], agent=agent, max_calls=rt.get("limits", {}).get("max_tool_calls", get_settings().max_tool_calls))
    return ctx


def _trace(agent: str, action: str, ctx: ToolContext | None, t0: float, status: str = "ok", detail: str = "") -> dict:
    return {"agent": agent, "action": action, "tools": [c["tool"] for c in ctx.log] if ctx else [],
            "sources": sorted({c["source"] for c in ctx.log}) if ctx else [], "status": status,
            "duration_ms": int((time.perf_counter() - t0) * 1000), "detail": detail}


def _ev(id_: str, kind: str, title: str, value, source: str, priority: int = 5, ref: str = "") -> dict:
    return {"id": id_, "kind": kind, "title": title, "value": value, "source": source, "priority": priority, "ref": ref}


# ---------------------------------------------------------------------------
# Supervisor / Planner
# ---------------------------------------------------------------------------
def supervisor(state: dict, config: RunnableConfig) -> dict:
    t0 = time.perf_counter()
    s = get_settings()
    rt = _rt(config)
    if "intent" not in state:
        intent, segment = classify(state["user_query"], has_vendor=bool(state.get("vendor_id")))
        method = "rules"
        if intent == "out_of_scope":
            out, rec = gateway.structured_call("classify", "Classify a procurement question into exactly one intent label.",
                                               f"Labels: {', '.join(PLANS)}\nQuestion: {state['user_query']}", IntentLLM, rt["budget"])
            if out is not None and out.intent in PLANS:
                intent, method = out.intent, f"llm:{rec.model}"
        flags = []
        if intent in VENDOR_INTENTS and not state.get("vendor_id"):
            flags.append("vendor_required_but_missing")
            intent = "out_of_scope"
        plan = PLANS[intent]
        upd = {"intent": intent, "intent_method": method, "segment": segment, "plan": plan, "step_count": 0,
               "guardrail_flags": flags,
               "agent_trace": [{"agent": "supervisor", "action": f"classified intent '{intent}' via {method}; plan: "
                                + (" -> ".join(plan) if plan else "respond directly"), "tools": [], "sources": [],
                                "status": "ok", "duration_ms": int((time.perf_counter() - t0) * 1000),
                                "detail": f"vendor={state.get('vendor_id') or '-'}"}]}
        state = {**state, **upd}
    else:
        upd = {}
    done = set(state.get("completed", []))
    step = state.get("step_count", 0) + 1
    remaining = [a for a in state.get("plan", []) if a not in done]
    elapsed = time.perf_counter() - state.get("started_at", time.perf_counter())
    nxt = remaining[0] if remaining else "synthesize"
    if step > rt.get("limits", {}).get("max_agent_steps", s.max_agent_steps):
        nxt = "synthesize"
        upd.setdefault("guardrail_flags", []).append("max_agent_steps_reached")
    if elapsed > s.agent_timeout_seconds:
        nxt = "synthesize"
        upd.setdefault("guardrail_flags", []).append("agent_timeout")
    return {**upd, "next_agent": nxt, "step_count": step}


def route_next(state: dict) -> str:
    return state["next_agent"]


# ---------------------------------------------------------------------------
# Performance Agent
# ---------------------------------------------------------------------------
def performance_agent(state: dict, config: RunnableConfig) -> dict:
    t0 = time.perf_counter()
    ctx = _ctx(config, "performance")
    intent = state["intent"]
    try:
        if intent.startswith("portfolio"):
            return _portfolio(state, ctx, t0)
        vid = state["vendor_id"]
        sc = ctx.call("calculate_vendor_score", vendor_id=vid)
        if not sc.ok:
            return {"completed": ["performance"], "errors": [sc.error], "agent_trace": [_trace("performance", "score lookup failed", ctx, t0, "error", sc.error)]}
        prof = ctx.call("get_vendor", vendor_id=vid).data
        trend_series = ctx.call("get_vendor_trend", vendor_id=vid).data
        d = sc.data
        b, k, t, bench = d["breakdown"], d["kpis"], d["trend"], d["benchmark"]
        sla = analytics.sla_compliance(prof, k)
        dk, qk, ck, lk = k["delivery"], k["quality"], k["cost"], k["lead_time"]
        ev = [
            _ev("P1", "metric", "Overall score", {"score": b["overall"], "band": b["band"], "period": d["period"],
                                                  "weights": b["weights"], "model": b["model_version"]}, "scoring-engine", 1),
            _ev("P2", "metric", "Delivery performance", {"score": b["delivery"], "on_time_pct": dk["on_time_pct"], "late_pos": dk["late_pos"],
                                                         "total_pos": dk["total_pos"], "avg_delay_days": dk["avg_delay_days"],
                                                         "critical_late_pos": dk["critical_late_pos"]}, "postgres", 2),
            _ev("P3", "metric", "Quality performance", {"score": b["quality"], "defect_rate_pct": qk["defect_rate_pct"],
                                                        "inspection_failure_rate_pct": qk["inspection_failure_rate_pct"],
                                                        "rejection_rate_pct": qk["rejection_rate_pct"], "inspections": qk["inspections"],
                                                        "top_reasons": [r["reason"] for r in qk["top_rejection_reasons"]]}, "postgres", 2),
            _ev("P4", "metric", "Cost performance", {"score": b["cost"], "invoice_variance_pct": ck["variance_pct"],
                                                     "price_vs_benchmark_pct": ck["benchmark_variance_pct"],
                                                     "disputed_invoices": ck["disputed_invoices"], "invoices": ck["invoices"]}, "postgres", 2),
            _ev("P5", "metric", "Lead-time consistency", {"score": b["lead_time"], "avg_promised_days": lk["avg_promised_days"],
                                                          "avg_actual_days": lk["avg_actual_days"], "cv": lk["coefficient_of_variation"],
                                                          "avg_overrun_pct": lk["avg_overrun_pct"]}, "postgres", 2),
            _ev("P6", "trend", "Score trend", {"direction": t["direction"], "change_3m": t["change_3m"], "peak_6m": t["peak_score"],
                                               "drop_from_peak": t["drop_from_peak"], "slope_per_month": t["slope_per_month"],
                                               "history": [round(x["overall"], 1) for x in trend_series[-6:]]}, "postgres", 1),
            _ev("P7", "metric", "Category benchmark", {"category": prof["category"], **bench}, "postgres", 4),
            _ev("P8", "metric", "Score drivers", [{"component": x["label"], "score": x["score"], "change_3m": x["change"],
                                                   "weighted_pts_lost": x["weighted_points_lost"]} for x in d["drivers"]], "scoring-engine", 2),
        ]
        for i, c in enumerate(sla, start=1):
            ev.append(_ev(f"S{i}", "sla", f"SLA check: {c['metric']}", c, "postgres", 2 if c["status"] == "breached" else 5, c["sla_id"]))
        upd = {"vendor_profile": prof, "score_breakdown": b, "performance_metrics": k, "trend_analysis": t,
               "drivers": d["drivers"], "sla_compliance": sla, "evidence": ev, "completed": ["performance"]}
        if not d["data_sufficient"]:
            upd["guardrail_flags"] = ["score_data_insufficient"]
        upd["agent_trace"] = [_trace("performance", f"scored {vid}: {b['overall']:.1f} {b['band']}, trend {t['direction']}", ctx, t0)]
        return upd
    except (ToolAccessDenied, ToolLimitExceeded) as exc:
        return {"completed": ["performance"], "errors": [str(exc)], "guardrail_flags": [type(exc).__name__],
                "agent_trace": [_trace("performance", "guardrail stop", ctx, t0, "blocked", str(exc))]}


def _portfolio(state: dict, ctx: ToolContext, t0: float) -> dict:
    intent = state["intent"]
    if intent == "portfolio_underperformers":
        rows = ctx.call("list_underperformers", limit=25).data
        summary = ctx.call("get_portfolio_summary").data
        port = {"vendors": rows, "count": summary["kpis"]["at_risk"] + summary["kpis"]["critical"], "period": summary["period"]}
    elif intent == "portfolio_deteriorated":
        rows = ctx.call("list_deteriorating", limit=10).data
        summary = ctx.call("get_portfolio_summary").data
        port = {"vendors": rows, "count": summary["kpis"]["deteriorating"], "period": summary["period"]}
    elif intent == "portfolio_segment":
        seg = state.get("segment") or "strong_quality_weak_delivery"
        r = ctx.call("segment_vendors", segment=seg).data
        port = {"vendors": r["vendors"], "count": r["count"], "segment": seg, "segment_label": SEGMENT_LABELS.get(seg, seg)}
    else:
        summary = ctx.call("get_portfolio_summary").data
        rows = analytics.list_vendors(ctx.db, page_size=6)["items"]
        port = {"vendors": rows, "kpis": summary["kpis"], "period": summary["period"], "count": summary["kpis"]["total_vendors"]}
    ev = [_ev("F1", "portfolio", "Portfolio result", {"query": intent, "count": port.get("count"), "period": port.get("period"),
                                                      **({"segment_definition": SEGMENT_LABELS.get(port["segment"])} if port.get("segment") else {}),
                                                      **({"kpis": port["kpis"]} if "kpis" in port else {})}, "postgres", 1)]
    for i, r in enumerate(port["vendors"][:8], start=2):
        ev.append(_ev(f"F{i}", "portfolio", f"Vendor {r['vendor_id']}", {k: r.get(k) for k in
                      ("vendor_id", "name", "overall", "band", "delivery", "quality", "cost", "lead_time", "change_3m", "risk_level", "category")},
                      "postgres", 3))
    return {"portfolio": port, "evidence": ev, "completed": ["performance"],
            "agent_trace": [_trace("performance", f"portfolio query '{intent}': {port.get('count')} vendors", ctx, t0)]}


# ---------------------------------------------------------------------------
# Risk / Trend Agent
# ---------------------------------------------------------------------------
def risk_agent(state: dict, config: RunnableConfig) -> dict:
    t0 = time.perf_counter()
    ctx = _ctx(config, "risk")
    if state["intent"].startswith("portfolio"):
        rows = (state.get("portfolio") or {}).get("vendors", [])
        high = [r["vendor_id"] for r in rows if r.get("risk_level") == "High"]
        ev = [_ev("R1", "risk", "Risk among listed vendors", {"high_risk": high, "listed": len(rows)}, "ml-model", 3)]
        return {"evidence": ev, "completed": ["risk"],
                "agent_trace": [_trace("risk", f"{len(high)} of {len(rows)} listed vendors carry High internal risk", ctx, t0)]}
    vid = state["vendor_id"]
    r = ctx.call("predict_vendor_risk", vendor_id=vid).data
    an = ctx.call("detect_vendor_anomalies", vendor_id=vid).data
    model = r.get("model", {})
    ev = [_ev("R1", "risk", "Internal performance risk", {"level": r["risk_level"], "probability": r.get("risk_probability"),
                                                          "model_credible": model.get("credible"), "horizon": model.get("label_definition"),
                                                          "model_roc_auc": (model.get("metrics") or {}).get("roc_auc"),
                                                          "raised_by_current_signals": next((d["detail"] for d in r.get("drivers", [])
                                                                                             if d.get("type") == "statistical"), None)},
              "ml-model" if model.get("credible") else "statistical", 1)]
    drivers = [d for d in r.get("drivers", []) if d.get("type") in ("model", "trend")][:4]
    if drivers:
        ev.append(_ev("R2", "risk", "Risk drivers", [{"driver": d.get("label"), "value": d.get("value"),
                                                       "contribution": d.get("contribution"), "method": d.get("method", d.get("type"))}
                                                      for d in drivers], "ml-model", 3))
    if an.get("is_anomaly"):
        ev.append(_ev("R3", "risk", "Anomaly detected", {"anomaly_score": an["anomaly_score"],
                                                         "reasons": [x.get("label") for x in an["reasons"]]}, "isolation-forest", 3))
    return {"risk_prediction": r, "risk_drivers": drivers, "evidence": ev, "completed": ["risk"],
            "agent_trace": [_trace("risk", f"internal risk {r['risk_level']}" + (f" (p={r['risk_probability']:.2f})" if r.get("risk_probability") is not None else "")
                                   + ("; anomaly flagged" if an.get("is_anomaly") else ""), ctx, t0)]}


# ---------------------------------------------------------------------------
# Knowledge Agent (hybrid RAG: decides which sources are relevant)
# ---------------------------------------------------------------------------
COMPONENT_QUERIES = {
    "delivery": ("search_supplier_policy", "late delivery SLA breach on-time target corrective action"),
    "quality": ("search_supplier_policy", "defect rate threshold inspection failure corrective action plan"),
    "cost": ("search_contract_knowledge", "invoice variance over-billing price above benchmark"),
    "lead_time": ("search_supplier_policy", "lead-time variability coefficient of variation capacity plan"),
}


POLICY_TOPICS = [
    (("sla", "service level", "on-time", "on time"), "sla"),
    (("aql", "inspection", "defect", "quality standard"), "standard"),
    (("contract", "invoice", "payment", "termination", "renewal"), "contract"),
    (("onboard", "category", "guideline", "denim", "kidswear", "footwear"), "guideline"),
    (("escalat", "evaluation", "score band", "procurement policy", "approval", "alternative", "dual sourcing"), "policy"),
]


def _policy_topic(query: str) -> str | None:
    """Metadata filter chosen from the question topic (None = search everything)."""
    q = query.lower()
    for keys, doc_type in POLICY_TOPICS:
        if any(k in q for k in keys):
            return doc_type
    return None


def knowledge_agent(state: dict, config: RunnableConfig) -> dict:
    t0 = time.perf_counter()
    ctx = _ctx(config, "knowledge")
    intent, vid = state["intent"], state.get("vendor_id")
    searches: list[tuple[str, str, str | None]] = []
    use_graph_rel = use_graph_dep = False
    if intent == "policy_question":
        searches.append(("search_knowledge", state["user_query"], _policy_topic(state["user_query"])))
    elif intent == "vendor_sla":
        use_graph_rel = True
        searches.append(("search_supplier_policy", "SLA tiers on-time delivery target defect rate invoice variance", "sla"))
    elif intent == "vendor_dependency":
        use_graph_dep = use_graph_rel = True
    elif intent == "vendor_explain":
        use_graph_rel = True
        searches.append(("search_procurement_policy", "supplier deterioration score drop bands expected action", "policy"))
        for d in [d for d in (state.get("drivers") or []) if d["impact"] == "negative"][:2]:
            tool, q = COMPONENT_QUERIES[d["component"]]
            searches.append((tool, q, None))
    elif intent == "vendor_recommendation":
        use_graph_dep = True
        searches.append(("search_procurement_policy", "supplier escalation stages corrective action performance improvement plan", "policy"))
        searches.append(("search_procurement_policy", "backup sourcing alternative supplier critical products human approval", "policy"))
    elif intent == "alternatives":
        use_graph_dep = True
        searches.append(("search_procurement_policy", "eligibility of alternative suppliers score risk active", "policy"))
        searches.append(("search_procurement_policy", "dual sourcing critical products volume transfer limits concentration", "policy"))
    prof = state.get("vendor_profile") or {}
    if vid and prof.get("category") and intent in ("vendor_explain", "vendor_recommendation", "alternatives"):
        searches.append(("search_supplier_policy", f"{prof['category']} category sourcing guideline", "guideline"))

    ev, chunks, seen = [], [], set()
    for tool, q, dtype in searches:
        try:
            res = ctx.call(tool, query=q, k=3, document_type=dtype)
        except (ToolAccessDenied, ToolLimitExceeded) as exc:
            return {"completed": ["knowledge"], "errors": [str(exc)], "agent_trace": [_trace("knowledge", "guardrail stop", ctx, t0, "blocked", str(exc))]}
        for r in (res.data or {}).get("results", [])[:2]:
            if r["id"] in seen or r["score"] < 0.25:
                continue
            seen.add(r["id"])
            chunks.append(r)
            body = r["text"].split("\n", 1)[-1].strip()
            ev.append(_ev(f"K{len(chunks)}", "policy", f"{r['title']} - {r['section']}", body, "chromadb", 3 if len(chunks) > 2 else 2,
                          r["clause"] or r["document_id"]))
    graph_ctx: dict = {}
    if vid and use_graph_rel:
        rel = ctx.call("get_vendor_relationships", vendor_id=vid)
        graph_ctx["relationships"] = rel.data
        rd = rel.data or {}
        if rd.get("sla"):
            ev.append(_ev("G1", "graph", "Contract & SLA", {**(rd.get("contract") or {}), **rd["sla"]}, rel.source, 2, rd["sla"].get("sla_id", "")))
        ev.append(_ev("G2", "graph", "Supplied products & categories", {"products": len(rd.get("products", [])), "categories": rd.get("categories", []),
                                                                         "critical_products": [p["name"] for p in rd.get("products", []) if p.get("is_critical")][:5],
                                                                         "region": rd.get("region"), "port": rd.get("port")}, rel.source, 4))
    if vid and use_graph_dep:
        dep = ctx.call("get_supplier_dependencies", vendor_id=vid)
        graph_ctx["dependency"] = dep.data
        dd = dep.data or {}
        prim = [p for p in dd.get("products", []) if p.get("is_primary_source")]
        ev.append(_ev("G3", "graph", "Supplier dependency", {"dependency_level": dd.get("dependency_level"), "products": len(dd.get("products", [])),
                                                             "categories": [c["category"] for c in dd.get("categories", [])],
                                                             "primary_for": [{"product": p["product"], "category": p["category"], "alt_sources": p["alt_sources"],
                                                                              "open_pos": p["open_pos"], "critical": p["is_critical"]} for p in prim[:5]],
                                                             "open_pos": sum(int(p.get("open_pos") or 0) for p in dd.get("products", []))}, dep.source, 2))
    sources = []
    if searches:
        sources.append(f"chromadb x{len(searches)}")
    if graph_ctx:
        gsrc = (graph_ctx.get("relationships") or graph_ctx.get("dependency") or {}).get("source", "neo4j")
        sources.append(gsrc)
    detail = "sources chosen: " + (", ".join(sources) or "none")
    return {"vector_context": chunks, "graph_context": graph_ctx or None, "evidence": ev, "completed": ["knowledge"],
            "agent_trace": [_trace("knowledge", f"{len(chunks)} policy passages, {len(graph_ctx)} graph lookups", ctx, t0, detail=detail)]}


# ---------------------------------------------------------------------------
# Recommendation Agent
# ---------------------------------------------------------------------------
def recommendation_agent(state: dict, config: RunnableConfig) -> dict:
    t0 = time.perf_counter()
    ctx = _ctx(config, "recommendation")
    vid = state["vendor_id"]
    score = state.get("score_breakdown")
    if not score:
        return {"completed": ["recommendation"], "agent_trace": [_trace("recommendation", "skipped: no score facts", ctx, t0, "skipped")]}
    dep = ((state.get("graph_context") or {}).get("dependency"))
    if dep is None:
        dep = ctx.call("get_supplier_dependencies", vendor_id=vid).data
    decision = rules.decide(score, state.get("trend_analysis") or {}, state.get("sla_compliance") or [],
                            state.get("risk_prediction"), state.get("drivers") or [], dep)
    alts_res = ctx.call("find_alternative_vendors", vendor_id=vid)
    alts = (alts_res.data or {}).get("alternatives", [])
    rec = {**decision, "vendor_id": vid, "alternatives": alts[:3], "alternatives_source": alts_res.source,
           "ranking_method": (alts_res.data or {}).get("method"), "policy_constraints": (alts_res.data or {}).get("policy_constraints", [])}
    ev = [_ev("A1", "recommendation", "Recommended action", {"stage": decision["stage"], "action": decision["title"],
                                                             "triggers": decision["triggers"], "steps": decision["steps"],
                                                             "requires_approval": decision["requires_approval"], "approver": decision["approver"]},
              "policy-rules", 1, ",".join(decision["policy_refs"]))]
    for i, a in enumerate(alts[:3], start=2):
        label = "RANK 1 - recommended best fit" if i == 2 else f"rank {i - 1} - backup"
        ev.append(_ev(f"A{i}", "recommendation", f"Alternative supplier {a['vendor_id']} ({label})", {
            "rank": i - 1, "vendor_id": a["vendor_id"], "name": a["name"], "score": a["overall"], "band": a["band"], "fit_score": a["fit_score"],
            "product_overlap_pct": a["product_overlap_pct"], "risk": a["risk_level"], "trend": a["trend"], "region": a["region"],
            "eligible": a["eligible"], "issues": a["eligibility_issues"]}, alts_res.source, 2 if i == 2 else 3, "SEP-4.2"))
    return {"recommendation": rec, "candidate_vendors": alts, "evidence": ev, "completed": ["recommendation"],
            "agent_trace": [_trace("recommendation", f"{decision['title']}; {len(alts)} ranked alternatives", ctx, t0,
                                   detail="action decided by deterministic SEP-2 rules")]}


# ---------------------------------------------------------------------------
# Synthesis (LLM via optimisation layer, or labelled deterministic fallback)
# ---------------------------------------------------------------------------
TASK_FOR_INTENT = {
    "vendor_recommendation": "recommendation", "alternatives": "recommendation", "vendor_explain": "performance_explanation",
    "vendor_overview": "summary", "vendor_sla": "policy_explanation", "policy_question": "policy_explanation",
    "vendor_dependency": "summary", "portfolio_underperformers": "summary", "portfolio_deteriorated": "summary",
    "portfolio_segment": "summary", "portfolio_summary": "executive_synthesis",
}


def synthesize(state: dict, config: RunnableConfig) -> dict:
    t0 = time.perf_counter()
    rt = _rt(config)
    evidence = state.get("evidence", [])
    fallback = compose.deterministic_answer(state)
    if state["intent"] == "out_of_scope" or not evidence:
        return {"answer": {**fallback, "mode": "deterministic", "model": None, "jev": None},
                "agent_trace": [{"agent": "synthesizer", "action": "no evidence path - deterministic response", "tools": [], "sources": [],
                                 "status": "ok", "duration_ms": int((time.perf_counter() - t0) * 1000), "detail": ""}]}
    items = [EvidenceItem(e["id"], e["kind"], e["title"], e["value"], e["source"], e.get("priority", 5), e.get("ref", "")) for e in evidence]
    budget_tokens = runtime_settings.get_runtime(rt["db"])["agent"]["context_budget_tokens"]
    jev = compress(items, budget_tokens)
    gateway.telemetry.record_jev(jev.raw_tokens, jev.compressed_tokens)
    jev_info = {"raw_tokens": jev.raw_tokens, "compressed_tokens": jev.compressed_tokens, "saved_tokens": jev.saved_tokens,
                "dropped": jev.dropped, "items": len(jev.included)}
    system, user = compose.llm_messages(state["user_query"], state["intent"], state.get("vendor_id"), jev.context)
    task = TASK_FOR_INTENT.get(state["intent"], "summary")
    out, rec = gateway.structured_call(task, system, user, compose.SynthOutput, rt["budget"])
    if out is None:
        answer = {**fallback, "mode": "deterministic-fallback", "model": None, "fallback_reason": rec.reason, "jev": jev_info}
        action = f"deterministic answer ({rec.reason})"
    else:
        answer = {"text": out.answer, "reasoning": out.reasoning[:6], "cited_evidence": out.cited_evidence,
                  "mode": "llm", "model": rec.model, "jev": jev_info, "fallback_text": fallback}
        action = f"LLM synthesis via {rec.model} ({rec.tier} tier, {rec.status})"
    return {"answer": answer, "llm_calls": [rec.as_dict()],
            "agent_trace": [{"agent": "synthesizer", "action": action, "tools": ["jev.compress"], "sources": ["llm-gateway"],
                             "status": "ok", "duration_ms": int((time.perf_counter() - t0) * 1000),
                             "detail": f"JEV {jev.raw_tokens}->{jev.compressed_tokens} tokens"}]}


# ---------------------------------------------------------------------------
# Governance Agent
# ---------------------------------------------------------------------------
def governance_agent(state: dict, config: RunnableConfig) -> dict:
    t0 = time.perf_counter()
    rt = _rt(config)
    db = rt["db"]
    answer = dict(state.get("answer") or {})
    rset = runtime_settings.get_runtime(db)
    graph_src = None
    gc = state.get("graph_context") or {}
    if gc:
        graph_src = (gc.get("relationships") or gc.get("dependency") or {}).get("source")
    rec = state.get("recommendation")
    score = state.get("score_breakdown")
    kw = dict(intent=state["intent"], evidence=state.get("evidence", []),
              score_sufficient=None if not score else score.get("data_sufficient", True), recommendation=rec,
              graph_source=graph_src, approval_threshold=rset["risk"]["approval_confidence_threshold"],
              guardrail_flags=state.get("guardrail_flags", []))
    result = gov.evaluate(answer=answer, llm_used=answer.get("mode") == "llm", **kw)
    # Output guardrails (configurable on the Guardrails page): an LLM draft that breaks a rule is
    # replaced by the grounded deterministic answer, and the reason is recorded.
    og = guardrails.config(db)["output"]
    reasons = []
    if answer.get("mode") == "llm":
        figures = [c for c in result["unsupported_claims"] if c.startswith("figure ")]
        if len(figures) > og["max_unsupported_figures"]:
            reasons.append(f"{len(figures)} unsupported figures")
        if og["enforce_ranking"] and result.get("ranking_violation"):
            reasons.append("it overrode the deterministic alternative ranking")
        if og["require_citations"] and not (answer.get("cited_evidence") or gov.CITE.findall(answer.get("text", ""))):
            reasons.append("it cited no evidence")
    if reasons:
        fb = answer.get("fallback_text") or compose.deterministic_answer(state)
        rejected = result["unsupported_claims"] or reasons
        answer = {**fb, "mode": "deterministic-fallback", "model": answer.get("model"), "jev": answer.get("jev"),
                  "fallback_reason": "LLM draft rejected by output guardrail: " + "; ".join(reasons)}
        result = gov.evaluate(answer=answer, llm_used=False, **kw)
        result["rejected_llm_claims"] = rejected
        guardrails.record(db, actor=state.get("actor", "-"), role=state.get("role", "-"), request_id=state["request_id"], verdict="flag",
                          triggered=[{"layer": "output", "rule": "llm_draft_rejected", "action": "reject draft", "detail": "; ".join(reasons)}],
                          question=state["user_query"])
    answer.pop("fallback_text", None)
    if state["intent"] != "out_of_scope" and result["confidence"] < og["min_confidence"]:
        answer["text"] = (f"**Low confidence ({round(result['confidence'] * 100)}%) - verify before acting.** " + answer.get("text", ""))
        result["low_confidence_warning"] = True
        guardrails.record(db, actor=state.get("actor", "-"), role=state.get("role", "-"), request_id=state["request_id"], verdict="flag",
                          triggered=[{"layer": "output", "rule": "min_confidence", "action": "qualify",
                                      "detail": f"confidence {result['confidence']:.2f} < {og['min_confidence']:.2f}"}], question=state["user_query"])

    rec_id = None
    if rec:
        row = Recommendation(
            vendor_id=rec["vendor_id"], action=rec["action"], title=rec["title"],
            rationale=rec["triggers"] + rec["steps"], alternatives=[{k: a[k] for k in ("vendor_id", "name", "overall", "band", "fit_score",
                                                                                        "product_overlap_pct", "eligible", "risk_level")}
                                                                     for a in rec.get("alternatives", [])],
            evidence=[{"id": e["id"], "title": e["title"], "source": e["source"]} for e in state.get("evidence", [])],
            policy_refs=rec["policy_refs"], confidence=result["confidence"], requires_approval=result["requires_approval"],
            status="pending_approval" if result["requires_approval"] else "auto_approved",
            governance={"status": result["status"], "checks": result["checks"], "approval_reason": result["approval_reason"]},
            source="copilot", request_id=state["request_id"], created_by=state.get("actor", "demo-user"))
        db.add(row)
        db.flush()
        rec_id = row.id
    audit(db, request_id=state["request_id"], actor=state.get("actor", "demo-user"), event_type="copilot_answer",
          entity_type="vendor" if state.get("vendor_id") else "portfolio", entity_id=state.get("vendor_id") or "all",
          summary=f"[{state['intent']}] {state['user_query'][:120]}",
          details={"confidence": result["confidence"], "governance": result["status"], "mode": answer.get("mode"),
                   "model": answer.get("model"), "recommendation_id": rec_id,
                   "evidence": [e["id"] for e in state.get("evidence", [])],
                   "agent_trace": [{k: s.get(k) for k in ("agent", "action", "status", "duration_ms")} for s in state.get("agent_trace", [])],
                   "llm_calls": state.get("llm_calls", []), "guardrails": state.get("guardrail_flags", [])})
    result["recommendation_id"] = rec_id
    return {"answer": answer, "governance_result": result, "confidence": result["confidence"],
            "agent_trace": [{"agent": "governance", "action": f"{result['status']}; confidence {result['confidence']:.2f}"
                             + ("; human approval required" if result["requires_approval"] else ""), "tools": [], "sources": ["audit-log"],
                             "status": "ok", "duration_ms": int((time.perf_counter() - t0) * 1000),
                             "detail": f"{sum(c['passed'] for c in result['checks'])}/{len(result['checks'])} checks passed"}]}
