"""Relational model (PostgreSQL). Transactional and governance data only.

Relationships for graph traversal live in Neo4j; unstructured policy text lives
in ChromaDB. This schema is mirrored by the Alembic migration in
``backend/alembic/versions``.
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from sqlalchemy import JSON, Boolean, Date, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Category(Base):
    __tablename__ = "categories"
    category_id: Mapped[str] = mapped_column(String(16), primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True)


class Product(Base):
    __tablename__ = "products"
    product_id: Mapped[str] = mapped_column(String(24), primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    category_id: Mapped[str] = mapped_column(ForeignKey("categories.category_id"), index=True)
    benchmark_unit_cost: Mapped[float] = mapped_column(Float)
    is_critical: Mapped[bool] = mapped_column(Boolean, default=False)


class Vendor(Base):
    __tablename__ = "vendors"
    vendor_id: Mapped[str] = mapped_column(String(12), primary_key=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    country: Mapped[str] = mapped_column(String(60))
    region: Mapped[str] = mapped_column(String(60), index=True)
    city: Mapped[str] = mapped_column(String(60))
    port: Mapped[str] = mapped_column(String(60))
    primary_category_id: Mapped[str] = mapped_column(ForeignKey("categories.category_id"), index=True)
    tier: Mapped[str] = mapped_column(String(20))
    status: Mapped[str] = mapped_column(String(20), index=True)
    onboarded_date: Mapped[date] = mapped_column(Date)
    annual_capacity_units: Mapped[int] = mapped_column(Integer)
    sustainability_rating: Mapped[str] = mapped_column(String(2))
    contact_email: Mapped[str] = mapped_column(String(120))

    category: Mapped[Category] = relationship()


class VendorProduct(Base):
    __tablename__ = "vendor_products"
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"), primary_key=True)
    product_id: Mapped[str] = mapped_column(ForeignKey("products.product_id"), primary_key=True)
    category_id: Mapped[str] = mapped_column(ForeignKey("categories.category_id"), index=True)
    is_primary_source: Mapped[bool] = mapped_column(Boolean, default=False)


class Contract(Base):
    __tablename__ = "contracts"
    contract_id: Mapped[str] = mapped_column(String(16), primary_key=True)
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"), index=True)
    contract_type: Mapped[str] = mapped_column(String(60))
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    sla_id: Mapped[str] = mapped_column(String(16))
    sla_otd_target_pct: Mapped[float] = mapped_column(Float)
    sla_max_defect_rate_pct: Mapped[float] = mapped_column(Float)
    sla_max_invoice_variance_pct: Mapped[float] = mapped_column(Float)
    payment_terms_days: Mapped[int] = mapped_column(Integer)
    penalty_clause: Mapped[str] = mapped_column(Text)
    exclusivity: Mapped[bool] = mapped_column(Boolean, default=False)


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    po_id: Mapped[str] = mapped_column(String(16), primary_key=True)
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"))
    product_id: Mapped[str] = mapped_column(ForeignKey("products.product_id"))
    category_id: Mapped[str] = mapped_column(ForeignKey("categories.category_id"))
    po_date: Mapped[date] = mapped_column(Date)
    promised_date: Mapped[date] = mapped_column(Date)
    quantity: Mapped[int] = mapped_column(Integer)
    unit_price: Mapped[float] = mapped_column(Float)
    expected_value: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    is_critical: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(16))

    __table_args__ = (
        Index("ix_po_vendor_date", "vendor_id", "po_date"),
        Index("ix_po_category_date", "category_id", "po_date"),
        Index("ix_po_status", "status"),
    )


class Delivery(Base):
    __tablename__ = "deliveries"
    delivery_id: Mapped[str] = mapped_column(String(16), primary_key=True)
    po_id: Mapped[str] = mapped_column(ForeignKey("purchase_orders.po_id"), index=True)
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"))
    shipment_no: Mapped[int] = mapped_column(Integer)
    delivered_date: Mapped[date] = mapped_column(Date)
    promised_date: Mapped[date] = mapped_column(Date)
    delivered_qty: Mapped[int] = mapped_column(Integer)
    days_late: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(12))

    __table_args__ = (Index("ix_delivery_vendor_date", "vendor_id", "delivered_date"),)


class QualityInspection(Base):
    __tablename__ = "quality_inspections"
    inspection_id: Mapped[str] = mapped_column(String(16), primary_key=True)
    delivery_id: Mapped[str] = mapped_column(ForeignKey("deliveries.delivery_id"))
    po_id: Mapped[str] = mapped_column(ForeignKey("purchase_orders.po_id"))
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"))
    category_id: Mapped[str] = mapped_column(ForeignKey("categories.category_id"))
    inspection_date: Mapped[date] = mapped_column(Date)
    inspected_qty: Mapped[int] = mapped_column(Integer)
    defect_qty: Mapped[int] = mapped_column(Integer)
    rejected_qty: Mapped[int] = mapped_column(Integer)
    result: Mapped[str] = mapped_column(String(8))
    rejection_reason: Mapped[str] = mapped_column(String(80), default="")

    __table_args__ = (Index("ix_qi_vendor_date", "vendor_id", "inspection_date"),)


class Invoice(Base):
    __tablename__ = "invoices"
    invoice_id: Mapped[str] = mapped_column(String(16), primary_key=True)
    po_id: Mapped[str] = mapped_column(ForeignKey("purchase_orders.po_id"), index=True)
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"))
    invoice_date: Mapped[date] = mapped_column(Date)
    po_value: Mapped[float] = mapped_column(Float)
    invoice_value: Mapped[float] = mapped_column(Float)
    variance_amount: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(12))

    __table_args__ = (Index("ix_invoice_vendor_date", "vendor_id", "invoice_date"),)


class LeadTimeRecord(Base):
    __tablename__ = "lead_time_records"
    po_id: Mapped[str] = mapped_column(ForeignKey("purchase_orders.po_id"), primary_key=True)
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"), index=True)
    promised_lead_days: Mapped[int] = mapped_column(Integer)
    actual_lead_days: Mapped[int] = mapped_column(Integer)
    variance_days: Mapped[int] = mapped_column(Integer)


class VendorScoreSnapshot(Base):
    """Monthly score per vendor over a rolling 3-month window."""
    __tablename__ = "vendor_score_snapshots"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"))
    period: Mapped[date] = mapped_column(Date)            # month-end the window closes on
    window_start: Mapped[date] = mapped_column(Date)
    delivery_score: Mapped[float] = mapped_column(Float)
    quality_score: Mapped[float] = mapped_column(Float)
    cost_score: Mapped[float] = mapped_column(Float)
    lead_time_score: Mapped[float] = mapped_column(Float)
    overall_score: Mapped[float] = mapped_column(Float)
    band: Mapped[str] = mapped_column(String(12))
    weights: Mapped[dict] = mapped_column(JSON)
    kpis: Mapped[dict] = mapped_column(JSON)
    data_sufficient: Mapped[bool] = mapped_column(Boolean, default=True)
    model_version: Mapped[str] = mapped_column(String(16))
    data_version: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    __table_args__ = (
        UniqueConstraint("vendor_id", "period", name="uq_score_vendor_period"),
        Index("ix_score_period_band", "period", "band"),
    )


class VendorRiskSnapshot(Base):
    __tablename__ = "vendor_risk_snapshots"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"))
    period: Mapped[date] = mapped_column(Date)
    risk_probability: Mapped[float | None] = mapped_column(Float, nullable=True)
    risk_level: Mapped[str] = mapped_column(String(10))
    anomaly_score: Mapped[float] = mapped_column(Float)
    is_anomaly: Mapped[bool] = mapped_column(Boolean, default=False)
    drivers: Mapped[list] = mapped_column(JSON)
    model_version: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    __table_args__ = (UniqueConstraint("vendor_id", "period", name="uq_risk_vendor_period"),)


class Recommendation(Base):
    __tablename__ = "recommendations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vendor_id: Mapped[str] = mapped_column(ForeignKey("vendors.vendor_id"), index=True)
    action: Mapped[str] = mapped_column(String(60))
    title: Mapped[str] = mapped_column(String(200))
    rationale: Mapped[list] = mapped_column(JSON)
    alternatives: Mapped[list] = mapped_column(JSON)
    evidence: Mapped[list] = mapped_column(JSON)
    policy_refs: Mapped[list] = mapped_column(JSON)
    confidence: Mapped[float] = mapped_column(Float)
    requires_approval: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(20), index=True)  # pending_approval | approved | rejected | auto_approved
    governance: Mapped[dict] = mapped_column(JSON)
    source: Mapped[str] = mapped_column(String(20))  # copilot | engine
    request_id: Mapped[str] = mapped_column(String(40), default="")
    created_by: Mapped[str] = mapped_column(String(80))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    decided_by: Mapped[str | None] = mapped_column(String(80), nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    decision_note: Mapped[str | None] = mapped_column(Text, nullable=True)


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    request_id: Mapped[str] = mapped_column(String(40), index=True)
    actor: Mapped[str] = mapped_column(String(80))
    event_type: Mapped[str] = mapped_column(String(40), index=True)
    entity_type: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[str] = mapped_column(String(40))
    summary: Mapped[str] = mapped_column(String(300))
    details: Mapped[dict] = mapped_column(JSON)


class ExternalEvent(Base):
    """Secondary module: synthetic external intelligence feed."""
    __tablename__ = "external_events"
    event_id: Mapped[str] = mapped_column(String(20), primary_key=True)
    event_type: Mapped[str] = mapped_column(String(20))
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text)
    affected_countries: Mapped[str] = mapped_column(String(300))
    affected_ports: Mapped[str] = mapped_column(String(200))
    severity: Mapped[str] = mapped_column(String(10))
    detected_at: Mapped[date] = mapped_column(Date)
    expected_duration_days: Mapped[int] = mapped_column(Integer)
    expected_delay_days: Mapped[int] = mapped_column(Integer)
    source: Mapped[str] = mapped_column(String(80))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class MLModelRun(Base):
    """One trained candidate in the Model Lab (temporal hold-out evaluation)."""
    __tablename__ = "ml_model_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    experiment_id: Mapped[str] = mapped_column(String(24), index=True)
    algorithm: Mapped[str] = mapped_column(String(40))
    params: Mapped[dict] = mapped_column(JSON)
    dataset: Mapped[dict] = mapped_column(JSON)       # label definition, periods, sizes, positive rates, data_version
    metrics: Mapped[dict] = mapped_column(JSON)       # accuracy, precision, recall, f1, roc_auc, pr_auc, brier, ...
    curves: Mapped[dict] = mapped_column(JSON)        # roc, pr, calibration, confusion matrices
    importance: Mapped[list] = mapped_column(JSON)
    credible: Mapped[bool] = mapped_column(Boolean, default=False)
    credibility_reason: Mapped[str] = mapped_column(Text, default="")
    is_active: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    train_seconds: Mapped[float] = mapped_column(Float)
    trained_by: Mapped[str] = mapped_column(String(80))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    promoted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class LLMUsage(Base):
    """One AI model call (or avoided call) - the basis for cost tracking and FinOps."""
    __tablename__ = "llm_usage"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    request_id: Mapped[str] = mapped_column(String(40), index=True)
    user: Mapped[str] = mapped_column(String(80), index=True)
    role: Mapped[str] = mapped_column(String(20))
    feature: Mapped[str] = mapped_column(String(40))          # copilot | recommendation | ...
    task: Mapped[str] = mapped_column(String(40))             # routing task (summary, recommendation, ...)
    model: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(20))           # ok | cache_hit | semantic_cache | fallback | budget | error
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0)
    cost_usd: Mapped[float] = mapped_column(Float, default=0.0)
    saved_tokens: Mapped[int] = mapped_column(Integer, default=0)   # context tokens avoided by JEV compression
    latency_ms: Mapped[int] = mapped_column(Integer, default=0)


class AppSetting(Base):
    """Runtime-editable, non-secret settings (scoring weights, thresholds, cache)."""
    __tablename__ = "app_settings"
    key: Mapped[str] = mapped_column(String(60), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
