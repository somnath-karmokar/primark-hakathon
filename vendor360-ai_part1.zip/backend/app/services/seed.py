"""Load the synthetic CSV dataset into PostgreSQL (idempotent: replaces all data)."""
from __future__ import annotations

import csv
import logging
from datetime import date
from pathlib import Path

from sqlalchemy import Boolean, Date, Float, Integer, delete, insert
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models.entities import (
    Category, Contract, Delivery, ExternalEvent, Invoice, LeadTimeRecord, Product, PurchaseOrder,
    QualityInspection, Recommendation, Vendor, VendorProduct, VendorRiskSnapshot, VendorScoreSnapshot,
)

log = logging.getLogger(__name__)

# Order matters for FK constraints (parents first).
LOAD_ORDER = [
    (Category, "categories.csv"),
    (Product, "products.csv"),
    (Vendor, "vendors.csv"),
    (VendorProduct, "vendor_products.csv"),
    (Contract, "contracts.csv"),
    (PurchaseOrder, "purchase_orders.csv"),
    (Delivery, "deliveries.csv"),
    (QualityInspection, "quality_inspections.csv"),
    (Invoice, "invoices.csv"),
    (LeadTimeRecord, "lead_times.csv"),
    (ExternalEvent, "external_events.csv"),
]
DERIVED = [VendorRiskSnapshot, VendorScoreSnapshot, Recommendation]


def _converter(model):
    conv = {}
    for col in model.__table__.columns:
        t = col.type
        if isinstance(t, Boolean):
            conv[col.name] = lambda v: str(v).strip().lower() in ("true", "1", "yes")
        elif isinstance(t, Date):
            conv[col.name] = lambda v: date.fromisoformat(v)
        elif isinstance(t, Integer):
            conv[col.name] = lambda v: int(float(v))
        elif isinstance(t, Float):
            conv[col.name] = float
        else:
            conv[col.name] = lambda v: v
    return conv


def _rows(model, path: Path) -> list[dict]:
    conv = _converter(model)
    with path.open(encoding="utf-8") as fh:
        return [{k: conv[k](v) for k, v in row.items() if k in conv} for row in csv.DictReader(fh)]


def load_csvs(db: Session, data_dir: str | None = None) -> dict[str, int]:
    base = Path(data_dir or get_settings().data_dir)
    missing = [f for _, f in LOAD_ORDER if not (base / f).exists()]
    if missing:
        raise FileNotFoundError(f"Missing data files in {base}: {missing}. Run scripts/generate_data.py first.")
    for model in DERIVED:
        db.execute(delete(model))
    for model, _ in reversed(LOAD_ORDER):
        db.execute(delete(model))
    counts = {}
    for model, fname in LOAD_ORDER:
        rows = _rows(model, base / fname)
        for i in range(0, len(rows), 5000):
            db.execute(insert(model), rows[i:i + 5000])
        counts[model.__tablename__] = len(rows)
        log.info("loaded %s rows into %s", len(rows), model.__tablename__)
    db.flush()
    return counts

