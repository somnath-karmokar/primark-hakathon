"""Materialises monthly vendor score snapshots (rolling 3-month windows).

Scores are always produced by ``app.analytics.scoring`` - this module only
orchestrates windows, persistence and versioning.
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import date, timedelta

from sqlalchemy import delete, func, insert, select
from sqlalchemy.orm import Session

from app.analytics.metrics import TransactionFrames, VendorKPIs, compute_window_kpis, load_frames
from app.analytics.scoring import SCORING_MODEL_VERSION, ScoreBreakdown, ScoringWeights, score_from_kpis
from app.database.session import get_engine
from app.models.entities import PurchaseOrder, VendorScoreSnapshot
from app.services import runtime_settings

log = logging.getLogger(__name__)
WINDOW_MONTHS = 3

_frames: TransactionFrames | None = None
_frames_lock = threading.Lock()


def frames(refresh: bool = False) -> TransactionFrames:
    global _frames
    with _frames_lock:
        if _frames is None or refresh:
            _frames = load_frames(get_engine())
        return _frames


def month_end(d: date) -> date:
    nxt = date(d.year + d.month // 12, d.month % 12 + 1, 1)
    return nxt - timedelta(days=1)


def add_months(d: date, n: int) -> date:
    m = d.month - 1 + n
    return date(d.year + m // 12, m % 12 + 1, 1)


def score_periods(db: Session) -> list[tuple[date, date]]:
    """(window_start, period_end) for every month with a full 3-month window of completed data."""
    first, last = db.execute(select(func.min(PurchaseOrder.po_date), func.max(PurchaseOrder.po_date))).one()
    if first is None:
        return []
    first_month = date(first.year, first.month, 1)
    # Last complete month: the month before the latest PO month (which is still open).
    last_month = add_months(date(last.year, last.month, 1), -1)
    periods = []
    m = add_months(first_month, WINDOW_MONTHS - 1)
    while m <= last_month:
        periods.append((add_months(m, -(WINDOW_MONTHS - 1)), month_end(m)))
        m = add_months(m, 1)
    return periods


def compute_vendor_score(kpis: VendorKPIs, weights: ScoringWeights) -> ScoreBreakdown:
    return score_from_kpis(kpis.delivery, kpis.quality, kpis.cost, kpis.lead_time, weights)


def reweight(db: Session, reason: str = "weights changed") -> dict:
    """Weights only change the weighted sum, so re-derive overall + band from the stored
    component scores instead of recomputing every KPI window (sub-second vs ~40 s)."""
    from sqlalchemy import bindparam, update

    from app.analytics.scoring import overall_score
    t0 = time.perf_counter()
    weights = runtime_settings.weights(db)
    version = runtime_settings.bump_data_version(db, reason)
    rows = db.execute(select(VendorScoreSnapshot.id, VendorScoreSnapshot.delivery_score, VendorScoreSnapshot.quality_score,
                             VendorScoreSnapshot.cost_score, VendorScoreSnapshot.lead_time_score)).all()
    params = []
    for rid, d, q, c, lt in rows:
        b = overall_score(d, q, c, lt, weights)
        params.append({"rid": rid, "o": b.overall, "b": b.band, "w": b.weights, "dv": version})
    stmt = (update(VendorScoreSnapshot).where(VendorScoreSnapshot.id == bindparam("rid"))
            .values(overall_score=bindparam("o"), band=bindparam("b"), weights=bindparam("w"), data_version=bindparam("dv")))
    db.connection().execute(stmt, params)
    db.flush()
    return {"snapshots": len(params), "data_version": version, "weights": weights.as_dict(),
            "seconds": round(time.perf_counter() - t0, 2), "model_version": SCORING_MODEL_VERSION, "periods": []}


def recompute_all(db: Session, reason: str = "recompute") -> dict:
    t0 = time.perf_counter()
    weights = runtime_settings.weights(db)
    fr = frames(refresh=True)
    periods = score_periods(db)
    version = runtime_settings.bump_data_version(db, reason)
    rows = []
    for start, end in periods:
        kpis = compute_window_kpis(fr, start, end)
        for vid, k in kpis.items():
            b = compute_vendor_score(k, weights)
            rows.append({
                "vendor_id": vid, "period": end, "window_start": start,
                "delivery_score": b.delivery, "quality_score": b.quality, "cost_score": b.cost,
                "lead_time_score": b.lead_time, "overall_score": b.overall, "band": b.band,
                "weights": b.weights, "kpis": k.as_dict(), "data_sufficient": b.data_sufficient,
                "model_version": SCORING_MODEL_VERSION, "data_version": version,
            })
    db.execute(delete(VendorScoreSnapshot))
    for i in range(0, len(rows), 2000):
        db.execute(insert(VendorScoreSnapshot), rows[i:i + 2000])
    db.flush()
    elapsed = round(time.perf_counter() - t0, 2)
    log.info("scored %s vendor-periods across %s periods in %ss", len(rows), len(periods), elapsed)
    return {"snapshots": len(rows), "periods": [p[1].isoformat() for p in periods], "data_version": version,
            "weights": weights.as_dict(), "seconds": elapsed, "model_version": SCORING_MODEL_VERSION}
