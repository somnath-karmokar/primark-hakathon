"""Deterministic alternative-supplier ranking.

Candidates come from the supplier graph (shared products / ALTERNATIVE_TO);
ranking uses scored facts only:

    fit = 0.55 x overall score
        + 0.20 x product overlap (share of the incumbent's products the candidate already supplies)
        + 0.15 x risk headroom (Low 100 / Medium 60 / High 20)
        + 0.10 x trend (improving 100 / stable 85 / declining 50 / deteriorating 20)

Eligibility follows the Supplier Escalation Policy (SEP-4.2): Active status,
score >= 75 (Good or better) and internal risk not High.
"""
from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.graph import queries as graph
from app.services import analytics_service

RISK_HEADROOM = {"Low": 100, "Medium": 60, "High": 20, "Unknown": 60}
TREND_POINTS = {"improving": 100, "stable": 85, "declining": 50, "deteriorating": 20}
MIN_ELIGIBLE_SCORE = 75.0


@dataclass
class Candidate:
    vendor_id: str
    overall: float
    overlap_pct: float
    risk_level: str
    trend: str
    status: str


def fit_score(c: Candidate) -> float:
    return round(0.55 * c.overall + 0.20 * c.overlap_pct + 0.15 * RISK_HEADROOM.get(c.risk_level, 60)
                 + 0.10 * TREND_POINTS.get(c.trend, 70), 2)


def eligibility(c: Candidate) -> list[str]:
    issues = []
    if c.status not in ("Active",):
        issues.append(f"status is {c.status}")
    if c.overall < MIN_ELIGIBLE_SCORE:
        issues.append(f"score {c.overall:.1f} below {MIN_ELIGIBLE_SCORE:.0f}")
    if c.risk_level == "High":
        issues.append("internal risk is High")
    return issues


def _row(table, vid: str) -> dict:
    r = table.loc[vid].copy()
    r["vendor_id"] = vid
    return analytics_service._vendor_row(r)


def rank_alternatives(db: Session, vendor_id: str, limit: int = 5) -> dict:
    vendor_id = vendor_id.upper()
    analytics_service.get_vendor(db, vendor_id)
    table = analytics_service.current_table(db).set_index("vendor_id")
    graph_res = graph.alternative_candidates(db, vendor_id)
    my_products = len(graph.vendor_relationships(db, vendor_id).get("products", [])) or 1
    incumbent = _row(table, vendor_id)
    ranked = []
    for cand in graph_res["candidates"]:
        vid = cand["vendor_id"]
        if vid not in table.index or vid == vendor_id:
            continue
        r = table.loc[vid]
        c = Candidate(vid, float(r["overall"]), min(100.0, cand["shared_products"] / my_products * 100),
                      r.get("risk_level") or "Unknown", r.get("direction") or "stable", r["status"])
        issues = eligibility(c)
        ranked.append({
            **_row(table, vid),
            "fit_score": fit_score(c), "product_overlap_pct": round(c.overlap_pct, 1),
            "shared_products": cand["shared_products"], "shared_product_names": cand.get("shared_names", []),
            "graph_hops": cand.get("hops", 1), "eligible": not issues, "eligibility_issues": issues,
            "score_delta_vs_incumbent": round(c.overall - incumbent["overall"], 1),
        })
    ranked.sort(key=lambda x: (not x["eligible"], -x["fit_score"]))
    return {
        "vendor": incumbent, "alternatives": ranked[:limit], "candidates_considered": len(ranked),
        "graph_source": graph_res["source"],
        "method": "fit = 0.55*score + 0.20*product overlap + 0.15*risk headroom + 0.10*trend; eligibility per SEP-4.2",
        "policy_constraints": [
            "Alternative must be Active and score >= 75 (Supplier Escalation Policy SEP-4.2)",
            "Alternative must not carry High internal performance risk",
            "Dual-sourcing for critical products must keep at least two approved sources (Procurement Policy PP-3.4)",
        ],
    }
