"""End-to-end data pipeline used by the bootstrap script and the /data/seed API.

    CSV -> PostgreSQL -> score snapshots -> risk model -> Neo4j graph -> ChromaDB
"""
from __future__ import annotations

import logging
import time

from sqlalchemy.orm import Session

from app.governance.audit import audit
from app.services import cache, risk_service, runtime_settings, scoring_service, seed

log = logging.getLogger(__name__)


def rescore(db: Session, reason: str, actor: str = "system", request_id: str = "-", weights_only: bool = False) -> dict:
    result = scoring_service.reweight(db, reason) if weights_only else scoring_service.recompute_all(db, reason=reason)
    cache.invalidate_data()
    risk = risk_service.train_and_score(db)
    cache.invalidate_data()
    audit(db, request_id=request_id, actor=actor, event_type="scoring_run", entity_type="portfolio", entity_id="all",
          summary=f"Scored {result['snapshots']} vendor-periods ({reason})",
          details={"weights": result["weights"], "data_version": result["data_version"], "model_version": result["model_version"],
                   "risk": {k: v for k, v in risk.items() if k != "metrics"}})
    return {"scoring": result, "risk": risk}


def run_all(db: Session, *, load_csv: bool = True, graph: bool = True, knowledge: bool = True,
            actor: str = "system", request_id: str = "-") -> dict:
    t0 = time.perf_counter()
    out: dict = {}
    if load_csv:
        out["seed"] = seed.load_csvs(db)
        db.commit()
    out.update(rescore(db, reason="seed" if load_csv else "rescore", actor=actor, request_id=request_id))
    db.commit()
    if graph:
        from app.graph.ingest import ingest as graph_ingest
        try:
            out["graph"] = graph_ingest(db)
        except Exception as exc:  # graph is supporting context; never block scoring
            log.exception("graph ingestion failed")
            out["graph"] = {"status": "error", "error": f"{type(exc).__name__}: {str(exc)[:200]}"}
    if knowledge:
        from app.knowledge import store
        try:
            out["knowledge"] = store.ingest()
        except Exception as exc:
            log.exception("knowledge ingestion failed")
            out["knowledge"] = {"status": "error", "error": f"{type(exc).__name__}: {str(exc)[:200]}"}
    out["data_version"] = runtime_settings.data_version(db)
    out["seconds"] = round(time.perf_counter() - t0, 1)
    return out
