"""Internal performance risk = ML deterioration probability (if credible) + anomalies + trend.

External supplier risk is a *separate* indicator (app.risk_intel) and is never
mixed into the performance score or this internal risk.
"""
from __future__ import annotations

import logging
from dataclasses import asdict

import numpy as np
import pandas as pd
from sqlalchemy import delete, insert
from sqlalchemy.orm import Session

from app.analytics.scoring import score_band
from app.config import get_settings
from app.ml.risk_model import MODEL_VERSION, ModelReport, RiskModel, build_feature_frame, detect_anomalies, save_report
from app.models.entities import VendorRiskSnapshot
from app.services import analytics_service, runtime_settings

log = logging.getLogger(__name__)

_model: RiskModel | None = None
_report: ModelReport | None = None


def train_and_score(db: Session) -> dict:
    """Train on score history, score the latest period, persist VendorRiskSnapshot rows."""
    global _model, _report
    rt = runtime_settings.get_runtime(db)["risk"]
    snaps = analytics_service.snapshots_df(db)
    if snaps.empty:
        return {"status": "no_snapshots"}
    # The production configuration is whichever Model Lab run is promoted (default: XGBoost with the tuned settings).
    from app.services.model_lab import active_config
    cfg = active_config(db)
    model = RiskModel(drop_points=cfg["drop_points"], algorithm=cfg["algorithm"], params=cfg["params"])
    report = model.train(snaps)
    _model, _report = model, report
    save_report(report, get_settings().model_dir)

    feats = build_feature_frame(snaps)
    latest = feats["period"].max()
    cur = feats[feats["period"] == latest].copy()
    preds = model.predict(cur)
    anomalies = detect_anomalies(cur)
    trend = analytics_service._trend_table(db, latest.date().isoformat())
    merged = cur[["vendor_id", "overall"]].merge(preds, on="vendor_id").merge(anomalies, on="vendor_id").merge(trend, on="vendor_id")

    rows = []
    for _, r in merged.iterrows():
        level, drivers = classify(r, rt, report.credible)
        rows.append({"vendor_id": r["vendor_id"], "period": latest.date(),
                     "risk_probability": None if pd.isna(r["risk_probability"]) else float(r["risk_probability"]),
                     "risk_level": level, "anomaly_score": float(r["anomaly_score"]), "is_anomaly": bool(r["is_anomaly"]),
                     "drivers": drivers, "model_version": MODEL_VERSION if report.credible else "statistical-fallback"})
    db.execute(delete(VendorRiskSnapshot))
    db.execute(insert(VendorRiskSnapshot), rows)
    db.flush()
    levels = pd.Series([r["risk_level"] for r in rows]).value_counts().to_dict()
    return {"status": "ok", "credible_model": report.credible, "metrics": report.metrics, "levels": levels,
            "anomalies": int(sum(r["is_anomaly"] for r in rows)), "period": latest.date().isoformat()}


def classify(r: pd.Series, rt: dict, credible: bool) -> tuple[str, list]:
    drivers: list[dict] = []
    if credible and not pd.isna(r["risk_probability"]):
        p = float(r["risk_probability"])
        level = "High" if p >= rt["high_threshold"] else "Medium" if p >= rt["medium_threshold"] else "Low"
        drivers += [{"type": "model", **d} for d in r["drivers"]]
    else:
        level = "High" if r["is_deteriorating"] else "Medium" if r["direction"] == "declining" else "Low"
    # Current statistical signals can raise (never lower) the forward-looking model level:
    # a vendor already deteriorating into Watch-or-worse is High risk today, whatever the model says.
    band = score_band(float(r["overall"]))
    order = {"Low": 0, "Medium": 1, "High": 2}
    stat = "Low"
    if band in ("At Risk", "Critical") or (r["is_deteriorating"] and band == "Watch"):
        stat = "High"
    elif r["is_deteriorating"] or r["is_anomaly"] or r["direction"] == "declining":
        stat = "Medium"
    if order[stat] > order[level]:
        level = stat
        drivers.append({"type": "statistical", "label": f"Raised to {stat} by current signals",
                        "detail": f"band {band}" + (", deteriorating" if r["is_deteriorating"] else "") + (", anomaly" if r["is_anomaly"] else "")})
    if r["is_deteriorating"]:
        drivers.append({"type": "trend", "label": "Score deteriorating", "value": float(r["change_3m"]),
                        "detail": f"{r['change_3m']:+.1f} pts over 3 months (peak {r['peak_score']:.1f})"})
    for a in r["anomaly_reasons"]:
        drivers.append({"type": "anomaly", **a})
    return level, drivers


def model_report() -> dict | None:
    return asdict(_report) if _report else _load_report()


def _load_report() -> dict | None:
    import json
    from pathlib import Path
    p = Path(get_settings().model_dir) / "risk_model_report.json"
    return json.loads(p.read_text()) if p.exists() else None


def vendor_risk(db: Session, vendor_id: str) -> dict:
    from sqlalchemy import select
    snap = db.execute(select(VendorRiskSnapshot).where(VendorRiskSnapshot.vendor_id == vendor_id.upper())
                      .order_by(VendorRiskSnapshot.period.desc())).scalars().first()
    report = model_report() or {}
    if not snap:
        return {"vendor_id": vendor_id, "risk_level": "Unknown", "risk_probability": None, "drivers": [],
                "model": {"credible": False, "reason": "Risk not yet computed"}}
    return {"vendor_id": snap.vendor_id, "period": snap.period.isoformat(), "risk_level": snap.risk_level,
            "risk_probability": snap.risk_probability, "anomaly_score": snap.anomaly_score, "is_anomaly": snap.is_anomaly,
            "drivers": snap.drivers, "model_version": snap.model_version,
            "model": {"credible": report.get("credible", False), "label_definition": report.get("label_definition"),
                      "metrics": report.get("metrics", {}), "reason": report.get("reason", "")},
            "indicator": "internal_performance_risk"}


def _nan(v):
    return None if v is None or (isinstance(v, float) and np.isnan(v)) else v
