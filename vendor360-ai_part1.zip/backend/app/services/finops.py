"""AI cost tracking & FinOps.

* Every model call (and every call *avoided* by caching or the deterministic path) is written to
  ``llm_usage`` with tokens and cost, attributed to user, role, feature and model.
* Prices are list prices per 1M tokens, configurable via ``LLM_PRICE_TABLE`` (JSON) - update them
  when the provider changes prices or when using negotiated Azure rates.
* A monthly budget (set by an admin) drives an alert threshold and an optional hard stop: once the
  budget is spent, the copilot answers from facts only (no model calls) until the next month.
* Running-cost figures for infrastructure are **indicative planning estimates**, not quotes.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models.entities import LLMUsage

# USD per 1M tokens (input, output). Public list prices - override with LLM_PRICE_TABLE.
DEFAULT_PRICES = {
    "gpt-4o-mini": [0.15, 0.60],
    "gpt-4.1-mini": [0.40, 1.60],
    "gpt-4.1": [2.00, 8.00],
    "gpt-4o": [2.50, 10.00],
    "text-embedding-3-small": [0.02, 0.0],
}
DEFAULT_BUDGET = {"monthly_budget_gbp": 50.0, "alert_pct": 80, "hard_stop": True}

# Indicative monthly running costs for a pilot (~50 users) on Azure UK South. Planning ranges only.
INFRA_ESTIMATES = [
    {"item": "AI model usage (Azure OpenAI)", "low": None, "high": None, "basis": "Measured from actual usage - see forecast", "driver": "usage"},
    {"item": "Application hosting (API + web, Azure Container Apps)", "low": 60, "high": 150, "basis": "2 small containers, autoscale to zero out of hours", "driver": "fixed"},
    {"item": "Database (Azure PostgreSQL Flexible, 2 vCore)", "low": 110, "high": 180, "basis": "General Purpose tier, 128 GB storage, backups", "driver": "fixed"},
    {"item": "Supplier graph (Neo4j AuraDB Professional)", "low": 50, "high": 250, "basis": "Small instance; Aura Free is enough for the demo", "driver": "fixed"},
    {"item": "Policy search index (ChromaDB)", "low": 0, "high": 0, "basis": "Runs inside the API container - no separate service", "driver": "fixed"},
    {"item": "Monitoring & logs (Application Insights / Log Analytics)", "low": 20, "high": 60, "basis": "~5 GB logs per month", "driver": "fixed"},
    {"item": "Security services (Key Vault, private networking)", "low": 10, "high": 40, "basis": "Secrets, private endpoints", "driver": "fixed"},
]


def prices() -> dict[str, list[float]]:
    p = dict(DEFAULT_PRICES)
    raw = get_settings().llm_price_table
    if raw:
        try:
            p.update({k: [float(v[0]), float(v[1])] for k, v in json.loads(raw).items()})
        except (ValueError, TypeError, IndexError):
            pass
    return p


def _price(model: str) -> list[float]:
    name = model.split(":", 1)[-1]
    table = prices()
    return table.get(name) or next((v for k, v in table.items() if name.startswith(k)), [0.0, 0.0])


def cost_usd(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    pin, pout = _price(model)
    return round(prompt_tokens / 1e6 * pin + completion_tokens / 1e6 * pout, 8)


def gbp(usd: float) -> float:
    return usd * get_settings().usd_to_gbp


# ---------------------------------------------------------------- recording
def record(db: Session, *, request_id: str, user: str, role: str, feature: str, calls: list[dict],
           jev: dict | None = None, semantic_hit: bool = False) -> dict:
    """Persist one copilot request's model usage. Returns the request's cost summary."""
    rows = []
    saved = int((jev or {}).get("saved_tokens") or 0)
    if semantic_hit:
        rows.append(LLMUsage(request_id=request_id, user=user, role=role, feature=feature, task="semantic_cache",
                             model="-", status="semantic_cache"))
    for c in calls:
        cost = cost_usd(c.get("model", ""), int(c.get("prompt_tokens") or 0), int(c.get("completion_tokens") or 0)) if c.get("status") == "ok" else 0.0
        rows.append(LLMUsage(request_id=request_id, user=user, role=role, feature=feature, task=c.get("task", "-"),
                             model=c.get("model", "-"), status=c.get("status", "-"), prompt_tokens=int(c.get("prompt_tokens") or 0),
                             completion_tokens=int(c.get("completion_tokens") or 0), cost_usd=cost,
                             saved_tokens=saved if c.get("task") not in ("classify",) else 0, latency_ms=int(c.get("latency_ms") or 0)))
        saved = 0
    if not rows:  # answered without any model call (deterministic / out-of-scope)
        rows.append(LLMUsage(request_id=request_id, user=user, role=role, feature=feature, task="-", model="-", status="no_llm_needed"))
    db.add_all(rows)
    db.flush()
    total = sum(r.cost_usd for r in rows)
    return {"cost_usd": round(total, 6), "cost_gbp": round(gbp(total), 6), "tokens": sum(r.prompt_tokens + r.completion_tokens for r in rows),
            "model_calls": sum(1 for r in rows if r.status == "ok")}


# ---------------------------------------------------------------- budget
def budget_config(db: Session) -> dict:
    from app.services import runtime_settings
    stored = runtime_settings.get_runtime(db).get("finops") or {}
    return {**DEFAULT_BUDGET, **stored}


def save_budget(db: Session, cfg: dict) -> dict:
    from app.services import runtime_settings
    runtime_settings.set_section(db, "finops", {**budget_config(db), **cfg})
    return budget_config(db)


def _month_start(now: datetime) -> datetime:
    return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def month_to_date_usd(db: Session) -> float:
    now = datetime.now(timezone.utc)
    return float(db.execute(select(func.coalesce(func.sum(LLMUsage.cost_usd), 0.0)).where(LLMUsage.ts >= _month_start(now))).scalar_one())


def budget_status(db: Session) -> dict:
    cfg = budget_config(db)
    spent = gbp(month_to_date_usd(db))
    budget = float(cfg["monthly_budget_gbp"])
    # A zero budget means "no AI spend allowed" (fully exhausted), not "0% used".
    pct = spent / budget * 100 if budget > 0 else 100.0
    exhausted = spent >= budget
    return {**cfg, "spent_gbp": round(spent, 4), "used_pct": round(pct, 1),
            "alert": pct >= cfg["alert_pct"], "exhausted": exhausted,
            "blocking": bool(cfg["hard_stop"] and exhausted)}


# ---------------------------------------------------------------- reporting
def summary(db: Session) -> dict:
    s = get_settings()
    now = datetime.now(timezone.utc)
    ms = _month_start(now)
    rows = db.execute(select(LLMUsage).where(LLMUsage.ts >= now - timedelta(days=30))).scalars().all()
    month = [r for r in rows if r.ts >= ms]
    requests = {r.request_id for r in month}
    ok = [r for r in month if r.status == "ok"]
    cost_m = sum(r.cost_usd for r in month)
    avg_call = (sum(r.cost_usd for r in ok) / len(ok)) if ok else cost_usd(f"openai:{s.openai_model}", 1800, 250)
    cache_hits = sum(1 for r in month if r.status in ("cache_hit", "semantic_cache"))
    no_llm = sum(1 for r in month if r.status == "no_llm_needed")
    pin = _price(f"openai:{s.openai_model}")[0]
    jev_saved_tokens = sum(r.saved_tokens for r in month)
    savings = {
        "cache_hits": cache_hits, "cache_saving_usd": round(cache_hits * avg_call, 6),
        "jev_tokens_saved": jev_saved_tokens, "jev_saving_usd": round(jev_saved_tokens / 1e6 * pin, 6),
        "answered_without_llm": no_llm,
    }
    savings["total_saving_gbp"] = round(gbp(savings["cache_saving_usd"] + savings["jev_saving_usd"]), 6)

    def group(key):
        out: dict[str, dict] = {}
        for r in month:
            k = getattr(r, key) or "-"
            g = out.setdefault(k, {"key": k, "requests": set(), "calls": 0, "tokens": 0, "cost_usd": 0.0})
            g["requests"].add(r.request_id)
            g["calls"] += r.status == "ok"
            g["tokens"] += r.prompt_tokens + r.completion_tokens
            g["cost_usd"] += r.cost_usd
        return sorted([{**g, "requests": len(g["requests"]), "cost_gbp": round(gbp(g["cost_usd"]), 6), "cost_usd": round(g["cost_usd"], 6)}
                       for g in out.values()], key=lambda x: -x["cost_usd"])

    days = {}
    for r in rows:
        d = r.ts.date().isoformat()
        x = days.setdefault(d, {"date": d, "cost_gbp": 0.0, "requests": set(), "calls": 0})
        x["cost_gbp"] += gbp(r.cost_usd)
        x["requests"].add(r.request_id)
        x["calls"] += r.status == "ok"
    daily = []
    for i in range(29, -1, -1):
        d = (now - timedelta(days=i)).date().isoformat()
        x = days.get(d)
        daily.append({"date": d, "cost_gbp": round(x["cost_gbp"], 6) if x else 0.0, "requests": len(x["requests"]) if x else 0,
                      "model_calls": x["calls"] if x else 0})

    day_of_month = now.day
    days_in_month = ((ms + timedelta(days=32)).replace(day=1) - ms).days
    forecast_gbp = gbp(cost_m) / max(day_of_month, 1) * days_in_month
    per_request = gbp(cost_m) / len(requests) if requests else gbp(avg_call)
    return {
        "currency": "GBP", "usd_to_gbp": s.usd_to_gbp, "month": ms.strftime("%B %Y"),
        "month_to_date_gbp": round(gbp(cost_m), 6), "forecast_month_gbp": round(forecast_gbp, 4),
        "requests": len(requests), "model_calls": len(ok),
        "tokens": {"prompt": sum(r.prompt_tokens for r in month), "completion": sum(r.completion_tokens for r in month)},
        "avg_cost_per_question_gbp": round(per_request, 6), "avg_cost_per_model_call_gbp": round(gbp(avg_call), 6),
        "share_answered_without_new_model_call": round((cache_hits + no_llm) / len(month) * 100, 1) if month else 0.0,
        "savings": savings, "budget": budget_status(db), "daily": daily,
        "by_user": group("user"), "by_role": group("role"), "by_model": group("model"), "by_task": group("task"),
        "prices_usd_per_million": prices(), "active_model": s.openai_model if s.llm_provider == "openai" else s.azure_openai_deployment,
        "infrastructure": INFRA_ESTIMATES,
        "levers": [
            {"lever": "Fixed-rule scoring", "effect": "Scores, rankings and recommended actions cost nothing in AI fees - the model only writes explanations."},
            {"lever": "Small model by default", "effect": "Routine questions go to the cheapest suitable model; stronger models only for complex recommendations."},
            {"lever": "Context compression (JEV)", "effect": "Only compact, de-duplicated facts are sent to the model - about half the tokens of raw context."},
            {"lever": "Answer caching", "effect": "Repeated questions are answered from cache at zero model cost while data and policies are unchanged."},
            {"lever": "Per-question limits", "effect": "Caps on model calls and tokens per question stop runaway costs."},
            {"lever": "Monthly budget with hard stop", "effect": "When the budget is used up, the assistant keeps working from facts only - no surprise bills."},
            {"lever": "Cost attribution", "effect": "Every call is tagged with user, role, feature and model for showback / chargeback."},
        ],
    }
