"""In-process cache abstractions (swap for Redis by implementing the same interface).

Namespaces:
* ``analytics``  - key: vendor_id + period + data_version
* ``retrieval``  - Chroma chunk ids / graph query results, keyed by query + policy/graph version
* ``response``   - exact LLM response cache (prompt hash + model + prompt version)
* ``semantic``   - similar-question reuse, valid only while data/policy/prompt/model versions match
"""
from __future__ import annotations

import hashlib
import json
import math
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable


def stable_key(*parts: Any) -> str:
    raw = json.dumps(parts, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


@dataclass
class CacheStats:
    hits: int = 0
    misses: int = 0
    sets: int = 0
    invalidations: int = 0

    def as_dict(self) -> dict:
        total = self.hits + self.misses
        return {"hits": self.hits, "misses": self.misses, "sets": self.sets, "invalidations": self.invalidations,
                "hit_rate": round(self.hits / total, 3) if total else 0.0}


class TTLCache:
    def __init__(self, name: str, max_items: int = 2000, ttl_seconds: int = 3600):
        self.name, self.max_items, self.ttl = name, max_items, ttl_seconds
        self._data: OrderedDict[str, tuple[float, Any, dict]] = OrderedDict()
        self._lock = threading.Lock()
        self.stats = CacheStats()
        self.enabled = True

    def get(self, key: str) -> Any | None:
        if not self.enabled:
            return None
        with self._lock:
            item = self._data.get(key)
            if item is None or (time.time() - item[0]) > self.ttl:
                if item is not None:
                    self._data.pop(key, None)
                self.stats.misses += 1
                return None
            self._data.move_to_end(key)
            self.stats.hits += 1
            return item[1]

    def set(self, key: str, value: Any, tags: dict | None = None) -> None:
        if not self.enabled:
            return
        with self._lock:
            self._data[key] = (time.time(), value, tags or {})
            self._data.move_to_end(key)
            while len(self._data) > self.max_items:
                self._data.popitem(last=False)
            self.stats.sets += 1

    def get_or_set(self, key: str, fn: Callable[[], Any], tags: dict | None = None) -> tuple[Any, bool]:
        val = self.get(key)
        if val is not None:
            return val, True
        val = fn()
        self.set(key, val, tags)
        return val, False

    def invalidate(self, predicate: Callable[[dict], bool] | None = None) -> int:
        with self._lock:
            if predicate is None:
                n = len(self._data)
                self._data.clear()
            else:
                doomed = [k for k, (_, _, tags) in self._data.items() if predicate(tags)]
                for k in doomed:
                    self._data.pop(k, None)
                n = len(doomed)
            self.stats.invalidations += n
            return n

    def __len__(self) -> int:
        return len(self._data)


def cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


@dataclass
class SemanticEntry:
    embedding: list[float]
    question: str
    response: Any
    versions: dict
    at: float = field(default_factory=time.time)


class SemanticCache:
    """Reuses a previous answer for a *similar* question only when every
    version stamp (data, policy, prompt, model) and the resolved vendor match."""

    def __init__(self, threshold: float = 0.92, max_items: int = 500, ttl_seconds: int = 3600):
        self.threshold, self.max_items, self.ttl = threshold, max_items, ttl_seconds
        self._items: list[SemanticEntry] = []
        self._lock = threading.Lock()
        self.stats = CacheStats()
        self.enabled = True

    def lookup(self, embedding: list[float], versions: dict) -> tuple[SemanticEntry | None, float]:
        if not self.enabled:
            return None, 0.0
        best, best_sim = None, 0.0
        now = time.time()
        with self._lock:
            self._items = [e for e in self._items if now - e.at <= self.ttl]
            for e in self._items:
                if e.versions != versions:
                    continue
                sim = cosine(embedding, e.embedding)
                if sim > best_sim:
                    best, best_sim = e, sim
        if best is not None and best_sim >= self.threshold:
            self.stats.hits += 1
            return best, best_sim
        self.stats.misses += 1
        return None, best_sim

    def store(self, embedding: list[float], question: str, response: Any, versions: dict) -> None:
        if not self.enabled:
            return
        with self._lock:
            self._items.append(SemanticEntry(embedding, question, response, versions))
            self._items = self._items[-self.max_items:]
            self.stats.sets += 1

    def invalidate(self, predicate: Callable[[dict], bool] | None = None) -> int:
        with self._lock:
            before = len(self._items)
            self._items = [e for e in self._items if predicate is not None and not predicate(e.versions)]
            n = before - len(self._items)
            self.stats.invalidations += n
            return n


analytics_cache = TTLCache("analytics", max_items=5000)
retrieval_cache = TTLCache("retrieval", max_items=2000)
response_cache = TTLCache("response", max_items=1000)
semantic_cache = SemanticCache()


def configure(enabled: bool, ttl_seconds: int, semantic_threshold: float) -> None:
    for c in (analytics_cache, retrieval_cache, response_cache):
        c.enabled, c.ttl = enabled, ttl_seconds
    semantic_cache.enabled, semantic_cache.ttl, semantic_cache.threshold = enabled, ttl_seconds, semantic_threshold


def invalidate_data(vendor_id: str | None = None) -> dict:
    """Called when vendor data or scoring weights change."""
    if vendor_id:
        pred = lambda t: t.get("vendor_id") in (vendor_id, None)  # noqa: E731
        return {"analytics": analytics_cache.invalidate(pred), "response": response_cache.invalidate(pred),
                "semantic": semantic_cache.invalidate(lambda v: v.get("vendor_id") == vendor_id)}
    return {"analytics": analytics_cache.invalidate(), "response": response_cache.invalidate(),
            "semantic": semantic_cache.invalidate()}


def stats() -> dict:
    return {"analytics": {**analytics_cache.stats.as_dict(), "size": len(analytics_cache)},
            "retrieval": {**retrieval_cache.stats.as_dict(), "size": len(retrieval_cache)},
            "response": {**response_cache.stats.as_dict(), "size": len(response_cache)},
            "semantic": {**semantic_cache.stats.as_dict(), "size": len(semantic_cache._items)}}
