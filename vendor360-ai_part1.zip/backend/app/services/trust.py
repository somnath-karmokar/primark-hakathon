"""Trust Centre: evidence for responsible AI use and the security posture.

Everything here is computed from live data (audit trail, guardrail events, approvals, feedback,
configuration) so the page shows what the system *does*, not just what it promises.
"""
from __future__ import annotations

from collections import Counter

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import REPO_ROOT, get_settings
from app.models.entities import AuditEvent, Recommendation
from app.services import analytics_service

SCORE_INPUTS = ["on-time delivery", "lateness", "defect rate", "inspection failures", "rejections", "invoice accuracy",
                "price vs typical price", "lead-time variation", "lead-time overrun"]
NOT_USED = ["country", "region", "supplier size", "ownership", "tier", "workforce data", "any personal data"]


# ---------------------------------------------------------------- responsible AI
def responsible_ai(db: Session) -> dict:
    from app.governance import guardrails
    from app.ml.risk_model import FEATURES

    answers = db.execute(select(AuditEvent).where(AuditEvent.event_type == "copilot_answer").order_by(AuditEvent.ts.desc()).limit(1000)).scalars().all()
    n = len(answers)
    gov = Counter((a.details or {}).get("governance", "?") for a in answers)
    mode = Counter((a.details or {}).get("mode", "?") for a in answers)
    conf = [float((a.details or {}).get("confidence") or 0) for a in answers]
    gstats = guardrails.stats(db, limit=1000)
    by_rule = gstats["by_rule"]
    pii = sum(v for k, v in by_rule.items() if k.startswith("pii:"))
    injection = sum(v for k, v in by_rule.items() if k.startswith("prompt_injection"))
    recs = dict(db.execute(select(Recommendation.status, func.count()).group_by(Recommendation.status)).all())
    fb = db.execute(select(AuditEvent).where(AuditEvent.event_type == "ai_feedback").order_by(AuditEvent.ts.desc()).limit(500)).scalars().all()
    up = sum(1 for f in fb if (f.details or {}).get("rating") == "up")
    down = sum(1 for f in fb if (f.details or {}).get("rating") == "down")

    metrics = {
        "answers": n, "fully_checked_pct": round(gov.get("passed", 0) / n * 100, 1) if n else None,
        "ai_written": mode.get("llm", 0), "fact_based_fallback": n - mode.get("llm", 0),
        "avg_confidence_pct": round(sum(conf) / n * 100, 1) if n else None,
        "drafts_rejected": by_rule.get("llm_draft_rejected", 0), "low_confidence_flags": by_rule.get("min_confidence", 0),
        "blocked_questions": gstats["by_verdict"].get("block", 0), "personal_data_redactions": pii, "injection_attempts": injection,
        "approvals_pending": recs.get("pending_approval", 0), "approvals_approved": recs.get("approved", 0),
        "approvals_rejected": recs.get("rejected", 0), "auto_approved": recs.get("auto_approved", 0),
        "feedback_up": up, "feedback_down": down, "feedback_positive_pct": round(up / (up + down) * 100, 1) if (up + down) else None,
    }
    recent_negative = [{"ts": f.ts.isoformat(), "user": f.actor, "question": (f.details or {}).get("question"),
                        "comment": (f.details or {}).get("comment"), "request_id": f.request_id}
                       for f in fb if (f.details or {}).get("rating") == "down"][:10]

    principles = [
        {"principle": "Human in control", "what": "AI suggests; people decide. Actions that affect suppliers (step 2 and above) wait for an approver.",
         "controls": ["Approval queue with named approver", "Recommended action decided by policy rules, not by the AI", "Admins can switch the AI off (0 model calls) at any time"],
         "evidence": f"{metrics['approvals_pending']} awaiting approval · {metrics['approvals_approved']} approved · {metrics['approvals_rejected']} rejected"},
        {"principle": "Accuracy & grounding", "what": "The AI may only use facts the system has already calculated, and must cite them.",
         "controls": ["Every figure in an AI answer is checked against the facts", "Drafts that invent numbers, skip citations or re-order the supplier ranking are replaced", "Low-confidence answers carry a warning"],
         "evidence": f"{metrics['fully_checked_pct'] if metrics['fully_checked_pct'] is not None else '-'}% of answers passed every check · {metrics['drafts_rejected']} AI drafts rejected"},
        {"principle": "Transparency", "what": "Users can see why an answer was given and whether AI wrote it.",
         "controls": ["'AI-written' label on every model answer", "Facts, policy quotes, supplier links and steps shown with each answer", "Score formulas published (docs/SCORING.md)"],
         "evidence": f"{metrics['ai_written']} AI-written answers · {metrics['fact_based_fallback']} fact-based summaries"},
        {"principle": "Fairness", "what": "Vendors are judged only on how they perform - never on where they are or who they are.",
         "controls": [f"Score inputs: {', '.join(SCORE_INPUTS)}", f"Never used: {', '.join(NOT_USED)}", "Same rules and weights for every vendor; regional differences are explained by measured performance (below)"],
         "evidence": "Risk model features contain no location or ownership data" if not {"region", "country", "tier"} & set(FEATURES) else "WARNING: location used as a model feature"},
        {"principle": "Privacy", "what": "Personal data is kept away from the AI model and only summaries are shared.",
         "controls": ["Emails, phone numbers, card and NI numbers removed before the AI sees a question", "Only compact KPI summaries are sent - never raw transactions", "Data stays in the configured cloud region"],
         "evidence": f"{pii} personal-data redactions"},
        {"principle": "Safety & security", "what": "Misuse is detected and blocked; every action is logged.",
         "controls": ["Prompt-injection detection", "Blocked terms (e.g. bribery)", "Per-user rate limits and role-based access", "Permanent audit log"],
         "evidence": f"{metrics['blocked_questions']} questions blocked · {injection} injection attempts caught"},
        {"principle": "Honest ML", "what": "Prediction models are tested on later months they never saw, and only used when good enough.",
         "controls": ["Time-based test split", "0.65 accuracy (ROC-AUC) bar before a model can be used", "Model metrics shown as measured on later months the model never saw"],
         "evidence": _model_evidence()},
        {"principle": "Feedback & accountability", "what": "Users rate answers; poor answers are reviewed.",
         "controls": ["Thumbs up / down on every answer", "Negative feedback listed for review", "Owner: Procurement Excellence team"],
         "evidence": f"{up} helpful · {down} not helpful" + (f" ({metrics['feedback_positive_pct']}% positive)" if metrics["feedback_positive_pct"] is not None else "")},
    ]
    return {"principles": principles, "metrics": metrics, "fairness": fairness(db), "recent_negative_feedback": recent_negative}


def _model_evidence() -> str:
    from app.services import risk_service
    r = risk_service.model_report() or {}
    if not r:
        return "Risk model not trained yet"
    auc = (r.get("metrics") or {}).get("roc_auc")
    return f"Current model {'passes' if r.get('credible') else 'does NOT pass'} the bar (held-out ROC-AUC {auc})"


def fairness(db: Session) -> dict:
    """Score parity by sourcing region, decomposed into the measured components."""
    df = analytics_service.current_table(db)
    g = df.groupby("region").agg(vendors=("vendor_id", "count"), overall=("overall", "mean"), delivery=("delivery", "mean"),
                                 quality=("quality", "mean"), cost=("cost", "mean"), lead_time=("lead_time", "mean"),
                                 weak=("band", lambda b: float(b.isin(["Watch", "At Risk", "Critical"]).mean() * 100))).round(1).reset_index()
    rows = g.sort_values("overall", ascending=False).to_dict("records")
    gap = round(float(g["overall"].max() - g["overall"].min()), 1) if len(g) else 0.0
    portfolio = round(float(df["overall"].mean()), 1)
    for r in rows:
        diffs = {k: round(r[k] - float(df[k].mean()), 1) for k in ("delivery", "quality", "cost", "lead_time")}
        main = min(diffs, key=diffs.get)
        r["explained_by"] = (f"{main.replace('_', '-')} ({diffs[main]:+.1f} vs average)" if diffs[main] < -1 else "in line with average")
    return {"by_region": rows, "max_gap": gap, "portfolio_avg": portfolio,
            "verdict": "Differences between regions are explained by measured delivery, quality, cost and lead-time results. "
                       "Location is not an input to the score or the risk model.",
            "threshold_note": "Review if the gap between regions exceeds 10 points without a clear performance explanation."}


# ---------------------------------------------------------------- security
def security(db: Session) -> dict:
    from app.governance import guardrails
    from app.security import LOCKOUT_ATTEMPTS, LOCKOUT_WINDOW
    s = get_settings()
    g = guardrails.config(db)["input"]
    gitignore = (REPO_ROOT / ".gitignore")
    env_ignored = gitignore.exists() and ".env" in gitignore.read_text(encoding="utf-8").split()
    audit_events = db.execute(select(func.count()).select_from(AuditEvent)).scalar_one()
    default_db_pw = ":vendor360@" in s.database_url

    def chk(area, name, ok, detail, fix, severity="high"):
        return {"area": area, "check": name, "status": "pass" if ok is True else ("warn" if ok is None else "fail"),
                "detail": detail, "enterprise": fix, "severity": severity}

    checks = [
        chk("Identity", "Sign-in required", s.auth_mode in ("login", "api_key"), f"Mode: {s.auth_mode}",
            "Single sign-on with Microsoft Entra ID, MFA and conditional access"),
        chk("Identity", "Role-based access enforced by the server", True, "business / staff / admin permissions checked on every API call",
            "Roles mapped from Entra ID groups; quarterly access reviews; PIM for admins"),
        chk("Identity", "Login lockout", True, f"{LOCKOUT_ATTEMPTS} failed attempts lock an account for {LOCKOUT_WINDOW // 60} minutes",
            "Handled by Entra ID smart lockout and risk-based sign-in"),
        chk("Identity", "Session lifetime", s.token_ttl_minutes <= 720, f"{s.token_ttl_minutes} minutes, signed tokens (HMAC-SHA256)",
            "Short-lived OIDC tokens with refresh and revocation", "medium"),
        chk("Secrets", "Token signing secret is not the default", s.auth_secret != "dev-only-change-me-vendor360" and len(s.auth_secret) >= 32,
            "Random secret set in .env" if s.auth_secret != "dev-only-change-me-vendor360" else "Default development secret in use",
            "Secrets in Azure Key Vault, read via managed identity, rotated automatically"),
        chk("Secrets", "Demo passwords changed", None if s.demo_admin_password == "Admin@2026" else True,
            "Default demo passwords still in use (acceptable for a local demo only)" if s.demo_admin_password == "Admin@2026" else "Custom passwords set",
            "No local passwords - all users sign in through Entra ID", "medium"),
        chk("Secrets", "Database password", None if default_db_pw else True, "Default local password" if default_db_pw else "Custom password",
            "Passwordless access with managed identity; database on a private endpoint", "medium"),
        chk("Secrets", "Secrets kept out of source control", env_ignored, ".env listed in .gitignore" if env_ignored else ".env is NOT git-ignored",
            "Secret scanning in CI (e.g. GitHub Advanced Security) blocks commits containing keys"),
        chk("Secrets", "AI provider key never sent to the browser", True, "Key used only by the server; the web app never sees it",
            "Azure OpenAI with managed identity - no keys at all"),
        chk("Network", "Encrypted connection to the graph database", s.neo4j_uri.startswith("neo4j+s://") or not s.neo4j_uri,
            "neo4j+s (TLS)" if s.neo4j_uri.startswith("neo4j+s://") else s.neo4j_uri.split("://")[0], "Private endpoints / VNet integration for all data services"),
        chk("Network", "HTTPS for users", None, "Local demo runs on http://localhost", "TLS 1.2+ terminated at Azure Front Door with WAF; HSTS enabled", "medium"),
        chk("Network", "Browser security headers", True, "CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy set on every response",
            "Same headers plus HSTS at the edge"),
        chk("Network", "Allowed web origins (CORS)", "*" not in s.cors_origin_list, ", ".join(s.cors_origin_list), "Locked to the production domain only", "medium"),
        chk("Application", "Input validation", True, "All request bodies validated (Pydantic); vendor IDs and lengths checked",
            "Plus WAF rules and API Management policies"),
        chk("Application", "AI input protection", True, f"Prompt-injection: {g['injection_action']} · personal-data redaction: {'on' if g['pii_redaction'] else 'off'} · rate limit {g['rate_limit_per_minute']}/min",
            "Azure AI Content Safety / Prompt Shields in front of the model"),
        chk("Application", "API documentation exposure", None, "Interactive API docs (/docs) are public in the demo",
            "Disable or put behind sign-in in production", "low"),
        chk("Application", "Dependency vulnerability scanning", None, "Not automated in the hackathon build",
            "pip-audit / npm audit and Dependabot in CI; SBOM per release", "medium"),
        chk("Data", "Only summaries sent to the AI model", True, "Raw transactions never leave the database; the model receives compact KPI facts",
            "Azure OpenAI in Primark's tenant, UK region, no training on customer data"),
        chk("Data", "Audit trail", audit_events > 0, f"{audit_events:,} events recorded (answers, approvals, logins, settings, guardrails)",
            "Stream to Microsoft Sentinel; retain 7 years per policy PP-6"),
        chk("Data", "Sensitive values hidden in logs", True, "Log formatter masks keys, passwords, secrets and tokens", "Same, plus DLP policies"),
    ]
    summary = Counter(c["status"] for c in checks)
    return {"checks": checks, "summary": {"pass": summary.get("pass", 0), "warn": summary.get("warn", 0), "fail": summary.get("fail", 0)},
            "enterprise_plan": ENTERPRISE_PLAN}


ENTERPRISE_PLAN = [
    {"area": "Identity & access", "items": ["Microsoft Entra ID single sign-on with MFA", "Roles from Entra groups (business / staff / admin)", "Privileged Identity Management for admins", "Quarterly access reviews"]},
    {"area": "Secrets & keys", "items": ["Azure Key Vault + managed identities (no passwords in config)", "Automatic key rotation", "Secret scanning in CI"]},
    {"area": "Network", "items": ["Azure Front Door + Web Application Firewall", "Private endpoints for PostgreSQL, Neo4j, Azure OpenAI", "No public database access"]},
    {"area": "Data protection", "items": ["Encryption in transit (TLS 1.2+) and at rest (customer-managed keys)", "UK data residency", "Data classification & DPIA for supplier data", "Retention 7 years (PP-6)"]},
    {"area": "AI-specific", "items": ["Azure OpenAI in Primark tenant - prompts not used for training", "Content Safety & Prompt Shields", "Red-team testing of the assistant before go-live", "Model and prompt versions recorded with every answer"]},
    {"area": "Monitoring & response", "items": ["Defender for Cloud", "Microsoft Sentinel SIEM with alerts on guardrail spikes", "Application Insights tracing", "Incident runbook"]},
    {"area": "Secure delivery", "items": ["SAST / dependency scanning / SBOM in CI", "Penetration test before go-live", "Infrastructure as code with policy checks"]},
]

