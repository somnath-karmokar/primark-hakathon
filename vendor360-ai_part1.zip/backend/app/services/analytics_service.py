"""Read-side analytics for dashboards, Vendor 360, analytics and comparison.

All numbers come from persisted score snapshots / transactions. Results are
cached under the ``analytics`` namespace keyed by data_version.
"""
from __future__ import annotations

from dataclasses import asdict
from datetime import date

import numpy as np
import pandas as pd
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.analytics.scoring import COMPONENT_LABELS, BANDS, analyse_trend, overall_score, score_drivers
from app.models.entities import (
    Category, Contract, Delivery, Invoice, Product, PurchaseOrder, QualityInspection, Recommendation, Vendor,
    VendorProduct, VendorRiskSnapshot, VendorScoreSnapshot,
)
from app.services import runtime_settings
from app.services.cache import analytics_cache, stable_key

COMPONENTS = ["delivery", "quality", "cost", "lead_time"]
SPOTLIGHT_VENDOR = "V1024"
BAND_ORDER = [b for _, b in BANDS]


class VendorNotFound(LookupError):
    pass


# ---------------------------------------------------------------------------
# Cached frames
# ---------------------------------------------------------------------------
def _cached(db: Session, name: str, fn, **tags):
    dv = runtime_settings.data_version(db)
    key = stable_key(name, dv, tags)
    val, _ = analytics_cache.get_or_set(key, fn, tags={"data_version": dv, **tags})
    return val


def snapshots_df(db: Session) -> pd.DataFrame:
    def load():
        rows = db.execute(select(
            VendorScoreSnapshot.vendor_id, VendorScoreSnapshot.period, VendorScoreSnapshot.overall_score,
            VendorScoreSnapshot.delivery_score, VendorScoreSnapshot.quality_score, VendorScoreSnapshot.cost_score,
            VendorScoreSnapshot.lead_time_score, VendorScoreSnapshot.band, VendorScoreSnapshot.kpis,
            VendorScoreSnapshot.data_sufficient)).all()
        df = pd.DataFrame(rows, columns=["vendor_id", "period", "overall", "delivery", "quality", "cost", "lead_time",
                                         "band", "kpis", "data_sufficient"])
        df["period"] = pd.to_datetime(df["period"])
        return df
    return _cached(db, "snapshots", load)


def vendors_df(db: Session) -> pd.DataFrame:
    def load():
        rows = db.execute(select(Vendor.vendor_id, Vendor.name, Vendor.country, Vendor.region, Vendor.tier, Vendor.status,
                                 Vendor.primary_category_id, Category.name.label("category"), Vendor.port)
                          .join(Category, Category.category_id == Vendor.primary_category_id)).all()
        return pd.DataFrame(rows, columns=["vendor_id", "name", "country", "region", "tier", "status", "category_id", "category", "port"])
    return _cached(db, "vendors", load)


def risk_df(db: Session) -> pd.DataFrame:
    def load():
        rows = db.execute(select(VendorRiskSnapshot.vendor_id, VendorRiskSnapshot.period, VendorRiskSnapshot.risk_probability,
                                 VendorRiskSnapshot.risk_level, VendorRiskSnapshot.anomaly_score, VendorRiskSnapshot.is_anomaly)).all()
        return pd.DataFrame(rows, columns=["vendor_id", "period", "risk_probability", "risk_level", "anomaly_score", "is_anomaly"])
    return _cached(db, "risk", load)


def periods(db: Session) -> list[str]:
    s = snapshots_df(db)
    return sorted({p.date().isoformat() for p in s["period"]})


def latest_period(db: Session) -> str | None:
    p = periods(db)
    return p[-1] if p else None


def _trend_table(db: Session, upto: str | None = None) -> pd.DataFrame:
    """Per vendor trend classification computed from its score series up to ``upto``."""
    def compute():
        s = snapshots_df(db)
        if upto:
            s2 = s[s["period"] <= pd.Timestamp(upto)]
        else:
            s2 = s
        drop = runtime_settings.get_runtime(db)["risk"]["deterioration_drop_points"]
        rows = []
        for vid, g in s2.sort_values("period").groupby("vendor_id"):
            t = analyse_trend(g["overall"].tolist(), drop)
            rows.append({"vendor_id": vid, **asdict(t)})
        return pd.DataFrame(rows)
    return _cached(db, "trend_table", compute, upto=upto)


def current_table(db: Session, period: str | None = None) -> pd.DataFrame:
    """One row per vendor: profile + score at ``period`` + trend + risk."""
    period = period or latest_period(db)

    def compute():
        s = snapshots_df(db)
        cur = s[s["period"] == pd.Timestamp(period)].drop(columns=["kpis"])
        df = vendors_df(db).merge(cur, on="vendor_id", how="inner")
        df = df.merge(_trend_table(db, period), on="vendor_id", how="left")
        r = risk_df(db)
        if len(r):
            df = df.merge(r.drop(columns=["period"]), on="vendor_id", how="left")
        else:
            df = df.assign(risk_probability=np.nan, risk_level="Unknown", anomaly_score=np.nan, is_anomaly=False)
        df["rank"] = df["overall"].rank(ascending=False, method="min").astype(int)
        return df
    return _cached(db, "current_table", compute, period=period)


def _apply_filters(df: pd.DataFrame, category: str | None, region: str | None, status: str | None,
                   band: str | None = None, search: str | None = None) -> pd.DataFrame:
    if category:
        df = df[df["category_id"] == category]
    if region:
        df = df[df["region"] == region]
    if status:
        df = df[df["status"] == status]
    if band:
        df = df[df["band"] == band]
    if search:
        q = search.strip().lower()
        df = df[df["vendor_id"].str.lower().str.contains(q, regex=False) | df["name"].str.lower().str.contains(q, regex=False)]
    return df


def _vendor_row(r: pd.Series) -> dict:
    def f(v):
        return None if v is None or (isinstance(v, float) and np.isnan(v)) else v
    return {
        "vendor_id": r["vendor_id"], "name": r["name"], "country": r["country"], "region": r["region"], "tier": r["tier"],
        "status": r["status"], "category_id": r["category_id"], "category": r["category"],
        "overall": round(float(r["overall"]), 1), "delivery": round(float(r["delivery"]), 1), "quality": round(float(r["quality"]), 1),
        "cost": round(float(r["cost"]), 1), "lead_time": round(float(r["lead_time"]), 1), "band": r["band"],
        "trend": f(r.get("direction")), "change_3m": f(r.get("change_3m")), "slope": f(r.get("slope_per_month")),
        "is_deteriorating": bool(r.get("is_deteriorating") or False), "rank": int(r["rank"]),
        "risk_level": f(r.get("risk_level")) or "Unknown", "risk_probability": f(r.get("risk_probability")),
        "is_anomaly": bool(r.get("is_anomaly") or False), "data_sufficient": bool(r["data_sufficient"]),
    }


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
def dashboard_summary(db: Session, period: str | None = None, category: str | None = None,
                      region: str | None = None, status: str | None = None) -> dict:
    period = period or latest_period(db)
    df = _apply_filters(current_table(db, period), category, region, status)
    counts = df["band"].value_counts().to_dict()
    s = snapshots_df(db)
    s = s[s["vendor_id"].isin(df["vendor_id"])]
    s = s[s["period"] <= pd.Timestamp(period)]
    trend = (s.groupby("period").agg(avg=("overall", "mean"), delivery=("delivery", "mean"), quality=("quality", "mean"),
                                     cost=("cost", "mean"), lead_time=("lead_time", "mean"))
             .round(1).reset_index())
    prev_avg = float(trend["avg"].iloc[-2]) if len(trend) >= 2 else None
    cat = (df.groupby(["category_id", "category"]).agg(vendors=("vendor_id", "count"), avg=("overall", "mean"),
                                                         delivery=("delivery", "mean"), quality=("quality", "mean"),
                                                         cost=("cost", "mean"), lead_time=("lead_time", "mean"),
                                                         at_risk=("band", lambda b: int(b.isin(["At Risk", "Critical"]).sum())))
           .round(1).reset_index().sort_values("avg", ascending=False))
    ranked = df.sort_values("overall", ascending=False)
    deteriorating = df[df["is_deteriorating"] == True].sort_values("change_3m")  # noqa: E712
    return {
        "period": period,
        "filters": {"category": category, "region": region, "status": status},
        "operational": operational_kpis(db, period, df) if len(df) else None,
        "kpis": {
            "total_vendors": int(len(df)),
            "avg_score": round(float(df["overall"].mean()), 1) if len(df) else 0.0,
            "avg_score_change": round(float(df["overall"].mean()) - prev_avg, 1) if prev_avg is not None and len(df) else 0.0,
            "excellent": int(counts.get("Excellent", 0)), "good": int(counts.get("Good", 0)),
            "watch": int(counts.get("Watch", 0)), "at_risk": int(counts.get("At Risk", 0)),
            "critical": int(counts.get("Critical", 0)), "deteriorating": int(len(deteriorating)),
            "high_risk": int((df["risk_level"] == "High").sum()) if "risk_level" in df else 0,
        },
        "band_counts": [{"band": b, "count": int(counts.get(b, 0))} for b in BAND_ORDER],
        "distribution": distribution(df),
        "trend": [{"period": p.date().isoformat(), **{k: float(v) for k, v in row.items() if k != "period"}}
                  for p, row in zip(trend["period"], trend.to_dict("records"))],
        "top_vendors": [_vendor_row(r) for _, r in ranked.head(8).iterrows()],
        "bottom_vendors": [_vendor_row(r) for _, r in ranked.tail(8).iloc[::-1].iterrows()],
        "deteriorating_vendors": [_vendor_row(r) for _, r in deteriorating.head(8).iterrows()],
        # Demo spotlight: the scripted deteriorating vendor when present, else the steepest decline.
        "spotlight": next((_vendor_row(r) for _, r in deteriorating[deteriorating["vendor_id"] == SPOTLIGHT_VENDOR].iterrows()),
                          _vendor_row(deteriorating.iloc[0]) if len(deteriorating) else None),
        "category_performance": cat.to_dict("records"),
    }


def distribution(df: pd.DataFrame, width: int = 5) -> list[dict]:
    edges = list(range(0, 100, width))
    out = []
    for lo in edges:
        hi = lo + width
        n = int(((df["overall"] >= lo) & (df["overall"] < hi if hi < 100 else df["overall"] <= 100)).sum())
        mid = lo + width / 2
        band = "Excellent" if lo >= 90 else "Good" if lo >= 75 else "Watch" if lo >= 60 else "At Risk" if lo >= 40 else "Critical"
        out.append({"bucket": f"{lo}-{hi}", "from": lo, "to": hi, "mid": mid, "count": n, "band": band})
    first = next((i for i, b in enumerate(out) if b["count"]), 0)
    return out[max(0, first - 1):]


def filter_options(db: Session) -> dict:
    v = vendors_df(db)
    cats = db.execute(select(Category.category_id, Category.name).order_by(Category.name)).all()
    return {"periods": periods(db), "categories": [{"id": c, "name": n} for c, n in cats],
            "regions": sorted(v["region"].unique().tolist()), "statuses": sorted(v["status"].unique().tolist()),
            "bands": BAND_ORDER}


# ---------------------------------------------------------------------------
# Vendor list / ranking
# ---------------------------------------------------------------------------
SORTABLE = {"overall", "delivery", "quality", "cost", "lead_time", "change_3m", "rank", "name", "vendor_id", "risk_probability"}


def list_vendors(db: Session, *, period: str | None = None, category: str | None = None, region: str | None = None,
                 status: str | None = None, band: str | None = None, search: str | None = None,
                 sort: str = "overall", order: str = "desc", page: int = 1, page_size: int = 25,
                 deteriorating_only: bool = False) -> dict:
    df = _apply_filters(current_table(db, period), category, region, status, band, search)
    if deteriorating_only:
        df = df[df["is_deteriorating"] == True]  # noqa: E712
    sort = sort if sort in SORTABLE else "overall"
    df = df.sort_values(sort, ascending=(order == "asc"), na_position="last")
    total = len(df)
    page = max(1, page)
    items = [_vendor_row(r) for _, r in df.iloc[(page - 1) * page_size: page * page_size].iterrows()]
    return {"items": items, "total": total, "page": page, "page_size": page_size, "period": period or latest_period(db)}


# ---------------------------------------------------------------------------
# Vendor 360
# ---------------------------------------------------------------------------
def get_vendor(db: Session, vendor_id: str) -> Vendor:
    v = db.get(Vendor, vendor_id.upper())
    if not v:
        raise VendorNotFound(vendor_id)
    return v


def vendor_series(db: Session, vendor_id: str) -> pd.DataFrame:
    s = snapshots_df(db)
    return s[s["vendor_id"] == vendor_id].sort_values("period")


def category_benchmark(db: Session, category_id: str, period: str | None = None) -> dict:
    df = current_table(db, period)
    c = df[df["category_id"] == category_id]
    return {k: round(float(c[k].mean()), 1) for k in ["overall", *COMPONENTS]} | {"vendors": int(len(c))}


def score_detail(db: Session, vendor_id: str, period: str | None = None) -> dict:
    v = get_vendor(db, vendor_id)
    series = vendor_series(db, v.vendor_id)
    if series.empty:
        raise VendorNotFound(vendor_id)
    if period:
        series_upto = series[series["period"] <= pd.Timestamp(period)]
    else:
        series_upto = series
    cur, prev3 = series_upto.iloc[-1], (series_upto.iloc[-4] if len(series_upto) >= 4 else series_upto.iloc[0])
    w = runtime_settings.weights(db)
    cur_b = overall_score(cur["delivery"], cur["quality"], cur["cost"], cur["lead_time"], w)
    prev_b = overall_score(prev3["delivery"], prev3["quality"], prev3["cost"], prev3["lead_time"], w)
    drop = runtime_settings.get_runtime(db)["risk"]["deterioration_drop_points"]
    trend = analyse_trend(series_upto["overall"].tolist(), drop)
    return {
        "vendor_id": v.vendor_id, "period": cur["period"].date().isoformat(),
        "breakdown": cur_b.as_dict(), "kpis": cur["kpis"],
        "previous_period": prev3["period"].date().isoformat(), "previous_breakdown": prev_b.as_dict(),
        "drivers": score_drivers(cur_b, prev_b), "trend": asdict(trend),
        "benchmark": category_benchmark(db, v.primary_category_id, cur["period"].date().isoformat()),
        "data_sufficient": bool(cur["data_sufficient"]),
    }


def vendor_trend(db: Session, vendor_id: str) -> list[dict]:
    v = get_vendor(db, vendor_id)
    s = vendor_series(db, v.vendor_id)
    bench = (snapshots_df(db).merge(vendors_df(db)[["vendor_id", "category_id"]], on="vendor_id")
             .query("category_id == @v.primary_category_id").groupby("period")["overall"].mean())
    out = []
    for _, r in s.iterrows():
        k = r["kpis"]
        out.append({"period": r["period"].date().isoformat(), "overall": r["overall"], "delivery": r["delivery"],
                    "quality": r["quality"], "cost": r["cost"], "lead_time": r["lead_time"], "band": r["band"],
                    "category_avg": round(float(bench.get(r["period"], np.nan)), 1),
                    "on_time_pct": k["delivery"]["on_time_pct"], "defect_rate_pct": k["quality"]["defect_rate_pct"],
                    "invoice_variance_pct": k["cost"]["variance_pct"], "lead_time_cv": k["lead_time"]["coefficient_of_variation"]})
    return out


def vendor_profile(db: Session, vendor_id: str) -> dict:
    v = get_vendor(db, vendor_id)
    products = db.execute(select(Product.product_id, Product.name, Product.category_id, Category.name, Product.is_critical,
                                 VendorProduct.is_primary_source)
                          .join(VendorProduct, VendorProduct.product_id == Product.product_id)
                          .join(Category, Category.category_id == Product.category_id)
                          .where(VendorProduct.vendor_id == v.vendor_id)).all()
    contract = db.execute(select(Contract).where(Contract.vendor_id == v.vendor_id)).scalar_one_or_none()
    cat = db.get(Category, v.primary_category_id)
    return {
        "vendor_id": v.vendor_id, "name": v.name, "country": v.country, "region": v.region, "city": v.city, "port": v.port,
        "tier": v.tier, "status": v.status, "category_id": v.primary_category_id, "category": cat.name if cat else "",
        "onboarded_date": v.onboarded_date.isoformat(), "annual_capacity_units": v.annual_capacity_units,
        "sustainability_rating": v.sustainability_rating,
        "products": [{"product_id": p, "name": n, "category_id": c, "category": cn, "is_critical": crit, "is_primary_source": prim}
                     for p, n, c, cn, crit, prim in products],
        "categories": sorted({cn for _, _, _, cn, _, _ in products}),
        "contract": None if not contract else {
            "contract_id": contract.contract_id, "contract_type": contract.contract_type,
            "start_date": contract.start_date.isoformat(), "end_date": contract.end_date.isoformat(),
            "sla_id": contract.sla_id, "sla_otd_target_pct": contract.sla_otd_target_pct,
            "sla_max_defect_rate_pct": contract.sla_max_defect_rate_pct,
            "sla_max_invoice_variance_pct": contract.sla_max_invoice_variance_pct,
            "payment_terms_days": contract.payment_terms_days, "penalty_clause": contract.penalty_clause,
            "exclusivity": contract.exclusivity},
    }


def sla_compliance(profile: dict, kpis: dict) -> list[dict]:
    c = profile.get("contract")
    if not c:
        return []
    checks = [
        ("On-time delivery", kpis["delivery"]["on_time_pct"], c["sla_otd_target_pct"], ">=", "%"),
        ("Defect rate", kpis["quality"]["defect_rate_pct"], c["sla_max_defect_rate_pct"], "<=", "%"),
        ("Invoice variance", kpis["cost"]["variance_pct"], c["sla_max_invoice_variance_pct"], "<=", "%"),
    ]
    out = []
    for name, actual, target, op, unit in checks:
        ok = actual >= target if op == ">=" else actual <= target
        out.append({"metric": name, "actual": round(actual, 2), "target": target, "operator": op, "unit": unit,
                    "status": "met" if ok else "breached", "sla_id": c["sla_id"]})
    return out


def vendor_transactions(db: Session, vendor_id: str, limit: int = 12) -> dict:
    v = get_vendor(db, vendor_id)
    # Recently completed POs show delivery performance; open POs are summarised separately.
    pos = db.execute(select(PurchaseOrder, Product.name).join(Product, Product.product_id == PurchaseOrder.product_id)
                     .where(PurchaseOrder.vendor_id == v.vendor_id, PurchaseOrder.status == "Delivered")
                     .order_by(PurchaseOrder.promised_date.desc()).limit(limit)).all()
    po_ids = [p.po_id for p, _ in pos]
    last_del = {}
    if po_ids:
        for d in db.execute(select(Delivery).where(Delivery.po_id.in_(po_ids))).scalars():
            if d.po_id not in last_del or d.delivered_date > last_del[d.po_id].delivered_date:
                last_del[d.po_id] = d
    issues = db.execute(select(QualityInspection).where(QualityInspection.vendor_id == v.vendor_id, QualityInspection.result == "FAIL")
                        .order_by(QualityInspection.inspection_date.desc()).limit(limit)).scalars().all()
    invs = db.execute(select(Invoice).where(Invoice.vendor_id == v.vendor_id).order_by(Invoice.invoice_date.desc()).limit(60)).scalars().all()
    invs = sorted(invs, key=lambda i: -(i.variance_amount / i.po_value if i.po_value else 0))[:limit]
    open_pos = db.execute(select(PurchaseOrder).where(PurchaseOrder.vendor_id == v.vendor_id, PurchaseOrder.status == "Open")).scalars().all()
    return {
        "purchase_orders": [{
            "po_id": p.po_id, "product": pname, "po_date": p.po_date.isoformat(), "promised_date": p.promised_date.isoformat(),
            "delivered_date": last_del[p.po_id].delivered_date.isoformat() if p.po_id in last_del else None,
            "days_late": max(0, (last_del[p.po_id].delivered_date - p.promised_date).days) if p.po_id in last_del else None,
            "value": round(p.expected_value, 2), "status": p.status, "is_critical": p.is_critical,
        } for p, pname in pos],
        "quality_issues": [{"inspection_id": q.inspection_id, "po_id": q.po_id, "date": q.inspection_date.isoformat(),
                            "inspected_qty": q.inspected_qty, "defect_qty": q.defect_qty, "rejected_qty": q.rejected_qty,
                            "defect_rate_pct": round(q.defect_qty / q.inspected_qty * 100, 2) if q.inspected_qty else 0,
                            "reason": q.rejection_reason or "AQL failure"} for q in issues],
        "invoice_variance": [{"invoice_id": i.invoice_id, "po_id": i.po_id, "date": i.invoice_date.isoformat(),
                              "po_value": round(i.po_value, 2), "invoice_value": round(i.invoice_value, 2),
                              "variance_amount": round(i.variance_amount, 2),
                              "variance_pct": round(i.variance_amount / i.po_value * 100, 2) if i.po_value else 0,
                              "status": i.status} for i in invs],
        "open_pos": {"count": len(open_pos), "value": round(sum(p.expected_value for p in open_pos), 2)},
    }


def vendor_recommendations(db: Session, vendor_id: str) -> list[dict]:
    recs = db.execute(select(Recommendation).where(Recommendation.vendor_id == vendor_id.upper())
                      .order_by(Recommendation.created_at.desc()).limit(10)).scalars().all()
    return [recommendation_dict(r) for r in recs]


def recommendation_dict(r: Recommendation) -> dict:
    return {"id": r.id, "vendor_id": r.vendor_id, "action": r.action, "title": r.title, "rationale": r.rationale,
            "alternatives": r.alternatives, "evidence": r.evidence, "policy_refs": r.policy_refs,
            "confidence": r.confidence, "requires_approval": r.requires_approval, "status": r.status,
            "governance": r.governance, "source": r.source, "request_id": r.request_id, "created_by": r.created_by,
            "created_at": r.created_at.isoformat() if r.created_at else None, "decided_by": r.decided_by,
            "decided_at": r.decided_at.isoformat() if r.decided_at else None, "decision_note": r.decision_note}


# ---------------------------------------------------------------------------
# Performance analytics
# ---------------------------------------------------------------------------
def performance_analytics(db: Session, period: str | None = None, category: str | None = None, region: str | None = None) -> dict:
    period = period or latest_period(db)
    df = _apply_filters(current_table(db, period), category, region, None)
    s = snapshots_df(db)
    latest_kpis = s[s["period"] == pd.Timestamp(period)].set_index("vendor_id")["kpis"]
    pts = []
    for _, r in df.iterrows():
        k = latest_kpis.get(r["vendor_id"])
        pts.append({"vendor_id": r["vendor_id"], "name": r["name"], "category": r["category"], "band": r["band"],
                    "overall": round(r["overall"], 1), "delivery": round(r["delivery"], 1), "quality": round(r["quality"], 1),
                    "cost": round(r["cost"], 1), "lead_time": round(r["lead_time"], 1),
                    "benchmark_variance_pct": k["cost"]["benchmark_variance_pct"] if k else None,
                    "lead_time_cv": k["lead_time"]["coefficient_of_variation"] if k else None,
                    "avg_lead_days": k["lead_time"]["avg_actual_days"] if k else None,
                    "on_time_pct": k["delivery"]["on_time_pct"] if k else None})
    # Segments that matter to buyers
    segments = {
        "strong_quality_weak_delivery": df[(df["quality"] >= 85) & (df["delivery"] < 70)],
        "low_cost_poor_quality": df[(df["cost"] >= 90) & (df["quality"] < 65)],
        "premium_high_quality": df[(df["cost"] < 75) & (df["quality"] >= 90)],
        "variable_lead_time": df[(df["lead_time"] < 65) & (df["delivery"] >= 70)],
    }
    by_cat = (df.groupby("category").agg(avg=("overall", "mean"), delivery=("delivery", "mean"), quality=("quality", "mean"),
                                         cost=("cost", "mean"), lead_time=("lead_time", "mean"), vendors=("vendor_id", "count"))
              .round(1).reset_index().sort_values("avg", ascending=False))
    by_region = (df.groupby("region").agg(avg=("overall", "mean"), vendors=("vendor_id", "count")).round(1)
                 .reset_index().sort_values("avg", ascending=False))
    trend_dir = df["direction"].value_counts().to_dict() if "direction" in df else {}
    return {
        "period": period, "points": pts, "distribution": distribution(df),
        "category_comparison": by_cat.to_dict("records"), "region_comparison": by_region.to_dict("records"),
        "ranking": [_vendor_row(r) for _, r in df.sort_values("overall", ascending=False).head(25).iterrows()],
        "deterioration": [_vendor_row(r) for _, r in df[df["is_deteriorating"] == True].sort_values("change_3m").head(20).iterrows()],  # noqa: E712
        "trend_directions": {k: int(v) for k, v in trend_dir.items()},
        "segments": {k: {"count": int(len(v)), "vendors": [_vendor_row(r) for _, r in v.sort_values("overall").head(6).iterrows()]}
                     for k, v in segments.items()},
    }


def compare_vendors(db: Session, vendor_ids: list[str]) -> dict:
    ids = [v.upper() for v in vendor_ids]
    cur = current_table(db)
    df = cur[cur["vendor_id"].isin(ids)]
    missing = sorted(set(ids) - set(df["vendor_id"]))
    if missing:
        raise VendorNotFound(", ".join(missing))
    s = snapshots_df(db)
    series = {vid: [{"period": p.date().isoformat(), "overall": o} for p, o in zip(g["period"], g["overall"])]
              for vid, g in s[s["vendor_id"].isin(ids)].sort_values("period").groupby("vendor_id")}
    rows = [_vendor_row(r) for _, r in df.set_index("vendor_id").loc[ids].reset_index().iterrows()]
    best = {c: max(rows, key=lambda r: r[c])["vendor_id"] for c in ["overall", *COMPONENTS]}
    return {"vendors": rows, "series": series, "best": best,
            "components": [{"key": c, "label": COMPONENT_LABELS[c]} for c in COMPONENTS]}


def underperformers(db: Session, limit: int = 10) -> list[dict]:
    df = current_table(db)
    df = df[df["band"].isin(["At Risk", "Critical"])].sort_values("overall")
    return [_vendor_row(r) for _, r in df.head(limit).iterrows()]


def most_deteriorated(db: Session, limit: int = 10) -> list[dict]:
    df = current_table(db).sort_values("change_3m")
    return [_vendor_row(r) for _, r in df.head(limit).iterrows()]


def latest_date() -> date:
    return date.today()


# ---------------------------------------------------------------------------
# Operational & commercial KPIs (deterministic, from transactions + snapshot KPIs)
# ---------------------------------------------------------------------------
WEAK_BANDS = ("Watch", "At Risk", "Critical")
INVOICE_TOLERANCE_PCT = 1.0     # CTG-2


def _window(period: str) -> tuple[pd.Timestamp, pd.Timestamp]:
    end = pd.Timestamp(period)
    start = (end - pd.offsets.MonthBegin(1)) - pd.DateOffset(months=2)
    return start.normalize(), end


def _operational_for(db: Session, period: str, vendor_ids: list[str], bands: dict[str, str]) -> dict:
    from app.services.scoring_service import frames
    fr = frames()
    ws, we = _window(period)
    inv = fr.invoices[(fr.invoices["invoice_date"] >= ws) & (fr.invoices["invoice_date"] <= we) & fr.invoices["vendor_id"].isin(vendor_ids)]
    spend = float(inv["invoice_value"].sum())
    weak = [v for v in vendor_ids if bands.get(v) in WEAK_BANDS]
    spend_weak = float(inv.loc[inv["vendor_id"].isin(weak), "invoice_value"].sum())
    var_pct = (inv["variance_amount"] / inv["po_value"]).abs() * 100
    accuracy = float((var_pct <= INVOICE_TOLERANCE_PCT).mean() * 100) if len(inv) else None

    s = snapshots_df(db)
    k = s[(s["period"] == pd.Timestamp(period)) & s["vendor_id"].isin(vendor_ids)]
    tot = {"pos": 0, "on_time": 0, "insp": 0, "defects": 0, "lt_n": 0, "lt_actual": 0.0, "lt_var": 0.0, "lt_overrun": 0.0}
    contracts = {c.vendor_id: c for c in db.execute(select(Contract).where(Contract.vendor_id.in_(vendor_ids))).scalars()}
    sla_ok = sla_n = breaches = 0
    for vid, kp in zip(k["vendor_id"], k["kpis"]):
        d, q, c, lt = kp["delivery"], kp["quality"], kp["cost"], kp["lead_time"]
        tot["pos"] += d["total_pos"]
        tot["on_time"] += d["on_time_pos"]
        tot["insp"] += q["inspected_qty"]
        tot["defects"] += q["defect_qty"]
        n = lt["records"]
        tot["lt_n"] += n
        tot["lt_actual"] += lt["avg_actual_days"] * n
        tot["lt_var"] += lt["avg_variance_days"] * n
        tot["lt_overrun"] += lt["avg_overrun_pct"] * n
        ct = contracts.get(vid)
        if ct and d["total_pos"]:
            checks = [d["on_time_pct"] >= ct.sla_otd_target_pct, q["defect_rate_pct"] <= ct.sla_max_defect_rate_pct,
                      c["variance_pct"] <= ct.sla_max_invoice_variance_pct]
            sla_n += 1
            sla_ok += all(checks)
            breaches += checks.count(False)

    def r(v, n=1):
        return None if v is None else round(v, n)
    return {
        "spend": r(spend, 0), "spend_at_risk": r(spend_weak, 0),
        "spend_at_risk_pct": r(spend_weak / spend * 100) if spend else None,
        "on_time_delivery_pct": r(tot["on_time"] / tot["pos"] * 100) if tot["pos"] else None,
        "defect_rate_pct": r(tot["defects"] / tot["insp"] * 100, 2) if tot["insp"] else None,
        "invoice_accuracy_pct": r(accuracy),
        "avg_lead_time_days": r(tot["lt_actual"] / tot["lt_n"]) if tot["lt_n"] else None,
        "avg_lead_time_variance_days": r(tot["lt_var"] / tot["lt_n"]) if tot["lt_n"] else None,
        "avg_overrun_pct": r(tot["lt_overrun"] / tot["lt_n"]) if tot["lt_n"] else None,
        "sla_compliance_pct": r(sla_ok / sla_n * 100) if sla_n else None, "sla_breaches": breaches,
        "pos_completed": tot["pos"],
    }


def operational_kpis(db: Session, period: str, df: pd.DataFrame) -> dict:
    """Window KPIs for the filtered vendor set, with the prior period for deltas."""
    ids = df["vendor_id"].tolist()

    def compute():
        bands = dict(zip(df["vendor_id"], df["band"]))
        cur = _operational_for(db, period, ids, bands)
        ps = periods(db)
        prev = None
        if period in ps and ps.index(period) > 0:
            pp = ps[ps.index(period) - 1]
            pt = current_table(db, pp)
            prev = _operational_for(db, pp, ids, dict(zip(pt["vendor_id"], pt["band"])))
        open_pos = db.execute(select(func.count(), func.coalesce(func.sum(PurchaseOrder.expected_value), 0))
                              .where(PurchaseOrder.status == "Open", PurchaseOrder.vendor_id.in_(ids))).one()
        weak = [v for v, b in bands.items() if b in WEAK_BANDS]
        open_weak = db.execute(select(func.coalesce(func.sum(PurchaseOrder.expected_value), 0))
                               .where(PurchaseOrder.status == "Open", PurchaseOrder.vendor_id.in_(weak))).scalar_one() if weak else 0
        pending = db.execute(select(func.count()).select_from(Recommendation).where(Recommendation.status == "pending_approval")).scalar_one()
        delta = {key: (round(cur[key] - prev[key], 2) if prev and cur[key] is not None and prev.get(key) is not None else None)
                 for key in cur if isinstance(cur[key], (int, float))}
        ws, we = _window(period)
        return {**cur, "delta": delta, "window": {"start": ws.date().isoformat(), "end": we.date().isoformat()},
                "open_po_count": int(open_pos[0]), "open_po_value": round(float(open_pos[1]), 0),
                "open_po_value_at_risk": round(float(open_weak), 0), "pending_approvals": int(pending),
                "invoice_tolerance_pct": INVOICE_TOLERANCE_PCT}
    return _cached(db, "operational", compute, period=period, n=len(ids), h=hash(tuple(ids)))


def vendor_commercials(db: Session, vendor_id: str, period: str | None = None) -> dict:
    """Vendor spend in the score window and its share of category spend (PP-3.3 concentration limit 35%)."""
    from app.services.scoring_service import frames
    period = period or latest_period(db)
    v = get_vendor(db, vendor_id)
    fr = frames()
    ws, we = _window(period)
    inv = fr.invoices[(fr.invoices["invoice_date"] >= ws) & (fr.invoices["invoice_date"] <= we)]
    inv = inv.merge(fr.pos[["po_id", "category_id"]], on="po_id", how="left")
    mine = inv[inv["vendor_id"] == v.vendor_id]
    by_cat = []
    for cat_id, g in mine.groupby("category_id"):
        cat_total = float(inv.loc[inv["category_id"] == cat_id, "invoice_value"].sum())
        share = float(g["invoice_value"].sum()) / cat_total * 100 if cat_total else 0.0
        cat = db.get(Category, cat_id)
        by_cat.append({"category_id": cat_id, "category": cat.name if cat else cat_id, "spend": round(float(g["invoice_value"].sum()), 0),
                       "share_pct": round(share, 1), "over_limit": share > 35.0})
    by_cat.sort(key=lambda x: -x["spend"])
    open_val = db.execute(select(func.coalesce(func.sum(PurchaseOrder.expected_value), 0))
                          .where(PurchaseOrder.vendor_id == v.vendor_id, PurchaseOrder.status == "Open")).scalar_one()
    return {"window": {"start": ws.date().isoformat(), "end": we.date().isoformat()},
            "spend": round(float(mine["invoice_value"].sum()), 0), "open_po_value": round(float(open_val), 0),
            "category_share": by_cat, "max_share_pct": max((c["share_pct"] for c in by_cat), default=0.0),
            "concentration_limit_pct": 35.0, "policy": "PP-3.3"}
