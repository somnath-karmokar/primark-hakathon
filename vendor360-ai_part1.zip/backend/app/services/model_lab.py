"""Model Lab service: run experiments, persist runs, promote a champion, anomaly lab."""
from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone

import numpy as np
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.governance.audit import audit
from app.ml import lab
from app.ml.algorithms import ALGORITHMS, DEFAULT_ALGORITHM
from app.ml.risk_model import build_feature_frame, detect_anomalies, prepare_dataset
from app.models.entities import MLModelRun
from app.services import analytics_service, cache, runtime_settings

DEFAULT_DROP_POINTS = 6.0


def algorithms() -> list[dict]:
    return [{"key": a.key, "label": a.label, "family": a.family, "description": a.description, "tree": a.tree,
             "params": [p.__dict__ for p in a.params]} for a in ALGORITHMS.values()]


def run_dict(r: MLModelRun) -> dict:
    return {"id": r.id, "experiment_id": r.experiment_id, "algorithm": r.algorithm,
            "algorithm_label": ALGORITHMS[r.algorithm].label if r.algorithm in ALGORITHMS else r.algorithm,
            "params": r.params, "dataset": r.dataset, "metrics": r.metrics, "curves": r.curves, "importance": r.importance,
            "credible": r.credible, "credibility_reason": r.credibility_reason, "is_active": r.is_active,
            "train_seconds": r.train_seconds, "trained_by": r.trained_by, "created_at": r.created_at.isoformat(),
            "promoted_at": r.promoted_at.isoformat() if r.promoted_at else None}


def active_run(db: Session) -> MLModelRun | None:
    return db.execute(select(MLModelRun).where(MLModelRun.is_active.is_(True)).order_by(MLModelRun.promoted_at.desc())).scalars().first()


def active_config(db: Session) -> dict:
    """Algorithm + params + label used by the production risk model."""
    r = active_run(db)
    if r and r.algorithm in ALGORITHMS:
        return {"algorithm": r.algorithm, "params": r.params, "drop_points": r.dataset.get("drop_points", DEFAULT_DROP_POINTS), "run_id": r.id}
    return {"algorithm": DEFAULT_ALGORITHM, "params": None, "drop_points": DEFAULT_DROP_POINTS, "run_id": None}


def dataset(db: Session, drop_points: float = DEFAULT_DROP_POINTS, test_periods: int = 1) -> dict:
    ds = prepare_dataset(analytics_service.snapshots_df(db), drop_points, test_periods)
    return lab.dataset_summary(ds)


def train(db: Session, candidates: list[dict], drop_points: float, test_periods: int, actor: str) -> dict:
    t0 = time.perf_counter()
    ds = prepare_dataset(analytics_service.snapshots_df(db), drop_points, test_periods)
    summary = {**lab.dataset_summary(ds), "drop_points": drop_points, "test_period_count": test_periods,
               "data_version": runtime_settings.data_version(db)}
    exp = "exp-" + uuid.uuid4().hex[:8]
    runs = []
    for c in candidates:
        res = lab.evaluate(c["algorithm"], c.get("params"), ds)
        if "error" in res:
            runs.append({"algorithm": c["algorithm"], "error": res["error"]})
            continue
        row = MLModelRun(experiment_id=exp, algorithm=res["algorithm"], params=res["params"], dataset=summary, metrics=res["metrics"],
                         curves=res["curves"], importance=res["importance"], credible=res["credible"],
                         credibility_reason=res["credibility_reason"], is_active=False, train_seconds=res["train_seconds"],
                         trained_by=actor)
        db.add(row)
        db.flush()
        runs.append(run_dict(row))
    ok = [r for r in runs if "error" not in r]
    best = max(ok, key=lambda r: (r["credible"], r["metrics"]["pr_auc"] or 0, r["metrics"]["roc_auc"] or 0)) if ok else None
    audit(db, request_id=exp, actor=actor, event_type="model_training", entity_type="ml_experiment", entity_id=exp,
          summary=f"Trained {len(ok)} model(s); best {best['algorithm_label']} PR-AUC {best['metrics']['pr_auc']}" if best else "Training produced no model",
          details={"candidates": [{"algorithm": r["algorithm"], "roc_auc": r.get("metrics", {}).get("roc_auc"),
                                   "pr_auc": r.get("metrics", {}).get("pr_auc"), "credible": r.get("credible")} for r in runs],
                   "dataset": {k: summary[k] for k in ("n_train", "n_test", "positives_train", "positives_test", "label_definition")}})
    return {"experiment_id": exp, "dataset": summary, "runs": runs, "best_run_id": best["id"] if best else None,
            "seconds": round(time.perf_counter() - t0, 2)}


def runs(db: Session, limit: int = 60) -> list[dict]:
    return [run_dict(r) for r in db.execute(select(MLModelRun).where(MLModelRun.algorithm.in_(list(ALGORITHMS)))
                                                     .order_by(MLModelRun.created_at.desc()).limit(limit)).scalars()]


def promote(db: Session, run_id: int, actor: str) -> dict:
    from app.services import risk_service
    r = db.get(MLModelRun, run_id)
    if not r:
        raise LookupError(run_id)
    if not r.credible:
        raise ValueError(f"Run {run_id} did not pass the credibility gate: {r.credibility_reason}")
    db.execute(update(MLModelRun).values(is_active=False))
    r.is_active, r.promoted_at = True, datetime.now(timezone.utc)
    db.flush()
    result = risk_service.train_and_score(db)       # retrains the production model with the promoted config
    cache.invalidate_data()
    audit(db, request_id=r.experiment_id, actor=actor, event_type="model_promoted", entity_type="ml_model_run", entity_id=str(r.id),
          summary=f"Promoted {ALGORITHMS[r.algorithm].label} (run #{r.id}) to production risk model",
          details={"params": r.params, "metrics": {k: r.metrics.get(k) for k in ("roc_auc", "pr_auc", "f1")}, "rescore": result})
    return {"promoted": run_dict(r), "rescore": result}


def reset_to_default(db: Session, actor: str) -> dict:
    from app.services import risk_service
    db.execute(update(MLModelRun).values(is_active=False))
    db.flush()
    result = risk_service.train_and_score(db)
    cache.invalidate_data()
    audit(db, request_id="-", actor=actor, event_type="model_promoted", entity_type="ml_model_run", entity_id="default",
          summary="Reverted production risk model to the default XGBoost configuration", details={"rescore": result})
    return {"rescore": result}


def anomaly_lab(db: Session, contamination: float, n_estimators: int) -> dict:
    """Unsupervised IsolationForest on the latest period. No labels exist, so we report a
    label-free sanity check: how over-represented weak / deteriorating vendors are among the flags."""
    from sklearn.ensemble import IsolationForest  # noqa: F401  (used inside detect_anomalies)
    t0 = time.perf_counter()
    feats = build_feature_frame(analytics_service.snapshots_df(db))
    cur = feats[feats["period"] == feats["period"].max()].copy()
    res = detect_anomalies(cur, contamination=contamination, n_estimators=n_estimators)
    table = analytics_service.current_table(db).set_index("vendor_id")
    res = res.join(table[["name", "band", "overall", "is_deteriorating"]], on="vendor_id")
    weak = res["band"].isin(["Watch", "At Risk", "Critical"]) | res["is_deteriorating"].fillna(False)
    flagged = res[res["is_anomaly"]]
    base = float(weak.mean())
    share = float(weak[res["is_anomaly"]].mean()) if len(flagged) else 0.0
    hist, edges = np.histogram(res["anomaly_score"], bins=20, range=(0, 1))
    return {
        "algorithm": "IsolationForest", "params": {"contamination": contamination, "n_estimators": n_estimators},
        "period": str(cur["period"].max())[:10], "vendors": int(len(res)), "flagged": int(len(flagged)),
        "sanity_check": {"weak_share_among_flagged": round(share, 3), "weak_share_overall": round(base, 3),
                         "lift": round(share / base, 2) if base else None,
                         "note": "Label-free check: anomalies should be enriched for Watch-or-worse / deteriorating vendors."},
        "histogram": [{"from": round(float(edges[i]), 2), "count": int(hist[i])} for i in range(len(hist))],
        "top": [{"vendor_id": r["vendor_id"], "name": r["name"], "band": r["band"], "overall": round(float(r["overall"]), 1),
                 "anomaly_score": round(float(r["anomaly_score"]), 3), "reasons": [x["label"] for x in r["anomaly_reasons"]]}
                for _, r in flagged.sort_values("anomaly_score", ascending=False).head(15).iterrows()],
        "seconds": round(time.perf_counter() - t0, 2),
    }
