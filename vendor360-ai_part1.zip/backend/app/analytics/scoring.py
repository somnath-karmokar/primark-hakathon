"""Deterministic vendor performance scoring engine (the P0 capability).

Pure functions, no I/O, no LLM. Every formula here is documented in
``docs/SCORING.md`` and covered by ``tests/test_scoring.py``.

    Overall = Delivery x w_d + Quality x w_q + Cost x w_c + LeadTime x w_l

Each component is a 0-100 score built from the KPIs of a scoring window.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

SCORING_MODEL_VERSION = "vps-1.3"


def clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


# ---------------------------------------------------------------------------
# Weights & bands
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ScoringWeights:
    delivery: float = 0.30
    quality: float = 0.30
    cost: float = 0.20
    lead_time: float = 0.20

    def validate(self) -> "ScoringWeights":
        vals = [self.delivery, self.quality, self.cost, self.lead_time]
        if any(v < 0 for v in vals):
            raise ValueError("Scoring weights must be non-negative")
        if abs(sum(vals) - 1.0) > 1e-6:
            raise ValueError(f"Scoring weights must sum to 1.0 (got {sum(vals):.3f})")
        return self

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


BANDS: list[tuple[float, str]] = [
    (90, "Excellent"),
    (75, "Good"),
    (60, "Watch"),
    (40, "At Risk"),
    (0, "Critical"),
]


def score_band(score: float) -> str:
    """90-100 Excellent, 75-89 Good, 60-74 Watch, 40-59 At Risk, 0-39 Critical.

    Bands are applied to the score rounded to one decimal, matching what users see.
    """
    s = round(score, 1)
    for floor, label in BANDS:
        if s >= floor:
            return label
    return "Critical"


# ---------------------------------------------------------------------------
# KPI containers (computed by app.analytics.metrics from transactions)
# ---------------------------------------------------------------------------
@dataclass
class DeliveryKPIs:
    total_pos: int = 0
    on_time_pos: int = 0
    late_pos: int = 0
    on_time_pct: float = 0.0
    avg_delay_days: float = 0.0      # mean days late across late POs
    avg_lateness_days: float = 0.0   # mean days late across ALL POs (on-time = 0)
    max_delay_days: int = 0
    critical_pos: int = 0
    critical_late_pos: int = 0


@dataclass
class QualityKPIs:
    inspections: int = 0
    failed_inspections: int = 0
    inspected_qty: int = 0
    defect_qty: int = 0
    rejected_qty: int = 0
    defect_rate_pct: float = 0.0
    rejection_rate_pct: float = 0.0
    inspection_failure_rate_pct: float = 0.0
    top_rejection_reasons: list[dict] = field(default_factory=list)


@dataclass
class CostKPIs:
    invoices: int = 0
    po_value: float = 0.0
    invoice_value: float = 0.0
    variance_amount: float = 0.0
    variance_pct: float = 0.0              # (invoice - PO) / PO over the window
    avg_cost_variance_pct: float = 0.0     # mean of per-invoice variance %
    benchmark_variance_pct: float = 0.0    # unit price vs category product benchmark
    disputed_invoices: int = 0


@dataclass
class LeadTimeKPIs:
    records: int = 0
    avg_promised_days: float = 0.0
    avg_actual_days: float = 0.0
    avg_variance_days: float = 0.0
    std_dev_days: float = 0.0
    coefficient_of_variation: float = 0.0  # CV of actual/promised ratio
    avg_overrun_pct: float = 0.0           # mean of max(0, actual-promised)/promised
    consistency_score: float = 0.0


# ---------------------------------------------------------------------------
# Component scores
# ---------------------------------------------------------------------------
def delivery_score(k: DeliveryKPIs) -> float:
    """75% on-time rate + 25% lateness severity - critical-PO penalty.

    severity = 100 - 8 x mean lateness across ALL POs (on-time POs count as 0 days)
    penalty  = 20 x share of all POs that were critical AND late

    Both terms are proportions of the whole window, so one very late PO in a
    small window cannot swing the score disproportionately.
    """
    if k.total_pos == 0:
        return 0.0
    severity = clamp(100 - 8.0 * k.avg_lateness_days)
    penalty = 20.0 * (k.critical_late_pos / k.total_pos)
    return round(clamp(0.75 * k.on_time_pct + 0.25 * severity - penalty), 2)


def quality_score(k: QualityKPIs) -> float:
    """60% defect rate, 25% inspection pass rate, 15% rejection rate.

    defect component    = 100 - 10 x defect rate %   (2% -> 80, 5% -> 50)
    pass component      = 100 - 2  x failure rate %  (10% fail -> 80)
    rejection component = 100 - 10 x rejection rate %

    The defect rate is pooled over every inspected unit, so it carries the most weight.
    """
    if k.inspections == 0:
        return 0.0
    defect_c = clamp(100 - 10.0 * k.defect_rate_pct)
    pass_c = clamp(100 - 2.0 * k.inspection_failure_rate_pct)
    reject_c = clamp(100 - 10.0 * k.rejection_rate_pct)
    return round(0.6 * defect_c + 0.25 * pass_c + 0.15 * reject_c, 2)


def cost_score(k: CostKPIs) -> float:
    """50% invoice discipline + 50% price competitiveness.

    invoice discipline = 100 - 12 x invoice over-billing % (under-billing is not rewarded)
    competitiveness    = 100 - 4 x unit price premium vs category benchmark %
    """
    if k.invoices == 0:
        return 0.0
    discipline = clamp(100 - 12.0 * max(0.0, k.variance_pct))
    competitiveness = clamp(100 - 4.0 * max(0.0, k.benchmark_variance_pct))
    return round(0.5 * discipline + 0.5 * competitiveness, 2)


def lead_time_consistency(cv: float) -> float:
    """Consistency = 100 - 250 x CV (CV 0.04 -> 90, 0.20 -> 50, >=0.40 -> 0)."""
    return round(clamp(100 - 250.0 * cv), 2)


def lead_time_score(k: LeadTimeKPIs) -> float:
    """60% consistency + 40% adherence (100 - 3 x average overrun %).

    Using the CV of the actual/promised ratio means two suppliers with the same
    *average* lead time score differently when one is much more variable.
    """
    if k.records == 0:
        return 0.0
    adherence = clamp(100 - 3.0 * k.avg_overrun_pct)
    return round(0.6 * lead_time_consistency(k.coefficient_of_variation) + 0.4 * adherence, 2)


# ---------------------------------------------------------------------------
# Overall score
# ---------------------------------------------------------------------------
@dataclass
class ScoreBreakdown:
    delivery: float
    quality: float
    cost: float
    lead_time: float
    overall: float
    band: str
    weights: dict[str, float]
    contributions: dict[str, float]   # weighted points each component contributes
    points_lost: dict[str, float]      # weighted points lost vs a perfect 100
    data_sufficient: bool
    model_version: str = SCORING_MODEL_VERSION

    def as_dict(self) -> dict:
        return asdict(self)


MIN_POS_FOR_CONFIDENT_SCORE = 3


def overall_score(delivery: float, quality: float, cost: float, lead_time: float,
                  weights: ScoringWeights | None = None, *, data_sufficient: bool = True) -> ScoreBreakdown:
    w = (weights or ScoringWeights()).validate()
    comps = {"delivery": delivery, "quality": quality, "cost": cost, "lead_time": lead_time}
    wmap = w.as_dict()
    contributions = {k: round(v * wmap[k], 2) for k, v in comps.items()}
    total = round(sum(v * wmap[k] for k, v in comps.items()), 2)
    lost = {k: round((100 - v) * wmap[k], 2) for k, v in comps.items()}
    return ScoreBreakdown(delivery=round(delivery, 2), quality=round(quality, 2), cost=round(cost, 2),
                          lead_time=round(lead_time, 2), overall=total, band=score_band(total), weights=wmap,
                          contributions=contributions, points_lost=lost, data_sufficient=data_sufficient)


def score_from_kpis(d: DeliveryKPIs, q: QualityKPIs, c: CostKPIs, lt: LeadTimeKPIs,
                    weights: ScoringWeights | None = None) -> ScoreBreakdown:
    sufficient = d.total_pos >= MIN_POS_FOR_CONFIDENT_SCORE and q.inspections > 0 and c.invoices > 0
    # A component with no observations in the window is neutral (scored at the
    # population-agnostic midpoint of 70) instead of 0 so missing data does not
    # masquerade as terrible performance; the snapshot is flagged insufficient.
    ds = delivery_score(d) if d.total_pos else 70.0
    qs = quality_score(q) if q.inspections else 70.0
    cs = cost_score(c) if c.invoices else 70.0
    ls = lead_time_score(lt) if lt.records else 70.0
    return overall_score(ds, qs, cs, ls, weights, data_sufficient=sufficient)


# ---------------------------------------------------------------------------
# Trend analysis
# ---------------------------------------------------------------------------
@dataclass
class TrendResult:
    direction: str            # improving | stable | declining | deteriorating
    slope_per_month: float
    change_3m: float
    change_6m: float
    peak_score: float
    drop_from_peak: float
    is_deteriorating: bool


def linear_slope(values: list[float]) -> float:
    n = len(values)
    if n < 2:
        return 0.0
    xs = list(range(n))
    mx, my = sum(xs) / n, sum(values) / n
    den = sum((x - mx) ** 2 for x in xs)
    return round(sum((x - mx) * (y - my) for x, y in zip(xs, values)) / den, 3) if den else 0.0


def analyse_trend(series: list[float], drop_threshold: float = 8.0) -> TrendResult:
    """Classify a chronological score series (oldest first).

    deteriorating: dropped >= ``drop_threshold`` points over 3 months or from the
                   6-month peak while the 6-month slope is <= -1.5 points/month.
    declining:     slope <= -0.75 points/month.
    improving:     slope >= +0.75 points/month.
    """
    if not series:
        return TrendResult("stable", 0.0, 0.0, 0.0, 0.0, 0.0, False)
    recent = series[-6:]
    slope = linear_slope(recent)
    cur = series[-1]
    change_3m = round(cur - series[-4], 2) if len(series) >= 4 else round(cur - series[0], 2)
    change_6m = round(cur - series[-7], 2) if len(series) >= 7 else round(cur - series[0], 2)
    peak = max(recent)
    drop = round(peak - cur, 2)
    # Sustained decline required: a one-off noisy month does not make a vendor "deteriorating".
    deteriorating = slope <= -1.5 and (change_3m <= -drop_threshold or drop >= drop_threshold)
    if deteriorating:
        direction = "deteriorating"
    elif slope <= -0.75:
        direction = "declining"
    elif slope >= 0.75:
        direction = "improving"
    else:
        direction = "stable"
    return TrendResult(direction, slope, change_3m, change_6m, round(peak, 2), drop, deteriorating)


# ---------------------------------------------------------------------------
# Score drivers - deterministic "why"
# ---------------------------------------------------------------------------
COMPONENT_LABELS = {"delivery": "Delivery", "quality": "Quality", "cost": "Cost", "lead_time": "Lead-time reliability"}


def score_drivers(current: ScoreBreakdown, previous: ScoreBreakdown | None = None) -> list[dict]:
    """Rank the components that cost the vendor the most points, and those that moved.

    Returns structured drivers (never prose generated by a model):
      {component, label, score, weighted_points_lost, change, direction, impact}
    """
    drivers = []
    for comp in ("delivery", "quality", "cost", "lead_time"):
        score = getattr(current, comp)
        change = round(score - getattr(previous, comp), 2) if previous else 0.0
        weighted_change = round(change * current.weights[comp], 2)
        drivers.append({
            "component": comp,
            "label": COMPONENT_LABELS[comp],
            "score": score,
            "weighted_points_lost": current.points_lost[comp],
            "change": change,
            "weighted_change": weighted_change,
            "direction": "down" if change < -1 else "up" if change > 1 else "flat",
            "impact": "negative" if (score < 75 or change <= -5) else "positive" if score >= 90 else "neutral",
        })
    drivers.sort(key=lambda d: (d["weighted_change"], -d["weighted_points_lost"]))
    return drivers
