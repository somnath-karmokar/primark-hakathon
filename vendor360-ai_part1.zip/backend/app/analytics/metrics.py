"""KPI calculation from transactional data (deterministic SQL/pandas analytics).

The LLM never sees these rows - only the KPI summaries produced here.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

import numpy as np
import pandas as pd
from sqlalchemy.engine import Engine

from app.analytics.scoring import CostKPIs, DeliveryKPIs, LeadTimeKPIs, QualityKPIs, lead_time_consistency


@dataclass
class TransactionFrames:
    pos: pd.DataFrame          # purchase orders joined with lead time + benchmark price
    inspections: pd.DataFrame
    invoices: pd.DataFrame

    @property
    def vendor_ids(self) -> list[str]:
        return sorted(self.pos["vendor_id"].unique().tolist())


def load_frames(engine: Engine) -> TransactionFrames:
    with engine.connect() as conn:
        pos = pd.read_sql(
            """
            SELECT po.po_id, po.vendor_id, po.category_id, po.product_id, po.po_date, po.promised_date,
                   po.quantity, po.unit_price, po.expected_value, po.is_critical, po.status,
                   lt.promised_lead_days, lt.actual_lead_days, lt.variance_days,
                   p.benchmark_unit_cost
            FROM purchase_orders po
            LEFT JOIN lead_time_records lt ON lt.po_id = po.po_id
            JOIN products p ON p.product_id = po.product_id
            """, conn)
        inspections = pd.read_sql(
            "SELECT inspection_id, vendor_id, category_id, po_id, inspection_date, inspected_qty, defect_qty, "
            "rejected_qty, result, rejection_reason FROM quality_inspections", conn)
        invoices = pd.read_sql(
            "SELECT i.invoice_id, i.vendor_id, i.po_id, i.invoice_date, i.po_value, i.invoice_value, i.variance_amount, "
            "i.status, po.unit_price, p.benchmark_unit_cost FROM invoices i "
            "JOIN purchase_orders po ON po.po_id = i.po_id JOIN products p ON p.product_id = po.product_id", conn)
    return prepare_frames(pos, inspections, invoices)


def prepare_frames(pos: pd.DataFrame, inspections: pd.DataFrame, invoices: pd.DataFrame) -> TransactionFrames:
    pos = pos.copy()
    for col in ("po_date", "promised_date"):
        pos[col] = pd.to_datetime(pos[col])
    pos["is_critical"] = pos["is_critical"].astype(bool)
    delivered = pos["actual_lead_days"].notna()
    pos["completion_date"] = pd.NaT
    pos.loc[delivered, "completion_date"] = pos.loc[delivered, "po_date"] + pd.to_timedelta(pos.loc[delivered, "actual_lead_days"], unit="D")
    pos["completion_date"] = pd.to_datetime(pos["completion_date"])
    inspections = inspections.copy()
    inspections["inspection_date"] = pd.to_datetime(inspections["inspection_date"])
    invoices = invoices.copy()
    invoices["invoice_date"] = pd.to_datetime(invoices["invoice_date"])
    return TransactionFrames(pos=pos, inspections=inspections, invoices=invoices)


def _window(df: pd.DataFrame, col: str, start: date, end: date) -> pd.DataFrame:
    return df[(df[col] >= pd.Timestamp(start)) & (df[col] <= pd.Timestamp(end))]


@dataclass
class VendorKPIs:
    delivery: DeliveryKPIs
    quality: QualityKPIs
    cost: CostKPIs
    lead_time: LeadTimeKPIs

    def as_dict(self) -> dict:
        from dataclasses import asdict
        return {"delivery": asdict(self.delivery), "quality": asdict(self.quality),
                "cost": asdict(self.cost), "lead_time": asdict(self.lead_time)}


def compute_window_kpis(frames: TransactionFrames, start: date, end: date,
                        vendor_ids: list[str] | None = None) -> dict[str, VendorKPIs]:
    """KPIs for every vendor (or the given ones) over [start, end]."""
    pos = _window(frames.pos.dropna(subset=["completion_date"]), "completion_date", start, end)
    qi = _window(frames.inspections, "inspection_date", start, end)
    inv = _window(frames.invoices, "invoice_date", start, end)
    if vendor_ids is not None:
        pos = pos[pos["vendor_id"].isin(vendor_ids)]
        qi = qi[qi["vendor_id"].isin(vendor_ids)]
        inv = inv[inv["vendor_id"].isin(vendor_ids)]

    out: dict[str, VendorKPIs] = {}
    ids = vendor_ids if vendor_ids is not None else frames.vendor_ids

    # ---- delivery + lead time (POs completed in window) ----
    pos = pos.assign(late=pos["variance_days"] > 0,
                     ratio=pos["actual_lead_days"] / pos["promised_lead_days"],
                     overrun=(pos["variance_days"].clip(lower=0) / pos["promised_lead_days"]))
    d_groups = {k: g for k, g in pos.groupby("vendor_id")}
    q_groups = {k: g for k, g in qi.groupby("vendor_id")}
    c_groups = {k: g for k, g in inv.groupby("vendor_id")}

    for vid in ids:
        g = d_groups.get(vid)
        if g is not None and len(g):
            late = g[g["late"]]
            crit = g[g["is_critical"]]
            dk = DeliveryKPIs(
                total_pos=int(len(g)), on_time_pos=int((~g["late"]).sum()), late_pos=int(len(late)),
                on_time_pct=round(float((~g["late"]).mean() * 100), 2),
                avg_delay_days=round(float(late["variance_days"].mean()), 2) if len(late) else 0.0,
                avg_lateness_days=round(float(g["variance_days"].clip(lower=0).mean()), 2),
                max_delay_days=int(late["variance_days"].max()) if len(late) else 0,
                critical_pos=int(len(crit)), critical_late_pos=int(crit["late"].sum()),
            )
            ratio = g["ratio"].to_numpy(dtype=float)
            cv = float(np.std(ratio) / np.mean(ratio)) if len(ratio) >= 2 and np.mean(ratio) else 0.0
            lk = LeadTimeKPIs(
                records=int(len(g)), avg_promised_days=round(float(g["promised_lead_days"].mean()), 2),
                avg_actual_days=round(float(g["actual_lead_days"].mean()), 2),
                avg_variance_days=round(float(g["variance_days"].mean()), 2),
                std_dev_days=round(float(g["variance_days"].std(ddof=0)), 2) if len(g) >= 2 else 0.0,
                coefficient_of_variation=round(cv, 4), avg_overrun_pct=round(float(g["overrun"].mean() * 100), 2),
                consistency_score=lead_time_consistency(cv),
            )
        else:
            dk, lk = DeliveryKPIs(), LeadTimeKPIs()

        g = q_groups.get(vid)
        if g is not None and len(g):
            insp_qty = int(g["inspected_qty"].sum())
            reasons = g.loc[g["rejection_reason"].fillna("") != "", "rejection_reason"].value_counts().head(3)
            qk = QualityKPIs(
                inspections=int(len(g)), failed_inspections=int((g["result"] == "FAIL").sum()), inspected_qty=insp_qty,
                defect_qty=int(g["defect_qty"].sum()), rejected_qty=int(g["rejected_qty"].sum()),
                defect_rate_pct=round(float(g["defect_qty"].sum() / insp_qty * 100), 2) if insp_qty else 0.0,
                rejection_rate_pct=round(float(g["rejected_qty"].sum() / insp_qty * 100), 2) if insp_qty else 0.0,
                inspection_failure_rate_pct=round(float((g["result"] == "FAIL").mean() * 100), 2),
                top_rejection_reasons=[{"reason": r, "count": int(c)} for r, c in reasons.items()],
            )
        else:
            qk = QualityKPIs()

        g = c_groups.get(vid)
        if g is not None and len(g):
            po_val = float(g["po_value"].sum())
            per_inv = g["variance_amount"] / g["po_value"]
            bench = (g["unit_price"] / g["benchmark_unit_cost"] - 1) * 100
            ck = CostKPIs(
                invoices=int(len(g)), po_value=round(po_val, 2), invoice_value=round(float(g["invoice_value"].sum()), 2),
                variance_amount=round(float(g["variance_amount"].sum()), 2),
                variance_pct=round(float(g["variance_amount"].sum() / po_val * 100), 3) if po_val else 0.0,
                avg_cost_variance_pct=round(float(per_inv.mean() * 100), 3),
                benchmark_variance_pct=round(float(bench.mean()), 2),
                disputed_invoices=int((g["status"] == "Disputed").sum()),
            )
        else:
            ck = CostKPIs()
        out[vid] = VendorKPIs(dk, qk, ck, lk)
    return out
