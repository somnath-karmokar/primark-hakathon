"""Explicit, typed tools used by the LangGraph agents.

* Every tool returns a ``ToolResult`` (Pydantic) - structured data, never prose.
* Each agent has an allow-list; calling anything else raises ``ToolAccessDenied``.
* ``ToolContext`` enforces max tool calls per request and records a trace.
* The registry doubles as an MCP-ready catalogue (name, description, input schema).
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.config import get_settings
from app.graph import queries as graph
from app.knowledge import store
from app.services import alternatives as alt_service
from app.services import analytics_service as analytics
from app.services import risk_service

VENDOR_ID = re.compile(r"^V\d{4}$")


class ToolAccessDenied(PermissionError):
    pass


class ToolLimitExceeded(RuntimeError):
    pass


class ToolResult(BaseModel):
    tool: str
    ok: bool = True
    source: str = "postgres"
    data: Any = None
    error: str | None = None
    duration_ms: int = 0


class VendorArgs(BaseModel):
    vendor_id: str = Field(pattern=r"^V\d{4}$", description="Vendor id, e.g. V1024")


class SearchArgs(BaseModel):
    query: str = Field(min_length=3, max_length=400)
    k: int = Field(default=4, ge=1, le=8)
    document_type: str | None = None


class ListArgs(BaseModel):
    limit: int = Field(default=8, ge=1, le=25)


class SegmentArgs(BaseModel):
    segment: str = Field(description="strong_quality_weak_delivery | low_cost_poor_quality | premium_high_quality | variable_lead_time")


@dataclass
class ToolSpec:
    name: str
    description: str
    args: type[BaseModel]
    fn: Callable[..., ToolResult]
    source: str


@dataclass
class ToolContext:
    db: Session
    agent: str = ""
    calls: int = 0
    log: list[dict] = field(default_factory=list)
    max_calls: int | None = None

    def call(self, name: str, **kwargs) -> ToolResult:
        if name not in AGENT_TOOLS.get(self.agent, set()):
            raise ToolAccessDenied(f"agent '{self.agent}' may not call tool '{name}'")
        limit = self.max_calls if self.max_calls is not None else get_settings().max_tool_calls
        if self.calls >= limit:
            raise ToolLimitExceeded(f"max tool calls ({limit}) reached")
        spec = REGISTRY[name]
        args = spec.args.model_validate(kwargs)
        self.calls += 1
        t0 = time.perf_counter()
        try:
            res = spec.fn(self.db, **args.model_dump())
        except analytics.VendorNotFound as exc:
            res = ToolResult(tool=name, ok=False, error=f"unknown vendor {exc}", source=spec.source)
        except Exception as exc:  # tools never crash the graph
            res = ToolResult(tool=name, ok=False, error=f"{type(exc).__name__}: {str(exc)[:160]}", source=spec.source)
        res.duration_ms = int((time.perf_counter() - t0) * 1000)
        self.log.append({"agent": self.agent, "tool": name, "args": args.model_dump(), "ok": res.ok,
                         "source": res.source, "duration_ms": res.duration_ms})
        return res


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------
def _ok(tool: str, data: Any, source: str = "postgres") -> ToolResult:
    return ToolResult(tool=tool, data=data, source=source)


def get_vendor(db, vendor_id): return _ok("get_vendor", analytics.vendor_profile(db, vendor_id))
def calculate_vendor_score(db, vendor_id): return _ok("calculate_vendor_score", analytics.score_detail(db, vendor_id), "scoring-engine")
def get_vendor_trend(db, vendor_id): return _ok("get_vendor_trend", analytics.vendor_trend(db, vendor_id))


def _kpi(section: str):
    def fn(db, vendor_id):
        return _ok(f"get_{section}_metrics", analytics.score_detail(db, vendor_id)["kpis"][section])
    return fn


def predict_vendor_risk(db, vendor_id): return _ok("predict_vendor_risk", risk_service.vendor_risk(db, vendor_id), "ml-model")


def detect_vendor_anomalies(db, vendor_id):
    r = risk_service.vendor_risk(db, vendor_id)
    return _ok("detect_vendor_anomalies", {"is_anomaly": r.get("is_anomaly"), "anomaly_score": r.get("anomaly_score"),
                                           "reasons": [d for d in r.get("drivers", []) if d.get("type") == "anomaly"]}, "isolation-forest")


def _search(tool: str, default_types: list[str] | None):
    def fn(db, query, k=4, document_type=None):
        filters = {"document_type": document_type} if document_type else ({"document_type": default_types} if default_types else None)
        r = store.search(query, k=k, filters=filters)
        return ToolResult(tool=tool, source="chromadb", data={
            "results": [{"id": x["id"], "document_id": x["metadata"]["document_id"], "title": x["metadata"]["title"],
                         "section": x["metadata"]["section"], "clause": x["metadata"].get("clause", ""),
                         "policy_version": x["metadata"]["policy_version"], "document_type": x["metadata"]["document_type"],
                         "text": x["text"], "score": x["score"]} for x in r["results"]],
            "filters": r["filters"], "cache_hit": r["cache_hit"], "embedding_model": r["embedding_model"]})
    return fn


def get_vendor_relationships(db, vendor_id):
    r = graph.vendor_relationships(db, vendor_id)
    return ToolResult(tool="get_vendor_relationships", data=r, source=r["source"])


def get_supplier_dependencies(db, vendor_id):
    r = graph.supplier_dependency(db, vendor_id)
    return ToolResult(tool="get_supplier_dependencies", data=r, source=r["source"])


def find_alternative_vendors(db, vendor_id):
    r = alt_service.rank_alternatives(db, vendor_id)
    return ToolResult(tool="find_alternative_vendors", data=r, source=f"{r['graph_source']}+scoring")


def list_underperformers(db, limit=8): return _ok("list_underperformers", analytics.underperformers(db, limit))
def list_deteriorating(db, limit=8): return _ok("list_deteriorating", analytics.most_deteriorated(db, limit))


def segment_vendors(db, segment):
    seg = analytics.performance_analytics(db)["segments"].get(segment)
    return _ok("segment_vendors", {"segment": segment, **(seg or {"count": 0, "vendors": []})})


def get_portfolio_summary(db, limit=8):
    s = analytics.dashboard_summary(db)
    return _ok("get_portfolio_summary", {"period": s["period"], "kpis": s["kpis"], "band_counts": s["band_counts"]})


REGISTRY: dict[str, ToolSpec] = {t.name: t for t in [
    ToolSpec("get_vendor", "Vendor master data, products, categories and contract/SLA", VendorArgs, get_vendor, "postgres"),
    ToolSpec("calculate_vendor_score", "Deterministic score, breakdown, drivers, trend and category benchmark", VendorArgs, calculate_vendor_score, "scoring-engine"),
    ToolSpec("get_vendor_trend", "Monthly score history with component KPIs", VendorArgs, get_vendor_trend, "postgres"),
    ToolSpec("get_delivery_metrics", "Delivery KPIs for the current window", VendorArgs, _kpi("delivery"), "postgres"),
    ToolSpec("get_quality_metrics", "Quality KPIs for the current window", VendorArgs, _kpi("quality"), "postgres"),
    ToolSpec("get_cost_metrics", "Cost KPIs for the current window", VendorArgs, _kpi("cost"), "postgres"),
    ToolSpec("get_lead_time_metrics", "Lead-time KPIs for the current window", VendorArgs, _kpi("lead_time"), "postgres"),
    ToolSpec("predict_vendor_risk", "Internal performance-risk prediction with drivers", VendorArgs, predict_vendor_risk, "ml-model"),
    ToolSpec("detect_vendor_anomalies", "IsolationForest anomaly flags", VendorArgs, detect_vendor_anomalies, "isolation-forest"),
    ToolSpec("search_procurement_policy", "Search procurement/evaluation/escalation policies", SearchArgs, _search("search_procurement_policy", ["policy"]), "chromadb"),
    ToolSpec("search_supplier_policy", "Search SLA, quality standards and guidelines", SearchArgs, _search("search_supplier_policy", ["sla", "standard", "guideline"]), "chromadb"),
    ToolSpec("search_contract_knowledge", "Search contract guidelines", SearchArgs, _search("search_contract_knowledge", ["contract", "sla"]), "chromadb"),
    ToolSpec("search_knowledge", "Search all procurement knowledge", SearchArgs, _search("search_knowledge", None), "chromadb"),
    ToolSpec("get_vendor_relationships", "Graph: products, categories, contract, SLA, region", VendorArgs, get_vendor_relationships, "neo4j"),
    ToolSpec("get_supplier_dependencies", "Graph: products/categories dependent on the vendor", VendorArgs, get_supplier_dependencies, "neo4j"),
    ToolSpec("find_alternative_vendors", "Graph candidates ranked by deterministic fit score", VendorArgs, find_alternative_vendors, "neo4j"),
    ToolSpec("list_underperformers", "Vendors in At Risk / Critical bands", ListArgs, list_underperformers, "postgres"),
    ToolSpec("list_deteriorating", "Vendors with the largest 3-month score decline", ListArgs, list_deteriorating, "postgres"),
    ToolSpec("segment_vendors", "Vendors in a named performance segment", SegmentArgs, segment_vendors, "postgres"),
    ToolSpec("get_portfolio_summary", "Portfolio KPIs and band counts", ListArgs, get_portfolio_summary, "postgres"),
]}

AGENT_TOOLS: dict[str, set[str]] = {
    "performance": {"get_vendor", "calculate_vendor_score", "get_vendor_trend", "get_delivery_metrics", "get_quality_metrics",
                    "get_cost_metrics", "get_lead_time_metrics", "list_underperformers", "list_deteriorating",
                    "segment_vendors", "get_portfolio_summary"},
    "risk": {"predict_vendor_risk", "detect_vendor_anomalies", "list_deteriorating"},
    "knowledge": {"search_procurement_policy", "search_supplier_policy", "search_contract_knowledge", "search_knowledge",
                  "get_vendor_relationships", "get_supplier_dependencies", "get_vendor"},
    "recommendation": {"find_alternative_vendors", "get_supplier_dependencies"},
    "governance": set(),
}


def catalogue() -> list[dict]:
    """MCP-ready tool catalogue."""
    return [{"name": t.name, "description": t.description, "source": t.source,
             "input_schema": t.args.model_json_schema(),
             "agents": sorted(a for a, tools in AGENT_TOOLS.items() if t.name in tools)} for t in REGISTRY.values()]
