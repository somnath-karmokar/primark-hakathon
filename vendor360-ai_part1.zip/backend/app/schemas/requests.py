"""Validated request bodies (input guardrails live here and in the copilot service)."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class ChatRequest(BaseModel):
    message: str = Field(min_length=3, max_length=600)
    session_id: str | None = Field(default=None, pattern=r"^ses-[a-f0-9]{6,20}$")


class CompareRequest(BaseModel):
    vendor_ids: list[str] = Field(min_length=2, max_length=5)

    @field_validator("vendor_ids")
    @classmethod
    def _ids(cls, v: list[str]) -> list[str]:
        out = []
        for x in v:
            x = x.strip().upper()
            if not (len(x) == 5 and x[0] == "V" and x[1:].isdigit()):
                raise ValueError(f"invalid vendor id '{x}'")
            out.append(x)
        if len(set(out)) != len(out):
            raise ValueError("vendor ids must be unique")
        return out


class Weights(BaseModel):
    delivery: float = Field(ge=0, le=1)
    quality: float = Field(ge=0, le=1)
    cost: float = Field(ge=0, le=1)
    lead_time: float = Field(ge=0, le=1)

    @model_validator(mode="after")
    def _sum(self) -> "Weights":
        total = self.delivery + self.quality + self.cost + self.lead_time
        if abs(total - 1.0) > 0.001:
            raise ValueError(f"weights must sum to 1.0 (got {total:.3f})")
        return self


class RiskSettings(BaseModel):
    high_threshold: float = Field(ge=0.05, le=0.99)
    medium_threshold: float = Field(ge=0.01, le=0.95)
    deterioration_drop_points: float = Field(ge=2, le=40)
    approval_confidence_threshold: float = Field(ge=0.3, le=0.99)

    @model_validator(mode="after")
    def _order(self) -> "RiskSettings":
        if self.medium_threshold >= self.high_threshold:
            raise ValueError("medium threshold must be below high threshold")
        return self


class CacheSettings(BaseModel):
    enabled: bool
    ttl_seconds: int = Field(ge=30, le=86400)
    semantic_threshold: float = Field(ge=0.8, le=0.999)


class AgentSettings(BaseModel):
    max_agent_steps: int = Field(ge=3, le=20)
    max_llm_calls: int = Field(ge=0, le=10)
    max_tool_calls: int = Field(ge=5, le=60)
    token_budget_per_request: int = Field(ge=1000, le=60000)
    context_budget_tokens: int = Field(ge=300, le=16000)


class SettingsUpdate(BaseModel):
    weights: Weights | None = None
    risk: RiskSettings | None = None
    cache: CacheSettings | None = None
    agent: AgentSettings | None = None
    demo_mode: bool | None = None


class DecisionRequest(BaseModel):
    decision: Literal["approved", "rejected"]
    note: str | None = Field(default=None, max_length=500)


class FeedbackRequest(BaseModel):
    request_id: str = Field(pattern=r"^req-[a-f0-9]{6,20}$")
    rating: Literal["up", "down"]
    comment: str | None = Field(default=None, max_length=500)
    question: str | None = Field(default=None, max_length=600)


class BudgetUpdate(BaseModel):
    monthly_budget_gbp: float = Field(ge=0, le=100000)
    alert_pct: int = Field(ge=10, le=100)
    hard_stop: bool


class LoginRequest(BaseModel):
    username: str = Field(min_length=2, max_length=60)
    password: str = Field(min_length=1, max_length=200)


class InputGuardrails(BaseModel):
    min_query_chars: int = Field(ge=1, le=50)
    max_query_chars: int = Field(ge=50, le=4000)
    injection_action: Literal["flag", "block"]
    pii_redaction: bool
    rate_limit_per_minute: int = Field(ge=0, le=600)
    blocked_terms: list[str] = Field(default_factory=list, max_length=50)

    @field_validator("blocked_terms")
    @classmethod
    def _terms(cls, v: list[str]) -> list[str]:
        return sorted({t.strip().lower() for t in v if t.strip()})[:50]


class OutputGuardrails(BaseModel):
    max_unsupported_figures: int = Field(ge=0, le=10)
    enforce_ranking: bool
    require_citations: bool
    min_confidence: float = Field(ge=0, le=0.95)


class AgentGuardrails(BaseModel):
    max_agent_steps: int = Field(ge=3, le=20)
    max_tool_calls: int = Field(ge=5, le=60)
    max_llm_calls: int = Field(ge=0, le=10)
    token_budget_per_request: int = Field(ge=1000, le=60000)
    context_budget_tokens: int = Field(ge=300, le=16000)


class GuardrailUpdate(BaseModel):
    input: InputGuardrails | None = None
    output: OutputGuardrails | None = None
    agent: AgentGuardrails | None = None


class GuardrailTest(BaseModel):
    text: str = Field(min_length=0, max_length=5000)


class Candidate(BaseModel):
    algorithm: Literal["xgboost"] = "xgboost"
    params: dict[str, float] = Field(default_factory=dict)


class TrainRequest(BaseModel):
    candidates: list[Candidate] = Field(min_length=1, max_length=8)
    drop_points: float = Field(default=6.0, ge=2, le=20)
    test_periods: int = Field(default=1, ge=1, le=2)


class AnomalyRequest(BaseModel):
    contamination: float = Field(default=0.05, ge=0.01, le=0.25)
    n_estimators: int = Field(default=200, ge=50, le=1000)


class SeedRequest(BaseModel):
    regenerate: bool = False
    vendors: int = Field(default=500, ge=50, le=2000)
    graph: bool = True
    knowledge: bool = True
