"""Central, environment-driven configuration.

Every secret comes from the environment (or a git-ignored ``.env``). Nothing
provider-specific is hard-coded: the LLM factory reads ``llm_provider`` and the
model-routing table below.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parent.parent
REPO_ROOT = BACKEND_DIR.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(str(REPO_ROOT / ".env"), str(BACKEND_DIR / ".env")),
        env_ignore_empty=True,
        extra="ignore",
    )

    # --- application -----------------------------------------------------
    app_name: str = "Vendor360 AI"
    environment: str = "local"
    demo_mode: bool = True
    log_level: str = "INFO"
    cors_origins: str = "http://localhost:5200,http://127.0.0.1:5200"

    # API protection. When API_KEYS is empty the API runs in demo-auth mode
    # (every caller is the demo procurement user). Comma separated.
    api_keys: str = ""
    auth_mode: str = "login"  # login | api_key | demo
    auth_secret: str = Field(default="dev-only-change-me-vendor360", repr=False)
    token_ttl_minutes: int = 480
    demo_business_password: str = Field(default="Business@2026", repr=False)
    demo_staff_password: str = Field(default="Staff@2026", repr=False)
    demo_admin_password: str = Field(default="Admin@2026", repr=False)

    # --- databases -------------------------------------------------------
    database_url: str = "postgresql+psycopg://vendor360:vendor360@localhost:5433/vendor360"

    neo4j_uri: str = ""
    neo4j_username: str = "neo4j"
    neo4j_password: str = ""
    neo4j_database: str = "neo4j"
    neo4j_enabled: bool = True
    graph_max_depth: int = 3

    chroma_path: str = str(REPO_ROOT / ".local" / "chroma")
    chroma_collection: str = "procurement_knowledge"

    data_dir: str = str(REPO_ROOT / "data")
    knowledge_dir: str = str(REPO_ROOT / "knowledge")
    model_dir: str = str(REPO_ROOT / ".local" / "models")

    # --- LLM providers ---------------------------------------------------
    llm_provider: str = "none"  # azure | openai | none
    azure_openai_endpoint: str = ""
    azure_openai_api_key: str = ""
    azure_openai_api_version: str = "2024-10-21"
    azure_openai_deployment: str = ""
    azure_openai_deployment_light: str = ""
    azure_openai_deployment_strong: str = ""

    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    openai_model_light: str = ""
    openai_model_strong: str = ""

    embedding_provider: str = "local"  # azure | openai | local
    azure_openai_embedding_deployment: str = ""
    openai_embedding_model: str = "text-embedding-3-small"

    llm_price_table: str = ""        # JSON {"model": [usd_per_1M_input, usd_per_1M_output]} overrides list prices
    usd_to_gbp: float = 0.79
    llm_temperature: float = 0.1
    llm_timeout_seconds: float = 30.0

    # --- agent guardrails / token budgets ---------------------------------
    max_agent_steps: int = 8
    max_llm_calls: int = 3
    max_tool_calls: int = 20
    agent_timeout_seconds: float = 45.0
    token_budget_per_request: int = 6000
    context_budget_tokens: int = 1800
    max_query_chars: int = 600

    # --- caching -----------------------------------------------------------
    cache_enabled: bool = True
    cache_ttl_seconds: int = 3600
    semantic_cache_threshold: float = 0.92
    prompt_version: str = "v1.4"

    # --- scoring defaults (overridable at runtime via Settings page) -------
    weight_delivery: float = 0.30
    weight_quality: float = 0.30
    weight_cost: float = 0.20
    weight_lead_time: float = 0.20

    risk_high_threshold: float = 0.60
    risk_medium_threshold: float = 0.35
    deterioration_drop_points: float = 8.0
    approval_confidence_threshold: float = 0.70

    langsmith_tracing: bool = False
    langsmith_api_key: str = Field(default="", repr=False)

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def api_key_list(self) -> list[str]:
        return [k.strip() for k in self.api_keys.split(",") if k.strip()]

    @property
    def llm_configured(self) -> bool:
        if self.llm_provider == "azure":
            return bool(self.azure_openai_endpoint and self.azure_openai_api_key and self.azure_openai_deployment)
        if self.llm_provider == "openai":
            return bool(self.openai_api_key)
        return False


@lru_cache
def get_settings() -> Settings:
    return Settings()
