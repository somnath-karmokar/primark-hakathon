import pytest

from app.analytics.scoring import (
    CostKPIs, DeliveryKPIs, LeadTimeKPIs, QualityKPIs, ScoringWeights, analyse_trend, cost_score, delivery_score,
    lead_time_consistency, lead_time_score, overall_score, quality_score, score_band, score_drivers, score_from_kpis,
)


# ---------------------------------------------------------------- delivery
def test_delivery_perfect():
    k = DeliveryKPIs(total_pos=10, on_time_pos=10, on_time_pct=100.0)
    assert delivery_score(k) == 100.0


def test_delivery_formula():
    # 80% OTD, mean lateness 2.5 days over all POs, 1 of 10 POs critical+late
    k = DeliveryKPIs(total_pos=10, on_time_pos=8, late_pos=2, on_time_pct=80.0, avg_delay_days=12.5,
                     avg_lateness_days=2.5, critical_pos=2, critical_late_pos=1)
    expected = 0.75 * 80 + 0.25 * (100 - 8 * 2.5) - 20 * (1 / 10)
    assert delivery_score(k) == pytest.approx(expected, abs=0.01)


def test_delivery_no_data_is_zero():
    assert delivery_score(DeliveryKPIs()) == 0.0


def test_delivery_single_very_late_po_is_proportional():
    """One 30-day-late PO in a window of 20 must not wipe out the severity term."""
    k = DeliveryKPIs(total_pos=20, on_time_pos=19, late_pos=1, on_time_pct=95.0, avg_delay_days=30, avg_lateness_days=1.5)
    assert delivery_score(k) > 90


# ---------------------------------------------------------------- quality
def test_quality_formula():
    k = QualityKPIs(inspections=10, defect_rate_pct=2.0, inspection_failure_rate_pct=10.0, rejection_rate_pct=1.0)
    assert quality_score(k) == pytest.approx(0.6 * 80 + 0.25 * 80 + 0.15 * 90, abs=0.01)


def test_quality_clamped_at_zero():
    k = QualityKPIs(inspections=5, defect_rate_pct=25, inspection_failure_rate_pct=90, rejection_rate_pct=40)
    assert quality_score(k) == 0.0


# ---------------------------------------------------------------- cost
def test_cost_underbilling_and_discount_not_rewarded_beyond_100():
    k = CostKPIs(invoices=5, variance_pct=-2.0, benchmark_variance_pct=-10.0)
    assert cost_score(k) == 100.0


def test_cost_formula():
    k = CostKPIs(invoices=5, variance_pct=2.0, benchmark_variance_pct=10.0)
    assert cost_score(k) == pytest.approx(0.5 * (100 - 24) + 0.5 * (100 - 40), abs=0.01)


# ---------------------------------------------------------------- lead time
def test_lead_time_consistency_scale():
    assert lead_time_consistency(0.0) == 100
    assert lead_time_consistency(0.2) == 50
    assert lead_time_consistency(0.5) == 0


def test_same_average_lead_time_different_variability_scores_differently():
    steady = LeadTimeKPIs(records=20, avg_promised_days=50, avg_actual_days=52, coefficient_of_variation=0.04, avg_overrun_pct=3)
    erratic = LeadTimeKPIs(records=20, avg_promised_days=50, avg_actual_days=52, coefficient_of_variation=0.30, avg_overrun_pct=3)
    assert lead_time_score(steady) - lead_time_score(erratic) > 30


# ---------------------------------------------------------------- overall + bands
def test_overall_default_weights():
    b = overall_score(58, 86, 61, 52)
    assert b.overall == pytest.approx(58 * 0.3 + 86 * 0.3 + 61 * 0.2 + 52 * 0.2, abs=0.01)
    assert b.band == "Watch"
    assert sum(b.contributions.values()) == pytest.approx(b.overall, abs=0.05)


def test_custom_weights():
    w = ScoringWeights(delivery=0.5, quality=0.2, cost=0.2, lead_time=0.1)
    assert overall_score(100, 0, 0, 0, w).overall == 50.0


@pytest.mark.parametrize("w", [ScoringWeights(0.5, 0.5, 0.2, 0.2), ScoringWeights(-0.1, 0.5, 0.3, 0.3)])
def test_invalid_weights_rejected(w):
    with pytest.raises(ValueError):
        w.validate()


@pytest.mark.parametrize("score,band", [(100, "Excellent"), (90, "Excellent"), (89.96, "Excellent"), (89.94, "Good"),
                                        (75, "Good"), (74.9, "Watch"), (60, "Watch"), (59.9, "At Risk"), (40, "At Risk"),
                                        (39.9, "Critical"), (0, "Critical")])
def test_score_bands(score, band):
    assert score_band(score) == band


def test_missing_component_is_neutral_and_flagged():
    b = score_from_kpis(DeliveryKPIs(total_pos=2, on_time_pos=2, on_time_pct=100), QualityKPIs(), CostKPIs(), LeadTimeKPIs())
    assert b.quality == 70.0 and b.cost == 70.0 and b.lead_time == 70.0
    assert b.data_sufficient is False


# ---------------------------------------------------------------- trend
def test_trend_deteriorating():
    t = analyse_trend([86, 85, 84, 79, 73, 68, 65, 64])
    assert t.direction == "deteriorating" and t.is_deteriorating
    assert t.change_3m == pytest.approx(64 - 73)


def test_trend_noise_is_not_deterioration():
    t = analyse_trend([88, 84, 89, 85, 88, 84, 87])
    assert not t.is_deteriorating


def test_trend_improving():
    assert analyse_trend([60, 63, 66, 70, 73, 77]).direction == "improving"


def test_drivers_rank_biggest_negative_change_first():
    prev = overall_score(90, 90, 90, 90)
    cur = overall_score(60, 89, 85, 70)
    d = score_drivers(cur, prev)
    assert d[0]["component"] == "delivery"
    assert d[0]["impact"] == "negative"
    assert {x["component"] for x in d} == {"delivery", "quality", "cost", "lead_time"}
