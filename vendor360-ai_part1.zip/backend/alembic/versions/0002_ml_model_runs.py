"""Model Lab: ml_model_runs

Revision ID: 0002
Revises: 0001
Create Date: 2026-10-13
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0002"
down_revision: Union[str, None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "ml_model_runs",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("experiment_id", sa.String(length=24), nullable=False),
        sa.Column("algorithm", sa.String(length=40), nullable=False),
        sa.Column("params", sa.JSON(), nullable=False),
        sa.Column("dataset", sa.JSON(), nullable=False),
        sa.Column("metrics", sa.JSON(), nullable=False),
        sa.Column("curves", sa.JSON(), nullable=False),
        sa.Column("importance", sa.JSON(), nullable=False),
        sa.Column("credible", sa.Boolean(), nullable=False),
        sa.Column("credibility_reason", sa.Text(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        sa.Column("train_seconds", sa.Float(), nullable=False),
        sa.Column("trained_by", sa.String(length=80), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("promoted_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_ml_model_runs_experiment_id", "ml_model_runs", ["experiment_id"])
    op.create_index("ix_ml_model_runs_is_active", "ml_model_runs", ["is_active"])
    op.create_index("ix_ml_model_runs_created_at", "ml_model_runs", ["created_at"])


def downgrade() -> None:
    op.drop_index("ix_ml_model_runs_created_at", table_name="ml_model_runs")
    op.drop_index("ix_ml_model_runs_is_active", table_name="ml_model_runs")
    op.drop_index("ix_ml_model_runs_experiment_id", table_name="ml_model_runs")
    op.drop_table("ml_model_runs")
