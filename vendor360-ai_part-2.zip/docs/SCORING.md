# Vendor Performance Score (VPS) - specification `vps-1.3`

The score is **deterministic**: plain arithmetic over KPIs computed from transactions in
PostgreSQL. No LLM is involved. Source: `backend/app/analytics/scoring.py` (pure functions)
and `backend/app/analytics/metrics.py` (KPI extraction). Tests: `backend/tests/test_scoring.py`.

## Window

Scores are computed **monthly over a rolling 3-month window**. Ten month-end snapshots
(Dec 2025 - Sep 2026) are stored in `vendor_score_snapshots`, with the weights, KPIs,
`model_version` and `data_version` used, so any historical score can be audited and reproduced.

| KPI family | A record belongs to the window when... |
|---|---|
| Delivery, lead time | the PO's final shipment arrived in the window |
| Quality | the inspection date is in the window |
| Cost | the invoice date is in the window |

## Overall

```
Overall = Delivery x 0.30 + Quality x 0.30 + Cost x 0.20 + Lead-time x 0.20
```

Weights are configurable (Settings page / `PUT /api/v1/settings`) and must sum to 1.0.
Changing weights re-derives every snapshot from the stored component scores (sub-second)
and is written to the audit trail.

| Band | Score |
|---|---|
| Excellent | 90-100 |
| Good | 75-89 |
| Watch | 60-74 |
| At Risk | 40-59 |
| Critical | 0-39 |

## Components (each clamped to 0-100)

**Delivery**
```
0.75 x on-time %                                   (PO on time = final shipment <= promised date)
+ 0.25 x (100 - 8 x mean lateness over ALL POs)     (on-time POs count as 0 days)
- 20 x (critical POs that were late / all POs)
```
Both penalty terms are proportions of the whole window, so a single very late PO in a small
window cannot swing the score disproportionately.

**Quality**
```
0.60 x (100 - 10 x defect rate %)            defect rate pooled over every inspected unit
+ 0.25 x (100 - 2 x inspection failure %)    AQL 2.5 failures
+ 0.15 x (100 - 10 x rejection rate %)
```

**Cost**
```
0.50 x (100 - 12 x max(0, invoice over-billing %))         invoice discipline
+ 0.50 x (100 - 4 x max(0, unit price vs benchmark %))     price competitiveness
```
Under-billing and below-benchmark prices are capped at 100 (not rewarded further).

**Lead-time consistency**
```
consistency = 100 - 250 x CV        CV = std / mean of (actual / promised lead time)
score       = 0.6 x consistency + 0.4 x (100 - 3 x mean overrun %)
```
Using the coefficient of variation means **two suppliers with the same average lead time get
different scores if one is much more variable** (unit test
`test_same_average_lead_time_different_variability_scores_differently`).

## Data sufficiency

A window with fewer than 3 completed POs, no inspections or no invoices is flagged
`data_sufficient = false` (shown as "provisional", policy SEV-5). A component with no
observations is scored at a neutral 70, never 0, so missing data does not masquerade as
poor performance.

## Trend and deterioration

Over the last 6 monthly scores:

* `slope` = least-squares slope (points/month)
* **deteriorating** = slope <= -1.5 **and** (3-month change <= -8 **or** drop from 6-month peak >= 8)
* declining = slope <= -0.75; improving = slope >= +0.75; otherwise stable

The sustained-slope condition was calibrated against the synthetic ground truth: it catches
34 of 35 genuinely deteriorating vendors while ignoring month-to-month sampling noise.

## Drivers ("why is the score low?")

`score_drivers()` returns each component's score, weighted points lost versus a perfect 100,
and its change versus the score 3 months earlier. They are ranked by weighted change, then
points lost. This is the deterministic "why" shown on Vendor 360 and used by the agents.
