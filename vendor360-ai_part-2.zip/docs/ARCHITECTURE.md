# Vendor360 AI - architecture

```
                         React + TS + Vite + Tailwind (shadcn-style) + Recharts + TanStack Query
                                                   | REST /api/v1 (OpenAPI /docs)
FastAPI ----------------------------------------------------------------------------------------------
  Analytics API          Copilot API              Governance API        Settings / Data / Risk-intel
       |                      |                         |
Deterministic core      LangGraph workflow  ---->  Governance agent  ---->  audit_events / recommendations
  metrics.py (KPIs)       Supervisor/Planner          (grounding, confidence, approval)
  scoring.py (VPS)          -> Performance agent ----- tools -> scoring engine / PostgreSQL
  snapshots (Postgres)      -> Risk/Trend agent  ----- tools -> ML risk model / IsolationForest
  ML risk + anomaly         -> Knowledge agent   ----- tools -> ChromaDB (policies) + Neo4j (relationships)
                            -> Recommendation    ----- deterministic SEP-2 rules + graph alternatives
                            -> Synthesis ---> LLM Optimisation Layer ---> Azure OpenAI / OpenAI
                                              (exact cache, JEV, token budget, router, timeout)
```

## Data planes - each store does one job

| Store | Holds | Never holds |
|---|---|---|
| PostgreSQL (SQLAlchemy 2 + Alembic) | vendors, POs, deliveries, inspections, invoices, lead times, score/risk snapshots, recommendations, audit | embeddings |
| Neo4j (Aura) | Vendor-SUPPLIES->Product-BELONGS_TO->Category, HAS_PO, HAS_QUALITY_ISSUE, HAS_CONTRACT, HAS_SLA, OPERATES_IN, SHIPS_VIA, ALTERNATIVE_TO, ExternalEvent-AFFECTS | KPI analytics |
| ChromaDB (embedded) | 8 policy / SLA / standard / guideline / contract documents, chunked by section with metadata | transactions |

Graph ingestion is idempotent (MERGE on business keys, aged-out POs removed). If Neo4j is
unreachable, every graph query answers from PostgreSQL and is labelled `postgres-fallback`:
real data, never fabricated.

## LangGraph workflow (`backend/app/agents`)

* **State** (`state.py`): a typed `TypedDict`. List fields such as evidence, trace and flags use
  `operator.add` reducers, and agents exchange structured dicts, not prose.
* **Supervisor** classifies intent with deterministic rules first, falls back to the *light*
  model (constrained enum) only when the rules can't place a question, builds the plan, and
  enforces max steps and the timeout. It runs as a loop: every specialist returns to it.
* **Performance / Risk / Knowledge / Recommendation** call explicit typed tools
  (`tools/registry.py`) through a per-agent **allow-list** with a max-tool-calls guard.
* **Knowledge agent** chooses its sources per intent (e.g. a dependency question = Neo4j only;
  "why" = graph + policy passages chosen by the negative score drivers; SLA = graph contract +
  SLA chunks), so it doesn't query every store blindly.
* **Recommendation agent**: the *action* comes from deterministic rules mapped to Supplier
  Escalation Policy stages (`rules.py`); alternatives come from graph candidates ranked by a
  deterministic fit score. The LLM can only phrase the explanation.
* **Synthesis** compresses evidence with JEV and calls the routed model; with no model
  available it returns a clearly labelled deterministic answer.
* **Governance** checks evidence presence, citation validity, **numeric grounding** (every
  figure in the answer must exist in the evidence), policy grounding and data sufficiency. It
  computes confidence, decides whether human approval is needed (PP-5 / SEP-5), **replaces an
  LLM draft with the grounded deterministic answer if it contains unsupported figures**, and
  writes the audit event and recommendation record.

## LLM Cost & Token Optimisation Layer (`backend/app/llm`)

* **JEV (JSON Evidence Vector)**: the context optimiser. It canonicalises evidence (drops
  nulls, rounds floats, shortens keys), de-duplicates identical facts, orders by priority,
  packs to a token budget (tiktoken), truncates long policy passages before dropping them, and
  encodes one compact line per item with stable ids (`P2|metric|Delivery performance|{...}`)
  so the model can cite and governance can verify. Telemetry reports raw vs sent tokens.
* **Model routing**: classify / summary -> light; policy / performance explanation -> standard;
  recommendation / executive synthesis -> strong. Each tier is set in the environment and falls
  back to the standard model.
* **Caches** (`services/cache.py`): analytics (keyed by data_version), retrieval (Chroma
  queries keyed by policy version; graph queries), exact LLM response cache (model + prompt
  version), and a **semantic** cache that reuses an answer only when data, policy, prompt and
  model versions *and* the resolved vendor all match. Recommendations are never served from
  cache. Changing data or weights bumps `data_version`, which invalidates the caches.
* **Budgets**: max LLM calls per request, per-request token budget, max agent steps, max tool
  calls, LLM timeout and agent timeout, all configurable.

## ML - used only where justified

* **Question**: will this vendor's performance deteriorate in a sustained way over the next
  3 months?
* **Label**: the average of the next 3 monthly scores is >= 6 points below the trailing 3-month
  average. These are observed outcomes in the score history. A smoothed label is used because
  a single-month label was dominated by sampling noise (held-out AUC 0.64 vs 0.72).
* **Validation**: temporal split (train on earlier periods, test on the last labelled
  period); one model - **XGBoost** (depth 2, 200 rounds, eta 0.05, min_child_weight 5, no class
  re-weighting) - compared against a random-guess reference; all metrics reported as measured.
  XGBoost was chosen after a bake-off against Logistic Regression, Random Forest and scikit-learn
  Gradient Boosting: tuned, it matched or beat all three (ROC-AUC 0.735, PR-AUC 0.403, Brier 0.100,
  lift@10% 3.7x), so the others were removed to keep the solution simple to explain and govern. **Credibility gate**: AUC < 0.65, too few positives or single-class labels mean
  no model is used, and the platform falls back to statistical trend + IsolationForest
  anomaly signals and says so.
* **Explainability**: SHAP TreeExplainer per vendor (top contributing features).
* **Internal risk level** = model probability band, which current statistical signals can
  *raise* but never lower (e.g. a Watch-band vendor that is already deteriorating is High).

## Model Lab (`/model-lab`, `app/ml/algorithms.py`, `app/ml/lab.py`, `app/services/model_lab.py`)

* One supervised algorithm, XGBoost, with bounded, validated hyper-parameters (the registry shape is kept so
  settings are validated), plus the unsupervised IsolationForest. Each training run tries one XGBoost setting.
* Every candidate gets the same evaluation: a temporal hold-out on the latest period(s), rolling-origin
  validation, ROC-AUC, PR-AUC, F1 at 0.5 and at the F1-optimal threshold, precision, recall, MCC, Brier score,
  log loss, lift in the top 10%, the train-test overfit gap, and ROC / PR / calibration curves and confusion
  matrices.
* Runs are persisted in `ml_model_runs` (migration 0002) and audited. **Promote** (credible runs only) makes a
  run the production risk configuration: `risk_service` retrains with it on all labelled history and
  re-scores every vendor. `POST /ml/reset` restores the XGBoost default settings.
* Class-weighted models produce inflated probabilities (see the calibration tab). Promoting one shifts more
  vendors into Medium/High risk under the fixed probability thresholds.

## Three separate indicators

`Vendor Performance Score` · `Internal performance risk` · `External supplier risk` (secondary
module `risk_intel/`). External events propagate Event -> Country/Port -> Vendor -> open PO ->
Product -> Category through Neo4j. They are never blended into the score.

## Security & observability

* Settings come only from the environment / `.env`; there are no hard-coded secrets, and the
  browser never sees provider keys.
* Auth abstraction (`security.py`): `AUTH_MODE=demo` (labelled demo user) or `api_key`
  (`X-API-Key`, constant-time compare). RBAC permissions: read / copilot / approve /
  configure / seed.
* Validation: Pydantic request models, vendor-id pattern checks, query-length limits, weight
  sum checks, CORS allow-list. The user's question is fenced as data in the prompt, and
  injection patterns are flagged.
* Structured JSON logs carry a request id, path, status and duration; sensitive keys are
  masked. Agent traces, tool calls, model, tokens, cache hits, retrieval sources and
  confidence are written to the audit log. LangSmith tracing is optional
  (`LANGSMITH_TRACING`).

## MCP-ready

`GET /api/v1/tools` publishes the tool catalogue (name, description, JSON-schema input, owning
agents). The same `ToolSpec` registry can be mounted as an MCP server later without changing
the agents.
