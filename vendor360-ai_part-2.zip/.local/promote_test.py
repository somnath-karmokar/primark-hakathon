import httpx
B = "http://127.0.0.1:8040/api/v1"
c = httpx.Client(timeout=300)
runs = c.get(B + "/ml/runs").json()
lr = next(r for r in runs["runs"] if r["algorithm"] == "logistic_regression")
print("before:", runs["active"])
r = c.post(B + f"/ml/runs/{lr['id']}/promote").json()
print("promoted run", r["promoted"]["id"], r["promoted"]["algorithm_label"], "| rescore:", {k: r["rescore"][k] for k in ("credible_model", "levels")})
risk = c.get(B + "/vendors/V1024/risk").json()["internal"]
print("V1024 internal risk:", risk["risk_level"], risk["risk_probability"], "| model:", risk["model_version"], "| driver methods:", sorted({d.get("method") for d in risk["drivers"] if d.get("method")}))
print("governance model card:", c.get(B + "/governance/model").json()["risk_model"]["algorithm"])
bad = next((x for x in runs["runs"] if not x["credible"]), None)
print("promote non-credible:", c.post(B + f"/ml/runs/{bad['id']}/promote").status_code if bad else "n/a (all credible)")
c.post(B + "/ml/reset")
print("after reset:", c.get(B + "/ml/runs").json()["active"], "|", c.get(B + "/governance/model").json()["risk_model"]["algorithm"])
print("audit:", [e["summary"] for e in c.get(B + "/governance/audit?event_type=model_promoted&limit=2").json()])
