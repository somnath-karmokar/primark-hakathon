from app.database.session import session_scope
from app.services import model_lab
with session_scope() as db:
    r = model_lab.train(db, [{"algorithm": a} for a in ["logistic_regression", "random_forest", "gradient_boosting", "xgboost"]], 6.0, 1, "test")
    d = r["dataset"]
    print("dataset:", d["n_train"], "train /", d["n_test"], "test rows; positives", d["positives_train"], "/", d["positives_test"], "| periods", d["train_periods"], "->", d["test_periods"], "|", r["seconds"], "s")
    for x in r["runs"]:
        if "error" in x: print(x); continue
        m = x["metrics"]
        print(f"{x['algorithm_label']:20s} AUC {m['roc_auc']} PR-AUC {m['pr_auc']} F1 {m['f1']} P {m['precision']} R {m['recall']} "
              f"bestF1 {x['curves']['best_threshold']['f1']}@{x['curves']['best_threshold']['threshold']} lift10 {m['lift_top10pct']} "
              f"CV {m['cv_roc_auc_mean']}±{m['cv_roc_auc_std']} gap {m['overfit_gap']} credible {x['credible']} {x['train_seconds']}s")
    print("best run:", r["best_run_id"])
    a = model_lab.anomaly_lab(db, 0.05, 200)
    print("anomaly:", a["flagged"], "flagged", a["sanity_check"], a["seconds"], "s")
