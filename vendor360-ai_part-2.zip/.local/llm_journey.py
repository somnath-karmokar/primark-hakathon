import httpx, time
B = "http://127.0.0.1:8040/api/v1/copilot/chat"
sid = None
for q in ["Why is Vendor V1024 underperforming?", "What procurement action do you recommend?", "Find the best alternative supplier.",
          ]:
    t = time.time()
    r = httpx.post(B, json={"message": q, **({"session_id": sid} if sid else {})}, timeout=120).json()
    sid = r["session_id"]
    g = r["governance"]
    calls = [(c["task"], c["status"], c["model"]) for c in r["llm_calls"]]
    print(f"\n### {q}\n  mode={r['mode']} model={r['model']} intent={r['intent']} vendor={r['vendor_id']} {int((time.time()-t)*1000)}ms "
          f"conf={r['confidence']} gov={g['status']} calls={calls}")
    if r.get("jev"): print(f"  JEV {r['jev']['raw_tokens']} -> {r['jev']['compressed_tokens']} tokens; budget used {r['budget']['tokens_used']}")
    if r.get("fallback_reason"): print("  FALLBACK:", r["fallback_reason"])
    if g.get("rejected_llm_claims"): print("  REJECTED LLM CLAIMS:", g["rejected_llm_claims"])
    failed = [c for c in g["checks"] if not c["passed"]]
    if failed: print("  FAILED CHECKS:", failed)
    print("  A:", r["answer"][:700])
    for x in r["reasoning"][:4]: print("   -", x[:200])
