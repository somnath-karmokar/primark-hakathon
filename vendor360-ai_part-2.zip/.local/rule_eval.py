from app.database.session import session_scope
from app.services import analytics_service as a
from app.analytics.scoring import linear_slope
import pandas as pd
arch=pd.read_csv('../data/_archetypes.csv').set_index('vendor_id')['archetype']
with session_scope() as db:
    s=a.snapshots_df(db).sort_values('period')
    rows=[]
    for vid,g in s.groupby('vendor_id'):
        x=g.overall.tolist(); r=x[-6:]
        rows.append(dict(vid=vid,slope=linear_slope(r),c3=x[-1]-x[-4],drop=max(r)-x[-1],sm=(sum(x[-3:])/3)-(sum(x[-6:-3])/3),a=arch[vid]))
    d=pd.DataFrame(rows); truth=d.a.isin(['deteriorating','quality_deterioration'])
    rules={'cur':(d.slope<=-1)&((d.c3<=-8)|(d["drop"]>=8)),
           'c3&slope':(d.slope<=-1)&(d.c3<=-8),
           'smooth8':(d.sm<=-6)&(d.slope<=-1.0),
           'smooth8b':(d.sm<=-7)&(d.slope<=-1.5),
           'slope2':(d.slope<=-1.5)&(d["drop"]>=8)}
    for k,m in rules.items(): print(k, 'flagged',int(m.sum()),'TP',int((m&truth).sum()),'of',int(truth.sum()))
