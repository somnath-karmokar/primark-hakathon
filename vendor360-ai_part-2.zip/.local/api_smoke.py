import httpx, json, time, sys
B="http://127.0.0.1:8040/api/v1"
c=httpx.Client(timeout=120)
for i in range(60):
    try: c.get(B+"/health"); break
    except Exception: time.sleep(1)
def show(m,u,body=None):
    t=time.time(); r=c.request(m,B+u,json=body); d=r.json()
    s=json.dumps(d)[:180]
    print(f"{r.status_code} {m} {u} {int((time.time()-t)*1000)}ms  {s}")
    return d
h=show("GET","/health"); print(json.dumps(h["components"],indent=0)[:600])
show("GET","/meta/filters"); show("GET","/dashboard/summary"); show("GET","/dashboard/summary?category=CAT-DEN&region=East%20Asia")
show("GET","/vendors?search=ningbo&page_size=5"); show("GET","/vendors/V1024"); show("GET","/vendors/v1024/score")
show("GET","/vendors/V1024/trend"); show("GET","/vendors/V1024/risk"); show("GET","/vendors/V1024/recommendations")
show("GET","/vendors/V1024/alternatives"); show("GET","/vendors/V1024/relationships"); show("GET","/vendors/V9999")
show("GET","/vendors/DROP TABLE"); show("GET","/analytics/performance"); show("POST","/analytics/compare",{"vendor_ids":["V1024","V1112","V1001"]})
show("POST","/analytics/compare",{"vendor_ids":["V1024"]})
show("POST","/copilot/chat",{"message":"Why is Vendor V1024 underperforming?"})
show("GET","/knowledge/documents"); show("GET","/knowledge/documents/SEP"); show("GET","/knowledge/search?q=late%20delivery%20credit&document_type=sla")
show("GET","/governance/audit?limit=5"); show("GET","/governance/recommendations"); show("GET","/governance/model")
show("GET","/settings"); show("PUT","/settings",{"weights":{"delivery":0.5,"quality":0.5,"cost":0.2,"lead_time":0.2}})
show("GET","/risk-intel/events"); show("GET","/risk-intel/events/EXT-2026-101/impact"); show("GET","/tools")
