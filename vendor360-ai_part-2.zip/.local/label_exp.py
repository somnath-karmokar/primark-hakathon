from app.database.session import session_scope
from app.services import analytics_service as a
from app.ml.risk_model import build_feature_frame, FEATURES
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import roc_auc_score
import pandas as pd
with session_scope() as db:
    s=a.snapshots_df(db)
df=build_feature_frame(s)
g=df.groupby('vendor_id')
df['trail3']=g['overall'].transform(lambda x:x.rolling(3).mean())
df['fut3']=g['overall'].transform(lambda x:x[::-1].rolling(3).mean()[::-1].shift(-1))
for name,lab in {'drop8':(df.future_overall-df.overall)<=-8,
                 'smooth6':(df.fut3-df.trail3)<=-6,'smooth5':(df.fut3-df.trail3)<=-5}.items():
    d=df.assign(label=lab.astype(int)).dropna(subset=['change_3m','future_overall','fut3'])
    ps=sorted(d.period.unique()); tr=d[d.period.isin(ps[:-1])]; te=d[d.period==ps[-1]]
    m=GradientBoostingClassifier(n_estimators=200,max_depth=3,learning_rate=0.05,subsample=0.9,random_state=7).fit(tr[FEATURES].fillna(0),tr.label)
    p=m.predict_proba(te[FEATURES].fillna(0))[:,1]
    print(name,'pos',round(tr.label.mean(),3),round(te.label.mean(),3),'auc',round(roc_auc_score(te.label,p),3), 'periods',len(ps))
