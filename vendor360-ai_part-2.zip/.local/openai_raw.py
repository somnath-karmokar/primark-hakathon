import time, httpx
from app.config import get_settings
k = get_settings().openai_api_key
for url, body in [("https://api.openai.com/v1/models", None),
                  ("https://api.openai.com/v1/chat/completions", {"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "Say OK"}], "max_tokens": 5})]:
    t = time.time()
    try:
        r = httpx.request("POST" if body else "GET", url, json=body, headers={"Authorization": f"Bearer {k}"}, timeout=40)
        txt = r.text[:200].replace(k, "***")
        print(r.status_code, f"{int((time.time()-t)*1000)}ms", txt if r.status_code != 200 or body else "(models listed)")
    except Exception as e:
        print("ERROR", type(e).__name__, str(e)[:200], f"{int((time.time()-t)*1000)}ms")
