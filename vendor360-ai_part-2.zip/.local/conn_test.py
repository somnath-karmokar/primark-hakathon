import time
from pydantic import BaseModel
from app.config import get_settings
from app.llm.gateway import RequestBudget, structured_call
from app.graph import client
s = get_settings()
print("LLM configured:", s.llm_configured, "| provider:", s.llm_provider, "| model:", s.openai_model)

class Ping(BaseModel):
    answer: str
t = time.time()
out, rec = structured_call("summary", "Reply briefly.", "Say 'Vendor360 OK' in the answer field.", Ping, RequestBudget(3, 5000))
print("OpenAI:", rec.status, "|", rec.model, "|", f"{int((time.time()-t)*1000)}ms", "| tokens in/out", rec.prompt_tokens, rec.completion_tokens,
      "|", (out.answer if out else rec.reason))

print("Neo4j available:", client.is_available(force=True), client.status())
for q in ["MATCH (n) RETURN labels(n)[0] AS label, count(*) AS n ORDER BY n DESC",
          "MATCH ()-[r]->() RETURN type(r) AS rel, count(*) AS n ORDER BY n DESC",
          "MATCH (v:Vendor {vendor_id:'V1024'})-[:SUPPLIES]->(p:Product)-[:BELONGS_TO]->(c:Category) RETURN v.name AS vendor, collect(p.name) AS products, collect(DISTINCT c.name) AS cats"]:
    print(client.run(q))
