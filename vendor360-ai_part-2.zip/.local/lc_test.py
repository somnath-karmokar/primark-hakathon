import time, logging
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from app.config import get_settings
s = get_settings()
class Ping(BaseModel):
    answer: str
llm = ChatOpenAI(api_key=s.openai_api_key, model="gpt-4o-mini", timeout=60, max_retries=0)
for name, fn in [("plain", lambda: llm.invoke("Say OK").content),
                 ("structured", lambda: llm.with_structured_output(Ping, include_raw=True).invoke("Say OK in answer")["parsed"])]:
    t = time.time()
    try:
        print(name, fn(), f"{int((time.time()-t)*1000)}ms")
    except Exception as e:
        print(name, "ERROR", type(e).__name__, str(e)[:300], f"{int((time.time()-t)*1000)}ms")
