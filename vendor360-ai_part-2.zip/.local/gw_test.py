import time, faulthandler, sys
from pydantic import BaseModel
from app.config import get_settings
get_settings().llm_timeout_seconds = 90
from app.llm.gateway import RequestBudget, structured_call
class Ping(BaseModel):
    answer: str
faulthandler.dump_traceback_later(25, exit=False, file=sys.stderr)
t = time.time()
out, rec = structured_call("summary", "Reply briefly.", "Say OK in answer.", Ping, RequestBudget(3, 5000))
print(rec.status, rec.reason, int((time.time()-t)*1000), "ms", out)
