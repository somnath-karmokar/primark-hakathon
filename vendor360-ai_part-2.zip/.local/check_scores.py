from app.database.session import session_scope
from app.services import analytics_service as a, risk_service
import pandas as pd
pd.set_option('display.width',200)
with session_scope() as db:
    s=a.snapshots_df(db); cur=a.current_table(db)
    print(cur['band'].value_counts().to_dict())
    print(cur[['overall','delivery','quality','cost','lead_time']].describe().round(1).loc[['mean','std','min','50%']])
    for v in ['V1001','V1024','V1035','V1050','V1088','V1112','V1147','V1203','V1176']:
        g=s[s.vendor_id==v].sort_values('period')
        print(v, [round(x) for x in g.overall], 'D',[round(x) for x in g.delivery][-3:],'Q',[round(x) for x in g.quality][-3:],'C',[round(x) for x in g.cost][-3:],'L',[round(x) for x in g.lead_time][-3:], cur.set_index('vendor_id').loc[v,['risk_level','direction']].tolist())
    print(cur['direction'].value_counts().to_dict(), cur.groupby('risk_level').size().to_dict())
    rep=risk_service.model_report()
    print('pos rate',rep['positive_rate_train'],rep['positive_rate_test'],rep['metrics'],'base',rep['baseline_metrics'])
    arch=pd.read_csv('../data/_archetypes.csv'); m=cur.merge(arch,on='vendor_id')
    print(m.groupby('archetype')[['overall','delivery','quality','cost','lead_time']].mean().round(1))
    print(pd.crosstab(m.archetype, m.direction))
