import json
import time

from app.database.session import session_scope
from app.services import analytics_service as a

with session_scope() as db:
    t = time.time()
    d = a.dashboard_summary(db)
    print(round(time.time() - t, 1), "s")
    print(json.dumps(d["operational"], indent=1))
    print(json.dumps(a.vendor_commercials(db, "V1024"), indent=1))
    print("denim OTD:", a.dashboard_summary(db, category="CAT-DEN")["operational"]["on_time_delivery_pct"])
