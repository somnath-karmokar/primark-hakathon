import json, sys
from app.database.session import session_scope
from app.agents import copilot
qs = sys.argv[1:] or ["Which vendors are currently underperforming?", "Why is Vendor V1024 underperforming?",
      "What procurement action do you recommend?", "Find the best alternative supplier.", "What is the SLA for Vendor V1024?",
      "Which products depend on V1024?", "Which vendors have strong quality but weak delivery?", "What does our supplier SLA policy say?",
      "Which vendors deteriorated the most this month?", "tell me a joke", "Why is V9999 low?"]
sid = None
for q in qs:
    with session_scope() as db:
        try:
            r = copilot.ask(db, q, sid)
        except copilot.InputRejected as e:
            print("\n### Q:", q, "\nREJECTED:", e); continue
        sid = r["session_id"]
        print("\n### Q:", q, "| intent", r["intent"], "| vendor", r["vendor_id"], "| mode", r["mode"], "| conf", r["confidence"], r["governance"].get("status"), "|", r["latency_ms"], "ms")
        print("A:", r["answer"])
        for x in r["reasoning"]: print("  -", x)
        print("  trace:", " > ".join(f"{t['agent']}({t['duration_ms']}ms)" for t in r["agent_trace"]))
        print("  checks:", [(c["check"], c["passed"]) for c in r["governance"].get("checks", []) if not c["passed"]], "| guardrails", r["guardrails"])
        if r["recommendation"]: print("  rec:", r["recommendation"]["title"], r["recommendation"]["status"], [a["vendor_id"] for a in r["recommendation"]["alternatives"]])
