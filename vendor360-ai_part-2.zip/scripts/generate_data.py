"""Generate the Vendor360 AI synthetic procurement dataset.

Realistic, scenario-driven data - not uniform noise. Every vendor gets a latent
performance *archetype* (excellent, deteriorating, cheap-but-poor-quality,
lead-time-variable, ...) whose parameters drive the transactions. Some
archetypes drift over time so trends, deterioration detection and the risk
model have genuine signal to find.

Usage:  python scripts/generate_data.py [--vendors 500] [--seed 42] [--out data]
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass, field, replace
from datetime import date, timedelta
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
START = date(2025, 10, 1)
MONTHS = 12  # Oct 2025 .. Sep 2026 complete; Oct 2026 POs are still open
AS_OF = date(2026, 10, 12)

CATEGORIES = [
    # id, name, benchmark lead days (sea), products (name, benchmark unit cost GBP)
    ("CAT-WOM", "Womenswear", [("Jersey T-Shirt", 1.85), ("Midi Dress", 5.40), ("Knit Cardigan", 6.20), ("Wide-Leg Trousers", 4.90), ("Satin Blouse", 4.10), ("Puffer Jacket", 11.50)]),
    ("CAT-MEN", "Menswear", [("Crew Neck Tee", 1.70), ("Oxford Shirt", 4.60), ("Chino Trousers", 5.10), ("Hooded Sweatshirt", 5.80), ("Quilted Gilet", 8.90), ("Wool-Blend Coat", 16.40)]),
    ("CAT-KID", "Kidswear", [("Kids Pyjama Set", 2.90), ("School Polo", 1.60), ("Kids Joggers", 2.40), ("Baby Bodysuit 3pk", 2.70), ("Kids Rain Jacket", 5.30)]),
    ("CAT-DEN", "Denim", [("Skinny Jeans", 5.60), ("Straight Jeans", 5.90), ("Denim Jacket", 8.20), ("Denim Shorts", 3.80), ("Mom Jeans", 6.10)]),
    ("CAT-FTW", "Footwear", [("Canvas Trainer", 4.30), ("Chelsea Boot", 9.80), ("Slider", 1.40), ("Running Shoe", 7.90), ("Ballet Flat", 3.60)]),
    ("CAT-ACC", "Accessories", [("Tote Bag", 2.10), ("Knit Beanie", 0.95), ("Leather-Look Belt", 1.30), ("Sunglasses", 1.10), ("Crossbody Bag", 3.40)]),
    ("CAT-LIN", "Lingerie & Nightwear", [("Cotton Brief 5pk", 2.20), ("T-Shirt Bra", 2.80), ("Fleece Pyjamas", 4.40), ("Dressing Gown", 6.30)]),
    ("CAT-ACT", "Activewear", [("Sports Leggings", 3.30), ("Sports Bra", 2.60), ("Training Tee", 2.10), ("Track Jacket", 6.70)]),
    ("CAT-HOM", "Home", [("Cotton Towel Set", 4.80), ("Duvet Cover Set", 7.20), ("Scented Candle", 1.60), ("Cushion Cover", 1.90), ("Ceramic Mug", 0.85)]),
    ("CAT-BTY", "Beauty", [("Lip Gloss", 0.55), ("Makeup Brush Set", 1.70), ("Body Mist", 0.95), ("Nail Polish", 0.45)]),
]

COUNTRIES = [
    # country, region, port, share, base sea lead days, cities
    ("Bangladesh", "South Asia", "Chittagong", 0.25, 62, ["Dhaka", "Gazipur", "Narayanganj", "Chittagong", "Savar"]),
    ("China", "East Asia", "Ningbo-Zhoushan", 0.20, 48, ["Ningbo", "Guangzhou", "Shaoxing", "Qingdao", "Dongguan"]),
    ("India", "South Asia", "Nhava Sheva", 0.12, 52, ["Tiruppur", "Bengaluru", "Ludhiana", "Noida", "Chennai"]),
    ("Turkey", "Europe & Mediterranean", "Mersin", 0.10, 18, ["Istanbul", "Izmir", "Bursa", "Denizli"]),
    ("Cambodia", "South-East Asia", "Sihanoukville", 0.08, 55, ["Phnom Penh", "Kandal", "Kampong Speu"]),
    ("Vietnam", "South-East Asia", "Cat Lai (HCMC)", 0.07, 50, ["Ho Chi Minh City", "Hai Phong", "Binh Duong", "Dong Nai"]),
    ("Pakistan", "South Asia", "Karachi", 0.06, 45, ["Karachi", "Lahore", "Faisalabad", "Sialkot"]),
    ("Sri Lanka", "South Asia", "Colombo", 0.05, 44, ["Colombo", "Katunayake", "Kandy"]),
    ("Morocco", "Europe & Mediterranean", "Tanger Med", 0.03, 12, ["Tangier", "Casablanca"]),
    ("Portugal", "Europe & Mediterranean", "Leixoes", 0.02, 9, ["Porto", "Braga", "Guimaraes"]),
    ("United Kingdom", "UK & Ireland", "Felixstowe", 0.02, 6, ["Leicester", "Manchester", "Birmingham"]),
]

NAME_NOUNS = ["Apparel", "Garments", "Knitwear", "Textiles", "Fashions", "Clothing", "Exports", "Industries", "Manufacturing", "Sourcing", "Mills", "Composite"]
NAME_SUFFIX = {"Bangladesh": "Ltd", "China": "Co., Ltd", "India": "Pvt Ltd", "Turkey": "A.S.", "Cambodia": "Co., Ltd", "Vietnam": "JSC",
               "Pakistan": "(Pvt) Ltd", "Sri Lanka": "(Pvt) Ltd", "Morocco": "SARL", "Portugal": "Lda", "United Kingdom": "Ltd"}
NAME_PREFIX = ["Golden", "Evergreen", "Northstar", "Harbour", "Silverline", "Bluewave", "Summit", "Lotus", "Crescent", "Meridian",
               "Orchid", "Pioneer", "Riverside", "Sunrise", "Unity", "Zenith", "Coral", "Heritage", "Apex", "Pearl", "Delta", "Monsoon",
               "Atlas", "Cedar", "Falcon", "Kestrel", "Linden", "Marble", "Nova", "Oakridge", "Prism", "Saffron", "Tidewater", "Willow"]

REJECTION_REASONS = ["Stitching defect", "Measurement out of tolerance", "Colour shade variation", "Fabric flaw",
                     "Labelling / care label error", "Packaging damage", "Print / embellishment defect", "Trim & accessory defect"]


@dataclass
class Profile:
    otd: float          # probability a PO arrives on/before promised date
    delay: float        # mean days late when late
    defect: float       # defect rate in inspected sample
    fail: float         # probability an inspection fails AQL
    price: float        # unit price index vs category benchmark
    inv_var: float      # mean invoice over-billing vs PO value (fraction)
    lt_cv: float        # lead-time variability (coefficient of variation of early/late spread)
    reasons: list[float] = field(default_factory=lambda: [1.0] * len(REJECTION_REASONS))


ARCHETYPES: dict[str, Profile] = {
    "excellent":       Profile(0.965, 2.0, 0.007, 0.02, 1.00, 0.002, 0.045),
    "good":            Profile(0.90, 3.2, 0.015, 0.055, 1.02, 0.005, 0.085),
    "average":         Profile(0.83, 4.5, 0.024, 0.10, 1.03, 0.008, 0.13),
    "poor":            Profile(0.58, 10.0, 0.065, 0.30, 1.09, 0.025, 0.28),
    "expensive_quality": Profile(0.91, 3.0, 0.006, 0.02, 1.19, 0.012, 0.07),
    "cheap_poor_quality": Profile(0.86, 4.0, 0.062, 0.27, 0.86, 0.003, 0.10),
    "lt_variable":     Profile(0.84, 6.0, 0.015, 0.05, 1.00, 0.004, 0.34),
    "delivery_problem": Profile(0.60, 11.0, 0.014, 0.05, 1.01, 0.004, 0.12),
    "deteriorating":   Profile(0.95, 2.5, 0.010, 0.03, 1.00, 0.003, 0.05),
    "quality_deterioration": Profile(0.92, 3.0, 0.010, 0.03, 1.01, 0.004, 0.08),
}
ARCHETYPE_SHARE = {
    "excellent": 0.11, "good": 0.33, "average": 0.25, "poor": 0.06, "expensive_quality": 0.05,
    "cheap_poor_quality": 0.05, "lt_variable": 0.04, "delivery_problem": 0.04, "deteriorating": 0.04,
    "quality_deterioration": 0.03,
}

# Fixed demo vendors (spec section 33). Index = vendor number - 1001.
DEMO_VENDORS = {
    "V1001": dict(archetype="excellent", country="Bangladesh", category="CAT-WOM", tier="Strategic", name="Meridian Knit Composite Ltd"),
    "V1024": dict(archetype="deteriorating", country="China", category="CAT-DEN", tier="Strategic", name="Ningbo Bluewave Denim Co., Ltd", drift_start=3),
    "V1035": dict(archetype="quality_deterioration", country="Cambodia", category="CAT-KID", tier="Preferred", name="Lotus Kidswear Manufacturing Co., Ltd", drift_start=5),
    "V1050": dict(archetype="expensive_quality", country="Turkey", category="CAT-MEN", tier="Preferred", name="Bursa Heritage Textiles A.S."),
    "V1088": dict(archetype="lt_variable", country="India", category="CAT-FTW", tier="Approved", name="Chennai Pioneer Footwear Pvt Ltd"),
}
# Strong same-category alternatives for the demo vendors so recommendations are meaningful.
DEMO_ALTERNATIVES = {
    "V1112": dict(archetype="excellent", country="Vietnam", category="CAT-DEN", tier="Preferred", name="Saigon Summit Denim JSC"),
    "V1147": dict(archetype="good", country="Bangladesh", category="CAT-DEN", tier="Approved", name="Gazipur Indigo Mills Ltd"),
    "V1203": dict(archetype="excellent", country="Turkey", category="CAT-DEN", tier="Preferred", name="Izmir Atlas Denim A.S."),
    "V1176": dict(archetype="excellent", country="Sri Lanka", category="CAT-KID", tier="Preferred", name="Katunayake Unity Apparel (Pvt) Ltd"),
}


# Hand-tuned starting points so the demo story matches the brief (V1024: ~86 -> ~64).
DEMO_PROFILES = {
    "V1024": Profile(0.86, 4.0, 0.014, 0.045, 1.04, 0.007, 0.10),
}


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def profile_at(p: Profile, archetype: str, month: int, drift_start: int) -> Profile:
    """Time-varying behaviour for drifting archetypes."""
    if archetype == "deteriorating" and month >= drift_start:
        t = min(1.0, (month - drift_start + 1) / (MONTHS - 1 - drift_start))
        bad = ARCHETYPES["poor"]
        return replace(p, otd=lerp(p.otd, 0.45, t), delay=lerp(p.delay, 13.0, t), lt_cv=lerp(p.lt_cv, 0.38, t),
                       inv_var=lerp(p.inv_var, 0.032, t), price=lerp(p.price, 1.13, t),
                       defect=lerp(p.defect, 0.021, t), fail=lerp(p.fail, 0.09, t), reasons=bad.reasons)
    if archetype == "quality_deterioration" and month >= drift_start:
        t = min(1.0, (month - drift_start + 1) / (MONTHS - drift_start))
        return replace(p, defect=lerp(p.defect, 0.085, t), fail=lerp(p.fail, 0.42, t))
    return p


def jitter(rng: np.random.Generator, p: Profile) -> Profile:
    def j(v: float, s: float, lo: float, hi: float) -> float:
        return float(np.clip(v * rng.normal(1, s), lo, hi))
    reasons = rng.dirichlet(np.ones(len(REJECTION_REASONS)) * 0.8).tolist()
    return Profile(j(p.otd, 0.025, 0.4, 0.995), j(p.delay, 0.2, 1, 20), j(p.defect, 0.2, 0.002, 0.12), j(p.fail, 0.2, 0.0, 0.5),
                   j(p.price, 0.025, 0.8, 1.3), j(p.inv_var, 0.3, 0.0, 0.04), j(p.lt_cv, 0.15, 0.02, 0.5), reasons)


def month_start(m: int) -> date:
    y, mo = START.year + (START.month - 1 + m) // 12, (START.month - 1 + m) % 12 + 1
    return date(y, mo, 1)


def days_in_month(d: date) -> int:
    nxt = date(d.year + (d.month // 12), d.month % 12 + 1, 1)
    return (nxt - d).days


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def generate(n_vendors: int = 500, seed: int = 42, out: Path = ROOT / "data") -> dict[str, int]:
    rng = np.random.default_rng(seed)

    # --- categories & products -------------------------------------------
    categories, products = [], []
    for cid, cname, items in CATEGORIES:
        categories.append({"category_id": cid, "name": cname})
        for i, (pname, cost) in enumerate(items):
            for variant in ("Core", "Seasonal"):
                pid = f"P-{cid[4:]}-{i + 1:02d}{variant[0]}"
                products.append({"product_id": pid, "name": f"{pname} ({variant})", "category_id": cid,
                                 "benchmark_unit_cost": round(cost * (1.0 if variant == "Core" else 1.12), 2),
                                 "is_critical": variant == "Core" and i < 2})
    prod_by_cat: dict[str, list[dict]] = {}
    for p in products:
        prod_by_cat.setdefault(p["category_id"], []).append(p)

    # --- vendors -----------------------------------------------------------
    country_weights = np.array([c[3] for c in COUNTRIES]); country_weights /= country_weights.sum()
    arch_names = list(ARCHETYPE_SHARE); arch_w = np.array(list(ARCHETYPE_SHARE.values())); arch_w /= arch_w.sum()
    cat_ids = [c[0] for c in CATEGORIES]
    cat_w = np.array([0.18, 0.15, 0.12, 0.11, 0.09, 0.09, 0.08, 0.07, 0.07, 0.04]); cat_w /= cat_w.sum()
    fixed = {**DEMO_VENDORS, **DEMO_ALTERNATIVES}

    vendors, vendor_products, contracts = [], [], []
    latent: dict[str, tuple[Profile, str, int, dict]] = {}
    used_names: set[str] = set()
    for idx in range(n_vendors):
        vid = f"V{1001 + idx}"
        spec = fixed.get(vid, {})
        country = spec.get("country") or COUNTRIES[rng.choice(len(COUNTRIES), p=country_weights)][0]
        cinfo = next(c for c in COUNTRIES if c[0] == country)
        archetype = spec.get("archetype") or arch_names[rng.choice(len(arch_names), p=arch_w)]
        primary = spec.get("category") or cat_ids[rng.choice(len(cat_ids), p=cat_w)]
        tier = spec.get("tier") or rng.choice(["Strategic", "Preferred", "Approved"], p=[0.15, 0.4, 0.45])
        city = rng.choice(cinfo[5])
        name = spec.get("name")
        while not name or name in used_names:
            name = f"{rng.choice(NAME_PREFIX)} {city} {rng.choice(NAME_NOUNS)} {NAME_SUFFIX[country]}" if rng.random() < 0.5 \
                else f"{city} {rng.choice(NAME_PREFIX)} {rng.choice(NAME_NOUNS)} {NAME_SUFFIX[country]}"
        used_names.add(name)
        drift_start = int(spec.get("drift_start", rng.integers(4, 8)))
        size = {"Strategic": 9.0, "Preferred": 6.0, "Approved": 4.0}[tier] * float(rng.uniform(0.8, 1.25))
        profile = DEMO_PROFILES.get(vid) or (ARCHETYPES[archetype] if vid in fixed else jitter(rng, ARCHETYPES[archetype]))
        cats = [primary]
        if rng.random() < 0.35:
            cats.append(cat_ids[rng.choice(len(cat_ids), p=cat_w)])
        cats = list(dict.fromkeys(cats))
        supplied: list[dict] = []
        for c in cats:
            pool = prod_by_cat[c]
            k = int(min(len(pool), rng.integers(2, 6) if c == primary else rng.integers(1, 3)))
            supplied += [pool[i] for i in rng.choice(len(pool), size=k, replace=False)]
        status = "Active"
        onboard = START - timedelta(days=int(rng.integers(200, 3000)))
        vendors.append({
            "vendor_id": vid, "name": name, "country": country, "region": cinfo[1], "city": city, "port": cinfo[2],
            "primary_category_id": primary, "tier": tier, "status": status, "onboarded_date": onboard.isoformat(),
            "annual_capacity_units": int(size * 120_000 * rng.uniform(0.8, 1.2)),
            "sustainability_rating": rng.choice(["A", "B", "B", "C"]) if archetype not in ("poor", "cheap_poor_quality") else rng.choice(["B", "C", "C"]),
            "contact_email": f"accounts@{vid.lower()}.example.com",
        })
        for p in supplied:
            vendor_products.append({"vendor_id": vid, "product_id": p["product_id"], "category_id": p["category_id"],
                                    "is_primary_source": False})
        otd_target = {"Strategic": 95, "Preferred": 92, "Approved": 90}[tier]
        start = date(2024 + int(rng.integers(0, 2)), int(rng.integers(1, 13)), 1)
        contracts.append({
            "contract_id": f"C-{vid[1:]}", "vendor_id": vid, "contract_type": "Master Supply Agreement",
            "start_date": start.isoformat(), "end_date": date(start.year + 3, start.month, 1).isoformat(),
            "sla_id": f"SLA-{tier[:3].upper()}", "sla_otd_target_pct": otd_target, "sla_max_defect_rate_pct": 2.5 if tier != "Approved" else 3.0,
            "sla_max_invoice_variance_pct": 1.0, "payment_terms_days": int(rng.choice([60, 90, 120])),
            "penalty_clause": "Late delivery credit 1% of PO value per 7 days late, capped at 5%",
            "exclusivity": tier == "Strategic" and rng.random() < 0.3,
        })
        latent[vid] = (profile, archetype, drift_start, {"size": size, "lead": cinfo[4], "supplied": supplied})

    # Mark a single primary source per product (largest strategic supplier) -> dependency analysis
    by_product: dict[str, list[str]] = {}
    for vp in vendor_products:
        by_product.setdefault(vp["product_id"], []).append(vp["vendor_id"])
    tier_rank = {v["vendor_id"]: ({"Strategic": 3, "Preferred": 2, "Approved": 1}[v["tier"]], latent[v["vendor_id"]][3]["size"]) for v in vendors}
    primary_src = {pid: max(vids, key=lambda v: tier_rank[v]) for pid, vids in by_product.items()}
    for vp in vendor_products:
        vp["is_primary_source"] = primary_src[vp["product_id"]] == vp["vendor_id"]

    # --- transactions --------------------------------------------------------
    pos, deliveries, inspections, invoices, lead_times = [], [], [], [], []
    po_seq = del_seq = insp_seq = inv_seq = 0
    for v in vendors:
        vid = v["vendor_id"]
        base, archetype, drift_start, meta = latent[vid]
        for m in range(MONTHS + 1):  # final month = Oct 2026 (open POs only)
            ms = month_start(m)
            prof = profile_at(base, archetype, m, drift_start)
            n = int(rng.poisson(meta["size"] if m < MONTHS else meta["size"] * 0.4))
            if vid in fixed and m < MONTHS:
                n = max(n, 20)  # demo vendors: enough volume that their story is not sampling noise
            for _ in range(n):
                po_seq += 1
                po_id = f"PO-{260000 + po_seq}"
                day = int(rng.integers(0, days_in_month(ms) if m < MONTHS else 11))
                po_date = ms + timedelta(days=day)
                product = meta["supplied"][int(rng.integers(0, len(meta["supplied"])))]
                promised_days = int(max(5, round(meta["lead"] * rng.uniform(0.9, 1.15))))
                promised = po_date + timedelta(days=promised_days)
                qty = int(rng.choice([1200, 2400, 3600, 4800, 6000, 9600, 12000]) * rng.uniform(0.85, 1.15))
                unit_price = round(product["benchmark_unit_cost"] * prof.price * rng.normal(1, 0.02), 3)
                critical = bool(product["is_critical"] or rng.random() < 0.08)
                # Lead-time outcome
                on_time = rng.random() < prof.otd
                if on_time:
                    actual_days = promised_days - abs(rng.normal(0, prof.lt_cv * promised_days * 0.6))
                else:
                    actual_days = promised_days + 1 + rng.exponential(prof.delay)
                    actual_days += abs(rng.normal(0, prof.lt_cv * promised_days * 0.3))
                actual_days = int(max(3, round(actual_days)))
                final_date = po_date + timedelta(days=actual_days)
                delivered = final_date <= AS_OF
                pos.append({"po_id": po_id, "vendor_id": vid, "product_id": product["product_id"], "category_id": product["category_id"],
                            "po_date": po_date.isoformat(), "promised_date": promised.isoformat(), "quantity": qty,
                            "unit_price": unit_price, "expected_value": round(qty * unit_price, 2), "currency": "GBP",
                            "is_critical": critical, "status": "Delivered" if delivered else "Open"})
                if not delivered:
                    continue
                lead_times.append({"po_id": po_id, "vendor_id": vid, "promised_lead_days": promised_days,
                                   "actual_lead_days": actual_days, "variance_days": actual_days - promised_days})
                # 1-2 shipments; the last one defines PO completion
                splits = 2 if rng.random() < 0.45 else 1
                first_qty = int(qty * rng.uniform(0.55, 0.8)) if splits == 2 else qty
                ship_dates = [final_date - timedelta(days=int(rng.integers(2, 9))), final_date] if splits == 2 else [final_date]
                ship_qtys = [first_qty, qty - first_qty] if splits == 2 else [qty]
                for s, (sd, sq) in enumerate(zip(ship_dates, ship_qtys), start=1):
                    del_seq += 1
                    did = f"DL-{500000 + del_seq}"
                    days_late = (sd - promised).days
                    deliveries.append({"delivery_id": did, "po_id": po_id, "vendor_id": vid, "shipment_no": s,
                                       "delivered_date": sd.isoformat(), "promised_date": promised.isoformat(),
                                       "delivered_qty": sq, "days_late": max(0, days_late),
                                       "status": "late" if days_late > 0 else "on_time"})
                    if rng.random() < 0.72:
                        insp_seq += 1
                        sample = int(min(sq, rng.choice([200, 315, 500])))
                        defect_rate = float(np.clip(rng.normal(prof.defect, prof.defect * 0.25), 0, 0.4))
                        defects = int(rng.binomial(sample, defect_rate))
                        failed = rng.random() < prof.fail or (defects / sample) > 0.065
                        rejected = int(round(sample * rng.uniform(0.12, 0.3))) if failed else int(round(defects * rng.uniform(0.4, 0.85)))
                        reason = REJECTION_REASONS[int(rng.choice(len(REJECTION_REASONS), p=np.array(prof.reasons) / sum(prof.reasons)))] if defects or failed else ""
                        inspections.append({"inspection_id": f"QI-{700000 + insp_seq}", "delivery_id": did, "po_id": po_id, "vendor_id": vid,
                                            "category_id": product["category_id"], "inspection_date": (sd + timedelta(days=int(rng.integers(0, 3)))).isoformat(),
                                            "inspected_qty": sample, "defect_qty": defects, "rejected_qty": rejected,
                                            "result": "FAIL" if failed else "PASS", "rejection_reason": reason})
                inv_seq += 1
                var = rng.normal(prof.inv_var, 0.006)
                if rng.random() < 0.04:
                    var += rng.uniform(0.02, 0.06)  # occasional surcharge
                inv_value = round(qty * unit_price * (1 + var), 2)
                invoices.append({"invoice_id": f"INV-{900000 + inv_seq}", "po_id": po_id, "vendor_id": vid,
                                 "invoice_date": (final_date + timedelta(days=int(rng.integers(1, 15)))).isoformat(),
                                 "po_value": round(qty * unit_price, 2), "invoice_value": inv_value,
                                 "variance_amount": round(inv_value - qty * unit_price, 2),
                                 "status": "Disputed" if var > 0.025 else "Approved"})

    # Vendor status reflects the procurement team's existing actions on the worst cases.
    archetype_of = {vid: latent[vid][1] for vid in latent}
    for v in vendors:
        a = archetype_of[v["vendor_id"]]
        if a == "poor" and rng.random() < 0.5:
            v["status"] = "Under Review"
        elif a in ("delivery_problem", "cheap_poor_quality") and rng.random() < 0.25:
            v["status"] = "Probation"
        elif rng.random() < 0.02:
            v["status"] = "Onboarding"

    external_events = [
        {"event_id": "EXT-2026-101", "event_type": "logistics", "title": "Chittagong port congestion and berth delays",
         "description": "Container dwell times at Chittagong have risen to 9-12 days following labour action and yard congestion. Carriers are applying congestion surcharges.",
         "affected_countries": "Bangladesh", "affected_ports": "Chittagong", "severity": "high", "detected_at": "2026-10-10",
         "expected_duration_days": 21, "expected_delay_days": 10, "source": "Synthetic demo feed (logistics)"},
        {"event_id": "EXT-2026-102", "event_type": "weather", "title": "Cyclone watch - Bay of Bengal",
         "description": "Meteorological agencies forecast a deep depression intensifying into a cyclone within 5 days; factory closures and port suspensions possible.",
         "affected_countries": "Bangladesh;India;Sri Lanka", "affected_ports": "Chittagong;Colombo", "severity": "medium", "detected_at": "2026-10-11",
         "expected_duration_days": 7, "expected_delay_days": 5, "source": "Synthetic demo feed (weather)"},
        {"event_id": "EXT-2026-103", "event_type": "geopolitical", "title": "Red Sea transit diversions extended",
         "description": "Major carriers extend Cape of Good Hope routing for Asia-Europe services, adding 10-14 days transit to UK-bound sea freight.",
         "affected_countries": "China;Vietnam;Cambodia;Bangladesh;India;Pakistan;Sri Lanka", "affected_ports": "", "severity": "medium",
         "detected_at": "2026-10-06", "expected_duration_days": 60, "expected_delay_days": 12, "source": "Synthetic demo feed (geopolitical)"},
        {"event_id": "EXT-2026-104", "event_type": "regulatory", "title": "Turkey textile export documentation change",
         "description": "New origin-certificate requirements for textile exports take effect 1 November; first shipments may face customs holds.",
         "affected_countries": "Turkey", "affected_ports": "Mersin", "severity": "low", "detected_at": "2026-10-08",
         "expected_duration_days": 30, "expected_delay_days": 3, "source": "Synthetic demo feed (regulatory)"},
        {"event_id": "EXT-2026-105", "event_type": "economic", "title": "Industrial power rationing - Zhejiang province",
         "description": "Provincial grid operator announces rotating power cuts for textile mills over the next two weeks.",
         "affected_countries": "China", "affected_ports": "Ningbo-Zhoushan", "severity": "medium", "detected_at": "2026-10-09",
         "expected_duration_days": 14, "expected_delay_days": 6, "source": "Synthetic demo feed (economic)"},
    ]

    out.mkdir(parents=True, exist_ok=True)
    write_csv(out / "categories.csv", categories)
    write_csv(out / "products.csv", products)
    write_csv(out / "vendors.csv", vendors)
    write_csv(out / "vendor_products.csv", vendor_products)
    write_csv(out / "contracts.csv", contracts)
    write_csv(out / "purchase_orders.csv", pos)
    write_csv(out / "deliveries.csv", deliveries)
    write_csv(out / "quality_inspections.csv", inspections)
    write_csv(out / "invoices.csv", invoices)
    write_csv(out / "lead_times.csv", lead_times)
    write_csv(out / "external_events.csv", external_events)
    # Ground truth for documentation/tests only - never loaded into the app.
    write_csv(out / "_archetypes.csv", [{"vendor_id": k, "archetype": v[1], "drift_start_month": v[2]} for k, v in latent.items()])
    return {"vendors": len(vendors), "products": len(products), "purchase_orders": len(pos), "deliveries": len(deliveries),
            "quality_inspections": len(inspections), "invoices": len(invoices), "lead_times": len(lead_times)}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--vendors", type=int, default=500)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", type=Path, default=ROOT / "data")
    a = ap.parse_args()
    print(generate(a.vendors, a.seed, a.out))
