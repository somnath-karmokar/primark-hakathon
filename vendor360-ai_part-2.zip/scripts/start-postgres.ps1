# Starts a user-owned PostgreSQL 17 cluster on port 5433 (no admin rights, no Docker).
# First run initialises .local/pgdata with user/password vendor360 and creates the database.
param([string]$PgBin = "C:\Program Files\PostgreSQL\17\bin", [int]$Port = 5433)
$root = Split-Path -Parent $PSScriptRoot
$data = Join-Path $root ".local\pgdata"
New-Item -ItemType Directory -Force (Join-Path $root ".local") | Out-Null
if (-not (Test-Path (Join-Path $data "PG_VERSION"))) {
  $pw = Join-Path $root ".local\pwfile.txt"
  Set-Content -Path $pw -Value "vendor360" -Encoding ascii -NoNewline
  & "$PgBin\initdb.exe" -D $data -U vendor360 --pwfile=$pw -A scram-sha-256 -E UTF8 --locale=C | Out-Null
  Remove-Item $pw
  $created = $true
}
& "$PgBin\pg_ctl.exe" -D $data -l (Join-Path $root ".local\postgres.log") -o "-p $Port" -w start
if ($created) { $env:PGPASSWORD = "vendor360"; & "$PgBin\createdb.exe" -h localhost -p $Port -U vendor360 vendor360 }
