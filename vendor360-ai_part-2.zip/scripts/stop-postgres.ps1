param([string]$PgBin = "C:\Program Files\PostgreSQL\17\bin")
$root = Split-Path -Parent $PSScriptRoot
& "$PgBin\pg_ctl.exe" -D (Join-Path $root ".local\pgdata") stop
