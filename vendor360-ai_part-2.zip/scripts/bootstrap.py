"""One-shot setup: migrate DB, (re)generate data, seed, score, train risk model,
ingest the Neo4j graph and the ChromaDB knowledge base.

    backend/.venv/Scripts/python scripts/bootstrap.py            # everything
    backend/.venv/Scripts/python scripts/bootstrap.py --no-graph # skip Neo4j
    backend/.venv/Scripts/python scripts/bootstrap.py --regenerate --vendors 500
"""
from __future__ import annotations

import argparse
import json
import logging
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT / "scripts"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--regenerate", action="store_true", help="regenerate the synthetic CSVs first")
    ap.add_argument("--vendors", type=int, default=500)
    ap.add_argument("--no-graph", action="store_true")
    ap.add_argument("--no-knowledge", action="store_true")
    ap.add_argument("--graph-only", action="store_true")
    ap.add_argument("--knowledge-only", action="store_true")
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    if a.regenerate or not (ROOT / "data" / "vendors.csv").exists():
        from generate_data import generate
        print("generating synthetic data:", generate(a.vendors))

    from app.database.session import session_scope

    if a.knowledge_only:
        from app.knowledge import store
        print(json.dumps(store.ingest(), indent=2))
        return
    if a.graph_only:
        from app.graph.ingest import ingest
        with session_scope() as db:
            print(json.dumps(ingest(db), indent=2))
        return

    print("applying migrations ...")
    subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], cwd=ROOT / "backend", check=True)

    from app.services.pipeline import run_all
    with session_scope() as db:
        result = run_all(db, graph=not a.no_graph, knowledge=not a.no_knowledge)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
