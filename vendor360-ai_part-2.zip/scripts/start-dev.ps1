# Starts PostgreSQL (if needed), the FastAPI backend (:8040) and the React frontend (:5200).
param([switch]$Bootstrap)
$root = Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot "start-postgres.ps1") 2>$null
$py = Join-Path $root "backend\.venv\Scripts\python.exe"
if ($Bootstrap) { & $py (Join-Path $root "scripts\bootstrap.py") }
New-Item -ItemType Directory -Force (Join-Path $root ".local") | Out-Null
$env:PYTHONPATH = "."
Start-Process -FilePath $py -ArgumentList "-m","uvicorn","app.main:app","--host","127.0.0.1","--port","8040" `
  -WorkingDirectory (Join-Path $root "backend") -RedirectStandardOutput (Join-Path $root ".local\api.out.log") `
  -RedirectStandardError (Join-Path $root ".local\api.err.log") -WindowStyle Hidden
Start-Process -FilePath "cmd.exe" -ArgumentList "/c","npm run dev" -WorkingDirectory (Join-Path $root "frontend") -WindowStyle Minimized
Write-Host "API      http://127.0.0.1:8040/docs"
Write-Host "Frontend http://localhost:5200"
