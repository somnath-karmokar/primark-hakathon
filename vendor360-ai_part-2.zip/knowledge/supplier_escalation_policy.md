---
document_id: SEP
title: Supplier Escalation Policy
document_type: policy
category: all
policy_version: "2.2"
effective_date: 2026-03-01
source: Synthetic demo content - Vendor360 AI hackathon (not an official Primark document)
---
# Supplier Escalation Policy

## SEP-1 Purpose
Defines the graduated response when a supplier's performance does not meet contractual or policy expectations. Escalation must be proportionate, documented and evidence-based.

## SEP-2 Escalation stages
1. Stage 1 - Monitor: score in the Watch band or a single SLA breach. Category Manager monitors monthly.
2. Stage 2 - Corrective Action Request (CAR): SLA breach for two consecutive months or score deterioration of 8+ points. Supplier must respond within 5 working days.
3. Stage 3 - Performance Improvement Plan (PIP): score in the At Risk band or deterioration continuing after a CAR. 90-day PIP with monthly checkpoints.
4. Stage 4 - Probation and volume re-allocation: PIP milestones missed or score in the Critical band. Up to 30% of open volume may be re-allocated to qualified alternatives.
5. Stage 5 - Exit: sustained Critical performance or a zero-tolerance breach. Requires Sourcing Director and Ethical Trade approval.

## SEP-3 Responsible exit
Exits must follow responsible-sourcing principles: give reasonable notice, honour open purchase orders where possible and consider the impact on factory workers.

## SEP-4.1 Backup sourcing
When a supplier reaches Stage 2 or above for a critical product, the category team must identify at least one qualified backup supplier.

## SEP-4.2 Eligibility of alternative suppliers
An alternative supplier is eligible only if it is Active, has a Vendor Performance Score of 75 or higher (Good or Excellent), and does not carry High internal performance risk. Preference is given to suppliers already producing the same products.

## SEP-4.3 Volume transfer limits
Volume transferred to an alternative supplier must not exceed that supplier's available capacity, and must not breach the 35% concentration limit in the Procurement Policy (PP-3.3) without a risk assessment.

## SEP-5 Human approval
All Stage 3 and higher actions require human approval. AI recommendations may propose a stage but cannot execute it.
