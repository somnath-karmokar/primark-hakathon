---
document_id: CTG
title: Supplier Contract Guidelines
document_type: contract
category: all
policy_version: "3.3"
effective_date: 2025-12-01
source: Synthetic demo content - Vendor360 AI hackathon (not an official Primark document)
---
# Supplier Contract Guidelines

## CTG-1 Master Supply Agreement
Every supplier signs a Master Supply Agreement (MSA) of up to three years. The MSA references the applicable SLA tier (SLA-STR, SLA-PRE or SLA-APP) and incorporates the Product Quality Standards.

## CTG-2 Pricing and invoices
Invoices must match the purchase order price and quantity. Invoice variance above 1.0% of PO value requires buyer approval. Repeated unexplained over-billing is a contractual breach and is escalated under the Supplier Escalation Policy.

## CTG-3 Payment terms
Standard payment terms are 60, 90 or 120 days from invoice date, as agreed in the MSA.

## CTG-4 Penalties and credits
Late delivery credits follow the Delivery SLA Standard (DSLA-3). Quality rejections are at the supplier's cost, including re-inspection fees.

## CTG-5 Termination
Either party may terminate for convenience with 90 days' notice. Termination for cause is permitted after a failed Performance Improvement Plan or a zero-tolerance ethical breach. Exclusivity clauses must be reviewed before any volume re-allocation.

## CTG-6 Renewal
Contracts approaching renewal within 90 days should be reviewed against the supplier's latest Vendor Performance Score and trend.
