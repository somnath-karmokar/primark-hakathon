---
document_id: PP
title: Procurement Policy
document_type: policy
category: all
policy_version: "3.1"
effective_date: 2026-04-01
source: Synthetic demo content - Vendor360 AI hackathon (not an official Primark document)
---
# Procurement Policy

## PP-1 Purpose and scope
This policy governs how the sourcing and procurement function selects, contracts, measures and manages suppliers of finished goods (apparel, footwear, accessories, home and beauty) and related services. It applies to every buying category and every sourcing region.

## PP-2 Principles
Procurement decisions must be fair, evidence-based and documented. Supplier performance is measured using the Vendor Performance Score (VPS), a deterministic, auditable score built from delivery, quality, cost and lead-time consistency. Commercial decisions must never rely on unverified data or unsupported AI output.

## PP-3.1 Approved supplier list
Purchase orders may only be placed with suppliers whose status is Active or Onboarding. Suppliers with status Under Review or Probation may continue to fulfil existing purchase orders, but new purchase orders require Head of Sourcing approval.

## PP-3.2 Performance reviews
Every Strategic supplier receives a quarterly business review. Preferred suppliers receive a semi-annual review. Approved suppliers are reviewed annually or when their Vendor Performance Score falls below 60.

## PP-3.3 Supplier concentration
No single supplier should account for more than 35% of spend in a product category without a documented risk assessment.

## PP-3.4 Dual sourcing of critical products
Products flagged as critical (core, high-volume lines) must have at least two approved sources. Where a critical product depends on a single supplier, the category team must qualify a second source within 90 days.

## PP-4 Decision rights
| Decision | Approver |
|---|---|
| Place PO with Active supplier | Buyer |
| Initiate performance improvement plan | Category Manager |
| Move supplier to Probation | Head of Sourcing |
| Re-allocate more than 20% of a supplier's volume | Head of Sourcing |
| Exit a supplier relationship | Sourcing Director and Ethical Trade lead |

## PP-5 Use of AI decision support
AI-generated recommendations are advisory. Any recommendation to re-allocate volume, place a supplier on Probation, or exit a supplier requires human approval and must reference the underlying score evidence and policy clause. Recommendations with confidence below 0.70 must be reviewed by a Category Manager before any action.

## PP-6 Records
All score snapshots, recommendations and approvals must be retained in the audit log for seven years.
