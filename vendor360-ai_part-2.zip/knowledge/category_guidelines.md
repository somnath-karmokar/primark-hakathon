---
document_id: CG
title: Category Sourcing Guidelines
document_type: guideline
category: multiple
policy_version: "2.0"
effective_date: 2026-01-01
source: Synthetic demo content - Vendor360 AI hackathon (not an official Primark document)
---
# Category Sourcing Guidelines

## CG-1 Denim
Denim lines depend on wash and finishing capacity. Lead-time consistency is weighted heavily in denim sourcing decisions because finishing bottlenecks cause variable lead times. Keep at least two sources for every core jean fit. Typical sea-freight lead time from East Asia is 45-55 days.

## CG-2 Kidswear
Kidswear suppliers must meet the additional children's safety testing in Quality Standards QS-5. Quality performance takes precedence over cost in kidswear decisions; a supplier with a deteriorating quality score must not receive new kidswear styles until corrective actions are verified.

## CG-3 Womenswear and Menswear
Fashion womenswear and menswear lines are trend-sensitive; on-time delivery against the in-store launch date is the critical success factor. Suppliers with repeated late delivery should be moved to core continuity lines rather than trend lines.

## CG-4 Footwear
Footwear lead times vary with sole and component sourcing. Suppliers with a lead-time coefficient of variation above 0.20 must provide component buffer-stock plans.

## CG-5 Home and Beauty
Home and beauty products carry regulatory requirements (cosmetics safety, electrical and fire safety). Cost competitiveness is important, but compliance documentation is mandatory before shipment.

## CG-6 Category benchmarks
Unit cost benchmarks are maintained per product and reviewed quarterly. A supplier priced more than 10% above benchmark should be challenged in the next negotiation round unless a documented quality premium justifies it.
